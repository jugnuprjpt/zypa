import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  useIonPopover,
  useIonViewWillEnter
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router';
import CallFor from '../../util/CallFor';
import userLogo from '../../assets/img/user-profile-placeholder.png';
import { close, ellipsisVertical } from 'ionicons/icons';
import { Link } from 'react-router-dom';
import SkeletonComonViewAll from '../common/skeleton/SkeletonComonViewAll';
import CommonGridList from '../common/CommonGridList';
import { setLocalStore } from '../../util/Common';
import { useTranslation } from 'react-i18next';

const TeamMember = (props: any) => {
  const { t } = useTranslation();
  useEffect(() => {
    getTeamMember();
  }, []);
  const history = useHistory();
  const { companyId } = useParams();
  const encodedString = (str) => {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
      return String.fromCharCode(parseInt(p1, 16));
    }));
  };
  const encodedCompanyName = encodedString(props.companyName);
  const admin = () => {
    dismiss();
    setLocalStore('companyOwner', encodedString(props.aboutDetails.owner).replace('/', '&quot;'));
    setLocalStore('companyAdmin', encodedString(props.aboutDetails.admin).replace('/', '&quot;'));
    history.push('/manageCompanyTeam/' + companyId + '/' + encodedCompanyName.replace('/', '&quot;'));
  };
  // const memberinvite = () => {
  //   dismiss();
  //   history.push('/memberinvite/' + companyId + '/' + encodedCompanyName.replace('/', '&quot;'));
  // };
  const [showModal, setShowModal] = useState(false);
  const [count, setCount] = useState(0);
  const [scrollData, setScrollData] = useState<object[]>([]);
  const [teamMember, setTeamMember] = useState<object[]>([]);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [loading, setLoading] = useState(false);
  // const [disableInfiniteScroll, setDisableInfiniteScroll] = useState<boolean>(false);
  // let count = 0;
  const getTeamMember = async() => {
    setLoading(true);
    const stateres = await CallFor('api/v1.1/companies/' + companyId + '/ALL', 'POST', '{"page": 0 }', 'Auth');
    if (stateres.status === 200) {
      const json1Response = await stateres.json();
      if (json1Response.data.content !== null) {
        setScrollData([...scrollData, ...json1Response.data.content]);
        setTeamMember([...teamMember, ...json1Response.data.content]);
      }
      // setCount(count + 1);
    } else if (stateres.status === 401) {
    //   setDisableInfiniteScroll(true);
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
    setCount(1);
  };
  const getTeamMemberOnScroll = async() => {
    const stateres = await CallFor('api/v1.1/companies/' + companyId + '/ALL', 'POST', '{"page": ' + count + '}', 'Auth');
    if (stateres.status === 200) {
      const json1Response = await stateres.json();
      if (json1Response.data.content.length > 0) {
        setScrollData([...scrollData, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (stateres.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  useIonViewWillEnter(async() => {
    getTeamMemberOnScroll();
  });

  function searchNext(ev: any) {
    setTimeout(() => {
      getTeamMemberOnScroll();
      ev.target.complete();
    }, 500);
  }
  const viewPaginaction = () => {
    setShowModal(true);
    getTeamMemberOnScroll();
  };
  const closemodel = () => {
    setCount(1);
    setShowModal(false);
    setScrollData(teamMember);
    setInfiniteDisabled(false);
  };
  // for mobile
  const PopoverList: React.FC<{
    onHide: () => void
  }> = ({ onHide }) => (
    <><IonList className="my-account-pr">
      {/* <IonButton fill="clear" onClick={memberinvite} className="link-btn-tx">
        Add Team Member1
      </IonButton> */}
    </IonList><IonList className="my-account-pr">
        <IonButton fill="clear" onClick={() =>{onHide(); admin()}} className="link-btn-tx">
                   {t('appproperties.text191')}
        </IonButton>
      </IonList></>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });// for mobile
  return (
    <>
    <IonCard className="MuiPaper-rounded ion-margin-top ion-margin-bottom ion-padding ion-no-margin follower-list-card shadow-none mt-0">
    <IonHeader className="profile-header ion-no-border head-title-con">
      <div className='left-col-cn'>
       {/* <h4>{t('teamproperties.text1')}</h4> */}
      </div>
       {(() => {
         if (props.aboutDetails.admin === true) {
           //  if (profileDetail.companies.includes(companyId)) {
           return (
            <><div className='right-col-cn gup-btn-action dn-mobile'>
                 {/* <Link to={'/memberinvite/' + companyId + '/' + encodedCompanyName.replace('/', '&quot;')} className="link-btn-tx">
                   Add Team Member1
                 </Link> */}
                 {/* <Link to={'/manageCompanyTeam/' + companyId + '/' + encodedCompanyName.replace('/', '&quot;')} className="link-btn-tx">
                   Manage Team
                 </Link> */}
                 <div className="link-btn-tx cursor-pointer" onClick={admin}>
                   {t('appproperties.text191')}
                 </div>
                 {teamMember.length >= 20
                   ? <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
                   {t('commonproperties.text3')}
                 </div>
                   : ''}
               </div>
               {/* for mobile */}
               <div className="dot-btn show-mobile team-member-dot">
                   <IonIcon
                     icon={ellipsisVertical}
                     slot="start"
                     className="test report cursor-pointer"
                     onClick={(e) => present({ event: e.nativeEvent })} />
                 </div>
                 {/* for mobile */}
                 </>
           );
           //  }
         } else {
           return (
         <div className='right-col-cn gup-btn-action dn-mobile'>
            {teamMember.length >= 20
              ? <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
                {t('commonproperties.text3')}
                 </div>
              : ''}
       </div>);
         }
       })()}
     </IonHeader>
        <IonRow className="ion-padding-top ptm-0 member-listing">
        {teamMember.length > 0
          ? <>
          {teamMember.map((detail, i) => (
            <CommonGridList key={i} id={detail.id} defultImage={userLogo} img={detail.profileImg} name={detail.firstName + ' ' + detail.lastName}
              subString={detail.profileTitle} dots={false} redirectLink='profile' />
          ))}
          </>
          : loading
            ? <>
          <SkeletonComonViewAll column={4} sizeMd={3} sizeXs={12} name={true} title={true} distription={true} link={false} />
        </>
            : <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">Team member not available</p>
              }
        </IonRow>
        {teamMember.length >= 8
          ? <div className='right-col-cn gup-btn-action view-all-mobile'>
            <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
            {t('commonproperties.text3')}
            </div>
       </div>
          : ''}
      </IonCard>
      <IonModal isOpen={showModal} cssClass="team-list-modal" onDidDismiss={() => closemodel()}>
         <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">{t('commonproperties.text3')}</IonLabel>
            <div
              onClick={closemodel}
              className="close ion-no-padding"
            >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 cursor-pointer"
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <IonContent>
          <div className="modal-body">
          <div className="no-footer">
             <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom member-listing">
        {!loading
          ? <>
            {scrollData.map((detail, i) => (
              <CommonGridList key={i} id={detail.id} defultImage={userLogo} img={detail.profileImg} name={detail.firstName + ' ' + detail.lastName}
                subString={detail.profileTitle} dots={false} redirectLink='profile'/>
            ))}
            </>
          : <SkeletonComonViewAll column={8} sizeMd={3} sizeXs={6} name={true} title={true} distription={true} link={false} />
                }
            </IonRow>
            <div className='d-flex ion-justify-content-center'>
              <IonInfiniteScroll
                onIonInfinite={searchNext}
                threshold="100px"
                disabled={isInfiniteDisabled}
              >
                <IonInfiniteScrollContent
                  loadingSpinner="circular"
                  loadingText={t('appproperties.text215')}
                ></IonInfiniteScrollContent>
              </IonInfiniteScroll>
            </div>
          </div>
          </div>
        </IonContent>
      </IonModal>
    </>
  );
};
export default TeamMember;
