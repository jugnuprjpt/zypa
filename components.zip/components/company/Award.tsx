/* eslint-disable react/jsx-key */
/* eslint-disable multiline-ternary */
/* eslint-disable no-return-assign */
import {
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  IonTextarea,
  useIonPopover,
  useIonViewWillEnter
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import CallFor from '../../util/CallFor';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import { add, close, ellipsisVertical, imageOutline, trashBinOutline } from 'ionicons/icons';
import awardimg from '../../assets/img/award.jpeg';
import { useForm } from 'react-hook-form';
import { useHistory, useParams } from 'react-router';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import AwardDetail from './AwardDetail';
import edit from '../../assets/img/edit.svg';
import EditAward from './EditAward';
// import SwiperCore, {
//   Navigation
// } from 'swiper/core';
import SkeletonAward from '../common/skeleton/SkeletonAward';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import { useTranslation } from 'react-i18next';
// SwiperCore.use([Navigation]);
const Award = (props: any) => {
  const { t } = useTranslation();
  const { companyId } = useParams();
  const profileDetail = useSelector(getProfileDetails);
  const history = useHistory();
  const [formState, setformState] = useState({ companyId: companyId });
  const [editFromshow, seteditFromShow] = useState(false);
  const [awardDetailShowModal, setAwardDetailShowModal] = useState(false);
  const [createDisabled, setCreateDisabled] = useState(false);
  const [isValid, setIsValid] = useState(true);
  const [allAwardModal, setAllAwardModal] = useState(false);
  const [scrollData, setScrollData] = useState<object[]>([]);
  const [loading, setLoading] = useState(false);
  const [count, setCount] = useState(0);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [EditAwardModal, setEditAwardModal] = useState(false);
  const [awardId, setAwardId] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [file, setAwardFile] = useState('');
  const [characterCount, setCharacterCount] = useState(0);
  const maxCount = 250;
  const formDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined && event.target.value.length > 0) {
      event.target.classList.add('input-fill');
    } else {
      event.target.classList.remove('input-fill');
    }
    setformState({ ...formState, [event.target.name]: event.target.value });
  };
  const [award, setAwardDetail] = useState([]);
  useEffect(() => {
    getAwardDetail();
  }, []);
  const getAwardDetail = async () => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/company/awards/' + companyId,
      'post',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setAwardDetail(json1Response.data.content);
        if (scrollData.length > 0) {
          setScrollData(json1Response.data.content);
          setCount(1);
        }
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const getAwardListOnScroll = async () => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/company/awards/' + companyId,
      'post',
      '{"page": ' + count + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setScrollData([...scrollData, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const uploadCompanylogoHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const input = document.getElementById('awardDisable');
      input.classList.add('postDisable');
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setIsValid(false);
        setError('awardlogo', {
          type: 'required',
          message: t('commonproperties.text1')
        });
      } else {
        if (event.target.files[0].size > 3145728) {
          setIsValid(false);
          setError('awardlogo', {
            type: 'required',
            message: t('commonproperties.text2')
          });
        } else {
          clearErrors('awardlogo');
          setIsValid(true);
        }
      }
      setAwardFile(file1);
    }
  };
  const validationSchema = Yup.object().shape({
    title: Yup.string().trim()
      .required(t('awardproperties.text5'))
      .min(10, t('awardproperties.text6'))
      .max(100, t('userproperties.text15')),
    description: Yup.string().trim()
      .required(t('signuprecommendation.text31'))
      .min(10, t('awardproperties.text6'))
      .max(250, t('awardproperties.text9'))
  });
  const openModelWithClearState = () => {
    setShowModal(true);
    clearErrors();
    setformState({ companyId: companyId });
    setAwardFile('');
    setCreateDisabled(false);
    dismiss();
  };
  const {
    register,
    handleSubmit,
    clearErrors,
    setError,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });
  const testHandler = () => {
    const awardPhoto = document.getElementById('awardlogo');
    let isUserLogoValid = true;
    if (awardPhoto.files[0] !== undefined && awardPhoto.files[0] !== '') {
      if (awardPhoto.files[0].size > 3145728) {
        setError('awardlogo', {
          type: 'required',
          message: t('commonproperties.text2')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
      if (!awardPhoto.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('awardlogo', {
          type: 'required',
          message: t('companyproperties.text34')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
    }

    if (isUserLogoValid) {
      setIsValid(true);
      return true;
    } else {
      setIsValid(false);
      return false;
    }
  };
  const submitHandler = async (event: any) => {
    if (testHandler() && isValid) {
      setCreateDisabled(true);
      //   const awardData =
      // '{"companyId":"' +
      // formState.companyId +
      // '","title":"' +
      // formState.title +
      // '","description":"' +
      // encodeURIComponent(formState.description).replaceAll('%0A', '\\n') +
      // '"}';
      const awardProfile = document.getElementById('awardlogo');
      const data = new FormData();
      data.append('logo', awardProfile.files[0]);
      // data.append('awardDto', awardData);
      let awardTitle = '';
      let awardDescription = '';

      if (formState.title !== undefined && formState.title !== null) {
        awardTitle = formState.title.trim();
        formState.title = awardTitle;
      }
      if (formState.description !== undefined && formState.description !== null) {
        awardDescription = formState.description.trim();
        formState.description = awardDescription;
      }

      data.append('awardDto', JSON.stringify(formState));

      const response = await CallFor(
        'api/v1.1/awards',
        'POST',
        data,
        'authWithoutContentType'
      );
      if (response.status === 201) {
        setShowModal(false);
        getAwardDetail();
      } else if (response.status === 400) {
        const datares = await response.json();
        setCreateDisabled(false);
        datares.error.errors.map((details) => {
          setError(details.field, {
            type: 'server',
            message: details.message
          });
        });
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else {
        setCreateDisabled(false);
      }
    }
  };
  const awardDetailsHandler = (id) => {
    seteditFromShow(false);
    setAllAwardModal(false);
    if (scrollData.length > 0) {
      const filteredData = scrollData.filter((item) => {
        return Object.values(item).join('').toLowerCase().includes(id);
      });
      setformState(filteredData[0]);
    } else {
      const filteredData1 = award.filter((item) => {
        return Object.values(item).join('').toLowerCase().includes(id);
      });
      setformState(filteredData1[0]);
    }
    // const filteredData = award.filter((item) => {
    //   return Object.values(item).join('').toLowerCase().includes(id);
    // });

    setAwardDetailShowModal(true);
  };
  const open = (id) => {
    setEditAwardModal(true);
    setAllAwardModal(false);
    setAwardId(id);
  };
  const deleteImg = () => {
    setAwardFile('');
    document.getElementById('awardlogo').value = '';
    clearErrors('awardlogo');
    const input = document.getElementById('awardDisable');
    input.classList.remove('postDisable');
  };
  const viewAwardHandler = () => {
    setAllAwardModal(true);
    getAwardListOnScroll();
  };
  const closeViewAll = () => {
    setCount(1);
    setAllAwardModal(false);
    setScrollData(award);
    setInfiniteDisabled(false);
  };
  useIonViewWillEnter(async () => {
    getAwardListOnScroll();
  });
  function searchNext(ev: any) {
    setTimeout(() => {
      getAwardListOnScroll();
      ev.target.complete();
    }, 500);
  }
  // for mobile
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonContent>
      <IonList className="my-account-pr">
        <IonButton fill="clear" onClick={() =>{onHide(); openModelWithClearState()}} className="link-btn-tx">
          + {t('awardproperties.text1')} &amp;  {t('awardproperties.text2')}
        </IonButton>
      </IonList>
    </IonContent>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });// for mobile
  const descriptionChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setformState({
        ...formState,
        description: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };

  const textMethod = (text) => {
    let stringvalue = '';
    if (text !== undefined && text !== null) {
      if (text.length > 100) {
        let msg = text.slice(0, 101);
        for (let i = 101; i < text.length; i++) {
          if (text.charAt(i) !== ' ') {
            msg += text.charAt(i);
          } else {
            break;
          }
        }
        stringvalue = msg;
      } else {
        stringvalue = text.slice(0, text.length);
      }
    }

    return stringvalue;
  };

  return (
    <>
      <IonCard className="MuiPaper-rounded ion-margin-top ion-margin-bottom ion-padding-horizontal ion-no-padding ion-padding-top ion-padding-bottom ion-no-margin follower-list-card shadow-none mt-0">
        <IonHeader className="profile-header ion-no-border head-title-con">
          <div className='left-col-cn'>
            {/* <h4>
            {t('appproperties.text182')}
            </h4> */}
          </div>
          {(() => {
            if (props.aboutDetails.admin === true) {
              // if (profileDetail.companies.includes(companyId)) {
              return (
                <><div className='right-col-cn dn-mobile'>
                  <div onClick={openModelWithClearState} className="link-btn-tx cursor-pointer">
                    <IonIcon icon={add} className="ion-text-center" /> {t('awardproperties.text1')} &amp; {t('awardproperties.text2')}
                  </div>
                </div>
                  {/* for mobile */}
                  {/* <div className="dot-btn show-mobile">
                    <IonIcon
                      icon={ellipsisVertical}
                      slot="start"
                      className="test report cursor-pointer"
                      onClick={(e) => {
                        if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                          present({ event: e.nativeEvent });
                        } else {
                          // history.push('/addnewcompany');
                          setLoginModal(true);
                        }
                      }}
                    />
                  </div> */}
                  {/* for mobile */}</>
              );
              // }
            }
          })()}
        </IonHeader>
        {award.length > 0 ? (
          <IonRow className="award-slider-aw product-slider-cn award-slider-custom">
            <IonCol size="12" className=''>
              <Swiper
                navigation={true}
                id="ka-swiper2"
                pagination={{
                  clickable: true
                }}
                className="mySwiper"
                autoHeight={true}
                breakpoints={{
                  320: {
                    width: 330,
                    slidesPerView: 1.4
                  },
                  640: {
                    width: 500,
                    slidesPerView: 1.4
                  },
                  768: {
                    width: 768,
                    slidesPerView: 3
                  }
                }}
              >
                {award.map((detail) => (
                  <>
                    {' '}
                    <SwiperSlide>
                      <IonCard className='no-shadow award-width'>
                        <div className="">
                          {(() => {
                            if (props.aboutDetails.owner || props.aboutDetails.admin) {
                              // if (profileDetail.companies.includes(companyId)) {
                              return (
                                <span className='edit-award-icon'>
                                  <div onClick={() => open(detail.id)}>
                                    <IonIcon
                                      icon={edit}
                                      className="ion-button-color pr-0 cursor-pointer"
                                      slot="start"
                                      size="undefined"
                                    />
                                  </div>
                                </span>);
                              // }
                            }
                          })()}
                          <div className='cursor-pointer text-center w-100' onClick={() => awardDetailsHandler(detail.id)}>

                            {detail.img === null || detail.img === ''
                              ? (
                                <div className='awardimg' style={{ background: 'url(' + awardimg + ')' }}></div>
                              )
                              : (
                                <div className='awardimg' style={{ background: 'url(' + detail.img + ')' }}></div>
                              )}

                            <IonCardTitle>
                              <p className='title fixed-textline mb-2'>{detail.title}</p>
                              <p className="description">
                                {detail.description.length >= 100
                                  ? <>{textMethod(detail.description) + '...'}<a className="readmore" onClick={() => awardDetailsHandler(detail.id)}> {t('commonproperties.text29')}</a></>
                                  : (detail.description)}
                              </p>
                            </IonCardTitle>
                          </div>
                        </div>
                      </IonCard>
                    </SwiperSlide>
                  </>
                ))}
                {award.length >= 5
                  ? <SwiperSlide>
                    <IonCard
                      className="MuiPaper-rounded ion-padding viewAll-swipe-slider"
                      onClick={viewAwardHandler}
                    >
                     {t('commonproperties.text3')}
                    </IonCard>
                  </SwiperSlide> : ''}
              </Swiper>
            </IonCol>
          </IonRow>
        ) : (
          loading ? <SkeletonAward column={3} />
            : (props.aboutDetails.admin === true
              ? <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text18')}
              </p>
              : <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text51')}
              </p>
            )

        )}
        {awardDetailShowModal
          ? <AwardDetail setAwardDetailShowModal={setAwardDetailShowModal} awardDetailShowModal={awardDetailShowModal}
            seteditFromShow={seteditFromShow} editFromshow={editFromshow} formState={formState} companyId={companyId} />
          : ''
        }
        {EditAwardModal
          ? <EditAward
            setEditAwardModal={setEditAwardModal}
            EditAwardModal={EditAwardModal}
            awardId={awardId}
            setAwardDetail={setAwardDetail}
            award={award}
            setScrollData={setScrollData}
            scrollData={scrollData} />
          : ''
        }
      </IonCard>
      <IonModal isOpen={showModal} cssClass="createGroupModal" onDidDismiss={() => { setShowModal(false); setCharacterCount(0); }}>
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">
              {t('awardproperties.text1')} &amp; {t('awardproperties.text2')}
            </IonLabel>
            <div onClick={() => { setShowModal(false); setCharacterCount(0); }} className="close ion-no-padding">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 cursor-pointer"
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <div className='modal-body'>
            <form
              data-testid="form-submit"
              noValidate
              autoComplete="off"
              onSubmit={handleSubmit(submitHandler, testHandler)}
              className="h-100"
            >
              <div className="body-content">
                <IonRow className="ion-padding-horizontal">
                  <IonCol size-md="12" size-xs="12" className='input-label-box'>
                    <IonItem
                      className={
                        errors.title
                          ? 'error-border form-group input-label-box position-relative w-full pt-0 mb-0'
                          : 'form-group input-label-box position-relative w-full pt-0 mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('appproperties.text189')} <sup>*</sup></IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box w-full'
                        data-testid="title"
                        placeholder=""
                        id="title"
                        value={formState.title}
                        onIonChange={formDataChangeHandler}
                        {...register('title')}
                      />
                    </IonItem>
                    <p className={errors.title ? 'error' : ''}>
                      {errors.title?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="12" size-xs="12" className='input-label-box mb-0'>
                    <IonItem
                      className={
                        errors.description
                          ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                          : 'form-group input-label-box position-relative pt-0 mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('commonproperties.text39')} <sup>*</sup></IonLabel>
                      <IonTextarea
                        className='input-box'
                        data-testid="description"
                        onIonChange={descriptionChangeHandler}
                        rows={4}
                        value={formState.description}
                        id="description"
                        {...register('description')}
                        maxlength={250}
                      />
                    </IonItem>
                    <p className={errors.description ? 'error' : ''}>
                      {errors.description?.message}
                    </p>
                    <p className='text-grey text-end font-14'>{characterCount}/{maxCount}</p>
                  </IonCol>
                </IonRow>
                <IonRow className='ion-padding-horizontal'>
                  <IonCol size-md="12" sizeXs="12" id='awardDisable' className='input-label-box'>
                    <IonItem className='form-group input-label-box position-relative mb-0'>
                      <input
                        type="file"
                        color="primary"
                        onChange={uploadCompanylogoHandleChange}
                        id="awardlogo"
                        accept="image/png, image/jpg, image/jpeg"
                        className="upload ion-padding-start"
                        disabled={file}
                      />
                      <label
                        htmlFor="awardlogo"
                        className="input-box upload-img-control cursor-pointer d-flex align-items-center color-grey mb-0 ps-0 mt-2"
                      >
                        <IonIcon
                          icon={imageOutline}
                          className="ion-button-color pr-0 me-2 color-grey font-22"
                          slot="start"
                          size="undefined"
                        />{' '}
                        <span className='color-grey'>{t('awardproperties.text4')}</span>
                      </label>
                    </IonItem>
                  </IonCol>
                  {file ? (
                    <IonCol size-md="12" sizeXs="12">
                      <div className="addPhoto-editor award-pic">
                        <IonList>
                          <>
                            <IonItem lines="none" className="ion-no-padding">
                              <img src={file} />
                              <span className="icon" onClick={deleteImg}>
                                <IonIcon icon={trashBinOutline} />
                              </span>
                            </IonItem>
                          </>
                        </IonList>
                      </div>
                      <div className='error ion-text-left w-100'>
                        {errors.awardlogo?.message}
                      </div>
                    </IonCol>
                  ) : (
                    ''
                  )}
                </IonRow>
              </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
                <IonRow>
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto pr-0"
                    type="submit"
                    size="small"
                    disabled={createDisabled}
                  >
                    {t('awardproperties.text1')} &amp; {t('awardproperties.text2')}
                    {createDisabled
                      ? <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                      : ''
                    }
                  </IonButton>
                </IonRow>
              </IonFooter>
            </form>
          </div>
        </IonContent>
      </IonModal>
      <IonModal isOpen={allAwardModal} cssClass="pageModel viewAllAward" onDidDismiss={() => { setAllAwardModal(false); closeViewAll(); }}>
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">{t('awardproperties.text10')}</IonLabel>
            <div
              onClick={closeViewAll}
              className="close ion-no-padding cursor-pointer"
            >
              <IonIcon
                icon={close}
                className="ion-button-color "
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <IonContent>
          <div className="modal-body company-award">
            <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom">
              {scrollData.length > 0
                ? (
                  scrollData.map((detail) => (
                    <IonCol sizeMd="4" sizeSm="4" sizeXs="6" className='equal-modal-child'>
                      <div className="box-group ion-no-padding group-team-center gp-mamber-box w-100">
                        {(() => {
                          if (props.aboutDetails.admin === true) {
                            // if (profileDetail.companies.includes(companyId)) {
                            return (
                              <span className='edit-award-icon'>
                                <div onClick={() => open(detail.id)}>
                                  <IonIcon
                                    icon={edit}
                                    className="ion-button-color pr-0 cursor-pointer"
                                    slot="start"
                                    size="undefined"
                                  />
                                </div>
                              </span>);
                          }
                          // }
                        })()}
                        <div onClick={() => awardDetailsHandler(detail.id)} className='cursor-pointer w-100'>
                          {detail.img === null || detail.img === ''
                            ? (
                              <div className='awdImg swiper-img' style={{ background: 'url(' + awardimg + ')' }}></div>
                            )
                            : (
                              <div className='awdImg swiper-img' style={{ background: 'url(' + detail.img + ')' }}></div>
                            )}
                          <IonRow className="profileName ion-padding-top">
                            <IonCardTitle className='text-center'>
                              <p className="title fixed-textline mb-2">{detail.title}</p>
                              <p className="decription">
                                {detail.description.length >= 100
                                  ? <>{textMethod(detail.description) + '...'}<a className="readmore" onClick={() => awardDetailsHandler(detail.id)}> {t('commonproperties.text29')}</a></>
                                  : (detail.description)}
                              </p>
                            </IonCardTitle>
                          </IonRow>
                        </div>
                      </div>
                    </IonCol>

                  ))) : loading}
              <IonInfiniteScroll
                onIonInfinite={searchNext}
                threshold="100px"
                disabled={isInfiniteDisabled}
              >
                <IonInfiniteScrollContent
                  loadingSpinner="circular"
                  loadingText={t('appproperties.text215')}
                >

                </IonInfiniteScrollContent>
              </IonInfiniteScroll>
            </IonRow>
          </div>
        </IonContent>
      </IonModal>
    </>
  );
};
export default Award;
