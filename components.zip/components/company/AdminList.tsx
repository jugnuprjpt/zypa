/* eslint-disable react/jsx-key */
import {
  IonCard,
  IonCol,
  IonContent,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonLabel,
  IonModal,
  IonRow,
  useIonViewWillEnter
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router';
import userLogo from '../../assets/img/user-profile-placeholder.png';
import { close } from 'ionicons/icons';
import SkeletonComonList from '../common/skeleton/SkeletonComonList';
import SkeletonComonViewAll from '../common/skeleton/SkeletonComonViewAll';
import CommonGridList from '../common/CommonGridList';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import ToastCommon from '../common/ToastCommon';
import callFor from '../../util/CallFor';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';

const AdminList = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const { companyId, companyName } = useParams();
  const profileDetail = useSelector(getProfileDetails);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [scrollData, setScrollData] = useState<object[]>([]);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [count, setCount] = useState(0);
  const [adminList, setAdminList] = useState([]);
  const [removeMemberState, setRemoveMemberState] = useState(false);
  const [removeConnectionModalData, setRemoveConnectionModalData] = useState({});
  useEffect(() => {
    getAdminList();
  }, []);
  const getAdminList = async () => {
    setLoading(true);
    const response = await callFor('api/v1.1/companies/' + companyId + '/TEAM', 'POST', '{"page": 0 }', 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setAdminList(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };

  const getAdminListOnScroll = async () => {
    const response = await callFor(
      'api/v1.1/companies/' + companyId + '/TEAM',
      'POST',
      '{"page": ' + count + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content > 0) {
        setScrollData([...scrollData, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  function searchNext(event) {
    setTimeout(() => {
      setCount(count + 1);
      getAdminListOnScroll();
      event.target.complete();
    }, 500);
  }
  const viewPaginaction = () => {
    setInfiniteDisabled(false);
    setShowModal(true);
    setScrollData(adminList);
    setCount(1);
  };
  const removeAsMember = async () => {
    const response = await callFor(
      'api/v1.1/companies/member/remove/' + removeConnectionModalData.id + '/' + companyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast1'));
      setShowToast(true);
      setTimeout(() => {
        history.push('/manageCompanyTeam/' + companyId + '/' + companyName);
      }, 1000);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  return (
    <>
      <IonCard className="colum-reverse profile-details ion-no-margin my-company-list MuiPaper-rounded grouplist-card  ion-padding-horizontal ion-padding-bottom">
        <div className="ion-text-right d-lg-flex d-none">
          {adminList.length >= 20
            ? <div onClick={viewPaginaction} className="link-btn-tx ml-auto cursor-pointer">
              {t('commonproperties.text3')}
            </div>
            : ''}
        </div>
        {adminList.length > 0
          ? (
            <>
              <IonRow className="grouplist-card-mb-list member-listing-group member-listing pt-1 mb-lg-0">
                {adminList.map((list, i) => (
                  <CommonGridList key={i} id={list.id} defultImage={userLogo} img={list.profileImg} name={list.firstName + ' ' + list.lastName}
                    subString={list.profileTitle} dots={true} redirectLink='profile' isAdmin={!list.owner && (profileDetail.id !== list.id)} dotsEventLable1={t('appproperties.text246')}
                    setRemoveConnectionModalData={setRemoveConnectionModalData} setRemoveConfirmModel={setRemoveMemberState} />
                ))}
              </IonRow>
            </>
          )
          : loading
            ? (
              <>
                <SkeletonComonList column={4} sizeMd={6} sizeXs={12} name={true} title={true} distription={false} link={false} />
              </>
            )
            : (
              <p>{t('nodatafound.text8')}</p>
            )
        }

        <IonModal isOpen={showModal} cssClass="pageModel" onDidDismiss={() => setShowModal(false)}>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6 cursor-pointer">{t('commonproperties.text3')}</IonLabel>
            <div
              onClick={() => setShowModal(false)}
              className="close ion-no-padding">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined" />
            </div>
          </IonRow>
          <IonContent>
            <div>
              <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom member-listing">
                {!loading
                  ? <>
                    {scrollData.map((list, i) => (
                      // eslint-disable-next-line react/jsx-key
                      <CommonGridList key={i} id={list.id} defultImage={userLogo} img={list.profileImg} name={list.firstName + ' ' + list.lastName}
                        subString={list.profileTitle} dots={true} redirectLink='profile' isAdmin={!list.owner} dotsEventLable1={t('appproperties.text246')}
                        setRemoveConnectionModalData={setRemoveConnectionModalData} setRemoveConfirmModel={setRemoveMemberState}
                      />
                    ))}
                  </>
                  : <SkeletonComonViewAll column={6} sizeMd={4} sizeXs={6} name={true} title={true} distription={true} link={false} />}
                <IonInfiniteScroll
                  threshold="100px"
                  onIonInfinite={(e: CustomEvent<void>) => searchNext(e)}
                  disabled={isInfiniteDisabled}
                >
                  <IonInfiniteScrollContent loadingText={t('appproperties.text215')}></IonInfiniteScrollContent>
                </IonInfiniteScroll>
              </IonRow>
            </div>
          </IonContent>
        </IonModal>
      </IonCard>
      <ConfirmModelCommon
        header={t('appproperties.text246')}
        message={t('appproperties.text305')}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text247')}
        confirmModel={removeMemberState}
        setConfirmModel={setRemoveMemberState}
        deleteBtnHandler={removeAsMember}
      />
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
    </>
  );
};
export default AdminList;
