/* eslint-disable prefer-const */
/* eslint-disable array-callback-return */
import {
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonFooter,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonTextarea,
  useIonPopover
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { close, duplicateOutline, ellipsisVertical, eyeOutline, pencil, personOutline, warningOutline } from 'ionicons/icons';
import CallFor from '../../util/CallFor';
import { useHistory, useParams } from 'react-router';
import companyProfile from '../../assets/img/banner-placeholder.png';
import companyProfileLogo from '../../assets/img/page-company-profile-placeholder.png';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import AsyncSelect from 'react-select/async';
import Select from 'react-select';
import edit from '../../assets/img/icons/pencil-line-blue.svg';
import ManageTeam from '../../assets/img/icons/teams-icon.svg';
import MetaTags from 'react-meta-tags';
import SkeletonComonViewDetais from '../common/skeleton/SkeletonComonViewDetail';
import PopoverCommon from '../common/PopoverCommon';
import ReportSpamCommon from '../common/ReportSpamCommon';
import ImageEditModal from '../myPage/ImageEditModal';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import ToastCommon from '../common/ToastCommon';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import { useTranslation } from 'react-i18next';
import NotAuthorizeModal from '../common/NotAuthorizeModal';
import ButtonComponent from '../common/ButtonComponent';

const CompanyDetails = (props: any) => {
  const [loginModal, setLoginModal] = useState(false);
  const { t } = useTranslation();
  const natureOfBusiness = [
    {
      value: 'MANUFACTURING',
      label: t('dropdownfields.text7')
    },
    {
      value: 'TRADER',
      label: t('dropdownfields.text8')
    },
    {
      value: 'SERVICE_PROVIDER',
      label: t('dropdownfields.text9')
    },
    {
      value: 'WORKS_CONTRACT',
      label: t('dropdownfields.text10')
    },
    {
      value: 'FREELANCER',
      label: t('dropdownfields.text11')
    },
    {
      value: 'NON_PROFIT_ORGANIZATION',
      label: t('dropdownfields.text12')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];
  const firmType = [
    {
      value: 'PROPRIETORSHIP',
      label: t('dropdownfields.text15')
    },
    {
      value: 'PARTNERSHIP_LLP',
      label: t('dropdownfields.text16')
    },
    {
      value: 'PUBLIC_LIMITED_COMPANY',
      label: t('dropdownfields.text17')
    },
    {
      value: 'PVT_LIMITED_COMPANY',
      label: t('dropdownfields.text18')
    },
    {
      value: 'TRUST',
      label: t('dropdownfields.text19')
    },
    {
      value: 'SOCIETIES',
      label: t('dropdownfields.text20')
    },
    {
      value: 'ASSOCIATIONS_CLUB',
      label: t('dropdownfields.text21')
    },
    {
      value: 'BANK_FINANCIAL_INSTITUTATION',
      label: t('dropdownfields.text22')
    },
    {
      value: 'EDUCATION_INSTUATION',
      label: t('dropdownfields.text23')
    },
    {
      value: 'GOVERNMENT_PUBLIC_SECTOR_Undertaking',
      label: t('dropdownfields.text24')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];
  const label = [
    {
      id: 1,
      name: t('appproperties.text266')
    },
    {
      id: 2,
      name: t('appproperties.text267')
    },
    {
      id: 3,
      name: t('appproperties.text268')
    },
    {
      id: 4,
      name: t('companyproperties.text4')
    },
    {
      id: 5,
      name: t('appproperties.text269')
    },
    {
      id: 6,
      name: t('appproperties.text182')
    },
    {
      id: 7,
      name: t('productproperties.text25')
    },
    {
      id: 8,
      name: t('dropdownfields.text13')
    }];
  const buys = [];
  const sales = [];
  const params = useParams();
  const [selectedValue, setSelectedValue] = useState([]);
  const [buySelectedValue, setBuySelectedValue] = useState([]);
  const [stateCombo, setstate] = useState([]);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  // const [isValid, setIsValid] = useState(true);
  const [characterCount, setCharacterCount] = useState(0);
  const history = useHistory();
  const [showModelProfilePicture, setshowModelProfilePicture] = useState(false);
  const [confirmModel, setConfirmModel] = useState(false);
  const [confirmModelMsg, setConfirmModelMsg] = useState('');
  // const divclick = () => {
  //   history.push('/inviteconnection');
  // };
  const { companyId } = useParams();
  const [companyDetail, setCompanyDetails] = useState([]);
  const [saveDisabled, setSaveDisabled] = useState(false);
  const profileDetail = useSelector(getProfileDetails);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    getcompanyDetail(params.companyId);
  }, []);
  const maxCount = 500;
  const getcompanyDetail = async (id) => {
    setLoading(true);
    const stateres = await CallFor(
      'api/v1.1/companies/details/' + id,
      'GET',
      null,
      'Auth'
    );
    if (stateres.status === 200) {
      const json1Response = await stateres.json();
      if (json1Response.data !== null) {
        setCompanyDetails(json1Response.data);
        props.setAboutDetails(json1Response.data);
        props.setCompanyName(json1Response.data.name);
      }
    } else if (stateres.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (stateres.status === 404) {
      history.push('/404');
    } else if (stateres.status === 500) {
      history.push('/500');
    }
    setLoading(false);
  };

  const customStyles = {
    control: (provided: any) => ({
      ...provided,
      minHeight: 48,
      background: '#fff !important',
      '&:focus': {
        border: '1px solid #d8d8d8'
      }
    }),
    multiValue: (styles, { data }) => {
      return {
        ...styles,
        padding: 4,
        backgroundColor: '#0073ae!important',
        borderRadius: '50px'
      };
    },
    multiValueLabel: (styles, { data }) => ({
      ...styles,
      color: '#fff'
    }),
    multiValueRemove: (styles, { data }) => ({
      ...styles,
      color: '#0073ae!important',
      borderRadius: '50px',
      margin: 3,
      backgroundColor: 'rgba(255, 255, 255, 0.7)',
      ':hover': {
        backgroundColor: '#fff'
      }
    }),
    indicatorSeparator: () => { }, // removes the "stick"
    dropdownIndicator: (defaultStyles: any) => ({
      ...defaultStyles,
      '& svg': { display: 'none' }
    })
  };
  const [editProfileFormState, setEditProfileFormState] = useState({
    email: '',
    contactNo2: null,
    comments: '',
    addressLine2: ''
    // name: '2 firmName',
    // type: '3 firmType',
    // natureOfBusiness: '4 businessType',
    // addressLine2: '5 firmAddress2',
    // firmPincode: '6 firmpincode',
    // city: '7 city',
    // email: '8 email',
    // // products: '9 products',
    // missing: '10 missing',
    // about: '11 aboutFirm',
    // contactNo1: '9662414007',
    // addressLine1: '12 firmAddress1',
    // contactNo2: '9694124137',
    // id: '1234'
  });
  const validationSchema = Yup.object().shape({
    name: Yup.string().trim()
      .required(t('commonproperties.text24'))
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length <= 200
      ),
    type: Yup.string().required(t('commonproperties.text25')),
    natureOfBusiness: Yup.string().required(t('companyproperties.text35')),
    firmPincode: Yup.string()
      .required(t('companyproperties.text20'))
      .test('typeError',
        t('companyproperties.text21'),
        (val) => Number(val))
      .test(
        'len',
        t('companyproperties.text21')
        ,
        (val) => val && val.toString().length === 6
      ),
    city: Yup.string().trim()
      .required(t('companyproperties.text23'))
      .matches(/^[A-Za-z-&-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('companyproperties.text24'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('userproperties.text15'),
        (val) => val && val.toString().length <= 100
      ),
    email: Yup.string().trim().nullable().email(t('commonproperties.text9')),
    contactNo1: Yup.string().nullable().optional()
      .test('typeError',
        'Landline must be a number',
        (val) => {
          if (val !== null && val !== '') {
            return Number(val);
          } else {
            return true;
          }
        })
      .test(
        'len',
        t('companyproperties.text18'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().length >= 6;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('companyproperties.text19'),
        (val) => {
          if (val !== null && val !== '') {
            return val && val.toString().length <= 10;
          } else {
            return true;
          }
        }
      ),
    contactNo2: Yup.string().optional().nullable()
      .test('typeError',
        t('commonproperties.text23'),
        (val) => {
          if (val !== null && val !== '') {
            return Number(val);
          } else {
            return true;
          }
        })
      .test(
        'len',
        t('commonproperties.text12'),
        (val) => {
          if (val !== null && val !== '') {
            return val && val.toString().length >= 10;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('commonproperties.text12'),
        (val) => {
          if (val !== null && val !== '') {
            return val && val.toString().length <= 10;
          } else {
            return true;
          }
        }
      ),
    about: Yup.string()
      .trim()
      .nullable(true)
      .optional()
      .notRequired()
      .test('len', t('companyproperties.text27'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().trim().length >= 2;
        } else {
          return true;
        }
      })
      .test('len', t('companyproperties.text27'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().trim().length <= 500;
        } else {
          return true;
        }
      }),
    // about: Yup.string()
    //   .required('About your company is required')
    //   .test(
    //     'len',
    //     'About your company field min 10 & max 500 characters',
    //     (val) => val && val.toString().length >= 10
    //   )
    //   .test(
    //     'len',
    //     'About your company field min 10 & max 500 characters',
    //     (val) => val && val.toString().length <= 500
    //   ),
    addressLine1: Yup.string()
      .trim()
      .nullable(true)
      .optional()
      .notRequired()
      .test('len', t('companyproperties.text17'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().trim().length >= 2;
        } else {
          return true;
        }
      })
      .test('len', t('companyproperties.text17'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().trim().length <= 150;
        } else {
          return true;
        }
      })
    /*,
  sales: Yup.array()
    .min(1, 'Please select what you sell')
    .of(
      Yup.object().shape({
        label: Yup.string().required(),
        value: Yup.string().required()
      })
    ).nullable()
    .required('Please select what you sell') */
    // productIds: Yup.string()
    //   .required('Topic is required!')
    // contactNo2: Yup.number().required('Company Contact is Required')
  });
  const [showModal, setShowModal] = useState(false);
  const [imageView, setImageView] = useState(false);
  const [editCompanyFile, seteditCompanyFile] = useState('');
  const {
    register,
    handleSubmit,
    setError,
    setValue,
    clearErrors,
    resetField,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });

  const userformDataChangeHandler = (event) => {
    if (event.target.value !== undefined) {
      if (event.target.value !== null && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setEditProfileFormState({
        ...editProfileFormState,
        [event.target.name]: event.target.value
      });
    }
  };
  const stateDataChangeHandler = (event) => {
    if (event !== null && event.value !== undefined) {
      setEditProfileFormState({ ...editProfileFormState, state: event.value });
    } else {
      setEditProfileFormState({ ...editProfileFormState, state: null });
    }
  };
  const uploadCompanylogoHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('companyproperties.text34')
        });
        // setIsValid(false);
      } else {
        if (event.target.files[0].size > 3145728) {
          setError('upload', {
            type: 'required',
            message: t('companyproperties.text33')
          });
          // setIsValid(false);
        } else {
          clearErrors('upload');
          resetField('upload');
          // setIsValid(true);
        }
      }
      seteditCompanyFile(file1);
      setImageView(true);
    }
  };
  const companySubmitHandler = async (event: any) => {
    if (testHandler()) {
      setSaveDisabled(true);
      setLoading(true);
      let pros = null;
      if (selectedValue.length > 0) {
        // let pro = null;
        // pro = '[';
        // selectedValue
        //   .join()
        //   .split(',')
        //   .map((v) => {
        //     pro += '"' + v + '",';
        //   });
        // pro += ']';
        pros = selectedValue;
      }
      let buys = null;
      if (buySelectedValue.length > 0) {
        // let buy = null;
        // buy = '[';
        // buySelectedValue
        //   .join()
        //   .split(',')
        //   .map((v) => {
        //     buy += '"' + v + '",';
        //   });
        // buy += ']';
        buys = buySelectedValue;
      }
      let contactNo2 = null;
      if (editProfileFormState.contactNo2 !== '' && editProfileFormState.contactNo2 !== null) {
        contactNo2 = editProfileFormState.contactNo2;
      }
      let contactNo1 = null;
      if (editProfileFormState.contactNo1 !== '' && editProfileFormState.contactNo1 !== null) {
        contactNo1 = editProfileFormState.contactNo1;
      }
      let state = null;
      if (editProfileFormState.state !== null) {
        state = editProfileFormState.state;
      }
      // const companyProfile = document.getElementById('upload');
      const data = new FormData();
      // if (companyProfile.files[0] !== undefined) {
      //   editProfileFormState.entityLogo = null;
      //   data.append('logo', companyProfile.files[0]);
      // } else {
      //   if (editProfileFormState.entityLogo !== null) {
      //     editProfileFormState.entityLogo = editCompanyFile;
      //   }
      //   data.append('logo', null);
      // }
      let companyname = '';
      let companyemail = '';
      let add1 = '';
      let add2 = '';
      let companycity = '';
      let companyabout = '';
      if (editProfileFormState.name !== undefined && editProfileFormState.name !== null) {
        companyname = editProfileFormState.name.trim();
        editProfileFormState.name = companyname;
      }
      if (editProfileFormState.email !== undefined && editProfileFormState.email !== null) {
        companyemail = editProfileFormState.email.trim();
        editProfileFormState.email = companyemail;
      }
      if (editProfileFormState.addressLine1 !== undefined && editProfileFormState.addressLine1 !== null) {
        add1 = editProfileFormState.addressLine1.trim();
        editProfileFormState.addressLine1 = add1;
      }
      if (editProfileFormState.addressLine2 !== undefined && editProfileFormState.addressLine2 !== null) {
        add2 = editProfileFormState.addressLine2.trim();
        editProfileFormState.addressLine2 = add2;
      }
      if (editProfileFormState.city !== undefined && editProfileFormState.city !== null) {
        companycity = editProfileFormState.city.trim();
        editProfileFormState.city = companycity;
      }
      if (editProfileFormState.about !== undefined && editProfileFormState.about !== null) {
        companyabout = editProfileFormState.about.trim();
        editProfileFormState.about = companyabout;
      }
      const companyData = {
        id: editProfileFormState.id,
        name: editProfileFormState.name,
        type: editProfileFormState.type,
        natureOfBusiness: editProfileFormState.natureOfBusiness,
        contactNo2: contactNo2,
        entityLogo: editProfileFormState.entityLogo,
        addressLine1: editProfileFormState.addressLine1,
        addressLine2: editProfileFormState.addressLine2,
        firmPincode: editProfileFormState.firmPincode,
        city: editProfileFormState.city,
        email: editProfileFormState.email,
        contactNo1: contactNo1,
        sales: pros,
        buys: buys,
        about: editProfileFormState.about,
        states: state,
        countries: '101'
      };
      data.append('companyDto', JSON.stringify(companyData));
      const response = await CallFor(
        'api/v1.1/companies',
        'PUT',
        JSON.stringify(companyData),
        'Auth'
      );
      if (response.status === 200) {
        setShowModal(false);
        getcompanyDetail(params.companyId);
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else if (response.status === 400) {
        const datares = await response.json();
        datares.error.errors.map((details) => {
          setError(details.field, {
            type: 'server',
            message: details.message
          });
        });
      }
      setSaveDisabled(false);
      setLoading(false);
    }
  };
  const testHandler = () => {
    // const profilePhoto = document.getElementById('upload');
    // let isUserLogoValid = true;
    let isSalesValid = true;

    if (selectedValue.length === 0) {
      setError('sales', {
        type: 'required',
        message: t('commonproperties.text36')
      });
      isSalesValid = false;
    } else {
      clearErrors('sales');
      isSalesValid = true;
    }
    // if (profilePhoto.files[0] !== undefined && profilePhoto.files[0] !== '') {
    //   if (profilePhoto.files[0].size > 3145728) {
    //     setError('upload', {
    //       type: 'required',
    //       message: t('companyproperties.text33')
    //     });
    //     // setIsValid(false);
    //     isUserLogoValid = false;
    //   }
    //   if (!profilePhoto.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
    //     setError('upload', {
    //       type: 'required',
    //       message: t('companyproperties.text34')
    //     });
    //     // setIsValid(false);
    //     isUserLogoValid = false;
    //   }
    // }

    if (isSalesValid) {
      // setIsValid(true);
      return true;
    } else {
      // setIsValid(false);
      return false;
    }
  };
  const validateIsNumericInput = (evt) => {
    const ASCIICode = (evt.which) ? evt.which : evt.keyCode;
    const permittedKeys = [8, 9, 46, 37, 39, 13, 46, 116, 50];
    if ((ASCIICode >= 48 && ASCIICode <= 57) || (ASCIICode >= 96 && ASCIICode <= 105)) {
      return true;
    };
    if (permittedKeys.includes(ASCIICode)) {
      return true;
    };
    return false;
  };
  const [isDisabled, setIsDisable] = useState(false);
  const getEditCompanyDetails = async () => {
    setShowModal(true);
    setEditProfileFormState({
      id: companyDetail.id,
      name: companyDetail.name,
      type: companyDetail.type,
      natureOfBusiness: companyDetail.natureOfBusiness,
      addressLine1: companyDetail.addressLine1,
      addressLine2: companyDetail.addressLine2,
      firmPincode: companyDetail.firmPincode,
      city: companyDetail.city,
      email: companyDetail.email,
      about: companyDetail.about,
      contactNo1: companyDetail.contactNo1,
      missing: companyDetail.missing,
      contactNo2: companyDetail.contactNo2,
      state: companyDetail.state
    });
    setIsDisable(true);
    const str = companyDetail.identityNumber;
    if ((str.substring(3, 4) === 'P')) {
      setIsDisable(false);
    } else {
      setIsDisable(true);
    }
    seteditCompanyFile(companyDetail.entityLogo);
    const buysValue = [];
    if (companyDetail.buys !== null) {
      companyDetail.buys.forEach((buy) => {
        let data = {};
        data.label = buy.name;
        data.value = buy.id;
        buys.push(data);
        buysValue.push(buy.id);
      });
      setBuySelectedValue(buysValue);
    }
    const salesValue = [];
    companyDetail.sales.map((sale) => {
      let data = {};
      data.label = sale.name;
      data.value = sale.id;
      sales.push(data);
      salesValue.push(sale.id);
    });
    setSelectedValue(salesValue);
    const fields = [
      'name',
      'type',
      'natureOfBusiness',
      'firmPincode',
      'addressLine1',
      'addressLine2',
      'city',
      'email',
      'contactNo1',
      'contactNo2',
      'sales',
      'buys',
      'about'
    ];
    fields.forEach((field) => setValue(field, companyDetail[field]));
    setImageView(true);
  };
  useEffect(() => {
    comboData(101);
  }, []);

  const comboData = async (companyId: string | number) => {
    const response = await CallFor(
      'api/v1.1/states/' + companyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      const states = await json1Response.data.map(
        (d: { id: any; name: any }) => ({
          value: d.id,
          label: d.name
        })
      );
      setstate(states);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const productHandleChange = (e: {
    map: (arg0: (x: any) => any) => React.SetStateAction<never[]>;
  }) => {
    setSelectedValue(Array.isArray(e) ? e.map((x) => x.value) : []);
  };
  const buyHandleChange = (e: {
    map: (arg0: (x: any) => any) => React.SetStateAction<never[]>;
  }) => {
    setBuySelectedValue(Array.isArray(e) ? e.map((x) => x.value) : []);
  };

  const promiseOptions = (inputValue: string) =>
    new Promise<any>((resolve) => {
      resolve(selectProducts(inputValue.trim()));
    });

  const selectProducts = async (inputValue: string) => {
    let productLists = [];
    if (inputValue.length >= 3) {
      const productsRes = await CallFor(
        'api/v1.1/searches/products/' + inputValue,
        'GET',
        null,
        'Auth'
      );
      if (productsRes.status === 200) {
        const json1Response = await productsRes.json();
        productLists = await json1Response.data.map(
          (d: { id: any; keyword: any }) => ({
            value: d.id,
            label: d.keyword
          })
        );
      }
    }
    return productLists;
  };
  const sellBlure = () => {
    if (selectedValue.length === 0) {
      setError('sales', {
        type: 'required',
        message: t('commonproperties.text36')
      });
    } else {
      resetField('sales');
      clearErrors('sales');
    }
  };
  const openModelClearError = () => {
    setShowModal(true);
    clearErrors();
  };
  const imageEditHandle = () => {
    setImageView(false);
  };
  const deleteImageHandle = () => {
    // document.getElementById('groupImg').src = `${product}`;
    // setIsValid(true);
    seteditCompanyFile(null);
    document.getElementById('upload').value = '';
    clearErrors('upload');
    setImageView(true);
  };
  const addImg = () => {
    setImageView(false);
  };
  const getCommaStringFromMap = (map) => {
    if (map !== undefined && map !== null) {
      let returnData = map.map(({ id, name }) => name).join(', ');
      return returnData;
    }
  };
  const ogTitle = `${companyDetail.name}` + '|' + `${companyDetail.natureOfBusiness}` + '|' + `${companyDetail.city}`;
  const ogImage = `${companyDetail.name}` + '|' + `${companyDetail.entityLogo}`;
  const keywordsSelsBuys = `${companyDetail.natureOfBusiness}` + ', ' + `${getCommaStringFromMap(companyDetail.sales)}` + ', ' + `${getCommaStringFromMap(companyDetail.buys)}` + ' in ' + `${companyDetail.city}`;
  // const urlLink = 'https://www.zyappar.com/' + `${companyDetail.name}`;
  const description = `${companyDetail.about}` + ',' + `${companyDetail.city}`;
  // const scriptData = {
  //   '@context': 'https://schema.org',
  //   '@type': 'LocalBusiness',
  //   name: companyDetail.name,
  //   // url: window.location.href,
  //   image: companyDetail.entityLogo,
  //   '@id': '',
  //   url: window.location.href,
  //   telephone: companyDetail.contactNo1,
  //   address: {
  //     '@type': 'PostalAddress',
  //     addressLocality: companyDetail.city,
  //     State: companyDetail.state

  //   }
  // };
  const schemaData = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [{
      '@type': 'ListItem',
      position: '1',
      name: 'zyapaar',
      item: 'https://www.zyapaar.com'
    },
    {
      '@type': 'ListItem',
      position: '2',
      name: companyDetail.name,
      item: companyDetail.entityLogo
    }]
  };
  const organizationData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: companyDetail.name,
    url: window.location.href,
    logo: companyDetail.entityLogo,
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: companyDetail.contactNo1,
      contactType: ''
    },
    sameAs: ''
  };
  const [reportModal, setReportModel] = useState(false);
  const openReportModelclearstate = () => {
    setReportModel(true);
    dismiss();
  };
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr">
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => { onHide(); openReportModelclearstate() }}
      >
        <IonIcon icon={warningOutline} size="small" className="header-menu-img " />
        <p>{t('commonproperties.text19')}</p>
      </IonItem>
    </IonList>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });

  const showEditProfileList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr popover-company">
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={openModelClearError}
      >
        <IonIcon icon={edit} size="small" className="header-menu-img " />
        <p className="ion-padding-start">Edit Company Profile</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer">
        <IonIcon icon={ManageTeam} size="small" className="header-menu-img " />
        <p className="ion-padding-start">Manage Team</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer">
        <IonIcon icon={personOutline} size="small" className="header-menu-img " />
        <p className="ion-padding-start">Manage Admins</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer">
        <IonIcon icon={duplicateOutline} size="small" className="header-menu-img " />
        <p className="ion-padding-start">Add Award & Certification</p>
      </IonItem>
    </IonList>
  );

  const [showEditProfile, setShowEditProfile] = useIonPopover(showEditProfileList, {
    onHide: () => setShowEditProfile()
  });
  const removeOverLay = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const addClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.add('imageHover');
  };
  const removeClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const aboutChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value !== null && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setEditProfileFormState({
        ...editProfileFormState,
        about: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };
  const closeModelClearError = () => {
    setShowModal(false);
  };
  const leaveBtn = () => {
    setConfirmModelMsg(t('appproperties.text25'));
    setConfirmModel(true);
  };
  const leaveSubmitBtn = async () => {
    const response = await CallFor(
      'api/v1.1/companies/member/leave/' + companyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast2'));
      setShowToast(true);
      getcompanyDetail(params.companyId);
    } else if (response.status === 400) {
      const json1Response = await response.json();
      console.log(json1Response);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const joinBtn = async () => {
    const response = await CallFor(
      'api/v1.1/companies/' + companyId + '/team/join',
      'POST',
      null,
      'Auth'
    );
    if (response.status === 201) {
      setShowToastMsg(t('toastmessages.toast3'));
      setShowToast(true);
      getcompanyDetail(params.companyId);
    } else if (response.status === 400) {
      const json1Response = await response.json();
      console.log(json1Response);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  // const requestedBtn = () => {
  //   setConfirmModelMsg(' Are you sure you want to withdraw Team request ?');
  //   setConfirmModel(true);
  // };
  // const requestedSubmitBtn = async() => {
  //   const response = await CallFor(
  //     'api/v1.1/companies/teams/invitations/' + companyId + '/CANCEL',
  //     'POST',
  //     null,
  //     'Auth'
  //   );
  //   if (response.status === 201) {
  //     setShowToastMsg('Request sent');
  //     setShowToast(true);
  //     getcompanyDetail(params.companyId);
  //   } else if (response.status === 400) {
  //     const json1Response = await response.json();
  //     console.log(json1Response);
  //   } else if (response.status === 401) {
  //     localStorage.clear();
  //     history.push('/login');
  //   }
  // };
  return (
    <>
      <script type="application/ld+json">
        {JSON.stringify(schemaData)}
      </script>
      <script type="application/ld+json">
        {JSON.stringify(organizationData)}
      </script>
      <MetaTags>
        <title>{companyDetail.name} | {companyDetail.natureOfBusiness} | {companyDetail.city} | Zyapaar</title>
        <meta name="description" content={description} />
        <meta name="keywords" content={keywordsSelsBuys} />
        <meta property="og:title" content={ogTitle} />
        <meta property="og:site_name" content='Zyapaar' />
        <meta property="og:url" content={window.location.href} />
        <meta property="og:description" content={description} />
        {companyDetail.entityLogo && <meta property="og:image" content={companyDetail.entityLogo} key="image" />}
        <meta property="og:image:width" content="247" />
        <meta property="og:image:height" content="250" />
        <link rel="canonical" href={window.location.href}></link>
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content={companyDetail.name} />
        <meta name="twitter:description" content={companyDetail.about} />
        <meta name="twitter:image" content={ogImage} />
        <meta name="twitter:image:width" content="250" />
        <meta name="twitter:image:height" content="250" />
      </MetaTags>
      {!loading
        ? <IonCard className="MuiPaper-rounded ion-no-margin ion-margin-top profile-card-content mtm-0">
          <ImageEditModal
            id={companyId}
            image={companyDetail.cover}
            defultLogo={companyProfile}
            serviceType='COMPANY'
            getDetails={getcompanyDetail}
            logo='COVER'
            aspect={22 / 4.5}
            cropShape={'rect'}
            className='cover-photo'
            cssClass='edit-img model-img-hei-width CoverPhotoMain'
            isAdmin={companyDetail.admin}
            reportHideState={props.reportHideState}
            isHide={companyDetail.hide}
          />
          {/*  Profile Picture Zoom  */}
          <IonModal isOpen={showModelProfilePicture} cssClass="add-award-model awd-img-gallery" backdropDismiss={false} onDidDismiss={() => setshowModelProfilePicture(false)}>
            <IonContent>
              <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
                <div onClick={() => setshowModelProfilePicture(false)} className="close ion-no-padding">
                  <IonIcon
                    icon={close}
                    className="ion-button-color pr-0 "
                    slot="start"
                    size="undefined" />
                </div>
              </IonRow>
              <IonRow className="mx-auto d-flex justify-content-center overview-heigth">
                {companyDetail.entityLogo === null ||
                  companyDetail.entityLogo === ''
                  ? (
                    <img src={companyProfile} />
                  )
                  : (
                    <img onError={(ev) => { ev.target.src = companyProfile; }} src={companyDetail.entityLogo} />
                  )}
              </IonRow>
            </IonContent>
          </IonModal>
          {/*  Profile Picture Zoom  */}

          <div className="profile-card-body pb-0">
            <div className="profile-avt-content">
              <ImageEditModal
                id={companyId}
                image={companyDetail.entityLogo}
                defultLogo={companyProfileLogo}
                serviceType='COMPANY'
                getDetails={getcompanyDetail}
                logo='LOGO'
                aspect={1}
                cropShape={'round'}
                className='logo-photo'
                cssClass='edit-img model-img-hei-width'
                isAdmin={companyDetail.admin}
                reportHideState={props.reportHideState}
                isHide={companyDetail.hide}
                background={true}
              />
              {!props.reportHideState
                ? companyDetail.hide !== true
                  ? <>
                    {(() => {
                      if (companyDetail.id !== undefined && companyDetail.admin === true) {
                        // if (profileDetail.companies.includes(companyDetail.id)) {
                        return (
                          <div className="edit-icon zindex9">
                            <IonIcon
                              onClick={(e) =>
                                showEditProfile({
                                  event: e.nativeEvent,
                                })
                              }
                              icon={ellipsisVertical}
                              slot="start"
                              className="header-menu-account-img color-theme-dark"
                            />
                          </div>


                        );
                        // }
                      }
                    })()}
                  </>
                  : ''
                : ''}
            </div>
            <div className="profileName w-100">
              <IonCardTitle>
                <h4 className="margin fixed-textline2 ">
                  {companyDetail.name}
                </h4>
                <p className='color-grey font-14 fixed-textline2 font-regular w-85'>
                  {companyDetail.addressLine1 !== '' && companyDetail.addressLine1 !== null && companyDetail.addressLine2 !== '' && companyDetail.addressLine1 !== null
                    ? <>{companyDetail.addressLine1}  {companyDetail.addressLine2} | </>
                    : ''}
                  {companyDetail.city} {companyDetail.firmPincode}
                </p>
                <div className='align-items-center color-grey d-flex font-15'>
                  <div className="d-flex justify-content-between w-100 ion-align-items-center">
                    <p className='me-1 text-left w-100 text-lg-left'>{companyDetail.members} <span className='me-2'>{t('appproperties.text190')}(s)</span>
                    </p>


                    <div className='d-flex justify-content-end align-items-center'>
                      {companyDetail.owner !== true
                        ? <>
                          {companyDetail.status === null
                            ? <ButtonComponent
                              btnClick={joinBtn}
                              className='ion-button-color mt-2 pe-0'
                              size='small'
                              name={t('appproperties.text237')} parametersPass={0} />
                            : companyDetail.status === 'accept'
                              ? companyDetail.admin !== true
                                ? <ButtonComponent
                                  btnClick={leaveBtn}
                                  className='ion-button-color mt-2 pe-0'
                                  size='small'
                                  name={t('appproperties.text243')} parametersPass={0} />
                                : ''
                              : ''}
                        </>
                        : ''}
                    </div>
                  </div>
                </div>
              </IonCardTitle>
              {!props.reportHideState
                ? companyDetail.hide !== true
                  ? <>
                    {companyDetail.admin !== true
                      ? <div className="dot-btn">
                        <IonIcon
                          icon={ellipsisVertical}
                          slot="start"
                          className="test report cursor-pointer"
                          onClick={(e) => {
                            if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                              present({ event: e.nativeEvent });
                            } else {
                              history.push('/addnewcompany');
                              // setLoginModal(true);
                            }
                          }
                          }
                        />
                      </div>
                      : ''}
                  </>
                  : ''
                : ''}
            </div>
          </div>
        </IonCard>
        : <SkeletonComonViewDetais />}
      <IonModal
        isOpen={showModal}
        onDidPresent={getEditCompanyDetails}
        className="CompanyProfile groupModel EditGroupModal "
        backdropDismiss={false}
        onDidDismiss={closeModelClearError}
      >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">
              {t('appproperties.text178')}
            </IonLabel>
            <div onClick={closeModelClearError} className="close ion-no-padding cursor-pointer">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0"
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <div className='modal-body'>
            <form
              noValidate
              data-testid="form-submit"
              autoComplete="off"
              onSubmit={handleSubmit(companySubmitHandler, testHandler)}
              className="h-100"
            >
              <div className="body-content">
                <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
                  <IonCol size-lg="12" size-md="12" size-xs="12" className='p-0'>
                    <IonRow>
                      <IonCol size-md="6" size-sm="12" size-xs="12" className="input-popover mt-lg-0 mt-1 prefillData">
                        <IonItem
                          className={
                            errors.name
                              ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                              : 'form-group input-label-box position-relative pt-0 mb-0'
                          }
                        >
                          <IonLabel position="floating">{' '} {t('commonproperties.text27')}<sup>*</sup>{' '}</IonLabel>
                          <IonInput
                            autocomplete="off"
                            type="text"
                            disabled={isDisabled}
                            className='input-box input-custom-width'
                            placeholder=""
                            id="name"
                            {...register('name')}
                            onIonChange={userformDataChangeHandler}
                            value={editProfileFormState.name}
                          />
                        </IonItem>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text161')} />
                        <span className={errors.name ? 'error text-nowrap input-error left5 bottom-10' : 'text-nowrap'}>
                          {errors.name?.message}
                        </span>
                      </IonCol>

                      <IonCol size-md="6" size-sm="12" size-xs="12" className="input-label-box input-popover mb-0 mt-lg-0  mt-3">
                        <div className='select-input-box'>
                          <IonSelect
                            interface="popover"
                            className={
                              errors.type ? 'error-border select-box ps-3' : 'select-box  input-fill ps-3'
                            }
                            id="type"
                            onIonChange={userformDataChangeHandler}
                            value={editProfileFormState.type}
                            {...register('type')}
                          >
                            {firmType.map((option) => (
                              <IonSelectOption
                                key={option.value}
                                value={option.value}
                              >
                                {option.label}
                              </IonSelectOption>
                            ))}
                          </IonSelect>
                          <span className='floating-label-outside'>{t('companyproperties.text37')}<sup>*</sup> </span>
                        </div>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text161')} />
                        <p className={errors.industryTypeText ? 'error' : ''}>
                          {errors.industryTypeText?.message}
                        </p>
                      </IonCol>
                      <IonCol size-md="12" size-sm="12" size-xs="12" className="input-label-box input-popover mt-3 zind1">
                        <div className='select-input-box'>
                          <IonSelect
                            interface="popover"
                            className={
                              errors.natureOfBusiness
                                ? 'error-border select-box ps-3'
                                : 'select-box  input-fill ps-3'
                            }
                            id="natureOfBusiness"
                            onIonChange={userformDataChangeHandler}
                            value={editProfileFormState.natureOfBusiness}
                            {...register('natureOfBusiness')}
                          >
                            {natureOfBusiness.map((option) => (
                              <IonSelectOption
                                key={option.value}
                                value={option.value}
                              >
                                {option.label}
                              </IonSelectOption>
                            ))}
                          </IonSelect>
                          <span className='floating-label-outside'>{t('dropdownfields.text6')}<sup>*</sup> </span>
                        </div>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text162')} />
                        <p className={errors.natureOfBusiness ? 'error' : ''}>
                          {errors.natureOfBusiness?.message}
                        </p>
                      </IonCol>
                    </IonRow>
                  </IonCol>
                  <IonRow className='full-width-row'>
                    <IonCol size-md="4" size-xs="12" className='mb-3'>
                      <IonItem
                        className={
                          errors.email
                            ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                            : 'form-group input-label-box position-relative pt-0 mb-0'
                        }
                      >
                        <IonLabel position="floating">{t('commonproperties.text33')}</IonLabel>
                        <IonInput
                          autocomplete="off"
                          type="email"
                          className='input-box'
                          placeholder=""
                          id="email"
                          {...register('email')}
                          onIonChange={userformDataChangeHandler}
                          value={editProfileFormState.email}
                        />
                      </IonItem>
                      <p className={errors.email ? 'error input-error left5' : ''}>
                        {errors.email?.message}
                      </p>
                    </IonCol>
                    <IonCol size-md="4" size-xs="12" className="mb-3">
                      <IonItem
                        className={
                          errors.contactNo1
                            ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                            : 'form-group input-label-box position-relative pt-0 mb-0'
                        }
                      >
                        <IonLabel position="floating">{' '}{t('companyproperties.text5')}</IonLabel>
                        <IonInput type='text'
                          inputmode="numeric"
                          pattern="[0-9]*"
                          autocomplete="off"
                          className='input-box'
                          placeholder=""
                          id="contactNo1"
                          {...register('contactNo1')}
                          onIonChange={userformDataChangeHandler}
                          onkeydown={validateIsNumericInput}
                          value={editProfileFormState.contactNo1}
                          maxlength={10}
                        />
                      </IonItem>
                      <p className={errors.contactNo1 ? 'error input-error left5' : ''}>
                        {errors.contactNo1?.message}
                      </p>
                    </IonCol>
                    <IonCol size-md="4" size-xs="12" className="mb-3">
                      <IonItem
                        className={
                          errors.contactNo2
                            ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                            : 'form-group input-label-box position-relative pt-0 mb-0'
                        }
                      >
                        <IonLabel position="floating">{t('companyproperties.text6')}</IonLabel>
                        <IonInput
                          inputmode="numeric" type='text'
                          pattern="[0-9]*"
                          autocomplete="off"
                          className='input-box'
                          placeholder=""
                          id="contactNo2"
                          {...register('contactNo2')}
                          onIonChange={userformDataChangeHandler}
                          onkeydown={validateIsNumericInput}
                          value={editProfileFormState.contactNo2}
                          maxlength={10}
                        />
                      </IonItem>
                      <p className={errors.contactNo2 ? 'error input-error left5' : ''}>
                        {errors.contactNo2?.message}
                      </p>
                    </IonCol>
                    <IonCol size-md="6" size-xs="12" className='mb-3'>
                      <IonItem
                        className={
                          errors.addressLine1
                            ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                            : 'form-group input-label-box position-relative pt-0 mb-0'
                        }
                      >
                        <IonLabel position="floating">{t('companyproperties.text8')} </IonLabel>
                        <IonInput
                          autocomplete="off"
                          type="text"
                          className='input-box'
                          data-testid="addressLine"
                          placeholder=""
                          id="addressLine1"
                          {...register('addressLine1')}
                          onIonChange={userformDataChangeHandler}
                          value={editProfileFormState.addressLine1}
                        />
                      </IonItem>
                      <p className={errors.addressLine1 ? 'error' : ''}>
                        {errors.addressLine1?.message}
                      </p>
                    </IonCol>
                    <IonCol
                      size-md="6"
                      size-xs="12"
                      className="ion-no-pading mb-3"
                    >
                      <IonItem
                        className={
                          errors.addressLine2
                            ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                            : 'form-group input-label-box position-relative pt-0 mb-0'
                        }
                      >
                        <IonLabel position="floating">{t('companyproperties.text9')}</IonLabel>
                        <IonInput
                          autocomplete="off"
                          type="text"
                          className='input-box'
                          placeholder=""
                          id="addressLine2"
                          {...register('addressLine2')}
                          onIonChange={userformDataChangeHandler}
                          value={editProfileFormState.addressLine2}
                        />
                      </IonItem>
                      <p className={errors.addressLine2 ? 'error' : ''}>
                        {errors.addressLine2?.message}
                      </p>
                    </IonCol>
                    <IonCol size-md="4" size-xs="12">
                      <IonItem
                        className={
                          errors.firmPincode
                            ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                            : 'form-group input-label-box position-relative pt-0 mb-0'
                        }
                      >
                        <IonLabel position="floating">{t('companyproperties.text10')} <sup>*</sup></IonLabel>
                        <IonInput type='text' autocomplete='off'
                          className='input-box'
                          data-testid="firmPincode"
                          placeholder=""
                          id="firmPincode"
                          {...register('firmPincode')}
                          onIonChange={userformDataChangeHandler}
                          onkeydown={validateIsNumericInput}
                          value={editProfileFormState.firmPincode}
                          maxlength={6}
                        />
                      </IonItem>
                      <p className={errors.firmPincode ? 'error' : ''}>
                        {errors.firmPincode?.message}
                      </p>
                    </IonCol>
                    <IonCol size-md="4" size-xs="12" className='mt-lg-0  mt-2 zindex1'>
                      <Select
                        className="selectOption moreimp v-imp form-group input-label-box py-0 state-height"
                        placeholder={t('companyproperties.text14')}
                        value={stateCombo.filter(
                          (obj) => obj.value === editProfileFormState.state
                        )}
                        options={stateCombo}
                        id="state"
                        menuPlacement='top'
                        styles={customStyles}
                        onChange={stateDataChangeHandler}
                        name="state"
                        isClearable
                        noOptionsMessage={() => null}
                      ></Select>
                      <p className={errors.state ? 'error' : ''}>
                        {errors.state?.message}
                      </p>
                    </IonCol>
                    <IonCol size-md="4" size-xs="12" className="input-label-box">
                      <IonItem
                        className={
                          errors.city
                            ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                            : 'form-group input-label-box position-relative pt-0 mb-0'
                        }
                      >
                        <IonLabel position="floating">{' '}{t('companyproperties.text11')} <sup>*</sup></IonLabel>
                        <IonInput
                          className='input-box'
                          placeholder=""
                          id="city"
                          {...register('city')}
                          onIonChange={userformDataChangeHandler}
                          value={editProfileFormState.city}
                        />
                      </IonItem>
                      <p className={errors.city ? 'error' : ''}>
                        {errors.city?.message}
                      </p>
                    </IonCol>

                    <IonCol size="12" className='pb-0'>
                      <IonCardTitle className='d-flex'>
                        {t('commonproperties.text7') + '*'}
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text163')} />
                      </IonCardTitle>
                    </IonCol>
                    <IonCol size-md="12" size-xs="12" className='show-tooltip input-tooltip d-block zindex9'>
                      <AsyncSelect
                        autocomplete="off"
                        type="text"
                        isMulti
                        value={editProfileFormState.sales}
                        className="selectOption moreimp minlinehght form-group input-label-box py-0 mb-0"
                        defaultValue={sales}
                        menuPlacement='top'
                        onChange={productHandleChange}
                        onBlur={sellBlure}
                        loadOptions={promiseOptions}
                        components={{ LoadingIndicator: null }}
                        placeholder={<div className="select-placeholder-text">{t('appproperties.text180')}</div>}
                        styles={customStyles}
                        id="sales"
                        name="sales"
                      // {...register('sales')}
                      />
                      <p className={errors.sales ? 'error' : ''}>
                        {errors.sales?.message}
                      </p>
                    </IonCol>
                    <IonCol size="12" className='mt-3 pb-0'>
                      <IonCardTitle className='d-flex'>
                        {t('commonproperties.text8')}
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text164')} />
                      </IonCardTitle>
                    </IonCol>
                    <IonCol size-md="12" size-xs="12" className='input-popover zindex9'>
                      <AsyncSelect
                        autocomplete="off"
                        type="text"
                        isMulti
                        menuPlacement='top'
                        // value={editProfileFormState.buy}
                        defaultValue={buys}
                        className="selectOption form-group input-label-box py-0 moreimp select-option-zindex zindex1"
                        onChange={buyHandleChange}
                        loadOptions={promiseOptions}
                        placeholder={<div className="select-placeholder-text">{t('appproperties.text180')}</div>}
                        styles={customStyles}
                        components={{ LoadingIndicator: null }}
                        id="buys"
                        name="buys"
                      />
                      <p className={errors.buys ? 'error' : ''}>
                        {errors.buys?.message}
                      </p>

                    </IonCol>
                    <IonCol size-md="12" size-xs="12" className="input-label-box">
                      <IonItem
                        className={
                          errors.about
                            ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                            : 'form-group input-label-box position-relative pt-0 mb-0'
                        }
                      >
                        <IonLabel position="floating">{t('commonproperties.text31')}</IonLabel>
                        <IonTextarea
                          autocomplete="off"
                          type="text"
                          rows={4}
                          className='input-box'
                          placeholder=""
                          value={editProfileFormState.about}
                          {...register('about')}
                          onIonChange={aboutChangeHandler}
                          maxlength={500}
                          id="about"
                        />
                      </IonItem>
                      <p className={errors.about ? 'error' : ''}>
                        {errors.about?.message}
                      </p>
                      <p className='text-grey text-end font-14'>{editProfileFormState.about !== undefined && editProfileFormState.about !== null && editProfileFormState.about.length > 0
                        ? editProfileFormState.about.length
                        : characterCount}/{maxCount}</p>
                    </IonCol>
                  </IonRow>
                </IonRow>
              </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
                <IonRow className="header-row-margin-left">
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto pr-0"
                    size="small"
                    type="submit"
                    disabled={saveDisabled}
                  >
                    {t('appproperties.text149')}
                    {loading
                      ? <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                      : ''
                    }
                  </IonButton>
                </IonRow>
              </IonFooter>
            </form>
          </div>
        </IonContent>
      </IonModal>
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
      <ReportSpamCommon reportModal={reportModal} setReportModel={setReportModel} reportId={companyId} origin='COMPANY' mapData={label} message={t('toastmessages.toast22')} setReportHideState={props.setReportHideState} />
      {/* <ConfirmModelCommon
        header="Withdraw invitation"
        message={confirmModelMsg}
        btn1="cancel"
        btn2="Withdraw"
        confirmModel={confirmModel}
        setConfirmModel={setConfirmModel}
        deleteBtnHandler={requestedSubmitBtn}
      /> */}
      <ConfirmModelCommon
        header={t('appproperties.text282')}
        message={t('appproperties.text283')}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text247')}
        confirmModel={confirmModel}
        setConfirmModel={setConfirmModel}
        deleteBtnHandler={leaveSubmitBtn}
      />
      {loginModal
        ? <NotAuthorizeModal setAuthModal={setLoginModal} authModal={loginModal} />
        : ''}
    </>
  );
};
export default CompanyDetails;
