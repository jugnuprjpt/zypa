import { IonCard, IonIcon, IonLabel, IonList } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { callOutline, mailOutline } from 'ionicons/icons';
import { useTranslation } from 'react-i18next';
import SkeletonAbout from '../common/skeleton/SkeletonAbout';

const About = (props: any) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(function() {
      setLoading(false);
    }, 100);
  }, []);

  const firmType = [
    {
      value: 'PROPRIETORSHIP',
      label: t('dropdownfields.text15')
    },
    {
      value: 'PARTNERSHIP_LLP',
      label: t('dropdownfields.text16')
    },
    {
      value: 'PUBLIC_LIMITED_COMPANY',
      label: t('dropdownfields.text17')
    },
    {
      value: 'PVT_LIMITED_COMPANY',
      label: t('dropdownfields.text18')
    },
    {
      value: 'TRUST',
      label: t('dropdownfields.text19')
    },
    {
      value: 'SOCIETIES',
      label: t('dropdownfields.text20')
    },
    {
      value: 'ASSOCIATIONS_CLUB',
      label: t('dropdownfields.text21')
    },
    {
      value: 'BANK_FINANCIAL_INSTITUTATION',
      label: t('dropdownfields.text22')
    },
    {
      value: 'EDUCATION_INSTUATION',
      label: t('dropdownfields.text23')
    },
    {
      value: 'GOVERNMENT_PUBLIC_SECTOR_Undertaking',
      label: t('dropdownfields.text24')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];

  const businessType = [
    {
      value: 'MANUFACTURING',
      label: t('dropdownfields.text7')
    },
    {
      value: 'TRADER',
      label: t('dropdownfields.text8')
    },
    {
      value: 'SERVICE_PROVIDER',
      label: t('dropdownfields.text9')
    },
    {
      value: 'WORKS_CONTRACT',
      label: t('dropdownfields.text10')
    },
    {
      value: 'FREELANCER',
      label: t('dropdownfields.text11')
    },
    {
      value: 'NON_PROFIT_ORGANIZATION',
      label: t('dropdownfields.text12')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];

  return (
    <>
      {loading
        ? <SkeletonAbout column={1} />
        : <IonCard className="MuiPaper-rounded ion-margin-top ion-padding ion-margin-bottom ion-no-margin about-details-content mt-0">
          {/* <h4 className="ion-margin-start textcolour"> {t('commonproperties.text17')} </h4> */}
          {props.aboutDetails.about
            ? (
              <>
                <div className='category-dtl'>
                  <p className="p_wrap">
                    {props.aboutDetails.about}
                  </p>
                </div>
              </>
              )
            : (
                ''
              )}

          {props.aboutDetails.sales
            ? (
              <>
                <div className='category-dtl'>
                  <span className='title'>
                    {t('appproperties.text185')} :
                  </span>
                  <p>
                    {props.aboutDetails.sales.map((sale) => (
                      <><IonList>{sale.name}</IonList></>
                    ))}
                  </p>
                </div>
              </>
              )
            : (
                ''
              )}
          {props.aboutDetails.buys
            ? (
              <>
                <div className='category-dtl'>
                  <span className='title'>
                    {t('appproperties.text323')} :
                  </span>
                  <p>
                    {props.aboutDetails.buys.map((buy) => (
                      <><IonList>{buy.name}</IonList></>
                    ))}
                  </p>
                </div>
              </>
              )
            : (
                ''
              )}
          <div className='category-dtl'>
            {props.aboutDetails.natureOfBusiness
              ? (
                <>
                  <span className='title'>
                    {t('dropdownfields.text6')} :
                  </span>
                  <span>
                    {businessType.map((record) => (
                      props.aboutDetails.natureOfBusiness === record.value
                        ? record.label
                        : ''
                    ))}
                  </span>
                </>
                )
              : (
                  ''
                )}
          </div>
          <div className='category-dtl'>
            {props.aboutDetails.type
              ? (
                <>
                  <span className='title'>
                    {t('companyproperties.text37')} :
                  </span>
                  <span>
                    {firmType.map((record) => (
                      props.aboutDetails.type === record.value
                        ? record.label
                        : ''
                    ))}
                  </span>
                </>
                )
              : (
                  ''
                )}
          </div>
          <div className='contact-dtl'>
            {props.aboutDetails.contactNo1
              ? (
                <IonLabel>
                  <IonIcon
                    icon={callOutline}
                    className="test icon-svg"
                  />
                  <a href={'tel::' + props.aboutDetails.contactNo1}>{props.aboutDetails.contactNo1}</a>
                </IonLabel>
                )
              : (
                  ''
                )}
            {props.aboutDetails.contactNo2
              ? (
                <IonLabel>
                  <IonIcon
                    icon={callOutline}
                    className="test icon-svg"
                  />
                  <a href={'tel::' + props.aboutDetails.contactNo2}>{props.aboutDetails.contactNo2}</a>
                </IonLabel>
                )
              : (
                  ''
                )}
            {props.aboutDetails.email
              ? (
                <IonLabel>
                  <IonIcon icon={mailOutline} className="test icon-svg" />
                  <a href={'mailto::' + props.aboutDetails.email}>{props.aboutDetails.email}</a>
                </IonLabel>
                )
              : (
                  ''
                )}
          </div>
        </IonCard>
      }
    </>
  );
};
export default About;
