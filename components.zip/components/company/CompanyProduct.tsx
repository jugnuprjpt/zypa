/* eslint-disable react/jsx-key */
/* eslint-disable multiline-ternary */
import {
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonItem,
  IonList,
  IonModal,
  IonRow,
  useIonPopover
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import CallFor from '../../util/CallFor';
import { useHistory } from 'react-router';
import { arrowBack, closeOutline, cloudUploadOutline, duplicateOutline, ellipsisVertical, trash } from 'ionicons/icons';
import product from '../../assets/img/Product_default.png';
import ProductDetail from './productDetail';
import edit from '../../assets/img/edit.svg';
import pricetag from '../../assets/img/price-tag.svg';
import SkeletonAward from '../common/skeleton/SkeletonAward';
import BulkProduct from '../common/BulkProduct';
import { ExcelRenderer } from 'react-excel-renderer';
import ToastCommon from '../common/ToastCommon';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import UploadCatelogModal from '../common/UploadCatelogModal';
import EmptyCatelogueErrorModal from '../common/EmptyCatelogueErrorModal';
import { useTranslation } from 'react-i18next';

function CompanyProduct(props: any) {
  const { t } = useTranslation();
  const [showModal, setShowModal] = useState(false);
  const [productList, setProductList] = useState<string[]>([]);
  const [imageList, setImagesList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [count, setCount] = useState(0);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(true);
  const [editFromshow, seteditFromShow] = useState(false);
  const [productDetailShowModal, setProductDetailShowModal] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [userFormState, setUserFormState] = useState({
    companyId: props.companyId, isActive: true
  });
  const history = useHistory();
  const [openmodal, setOpenmodal] = useState<Boolean>(false);
  const [productData, setProductData] = useState<object[]>([]);
  const [showEmptyErrorModal, setShowEmptyErrorModal] = useState<Boolean>(false);
  const [currProductId, setCurrProductId] = useState<String>('');
  const [deleteProductConfirmModal, setDeleteProductConfirmModal] = useState<boolean>(false);
  const [isSingle, setIsSingle] = useState(false)
  useEffect(() => {
    let subscriptions = true;
    if (subscriptions) {
      if (localStorage.getItem('upload')) {
        singleProductClickHandler();
      }
      productLists();
    }

    return () => {
      subscriptions = false;
    }
  }, []);
  const productLists = async () => {
    const data = await getProductDetails(0);
    if (data.length > 0) {
      const data1 = await getProductDetails(1);
      if (data1.length > 0) {
        setProductData([...data, ...data1]);
        setInfiniteDisabled(false);
        setCount(2);
      } else {
        setProductData(data);
        setInfiniteDisabled(true);
      }
      setLoading(false);
    } else {
      setProductData([]);
      setInfiniteDisabled(true);
      setLoading(false);
    }
  };

  const getProductDetails = async (page) => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/products/companies/' + props.companyId,
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();

      if (json1Response.data.content !== null) {
        return json1Response.data.content;
      } else {
        return [];
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else {
      return [];
    }
  };

  const getProductListOnScroll = async () => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/products/companies/' + props.companyId,
      'POST',
      '{"page": ' + count + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setProductData([...productData, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };

  const productEditHandler = (id: String, onHide: any) => {
    seteditFromShow(true);
    const filteredData1 = productData.filter((item) => {
      return Object.values(item).join('').toLowerCase().includes(id);
    });
    setUserFormState(filteredData1[0]);
    setProductDetailShowModal(true);
    setCurrProductId('');
    onHide();
  };

  const productDetailsHandler = (id) => {
    seteditFromShow(false);
    const filteredData1 = productData.filter((item) => {
      return Object.values(item).join('').toLowerCase().includes(id);
    });
    setUserFormState(filteredData1[0]);
    setProductDetailShowModal(true);
  };
  const deleteProduct = (id: String) => {
    const filteredData = productData.filter((item: any) => item.id !== id)
    setProductData(filteredData);
  }

  const deleteProductHandler = async () => {

    const response = await CallFor(
      'api/v1.1/product/' + currProductId,
      'DELETE',
      null,
      'Auth'
    );

    if (response.status === 200) {
      deleteProduct(currProductId);

      setShowToastMsg(t('appproperties.text392'))
      setShowToast(true)
    }
    setCurrProductId('');
    setDeleteProductConfirmModal(false);
  }

  const deleteProductClickHandler = (onHide: any) => {
    setDeleteProductConfirmModal(true);
    onHide()
  }
  function searchNext(ev: any) {
    setTimeout(() => {
      getProductListOnScroll();
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  }


  const textMethod = (text) => {
    let stringvalue = '';
    if (text !== undefined && text !== null) {
      if (text.length > 100) {
        let msg = text.slice(0, 101);
        for (let i = 101; i < text.length; i++) {
          if (text.charAt(i) !== ' ') {
            msg += text.charAt(i);
          } else {
            break;
          }
        }
        stringvalue = msg;
      } else {
        stringvalue = text.slice(0, text.length);
      }
    }
    return stringvalue;
  };
  const singleProductClickHandler = () => {
    setIsSingle(true);
    setShowModal(false)
    setImagesList([[]]);
    setProductList([{ name: '', price: '', brandName: '', minimumQty: '', paymentTerms: '', description: '', image: null, index: 0, imageCount: 0, entitiesId: props.companyId, hasError: false }]);
    setShowModal(true);
  }
  const uploadFileHandleChangeProduct = (event: any) => {
    setIsSingle(false);
    if (event.target.files.length > 0) {
      const images: any[] = [];
      const moreImgData: any[] = [];
      if (event.target.files.length <= 30) {
        for (let i = 0; i < event.target.files.length; i++) {

          if (
            !event.target.files[i].name.match(
              /\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/
            )
          ) {
            setShowModal(false);
            setShowToastMsg(t('appproperties.text397'));
            setShowToast(true);
            moreImgData.push([{ file: event.target.files[i], hasError: true, errorMsg: t('commonproperties.text1') }]);
            images.push({ name: '', price: '', brandName: '', minimumQty: '', paymentTerms: '', description: '', index: i, imageCount: 0, entitiesId: props.companyId, hasError: true });
          } else if (event.target.files[i].size > 716800) {
            setShowModal(false);
            setShowToastMsg(t('productproperties.text31'));
            moreImgData.push([{ file: event.target.files[i], hasError: true, errorMsg: t('appproperties.text391') }]);
            images.push({ name: '', price: '', brandName: '', minimumQty: '', paymentTerms: '', description: '', index: i, imageCount: 0, entitiesId: props.companyId, hasError: true });
            setShowToast(true);
          }
          else {
            moreImgData.push([{ file: event.target.files[i], hasError: false, errorMsg: '' }]);
            images.push({ name: '', price: '', brandName: '', minimumQty: '', paymentTerms: '', description: '', index: i, imageCount: 0, entitiesId: props.companyId, hasError: false });
          }
        }
      }

      setImagesList(moreImgData);
      setProductList(images);
      if (event.target.files.length > 30) {
        setShowToastMsg(t('productproperties.text30'));
        setShowToast(true);
        setShowModal(false);
      } else {
        setShowModal(true);
      }
    }

    event.target.value = null;
  };

  function fileHandler(e: any) {
    setOpenmodal(false);
    setShowEmptyErrorModal(false)
    if (e.target.files.length === 1) {
      if (e.target.files[0].name.match(/\.(xls|xlsx|csv|XLS|XLSX|CSV)$/)) {
        const fileObj = e.target.files[0];
        let data: any[] = [];
        // just pass the fileObj as parameter
        ExcelRenderer(fileObj, (err, resp) => {
          if (err) {
            setShowToastMsg(err);
            setShowToast(true);
            setShowModal(false);
          } else {
            data = resp.rows;
            const images = [];
            const moreImgData = [];
            data = emptyDataRemover(data)

            if (data.length <= 32) {
              if (data.length <= 2) {
                setShowEmptyErrorModal(true)
              } else if (data.length === 3) {

                setShowModal(true);

                for (let i = 2; i < data.length; i++) {


                  let emptyCount = 0;
                  for (let j = 0; j <= 6; j++) {
                    if (data[i][j] == undefined || String(data[i][j]).trim() == '') {
                      emptyCount++;
                    }
                  }
                  if (emptyCount < 7) {
                    moreImgData.push([]);
                    images.push({ name: data[i][1], price: data[i][2], brandName: data[i][3], minimumQty: data[i][4], paymentTerms: data[i][5], description: data[i][6], image: null, index: i, imageCount: 0, entitiesId: props.companyId, hasError: false });
                  }

                }

                setImagesList(moreImgData);
                setProductList(images);
              }
              else {
                setShowModal(true);
                for (let i = 2; i < data.length; i++) {

                  let emptyCount = 0;
                  for (let j = 0; j <= 6; j++) {
                    if (data[i][j] == undefined || String(data[i][j]).trim() == '') {
                      emptyCount++;
                    }
                  }
                  if (emptyCount < 7) {
                    moreImgData.push([]);
                    images.push({ name: data[i][1], price: data[i][2], brandName: data[i][3], minimumQty: data[i][4], paymentTerms: data[i][5], description: data[i][6], image: null, index: i, imageCount: 0, entitiesId: props.companyId });
                  }
                }
                setImagesList(moreImgData);
                setProductList(images);
              }
            } else {
              setShowToastMsg(t('productproperties.text33'));
              setShowToast(true);
              setShowModal(false);
            }
          }
        });
      } else {
        setShowToastMsg(t('productproperties.text32'))
        setShowToast(true);
        setShowModal(false);
      }

    } else {
      setShowToastMsg(t('appproperties.text270'));
      setShowToast(true);
      setShowModal(false);
    }


  };

  function emptyDataRemover(data) {
    const modifiedData = []
    for (let i = 0; i < data.length; i++) {
      let emptyCount = 0;
      for (let j = 0; j <= 7; j++) {
        if (data[i][j] == undefined || String(data[i][j]).trim() == '') {
          emptyCount++;
        }
      }

      if (emptyCount <= 7) {
        modifiedData.push(data[i])
      }

    }

    return modifiedData;
  }

  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr">
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => productEditHandler(currProductId, onHide)}
      >
        <IonIcon icon={edit} size="small" className="header-menu-img " />
        <p>{t('appproperties.text231')}</p>

      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => deleteProductClickHandler(onHide)}
      >
        <IonIcon icon={trash} size="small" className="header-menu-img " />
        <p>{t('commonproperties.text35')}</p>
      </IonItem>
    </IonList>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });

  return (
    <>
      <IonCard className="MuiPaper-rounded ion-margin-top ion-margin-bottom ion-padding-horizontal ion-no-padding ion-padding-top ion-padding-bottom ion-no-margin follower-list-card shadow-none product-catalogue">

        <IonHeader className="profile-header ion-no-border head-title-con ion-align-items-start">
          <div className="left-col-cn d-flex mb-lg-0 mb-2 align-items-center">
            {/* <IonIcon className='icon-mobile me-2 d-block d-lg-none' icon={arrowBack} onClick={() => props.setClassMobile(false)}></IonIcon> */}
            {/* <h4 className='m-0'>{t('productproperties.text25')}</h4> */}
            <h4 className='m-0 mt-2'>{t('appproperties.text95')}</h4>
          </div>
          {props.admin &&
            <div className="right-col-cn gup-btn-action mb-0 ms-auto">
              <div>
                <label
                  className="ion-no-padding ion-padding-end cursor-pointer"
                  color="dark"
                >
                  {/* <IonRow className="d-flex align-items-center link-btn-tx">
                      <IonIcon icon={cloudUploadOutline} /> <span className="mt-0 ms-1" onClick={() => setOpenmodal(true)}> {t('appproperties.text53')}</span>
                    </IonRow> */}
                  <IonRow className="d-flex align-items-center link-btn-tx">

                    <span className="mt-0 ms-1 d-flex" onClick={singleProductClickHandler}>
                    <IonIcon icon={duplicateOutline} className='me-1' />
                       {t('appproperties.text183')}</span>
                  </IonRow>
                </label>
              </div>
              <div>
                <input
                  type="file"
                  accept="image/png, image/gif, image/jpg, image/jpeg"
                  color="dark"
                  onChange={uploadFileHandleChangeProduct}
                  className="ion-text-capitalize ion-no-padding ion-padding-end upload"
                  multiple
                  id="productMultipleImage"
                ></input>
                <label
                  htmlFor="productMultipleImage"
                  className="ion-no-padding ion-padding-end cursor-pointer"
                  color="dark"
                >
                  <IonRow className="d-flex align-items-center link-btn-tx">
                    <IonIcon icon={cloudUploadOutline} /> <span className="mt-0 ms-1"> {t('appproperties.text53')}</span>
                  </IonRow>
                </label>
              </div>
            </div>}

        </IonHeader>

        {productData.length > 0 ? (

          <IonRow className="product-slider-cn scrolling productCatalouge">
            {productData.map((detail: any, i: number) => (
              <IonCol sizeMd="4" sizeXs='6' key={i} className="d-flex p-0">
                <IonCard
                  className="cursor-pointer w-100 p-0"
                >
                  {
                    (props.aboutDetails.owner || props.aboutDetails.admin) &&
                    <div
                      className='edit-award-icon d-flex ion-align-items-center ion-justify-content-center'
                    >
                      <IonIcon
                        icon={ellipsisVertical}
                        slot="start"
                        className="test report cursor-pointer"
                        onClick={(e) => {
                          present({ event: e.nativeEvent });
                          setCurrProductId(detail?.id)
                        }
                        }
                      />
                    </div>

                  }

                  <IonRow className="profileName text-center" onClick={() => productDetailsHandler(detail.id)}>
                    {detail?.logo === undefined || detail?.logo === null || detail?.logo.length === 0
                      ? (
                        <div className='catelougeImg' style={{ background: 'url(' + product + ')', height: '230px' }} />
                      )
                      : <>
                        <div className='catelougeImg' style={{ background: 'url(' + detail.logo[0] + ')', height: '230px' }} />

                      </>

                    }
                    
                    <IonCardTitle onClick={() => productDetailsHandler(detail.id)} className='text-left position-absolute d-flex align-items-center justify-content-between'>
                      <p className="title fixed-textline1 text-white p-1 font-regular">
                        {detail.productName}</p>

                        {detail.price
                        ? <div className="price me-1 mb-1">
                          <span className='align-items-center d-flex text-nowrap justify-content-center'><img src={pricetag} />{detail.price}</span>
                        </div> : ''}
                      {/* <p className="brand">{detail.brandName}</p> */}
                      {/* <p className="decription">
                        {detail.description.length >= 100
                          ? <>{textMethod(detail.description) + '...'}<a className="readmore" onClick={() => productDetailsHandler(detail.id)}> {t('commonproperties.text29')}</a></>
                          : (detail.description)}
                      </p> */}
                      
                      {/* <div className="pymode-content">
                        {detail.minimumQty ? (
                          <p>
                            {t('appproperties.text54')} :<span>{detail.minimumQty}</span>
                          </p>
                        ) : (
                          ''
                        )}
                        {detail.paymentTerms ? (
                          <p>
                            {t('productproperties.text7')} :{' '}
                            <span>{detail.paymentTerms}</span>
                          </p>
                        ) : (
                          ''
                        )}
                      </div> */}
                    </IonCardTitle>
                  </IonRow>
                </IonCard>
              </IonCol>
            ))}
            <IonInfiniteScroll
              onIonInfinite={searchNext}
              threshold="100px"
              disabled={isInfiniteDisabled}
            >
              <IonInfiniteScrollContent
                loadingSpinner="circular"
                loadingText={t('appproperties.text215')}
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </IonRow>

        ) : (
          loading ? <SkeletonAward column={3} sizeXs={6} description={true} />
            : (props.aboutDetails.owner
              ? <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text16')}</p>
              : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text50')}</p>
            )
        )}

      </IonCard>

      {deleteProductConfirmModal &&
        <IonModal
          isOpen={deleteProductConfirmModal}
          onDidDismiss={() => setDeleteProductConfirmModal(false)}
          cssClass="AddNewCatalogue Mesaage-popup"
          backdropDismiss={false}
        >
          <div className="pe-3 d-flex font-26 ion-no-padding justify-content-end  py-2 custom-modal-heading">
            <IonIcon
              icon={closeOutline}
              onClick={() => setDeleteProductConfirmModal(false)}
              className="close ion-button-color text-dark position-relative"
              slot="start"
              size="undefined"
            />
          </div>
          <IonRow className=''>
            <IonCol sizeMd="12" sizeXs="12" className='text-center mt-3'>
              {t('appproperties.text240')}
            </IonCol>

            <IonCol sizeMd="12" sizeXs="12" className='text-right mt-2 pe-3'>
              <IonButton className='button-padding' onClick={deleteProductHandler}>{t('appproperties.text241')}</IonButton>
              <IonButton className='button-padding' onClick={() => setDeleteProductConfirmModal(false)}>{t('appproperties.text242')}</IonButton>
            </IonCol>
          </IonRow>
        </IonModal>}


      {productDetailShowModal && <ProductDetail
        setProductDetailShowModal={setProductDetailShowModal}
        productDetailShowModal={productDetailShowModal}
        seteditFromShow={seteditFromShow}
        editFromshow={editFromshow}
        userFormState={userFormState}
        companyId={props.companyId}
        adminflag={props.aboutDetails.owner}
        setProductData={setProductData}
        productData={productData}
        imageList={imageList}
        setImagesList={setImagesList}
        setShowToastMsg={setShowToastMsg}
        setShowToast={setShowToast}
        showToast={showToast}
        showToastMsg={showToastMsg}
      />
      }
      {/* {showModal1
          ? <AddProducts
            setShowModal={setShowModal1}
            showModal={showModal1}
            companyId={props.companyId}
            key={Math.random()}
            productLists={productLists}
          />
          : ''} */}
      {
        showModal &&
        <BulkProduct
          setShowModal={setShowModal}
          productList={productList}
          setProductList={setProductList}
          setImagesList={setImagesList}
          imageList={imageList}
          showModal={showModal}
          companyId={props.companyId}
          userId={props.userId}
          // key ={Math.random()}
          productLists={productLists}
          setShowToast={setShowToast}
          setShowToastMsg={setShowToastMsg}
          showToast={showToast}
          showToastMsg={showToastMsg}
          setPageCount={setCount}
          addProductPage={isSingle}
          setIsSingle={setIsSingle}
        />
      }

      {showToast &&
        <ToastCommon
          setShowToast={setShowToast}
          setShowToastMsg={setShowToastMsg}
          showToast={showToast}
          showToastMsg={showToastMsg}
          duration={3000}
        />
      }

      {openmodal &&
        <UploadCatelogModal
          openModal={openmodal}
          setOpenmodal={setOpenmodal}
          fileHandler={fileHandler}
          userId={props.userId}
        />
      }

      {showEmptyErrorModal &&
        <EmptyCatelogueErrorModal
          openModal={showEmptyErrorModal}
          setOpenModal={setShowEmptyErrorModal}
          addProductShowModal={setShowModal}
          setProductList={setProductList}
          companyId={props.companyId}
          setImagesList={setImagesList}
          fileHandler={fileHandler}
        />
      }
    </>
  );
}
export default CompanyProduct;
