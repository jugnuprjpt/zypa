import { IonRow, IonLabel, IonButton, IonCol, IonSelect, IonSelectOption, IonItem, IonInput, IonCard, IonCardContent, IonIcon } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useHistory } from 'react-router';
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import CallFor from '../../../util/CallFor';
import { getlocalStore, setLocalStore } from '../../../util/Common';
import comregistration from '../../../assets/img/company-registration.svg';

import { getProfileDetails } from '../../../Redux/reducers/UserProfile';
import ToastCommon from '../../common/ToastCommon';
import PopoverCommon from '../../common/PopoverCommon';
import { useTranslation } from 'react-i18next';

const AddCompanyNew = () => {
  const { t } = useTranslation();
  const identity = [
    {
      value: 'GSTIN',
      label: 'GSTIN'
    },
    {
      value: 'PAN',
      label: t('dropdownfields.text3')
    },
    {
      value: 'UDYOG_ADHAR',
      label: t('dropdownfields.text4')
    },
    {
      value: 'UDYAM_ADHAR',
      label: t('dropdownfields.text5')
    }
  ];
  const [show, setShow] = useState(true);
  const [formState, setformState] = useState({});
  const profileDetail = useSelector(getProfileDetails);
  const [loading, setLoading] = useState(false);
  const [disabled, setdisabled] = useState(true);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const history = useHistory();
  const [nextBtn, setNextBtn] = useState(false);
  useEffect(() => {
    if (getlocalStore('companyData') !== null) {
      const identityType = document.getElementById('identityType');
      identityType.classList.add('input-fill');
      const companyData = JSON.parse(getlocalStore('companyData'));
      setformState({ identityType: companyData.identityType, identityNumber: companyData.identityNumber });
      setNextBtn(true);
    }
  }, []);
  const openDisableNullState = () => {
    setShow(true);
    setformState({});
    clearErrors();
    resetField('identityType');
    resetField('identityNumber');
  };
  const validationSchema = Yup.object().shape({
    // identityType: Yup.string().required('Identity Type is Required'),
    identityNumber: Yup.string().trim()
      .required(t('companyproperties.text28'))
      .when('identityType', {
        is: 'GSTIN',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1}/, t('companyproperties.text29'))
          .test(
            'len',
            t('companyproperties.text29'),
            (val) => val && val.toString().length >= 15
          )
          .test(
            'len',
            t('companyproperties.text29'),
            (val) => val && val.toString().length <= 15
          )
      })
      .when('identityType', {
        is: 'UDYOG_ADHAR',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[a-zA-Z]{2}[0-9]{2}[a-zA-Z][0-9]{7}/, t('companyproperties.text30'))
          .test(
            'len',
            t('companyproperties.text30'),
            (val) => val && val.toString().length >= 12
          )
          .test(
            'len',
            t('companyproperties.text30'),
            (val) => val && val.toString().length <= 12
          )
      })
      .when('identityType', {
        is: 'UDYAM_ADHAR',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[Uu]{1}[Dd]{1}[Yy]{1}[Aa]{1}[Mm]{1}[-][A-Za-z]{2}[-][0-9]{2}[-][0-9]{7}/, t('companyproperties.text31'))
          .test(
            'len',
            t('companyproperties.text31'),
            (val) => val && val.toString().length >= 19
          )
          .test(
            'len',
            t('companyproperties.text31'),
            (val) => val && val.toString().length <= 19
          )
      })
      .when('identityType', {
        is: 'PAN',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[a-zA-Z]{3}[pcftghlabjPCFTGHLABJ]{1}[a-zA-Z]{1}[0-9]{4}[a-zA-Z]{1}/, t('companyproperties.text32'))
          .test(
            'len',
            t('companyproperties.text32'),
            (val) => val && val.toString().length >= 10
          )
          .test(
            'len',
            t('companyproperties.text32'),
            (val) => val && val.toString().length <= 10
          )
      })
  });
  const {
    clearErrors,
    register,
    handleSubmit,
    setError,
    resetField,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });

  const submitHandler = async(event: any) => {
    const identityType = formState.identityType;
    const identityNumber = formState.identityNumber.toUpperCase();
    if (identityType !== undefined && identityNumber !== undefined) {
      setdisabled(true);
      setLoading(true);
      const response = await CallFor(
        'api/v1.1/verify/identity',
        'POST',
        '{"identity":"' +
        identityType +
        '","identityNumber":"' +
        identityNumber +
        '"}',
        'Auth'
      );
      if (response.status === 200) {
        const companyData = {};
        companyData.identityType = identityType;
        companyData.identityNumber = identityNumber;

        setLocalStore('companyData', JSON.stringify(companyData));
        setdisabled(false);
        setLoading(false);
        history.push('/addnewcompany/StepTwo');
      } else if (response.status === 400) {
        setdisabled(false);
        setLoading(false);
        const jsonResponse = await response.json();
        if (jsonResponse.error.errors !== null) {
          if (jsonResponse.error.errors[0].field === 'identityNumber') {
            if (
              jsonResponse.error.errors[0].message === '2'
            ) {
              setShow(false);
            }
          }
          setError(jsonResponse.error.errors[0].field, {
            message: 'Company is Already registered with you'
          });
        } else {
          setError('identityNumber', {
            message: jsonResponse.error.message
          });
        }
      } else if (response.status === 401) {
        setdisabled(false);
        setLoading(false);
        localStorage.clear();
        history.push('/login');
      }
    } else {
      setdisabled(false);
      setLoading(false);
      setError('identityType', {
        message: 'Identity Type is Required'
      });
    }
  };
  const blurHandler = () => {
    const identityType = document.getElementById('identityType').value;
    if (identityType === undefined) {
      setError('identityType', {
        type: 'required',
        message: t('commonproperties.text26')
      });
    }
  };
  const companyVerificationChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined && event.target.value !== null) {
      if (event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      if (event.target.name === 'identityType') {
        setformState({ ...formState, identityNumber: '', [event.target.name]: event.target.value });
      } else {
        setformState({ ...formState, [event.target.name]: event.target.value });
      }
      setNextBtn(false);
      localStorage.removeItem('companyData');
      localStorage.removeItem('companyDataStepThree');
    }
    const identityType = document.getElementById('identityType');
    const identityNumber = document.getElementById('identityNumber');
    if (identityType !== undefined && identityType !== null) {
      if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 15 &&
        identityType.value === 'GSTIN'
      ) {
        setdisabled(false);
      } else if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 10 &&
        identityType.value === 'PAN'
      ) {
        setdisabled(false);
      } else if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 12 &&
        identityType.value === 'UDYOG_ADHAR'
      ) {
        setdisabled(false);
      } else if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 19 &&
        identityType.value === 'UDYAM_ADHAR'
      ) {
        setdisabled(false);
      } else {
        setdisabled(true);
      }
    } else {
      setdisabled(true);
    }
    // clearErrors([event.target.name]);
  };
  const handleSearch = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      e.stopPropagation();
    }
  };
  const sendTeamRequest = async() => {
    // setLoading(true);
    const response = await CallFor(
      'api/v1.1/companies/identity/' + formState.identityNumber.toUpperCase(),
      'POST',
      null,
      'Auth'
    );
    if (response.status === 201) {
      setShowToastMsg(t('appproperties.text426'));
      setShowToast(true);
      history.push('/home');
      // setTimeout(() => {
      //   openDisableNullState();
      // }, 1000);
    } else if (response.status === 400) {
      openDisableNullState();
      const jsonResponse = await response.json();
      setShowToastMsg(jsonResponse.error.message);
      setShowToast(true);
    }
  };
  const clickHereToReport = async() => {
    const reportsData =
      '{"originId": "' + formState.identityNumber.toUpperCase() + '","origin": "COMPANY","remarks":"User entity claim." }';
    const response = await CallFor(
      'api/v1.1/spam-report',
      'POST',
      reportsData,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast24'));
      setShowToast(true);
      setTimeout(() => {
        openDisableNullState();
      }, 1000);
    }
  };
  const onNextBtnClick = () => {
    history.push('/addnewcompany/StepTwo');
  };
  return (
    <>
      <IonRow className='loginPage addcompany h-100'>
        <IonCol sizeMd="7" sizeXs="12" className='right p-lg-2 p-0 mx-auto my-0'>

          <h4 className='color-theme-dark font-16 text-center position-relative mt-3'>
            Company Registration
          </h4>
          <IonIcon
          icon={comregistration}
          className='h-25 pt-4 registration-icon text-center w-100'
          >
          </IonIcon>
          <IonCard className='shadow-none w-xl-90 w-xxl-75 w-lg-85 mx-auto w-100 border-0'>
            <IonCardContent className='mb-lg-4 px-2 py-0 px-lg-1 h-100'>
              <div className='mt-lg-4 mt-3 mb-lg-5 mb-4 d-flex ion-justify-content-center'>
                <ul className='steps d-flex mb-lg-4 mb-3'>
                  <li className='step1 text-white d-flex ion-align-items-center ion-justify-content-center'>
                    <span className='position-absolute'>{t('commonproperties.text30')}</span>
                  </li>
                  <li className='step2 text-white d-flex ion-align-items-center ion-justify-content-center'>
                  </li>
                  <li className='step3 text-white d-flex ion-align-items-center ion-justify-content-center'>
                    <span className='position-absolute'>{t('appproperties.text153')}</span>
                  </li>
                </ul>
              </div>
              {profileDetail.entityId !== undefined
                ? <>
                  {profileDetail.entityId === null
                    ? <p className='mb-3 px-3'>{t('appproperties.text369')}</p>
                    : ''}
                </>
                : ''}
              <IonRow className='stepbg stepone'>
                <div className="ion-no-margin registration-page w-100">
                  {show
                    ? <form data-testid="form-submit "
                      autoComplete="off"
                      className='w-100 h-100'
                      onSubmit={handleSubmit(submitHandler, blurHandler)}>
                      <div className="ion-no-margin px-0 w-lg-100 w-100 mx-auto">
                        <IonRow>
                          <IonCol size-md="12" size-xs="12" className='show-tooltip input-popover d-block mb-3'>
                            <div className='form-group mb-0'>
                              <div className='select-input-box'>
                                <IonSelect
                                  interface="popover"
                                  className={errors.identityType
                                    ? 'error-border select-box'
                                    : 'select-box'}
                                  onIonChange={companyVerificationChangeHandler}
                                  onIonBlur={blurHandler}
                                  value={formState.identityType}
                                  id="identityType"
                                  {...register('identityType')}
                                >
                                  {identity.map((option) => (
                                    <IonSelectOption
                                      key={option.label}
                                      value={option.value}
                                    >
                                      {option.label}
                                    </IonSelectOption>
                                  ))}
                                </IonSelect>
                                <span className='floating-label-outside'>{t('commonproperties.text37')}<sup>*</sup> </span>
                              </div>
                              <p className={errors.identityType ? 'error' : ''}>
                                {errors.identityType?.message}
                              </p>
                            </div>
                            <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text155')} />
                          </IonCol>
                          <IonCol size-md="12" size-xs="12" className='show-tooltip input-popover position-relative'>
                            <IonItem
                              className={errors.identityNumber
                                ? 'error-border form-group input-label-box mb-0'
                                : 'form-group input-label-box mb-0'}
                            >
                              <IonLabel position="floating">{' '}{t('commonproperties.text32')} <sup className='font-22'>*</sup>{' '}</IonLabel>
                              <IonInput
                                autocomplete="off"
                                type='text'
                                className='input-box ion-text-uppercase input-custom-width'
                                data-testid="identityNumber"
                                placeholder=""
                                onIonChange={companyVerificationChangeHandler}
                                value={formState.identityNumber}
                                id="identityNumber"
                                {...register('identityNumber')}
                                onKeyDown={(e) => e.key === 'Enter' && handleSearch(e)}
                                style={{ textTransform: 'uppercase' }} />
                            </IonItem>
                            <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text155')} />
                            <p className={errors.identityNumber ? 'error input-error left5' : ''}>
                              {errors.identityNumber?.message}
                            </p>
                          </IonCol>
                        </IonRow>
                      </div>
                      <IonCol className="p-0">
                          <div className="ion-text-center d-flex ion-justify-content-between px-2 pt-3">
                        <IonButton
                          disabled={disabled}
                          type="submit"
                          className="ion-button ion-button-color w-lg-25 pe-0 m-0"
                        >
                          {t('appproperties.text154')}
                          {loading
                            ? <span className="loader" id="loader-2">
                              <span></span>
                              <span></span>
                              <span></span>
                            </span>
                            : ''}
                        </IonButton>
                        {nextBtn
                          ? <IonButton
                              className="ion-button category-btn-color pe-0"
                              onClick={onNextBtnClick}
                            >
                          {t('appproperties.text435')}
                        </IonButton>
                          : '' }
                      </div>
                      </IonCol>
                    </form>
                    : <div>
                      <IonRow className='full-width-row ion-padding-top ion-padding-bottom pt-0'>
                        <IonRow>
                          <IonLabel className="MuiTypography-h6 ion-padding-start"> {t('companyproperties.text13')}</IonLabel>
                        </IonRow>
                      </IonRow>
                      <IonRow className='ion-padding-start ion-padding-end ion-padding-bottom ion-justify-content-center'>
                        <span>
                          {t('appproperties.text236a')}{profileDetail.name}{t('appproperties.text236b')}
                        </span>
                      </IonRow>
                      <IonRow className='ion-padding-start'>
                        <IonButton className="ion-button ion-button-color" onClick={sendTeamRequest}>
                          {t('appproperties.text237')}
                        </IonButton>
                      </IonRow>
                      <IonRow className='ion-padding-start ion-padding-top'>
                        <span className="error position-relative">
                          Note: {t('companyproperties.text38')} <a onClick={clickHereToReport}>{t('companyproperties.text39')}</a>.
                        </span>
                      </IonRow>
                    </div>
                  }
                </div>
              </IonRow>
              <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
            </IonCardContent>
          </IonCard>
        </IonCol>
      </IonRow>
    </>
  );
};
export default AddCompanyNew;
