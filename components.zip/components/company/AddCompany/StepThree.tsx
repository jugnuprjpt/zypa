/* eslint-disable array-callback-return */
import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardTitle,
  IonCol,
  IonContent,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonRow
} from '@ionic/react';
import AsyncSelect from 'react-select/async';
import React, { useEffect, useState } from 'react';
import CallFor from '../../../util/CallFor';
import { Controller, useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { getlocalStore, setLocalStore } from '../../../util/Common';
import { useHistory } from 'react-router';
import { checkmark, close } from 'ionicons/icons';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../../Redux/reducers/UserProfile';
import ToastCommon from '../../common/ToastCommon';
import PopoverCommon from '../../common/PopoverCommon';
import comregistration from '../../../assets/img/company-registration.svg';
import { useTranslation } from 'react-i18next';

const customStyles = {
  control: (provided: any) => ({
    ...provided,
    height: 48,
    background: '#fff !important',
    border: '1px solid #d8d8d8',
    '&:focus': {
      border: '1px solid #0763b2'
    }
  }),
  multiValue: (styles, { data }) => {
    return {
      ...styles,
      padding: 4,
      backgroundColor: '#0073ae!important',
      borderRadius: '50px'
    };
  },
  multiValueLabel: (styles, { data }) => ({
    ...styles,
    color: '#fff'
  }),
  multiValueRemove: (styles, { data }) => ({
    ...styles,
    color: '#0073ae!important',
    borderRadius: '50px',
    margin: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    ':hover': {
      backgroundColor: '#fff'
    }
  }),
  indicatorSeparator: () => { }, //
  dropdownIndicator: (defaultStyles: any) => ({
    ...defaultStyles,
    '& svg': { display: 'none' }
  })
};
const StepThree = () => {
  const { t } = useTranslation();
  const profileDetail = useSelector(getProfileDetails);
  const [companyModel, setCompanyModel] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const sales = [];
  const buys = [];
  const [companyId, setCompanyId] = useState('');
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [formState, setformState] = useState({});
  const [buySelectedValue, setBuySelectedValue] = useState([]);
  const [saveDisabled, setSaveDisabled] = useState(false);
  const history = useHistory();
  const [selectedSales, setSelectedSales] = useState([]);
  const [selectedBuys, setSelectedBuys] = useState([]);
  useEffect(() => {
    const companyData = JSON.parse(getlocalStore('companyData'));
    if (
      companyData === undefined ||
      companyData === null
    ) {
      history.push('/home');
    } else {
      const companyDataStepThree = JSON.parse(getlocalStore('companyDataStepThree'));
      if (
        companyDataStepThree === undefined ||
        companyDataStepThree === null
      ) {
        setformState({
          ...formState,
          identityType: companyData.identityType,
          identityNumber: companyData.identityNumber,
          companyName: companyData.name,
          industryTypeText: companyData.type,
          businessTypeText: companyData.natureOfBusiness
        });
      } else {
        setValue('cityName', companyDataStepThree.city);
        setValue('pincode', companyDataStepThree.firmPincode);
        // resetField('sales');
        companyDataStepThree.sales.map((sale) => {
          sales.push(sale);
        });
        setValue('sales', sales);
        setSelectedSales(companyDataStepThree.sales);
        companyDataStepThree.buys.map((buy) => {
          buys.push(buy);
        });
        setSelectedBuys(companyDataStepThree.buys);
        setformState({
          ...formState,
          identityType: companyData.identityType,
          identityNumber: companyData.identityNumber,
          companyName: companyData.name,
          industryTypeText: companyData.type,
          businessTypeText: companyData.natureOfBusiness,
          pincode: companyDataStepThree.firmPincode,
          cityName: companyDataStepThree.city
        });
      }
    }
    // setTimeout(() => {
    //   localStorage.removeItem('companyData');
    // }, 900000);
  }, []);

  const formDataChangeHandler = (value, name) => {
    if (value !== undefined && value !== null) {
      if (value !== undefined && value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setformState({
        ...formState,
        [name]: value
      });
    }
  };

  const buyHandleChange = (e) => {
    setSelectedBuys(e);
    setBuySelectedValue(Array.isArray(e) ? e.map((x) => x.value) : []);
  };

  const validationSchema = Yup.object().shape({
    pincode: Yup.string()
      .required(t('companyproperties.text20'))
      .test('typeError', t('companyproperties.text21'), (val) => Number(val))
      .test(
        'len',
        t('companyproperties.text21'),
        (val) => val && val.toString().length === 6
      ),
    cityName: Yup.string()
      .trim()
      .required(t('companyproperties.text23'))
      .matches(/^[A-Za-z-&-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('companyproperties.text24'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('userproperties.text15'),
        (val) => val && val.toString().length <= 100
      ),
    sales: Yup.array()
      .min(1, t('commonproperties.text36'))
      .of(
        Yup.object().shape({
          label: Yup.string().required(),
          value: Yup.string().required()
        })
      )
      .nullable()
      .required(t('commonproperties.text36'))
  });

  const promiseOptions = (inputValue: string) =>
    new Promise<any>((resolve) => {
      resolve(selectProducts(inputValue.trim()));
    });

  const selectProducts = async(inputValue: string) => {
    let productLists = [];
    if (inputValue.length >= 3) {
      const productsRes = await CallFor(
        'api/v1.1/searches/products/' + inputValue,
        'GET',
        null,
        'Auth'
      );
      if (productsRes.status === 200) {
        const json1Response = await productsRes.json();
        productLists = await json1Response.data.map(
          (d: { id: any; keyword: any }) => ({
            value: d.id,
            label: d.keyword
          })
        );
      } else if (productsRes.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    }
    return productLists;
  };

  const {
    register,
    handleSubmit,
    setError,
    resetField,
    control,
    setValue,
    formState: { errors, isValid }
  } = useForm({
    resolver: yupResolver(validationSchema),
    criteriaMode: 'all',
    reValidateMode: 'onTouched',
    mode: 'onChange'
  });

  const submitHandler = async(event: any) => {
    setSaveDisabled(true);
    let prodcustlist = null;
    const productsd = document.getElementsByName('sales');

    if (productsd.length > 0) {
      const sell = [];
      for (let i = 0; i < productsd.length; i++) {
        sell.push(productsd[i].value);
      }
      prodcustlist = sell;
    }

    let buys = null;

    if (buySelectedValue.length > 0) {
      buys = buySelectedValue;
    }

    let companyname = '';
    let add1 = '';
    let companycity = '';

    if (formState.companyName !== undefined && formState.companyName !== null) {
      companyname = formState.companyName.trim();
      formState.companyName = companyname;
    }

    if (
      formState.addressLine1 !== undefined &&
      formState.addressLine1 !== null
    ) {
      add1 = formState.addressLine1.trim();
      formState.addressLine1 = add1;
    }

    if (formState.cityName !== undefined && formState.cityName !== null) {
      companycity = formState.cityName.trim();
      formState.cityName = companycity;
    }

    const companyData = {
      verifiedBy: formState.identityType,
      identityNumber: formState.identityNumber,
      name: formState.companyName,
      type: formState.industryTypeText,
      natureOfBusiness: formState.businessTypeText,
      addressLine1: formState.addressLine1,
      firmPincode: formState.pincode,
      city: formState.cityName,
      sales: prodcustlist,
      buys: buys,
      countries: '101',
      userId: profileDetail.id
    };

    const data = JSON.stringify(companyData);
    const response = await CallFor(
      'api/v1.1/companies/users',
      'POST',
      data,
      'Auth'
    );
    if (response.status === 201) {
      setSaveDisabled(true);
      localStorage.removeItem('companyData');
      localStorage.removeItem('companyDataStepThree');
      const datares = await response.json();
      setCompanyId(datares.data.id);
      localStorage.setItem('upload', true);
      history.push('/catalogue/' + profileDetail.id);
    } else if (response.status === 400) {
      const datares = await response.json();
      datares.error.errors.map((details) => {
        setError(details.field, {
          type: 'server',
          message: details.message
        });
      });
      if (datares.error.errors[0].field === 'identityNumber') {
        if (
          datares.error.errors[0].message ===
          'Company is already registered with us'
        ) {
          setCompanyModel(true);
        }
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setSaveDisabled(false);
  };
  const validateIsNumericInput = (evt: { which: any; keyCode: any }) => {
    const ASCIICode = evt.which ? evt.which : evt.keyCode;
    const permittedKeys = [8, 9, 46, 37, 39, 13, 46, 116, 50];
    if (
      (ASCIICode >= 48 && ASCIICode <= 57) ||
      (ASCIICode >= 96 && ASCIICode <= 105)
    ) {
      return true;
    }
    if (permittedKeys.includes(ASCIICode)) {
      return true;
    }
    return false;
  };

  const sendTeamRequest = async() => {
    const response = await CallFor(
      'api/v1.1/company/user/request?IdentityNumber=' +
      formState.identityNumber,
      'POST',
      null,
      'Auth'
    );
    if (response.status === 201) {
      setCompanyModel(false);
      setShowToast(true);
      setShowToastMsg(t('appproperties.text262'));
      history.push('/home');
    } else if (response.status === 400) {
      setCompanyModel(false);
    }
  };

  const clickHereToReport = async() => {
    const reportsData =
      '{"originId": "' +
      formState.identityNumber.toUpperCase() +
      '","origin": "COMPANY","remarks":"User entity claim." }';
    const response = await CallFor(
      'api/v1.1/report/spam',
      'POST',
      reportsData,
      'registrationWithAuth'
    );
    if (response.status === 200) {
      setShowToastMsg(
        t('toastmessages.toast24')
      );
      setShowToast(true);
    }
  };

  const resetHandler = (event) => {
    if (event.target.name === 'identityType' && event.target.value === '') {
      resetField('identityType');
    } else if (
      event.target.name === 'identityNumber' &&
      event.target.value === ''
    ) {
      resetField('identityNumber');
    } else if (
      event.target.name === 'companyName' &&
      event.target.value === ''
    ) {
      resetField('companyName');
    } else if (
      event.target.name === 'industryTypeText' &&
      event.target.value === ''
    ) {
      resetField('industryTypeText');
    } else if (
      event.target.name === 'businessTypeText' &&
      event.target.value === ''
    ) {
      resetField('businessTypeText');
    } else if (event.target.name === 'pincode' && event.target.value === '') {
      resetField('pincode');
    } else if (event.target.name === 'cityName' && event.target.value === '') {
      resetField('cityName');
    } else if (event.target.name === 'sales' && event.target.value === '') {
      resetField('sales');
    } else if (event.target.name === 'buys' && event.target.value === '') {
      resetField('buys');
    }
  };

  const backBtn = () => {
    const companyDataStepThree = {
      firmPincode: formState.pincode,
      city: formState.cityName,
      sales: selectedSales,
      buys: selectedBuys
    };
    setLocalStore('companyDataStepThree', JSON.stringify(companyDataStepThree));
    history.push('/addnewcompany/StepTwo');
  };

  const onSelectChange = (event) => {
    // sales.push(event);
    setSelectedSales(event);
    setValue('sales', event);
  };
  return (
    <>
      {!showModal
        ? <IonRow className="loginPage addcompany steptwo h-100">
          <IonCol
            sizeMd="7"
            sizeXs="12"
            className="right p-lg-2 p-0 mx-auto my-0"
          >
            <h4 className='color-theme-dark font-16 text-center position-relative mt-3'>
            Company Registration
          </h4>
          <IonIcon
          icon={comregistration}
          className='h-25 pt-4 registration-icon text-center w-100'
          >
          </IonIcon>
            <IonCard className="shadow-none w-xl-90 w-xxl-75 w-lg-85 mx-auto w-100 border-0">
              <IonCardContent className="mb-lg-4 px-2 py-0 px-lg-1 h-100">
                <div className="mt-lg-4 mt-3 mb-lg-5 mb-4 d-flex ion-justify-content-center">
                  <ul className="steps step-3 d-flex mb-lg-4 mb-3">
                    <li className="step1 text-white d-flex ion-align-items-center ion-justify-content-center">
                      <IonIcon icon={checkmark} className="font-26" />
                      <span className="position-absolute">
                        {t('commonproperties.text30')}
                      </span>
                    </li>
                    <li className="step2 text-white d-flex ion-align-items-center ion-justify-content-center">
                      <IonIcon icon={checkmark} className="font-26" />
                    </li>
                    <li className="step3 text-white d-flex ion-align-items-center ion-justify-content-center">
                      <span className="position-absolute">
                        {t('appproperties.text153')}
                      </span>
                    </li>
                  </ul>
                </div>
                <IonRow className="stepbg stepone">
                  <div className="registration-page w-100">
                    <form
                      data-testid="form-submit"
                      autoComplete="off"
                      noValidate
                      onSubmit={handleSubmit(submitHandler)}
                    >

                      <div>
                        <IonCol col-md-12 className="p-0">
                          <IonCard className="MuiCard-root MuiPaper-rounded p-0 m-0 shadow-none">
                            <IonRow className="full-width-row">
                              <IonCol size="12" className="pb-lg-1 pb-0">
                                <IonCardTitle>
                                  <h3 className="ion-no-margin mb-2 mb-lg-0">{t('companyproperties.text3')}</h3>
                                </IonCardTitle>
                              </IonCol>
                              <IonCol
                                size-md="12"
                                size-xs="12"
                                className="input-label-box p-0"
                              >
                                <IonRow>

                                  <IonCol
                                    size-md="6"
                                    size-xs="12"
                                    className="input-label-box mb-lg-0 mb-3"
                                  >
                                    <IonItem
                                      className={
                                        errors.cityName
                                          ? 'error-border form-group input-label-box position-relative pt-0 my-0'
                                          : 'form-group input-label-box position-relative pt-0 my-0'
                                      }
                                    >
                                      <IonLabel position="floating">
                                        {' '}
                                        {t('companyproperties.text11')} <sup>*</sup>{' '}
                                      </IonLabel>
                                      <Controller
                                        name="cityName"
                                        control={control}
                                        defaultValue=""
                                        render={({ field: { value, onChange, ...field } }) => (
                                          <IonInput
                                            type="text"
                                            autocomplete="off"
                                            {...field}
                                            onIonChange={({ target: { value, name } }) => {
                                              onChange(value);
                                              formDataChangeHandler(value, name);
                                            }}
                                            onClick={resetHandler}
                                            placeholder=""
                                            className="input-box"
                                            value={formState.cityName}
                                            id="cityName"
                                            data-testid="cityName"
                                            {...register('cityName')}
                                          />
                                        )}
                                      />
                                    </IonItem>
                                    <p className={errors.cityName ? 'error' : ''}>
                                      {errors.cityName?.message}
                                    </p>
                                  </IonCol>
                                  <IonCol
                                    size-md="6"
                                    size-xs="12 "
                                    className="input-label-box mb-0"
                                  >
                                    <IonItem
                                      className={
                                        errors.pincode
                                          ? 'error-border form-group input-label-box position-relative pt-0 my-0'
                                          : 'form-group input-label-box position-relative pt-0 my-0'
                                      }
                                    >
                                      <IonLabel position="floating">
                                        {' '}
                                        {t('companyproperties.text10')} <sup>*</sup>{' '}
                                      </IonLabel>
                                      <Controller
                                        name="pincode"
                                        inputmode="numeric"
                                        pattern="[0-9]*"
                                        control={control}
                                        defaultValue=""
                                        render={({ field: { value, onChange, ...field } }) => (
                                          <IonInput
                                            type="text"
                                            pattern="[0-9]*"
                                            autocomplete="off"
                                            {...field}
                                            onIonChange={({ target: { value, name } }) => {
                                              onChange(value);
                                              formDataChangeHandler(value, name);
                                            }}
                                            onClick={resetHandler}
                                            onkeydown={validateIsNumericInput}
                                            maxlength={6}
                                            placeholder=""
                                            value={formState.pincode}
                                            className="input-box"
                                            id="pincode"
                                            data-testid="pincode"
                                            {...register('pincode')}
                                          />
                                        )}
                                      />
                                    </IonItem>
                                    <p className={errors.pincode ? 'error' : ''}>
                                      {errors.pincode?.message}
                                    </p>
                                  </IonCol>
                                </IonRow>
                              </IonCol>
                            </IonRow>
                          </IonCard>
                          <IonCard className="MuiCard-root MuiPaper-rounded p-0 pb-3 m-0 shadow-none zindex9">
                            <IonRow className="full-width-row">
                              <IonCol size="12" className="pb-0">
                                <IonCardTitle className="d-flex">
                                  <h3 className="ion-no-margin">
                                    {t('commonproperties.text7')} <sup className="mt-2">*</sup>
                                  </h3>
                                  <PopoverCommon
                                    className="popover-zyapaar"
                                    Description={t('appproperties.text163')}
                                  />
                                </IonCardTitle>
                              </IonCol>
                              <IonCol
                                size-md="12"
                                size-xs="12"
                                className="show-tooltip input-popover zindex1"
                              >
                                <Controller
                                  name="sales"
                                  control={control}
                                  render={({ field }) => (
                                    <AsyncSelect
                                      {...field}
                                      autocomplete="off"
                                      type="text"
                                      isMulti
                                      // value={selectedValue}
                                      defaultValue={sales}
                                      menuPlacement='top'
                                      autocomplete="off"
                                      className={errors.sales
                                        ? 'error-border border selectOption input-label-box borderradius8 pt-0 mb-0 customselect moreimp'
                                        : 'selectOption input-label-box borderradius6 pt-0 mb-0 customselect moreimp'
                                      }
                                      placeholder={<div className="select-placeholder-text">{t('appproperties.text180')}</div>}
                                      styles={customStyles}
                                      loadOptions={promiseOptions}
                                      onChange={onSelectChange}
                                      components={{ LoadingIndicator: null }}
                                      id="sales"
                                    />
                                  )}
                                />
                                <p className={errors.sales ? 'error input-error left5 bottom-13' : ''}>
                                  {errors.sales?.message}
                                </p>
                              </IonCol>
                            </IonRow>
                          </IonCard>
                          <IonCard className="MuiCard-root MuiPaper-rounded zindex1 p-0 pb-0 m-0 shadow-none mt-1 mb-3 zindex9">
                            <IonRow className="full-width-row">
                              <IonCol size="12" className="py-0">
                                <IonCardTitle className="d-flex">
                                  <h3 className="ion-no-margin">{t('commonproperties.text8')} </h3>
                                  <PopoverCommon
                                    className="popover-zyapaar"
                                    Description={t('appproperties.text164')}
                                  />
                                </IonCardTitle>
                              </IonCol>
                              <IonCol
                                size-md="12"
                                size-xs="12"
                                className="show-tooltip input-popover d-block"
                              >
                                <Controller
                                  name="buys"
                                  control={control}
                                  render={({ field: { value, onChange, ...field } }) => (
                                    <AsyncSelect
                                      onChange={buyHandleChange}
                                      autocomplete="off"
                                      type="text"
                                      isMulti
                                      menuPlacement='top'
                                      defaultValue={buys}
                                      autocomplete="off"
                                      className="selectOption input-label-box borderradius6 pt-0 mb-0 customselect moreimp"
                                      placeholder={<div className="select-placeholder-text">{t('appproperties.text180')}</div>}
                                      styles={customStyles}
                                      loadOptions={promiseOptions}
                                      id="buys"
                                      components={{ LoadingIndicator: null }}
                                    />
                                  )}
                                />
                                <p className={errors.buys ? 'error' : ''}>
                                  {errors.buys?.message}
                                </p>
                              </IonCol>
                            </IonRow>
                          </IonCard>
                        </IonCol>
                        <IonCol className="p-0">
                          <div className="ion-text-center d-flex ion-justify-content-between">
                            <IonButton className="ion-button category-btn-color" onClick={backBtn}>
                                {t('appproperties.text49')}
                            </IonButton>

                            <IonButton
                              disabled={saveDisabled || !isValid}
                              type="submit"
                              className="ion-button ion-button-color pe-0"
                            >
                              {t('appproperties.text158')}
                              {saveDisabled
                                ? (
                                  <span className="loader" id="loader-2">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                  </span>
                                  )
                                : (
                                    ''
                                  )}
                            </IonButton>
                          </div>
                        </IonCol>
                      </div>
                    </form>
                  </div>

                  <IonModal
                    isOpen={companyModel}
                    cssClass="small-model"
                    backdropDismiss={false}
                    onDidDismiss={() => setCompanyModel(false)}
                  >
                    <IonContent>
                      <IonRow className="full-width-row ion-padding-top ion-padding-bottom pt-0">
                        <IonRow>
                          <IonLabel className="MuiTypography-h6 ion-padding-start">
                            {' '}
                            {t('companyproperties.text13')}
                          </IonLabel>
                        </IonRow>
                        <IonButton
                          fill="clear"
                          className="ion-activatable header-row-margin-left"
                          onClick={() => setCompanyModel(false)}
                        >
                          <IonIcon
                            icon={close}
                            className="ion-button-color"
                            slot="start"
                            size="undefined"
                          />
                        </IonButton>
                      </IonRow>
                      <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom ion-justify-content-center">
                        <span>
                          Hi {profileDetail.name}, The entity is already registered by
                          another user. To join the entity team click the below button.
                        </span>
                      </IonRow>
                      <IonRow className="ion-padding-start">
                        <IonButton
                          className="ion-button ion-button-color"
                          onClick={sendTeamRequest}
                        >
                          {t('appproperties.text237')}
                        </IonButton>
                      </IonRow>
                      <IonRow className="ion-padding-start ion-padding-top">
                        <span className="error">
                          Note: {t('companyproperties.text38')}{' '}
                          <a onClick={clickHereToReport}>{t('companyproperties.text39')}</a>.
                        </span>
                      </IonRow>
                    </IonContent>
                  </IonModal>
                  <ToastCommon
                    setShowToast={setShowToast}
                    setShowToastMsg={setShowToastMsg}
                    showToast={showToast}
                    showToastMsg={showToastMsg}
                    duration={5000}
                  />
                </IonRow>
              </IonCardContent>
            </IonCard>
          </IonCol>
        </IonRow>
        : ''}
    </>
  );
};
export default StepThree;
