/* eslint-disable array-callback-return */
import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardTitle,
  IonCol,
  IonContent,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonRow,
  IonSelect,
  IonSelectOption
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import CallFor from '../../../util/CallFor';
import { Controller, useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { getlocalStore, setLocalStore } from '../../../util/Common';
import { useHistory } from 'react-router';
import { checkmark, close } from 'ionicons/icons';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../../Redux/reducers/UserProfile';
import ToastCommon from '../../common/ToastCommon';
import PopoverCommon from '../../common/PopoverCommon';
import { Link } from 'react-router-dom';
import comregistration from '../../../assets/img/company-registration.svg';
import { useTranslation } from 'react-i18next';

const StepTwo = () => {
  const { t } = useTranslation();
  const firmType = [
    {
      value: 'PROPRIETORSHIP',
      label: t('dropdownfields.text15')
    },
    {
      value: 'PARTNERSHIP_LLP',
      label: t('dropdownfields.text16')
    },
    {
      value: 'PUBLIC_LIMITED_COMPANY',
      label: t('dropdownfields.text17')
    },
    {
      value: 'PVT_LIMITED_COMPANY',
      label: t('dropdownfields.text18')
    },
    {
      value: 'TRUST',
      label: t('dropdownfields.text19')
    },
    {
      value: 'SOCIETIES',
      label: t('dropdownfields.text20')
    },
    {
      value: 'ASSOCIATIONS_CLUB',
      label: t('dropdownfields.text21')
    },
    {
      value: 'BANK_FINANCIAL_INSTITUTATION',
      label: t('dropdownfields.text22')
    },
    {
      value: 'EDUCATION_INSTUATION',
      label: t('dropdownfields.text23')
    },
    {
      value: 'GOVERNMENT_PUBLIC_SECTOR_Undertaking',
      label: t('dropdownfields.text24')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];

  const businessType = [
    {
      value: 'MANUFACTURING',
      label: t('dropdownfields.text7')
    },
    {
      value: 'TRADER',
      label: t('dropdownfields.text8')
    },
    {
      value: 'SERVICE_PROVIDER',
      label: t('dropdownfields.text9')
    },
    {
      value: 'WORKS_CONTRACT',
      label: t('dropdownfields.text10')
    },
    {
      value: 'FREELANCER',
      label: t('dropdownfields.text11')
    },
    {
      value: 'NON_PROFIT_ORGANIZATION',
      label: t('dropdownfields.text12')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];
  const profileDetail = useSelector(getProfileDetails);
  const [companyModel, setCompanyModel] = useState(false);

  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [formState, setformState] = useState({
    identityNumber: JSON.parse(getlocalStore('companyData')).identityNumber,
    identityType: JSON.parse(getlocalStore('companyData')).identityType
  });
  const history = useHistory();

  useEffect(() => {
    const companyData = JSON.parse(getlocalStore('companyData'));
    if (
      companyData === undefined ||
      companyData === null
    ) {
      history.push('/home');
    } else {
      if (companyData.type !== undefined) {
        setformState({
          ...formState,
          companyName: companyData.name,
          industryTypeText: companyData.type,
          businessTypeText: companyData.natureOfBusiness
        });
        setValue('companyName', companyData.name);
        setValue('industryTypeText', companyData.type);
        setValue('businessTypeText', companyData.natureOfBusiness);
        industryTypeText.classList.add('input-fill');
        businessTypeText.classList.add('input-fill');
        if (companyData.identityType === 'PAN') {
          const str = companyData.identityNumber;
          if ((str.substring(3, 4) === 'P')) {
            setIsDisable(false);
          } else {
            setIsDisable(true);
          }
        } else {
          setIsDisable(true);
        }
      } else {
        verifybtn();
      }
    }

    // setTimeout(() => {
    //   localStorage.removeItem('companyData');
    // }, 900000);
  }, []);

  const formDataChangeHandler = (event) => {
    if (event.target !== undefined && event.target.value !== undefined && event.target.value !== null) {
      if (event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setformState({
        ...formState,
        [event.target.name]: event.target.value
      });
    }
  };

  const validationSchema = Yup.object().shape({
    companyName: Yup.string()
      .trim()
      .required(t('commonproperties.text24'))
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length <= 200
      ),
    industryTypeText: Yup.string().required('Entity type is required'),
    businessTypeText: Yup.string().required('Nature of business is required')
  });

  const {
    register,
    handleSubmit,
    setError,
    resetField,
    control,
    setValue,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    criteriaMode: 'all',
    reValidateMode: 'onTouched',
    mode: 'onChange'
  });

  const submitHandler = () => {
    let companyname = '';
    if (formState.companyName !== undefined && formState.companyName !== null) {
      companyname = formState.companyName.trim();
      formState.companyName = companyname;
    }

    const companyData = {
      identityType: formState.identityType,
      identityNumber: formState.identityNumber,
      name: formState.companyName,
      type: formState.industryTypeText,
      natureOfBusiness: formState.businessTypeText
    };
    setLocalStore('companyData', JSON.stringify(companyData));
    history.push('/addnewcompany/StepThree');
  };
  const verifybtn = async() => {
    const response = await CallFor(
      'api/v1.1/verify/identity',
      'POST',
      '{"identity":"' +
      JSON.parse(getlocalStore('companyData')).identityType +
      '","identityNumber":"' +
      JSON.parse(getlocalStore('companyData')).identityNumber +
      '"}',
      'Auth'
    );
    if (response.status === 200) {
      const jsonResponse = await response.json();
      stateupdate(jsonResponse.data);
    } else if (response.status === 400) {
      const jsonResponse = await response.json();
      if (jsonResponse.error.errors !== null) {
        if (jsonResponse.error.errors[0].field === 'identityNumber') {
          if (
            jsonResponse.error.errors[0].message ===
            'Company is Already registered with us'
          ) {
            if (
              jsonResponse.error.errors[0].message ===
              'Company is already registered with us'
            ) {
              setCompanyModel(true);
            }
          }
        }
      } else {
        setError('identityNumber', {
          message: jsonResponse.error.message
        });
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const [isDisable, setIsDisable] = useState(false);
  const stateupdate = (data: React.SetStateAction<{}>) => {
    const companyData = {};
    // companyData.address = data.address;
    if (data.address !== null && data.address !== '') {
      if (data.address.pincode !== null && data.address.pincode !== '') {
        companyData.pincode = data.address.pincode;
        setValue('pincode', data.address.pincode);
      }
    }
    if (data.companyName !== null) {
      if (JSON.parse(getlocalStore('companyData')).identityType === 'PAN') {
        const str = JSON.parse(getlocalStore('companyData')).identityNumber;
        if ((str.substring(3, 4) === 'P')) {
          setIsDisable(false);
        } else {
          setIsDisable(true);
          companyData.companyName = data.companyName;
          setValue('companyName', data.companyName);
          setformState({ ...formState, ...companyData });
        }
      } else {
        companyData.companyName = data.companyName;
        setValue('companyName', data.companyName);
        setformState({ ...formState, ...companyData });
        setIsDisable(true);
      }
    }
  };

  const sendTeamRequest = async() => {
    const response = await CallFor(
      'api/v1.1/company/user/request?IdentityNumber=' +
      formState.identityNumber,
      'POST',
      null,
      'Auth'
    );
    if (response.status === 201) {
      setCompanyModel(false);
      setShowToast(true);
      setShowToastMsg(t('appproperties.text262'));
      history.push('/home');
    } else if (response.status === 400) {
      setCompanyModel(false);
    }
  };

  const clickHereToReport = async() => {
    const reportsData =
      '{"originId": "' +
      formState.identityNumber.toUpperCase() +
      '","origin": "COMPANY","remarks":"User entity claim." }';
    const response = await CallFor(
      'api/v1.1/report/spam',
      'POST',
      reportsData,
      'registrationWithAuth'
    );
    if (response.status === 200) {
      setShowToastMsg(
        t('toastmessages.toast24')
      );
      setShowToast(true);
    }
  };

  const businessBlurHandler = () => {
    const businessTypeText = formState.businessTypeText;
    if (businessTypeText === undefined) {
      setError('businessTypeText', {
        type: 'required',
        message: t('companyproperties.text35')
      });
    }
  };

  const blurHandler = () => {
    const industryTypeText = formState.industryTypeText;
    if (industryTypeText === undefined) {
      setError('industryTypeText', {
        type: 'required',
        message: t('commonproperties.text25')
      });
    }
  };

  const resetHandler = (event) => {
    if (event.target.name === 'identityType' && event.target.value === '') {
      resetField('identityType');
    } else if (
      event.target.name === 'identityNumber' &&
      event.target.value === ''
    ) {
      resetField('identityNumber');
    } else if (
      event.target.name === 'companyName' &&
      event.target.value === ''
    ) {
      resetField('companyName');
    } else if (
      event.target.name === 'industryTypeText' &&
      event.target.value === ''
    ) {
      resetField('industryTypeText');
    } else if (
      event.target.name === 'businessTypeText' &&
      event.target.value === ''
    ) {
      resetField('businessTypeText');
    } else if (event.target.name === 'pincode' && event.target.value === '') {
      resetField('pincode');
    } else if (event.target.name === 'cityName' && event.target.value === '') {
      resetField('cityName');
    } else if (event.target.name === 'sales' && event.target.value === '') {
      resetField('sales');
    } else if (event.target.name === 'buys' && event.target.value === '') {
      resetField('buys');
    }
  };
  const backBtn = () => {
    let companyname = '';
    if (formState.companyName !== undefined && formState.companyName !== null) {
      companyname = formState.companyName.trim();
      formState.companyName = companyname;
    }

    const companyData = {
      identityType: formState.identityType,
      identityNumber: formState.identityNumber,
      name: formState.companyName,
      type: formState.industryTypeText,
      natureOfBusiness: formState.businessTypeText
    };
    setLocalStore('companyData', JSON.stringify(companyData));
    history.push('/addnewcompany');
  };

  return (
    <>
      <IonRow className="loginPage addcompany steptwo h-100">
          <IonCol
            sizeMd="7"
            sizeXs="12"
            className="right p-lg-2 p-0 mx-auto my-0"
          >
            <h4 className='color-theme-dark font-16 text-center position-relative mt-3'>
            Company Registration
          </h4>
          <IonIcon
          icon={comregistration}
          className='h-25 pt-4 registration-icon text-center w-100'
          >
          </IonIcon>
            <IonCard className="shadow-none w-xl-90 w-xxl-75 w-lg-85 mx-auto w-100 border-0">
              <IonCardContent className="mb-lg-4 px-2 py-0 px-lg-1 h-100">
                <div className="mt-lg-4 mt-3 mb-lg-5 mb-4 d-flex ion-justify-content-center">
                  <ul className="steps step-2 d-flex mb-lg-4 mb-3">
                    <li className="step1 text-white d-flex ion-align-items-center ion-justify-content-center">
                      <IonIcon icon={checkmark} className="font-26" />
                      <span className="position-absolute">
                        {t('commonproperties.text30')}
                      </span>
                    </li>
                    <li className="step2 text-white d-flex ion-align-items-center ion-justify-content-center"></li>
                    <li className="step3 text-white d-flex ion-align-items-center ion-justify-content-center">
                      <span className="position-absolute">
                        {t('appproperties.text153')}
                      </span>
                    </li>
                  </ul>
                </div>
                <IonRow className="stepbg stepone">
                  <div className="registration-page w-100">
                    <form
                      data-testid="form-submit"
                      autoComplete="off"
                      noValidate
                      onSubmit={handleSubmit(submitHandler)}
                    >

                      <div>
                        <IonCol col-md-12 className="p-0">
                          <IonCard className="MuiCard-root MuiPaper-rounded p-0 m-0 shadow-none">
                            <IonRow className="full-width-row">
                              <IonCol size="12" className="pb-lg-1 pb-0">
                                <IonCardTitle>
                                  <h3 className="ion-no-margin mb-2 mb-lg-0">{t('companyproperties.text3')}</h3>
                                </IonCardTitle>
                              </IonCol>
                              <IonCol
                                size-md="12"
                                size-xs="12"
                                className="input-label-box p-0"
                              >
                                <IonRow>
                                  <IonCol
                                    size-md="6"
                                    size-xs="12"
                                    className="input-label-box show-tooltip input-popover mb-lg-4 mb-3 prefillData">
                                    <IonItem
                                      className={
                                        errors.companyName
                                          ? 'error-border form-group input-label-box position-relative my-0 pt-0'
                                          : 'form-group input-label-box position-relative my-0 pt-0'
                                      }
                                    >
                                      <IonLabel position="floating">
                                        {' '}
                                        {t('commonproperties.text27')} <sup>*</sup>{' '}
                                      </IonLabel>
                                      <Controller
                                        name="companyName"
                                        control={control}
                                        defaultValue=""
                                        render={({ field: { value, onChange, ...field } }) => (
                                          <IonInput
                                            type="text"
                                            disabled={isDisable}
                                            autocomplete="off"
                                            {...field}
                                            onIonChange={formDataChangeHandler}
                                            onClick={resetHandler}
                                            placeholder=""
                                            className="input-box input-custom-width"
                                            id="companyName"
                                            data-testid="companyName"
                                            value={formState.companyName}
                                            {...register('companyName')}
                                          />
                                        )}
                                      />
                                    </IonItem>
                                    <PopoverCommon
                                      className="popover-zyapaar"
                                      Description={t('appproperties.text160')}
                                    />
                                    <p className={errors.companyName ? 'error text-nowrap' : ''}>
                                      {errors.companyName?.message}
                                    </p>
                                  </IonCol>

                                  <IonCol
                                    size-md="6"
                                    size-xs="12"
                                    className=" show-tooltip input-popover d-block mb-lg-4 mb-3"
                                  >
                                    <div className="select-input-box">
                                      <Controller
                                        name="industryTypeText"
                                        control={control}
                                        defaultValue=""
                                        render={({ field: { value, onChange, ...field } }) => (
                                          <IonSelect
                                            interface="popover"
                                            {...field}
                                            onIonChange={formDataChangeHandler}
                                            value={formState.industryTypeText}
                                            onClick={resetHandler}
                                            onIonBlur={blurHandler}
                                            className={
                                              errors.industryTypeText
                                                ? 'error-border select-box'
                                                : 'select-box'
                                            }
                                            placeholder=""
                                            id="industryTypeText"
                                            data-testid="industryTypeText"
                                            {...register('industryTypeText')}
                                          >
                                            {firmType.map((option) => (
                                              <IonSelectOption
                                                key={option.value}
                                                value={option.value}
                                              >
                                                {option.label}
                                              </IonSelectOption>
                                            ))}
                                          </IonSelect>
                                        )}
                                      />
                                      <span className="floating-label-outside">
                                        {t('companyproperties.text37')}<sup>*</sup>
                                      </span>
                                    </div>
                                    <PopoverCommon
                                      className="popover-zyapaar"
                                      Description={t('appproperties.text161')}
                                    />
                                    <p className={errors.industryTypeText ? 'error' : ''}>
                                      {errors.industryTypeText?.message}
                                    </p>
                                  </IonCol>

                                  <IonCol
                                    size-md="6"
                                    size-xs="12"
                                    className=" show-tooltip input-popover d-block mb-3"
                                  >
                                    <div className="select-input-box mb-0">
                                      <Controller
                                        name="businessTypeText"
                                        control={control}
                                        defaultValue=""
                                        render={({ field: { value, onChange, ...field } }) => (
                                          <IonSelect
                                            interface="popover"
                                            {...field}
                                            onIonChange={formDataChangeHandler}
                                            value={formState.businessTypeText}
                                            onClick={resetHandler}
                                            onIonBlur={businessBlurHandler}
                                            placeholder=""
                                            className={
                                              errors.businessTypeText
                                                ? 'error-border select-box'
                                                : 'select-box'
                                            }
                                            id="businessTypeText"
                                            data-testid="businessTypeText"
                                            {...register('businessTypeText')}
                                          >
                                            {businessType.map((option) => (
                                              <IonSelectOption
                                                key={option.value}
                                                value={option.value}
                                              >
                                                {option.label}
                                              </IonSelectOption>
                                            ))}
                                          </IonSelect>
                                        )}
                                      />
                                      <span className="floating-label-outside">
                                        {t('appproperties.text179')}<sup>*</sup>
                                      </span>
                                    </div>
                                    <PopoverCommon
                                      className="popover-zyapaar"
                                      Description={t('appproperties.text162')}
                                    />
                                    <p className={errors.businessTypeText ? 'error' : ''}>
                                      {errors.businessTypeText?.message}
                                    </p>
                                  </IonCol>

                                </IonRow>
                              </IonCol>
                            </IonRow>
                          </IonCard>
                        </IonCol>
                        <IonCol className="p-0">
                          <div className="ion-text-center d-flex ion-justify-content-between">
                            <IonButton className="ion-button category-btn-color" onClick={backBtn}>
                                {t('appproperties.text49')}
                            </IonButton>

                            <IonButton
                              type="submit"
                              className="ion-button ion-button-color pe-0"
                            >
                              {t('appproperties.text435')}
                            </IonButton>
                          </div>
                        </IonCol>
                      </div>
                    </form>
                  </div>

                  <IonModal
                    isOpen={companyModel}
                    cssClass="small-model"
                    backdropDismiss={false}
                    onDidDismiss={() => setCompanyModel(false)}
                  >
                    <IonContent>
                      <IonRow className="full-width-row ion-padding-top ion-padding-bottom pt-0">
                        <IonRow>
                          <IonLabel className="MuiTypography-h6 ion-padding-start">
                            {' '}
                            {t('companyproperties.text13')}
                          </IonLabel>
                        </IonRow>
                        <IonButton
                          fill="clear"
                          className="ion-activatable header-row-margin-left"
                          onClick={() => setCompanyModel(false)}
                        >
                          <IonIcon
                            icon={close}
                            className="ion-button-color"
                            slot="start"
                            size="undefined"
                          />
                        </IonButton>
                      </IonRow>
                      <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom ion-justify-content-center">
                        <span>
                          Hi {profileDetail.name}, The entity is already registered by
                          another user. To join the entity team click the below button.
                        </span>
                      </IonRow>
                      <IonRow className="ion-padding-start">
                        <IonButton
                          className="ion-button ion-button-color"
                          onClick={sendTeamRequest}
                        >
                          {t('appproperties.text237')}
                        </IonButton>
                      </IonRow>
                      <IonRow className="ion-padding-start ion-padding-top">
                        <span className="error">
                          Note: {t('companyproperties.text38')}{' '}
                          <a onClick={clickHereToReport}>{t('companyproperties.text39')}</a>.
                        </span>
                      </IonRow>
                    </IonContent>
                  </IonModal>
                  <ToastCommon
                    setShowToast={setShowToast}
                    setShowToastMsg={setShowToastMsg}
                    showToast={showToast}
                    showToastMsg={showToastMsg}
                    duration={5000}
                  />
                </IonRow>
              </IonCardContent>
            </IonCard>
          </IonCol>
        </IonRow>
    </>
  );
};
export default StepTwo;
