/* eslint-disable no-return-assign */
/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCol,
  IonContent,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonItem,
  IonList,
  IonListHeader,
  IonPage,
  IonRow,
  useIonPopover
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router';
import callFor from '../../util/CallFor';
import AdminList from './AdminList';
import userImage from '../../assets/img/user-profile-placeholder.png';
import Footer from '../Layout/Footer';
import SkeletonComonInvitaion from '../common/skeleton/SkeletonComonInvitaion';
import { getlocalStore } from '../../util/Common';
import { type } from 'os';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import { ellipsisVertical, trashBinOutline, arrowBack, chevronForward, chevronBack } from 'ionicons/icons';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import ToastCommon from '../common/ToastCommon';
import { useTranslation } from 'react-i18next';
import MutualConnectionRow from '../common/MutualConnectionRow';
import NotAuthorizeModal from '../common/NotAuthorizeModal';

const ManageCompanyTeam = () => {
  const [loginModal, setLoginModal] = useState(false);
  const { t } = useTranslation();
  const history = useHistory();
  const profileDetail = useSelector(getProfileDetails);
  const { companyId, companyName } = useParams();
  const [loading, setLoading] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [count, setCount] = useState();
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [leaveAsAdminModel, setLeaveAsAdminModel] = useState(false);
  const [leaveAsMemberModel, setLeaveAsMemberModel] = useState(false);
  const [classMobile, setClassMobile] = useState(false);
  const [companydata, setCompanyData] = useState({
    CompanyOwner: decodeURIComponent(escape(window.atob(getlocalStore('companyOwner').replace('&quot;', '/')))),
    CompanyAdmin: decodeURIComponent(escape(window.atob(getlocalStore('companyAdmin').replace('&quot;', '/'))))
  });
  const companyinvite = () => {
    dismissManageTeam();
    history.push('/companyInvite/' + companyId + '/' + companyName);
  };

  const memberinvite = () => {
    dismissManageTeam();
    history.push('/memberinvite/' + companyId + '/' + companyName);
  };
  const [adminInvite, setAdminInvite] = useState([]);
  useEffect(async() => {
    // getinvitedlist(0, false);
    const data = await getinvited(0);
    if (data.length > 0) {
      const data1 = await getinvited(1);
      if (data1.length > 0) {
        setAdminInvite([...data, ...data1]);
        setCount(2);
      } else {
        setAdminInvite(data);
        setInfiniteDisabled(false);
      }
    } else {
      setAdminInvite([]);
      setInfiniteDisabled(false);
    }
  }, []);
  const getinvited = async(page) => {
    const response = await callFor(
      'api/v1.1/companies/' + companyId + '/ADMIN',
      // 'api/v1.1/companies/teams/invitations/' + type.toUpperCase(),
      'POST',
      '{"page":  ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        return json1Response.data.content;
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    return [];
  };
  const getinvitedlist = async(page, scrolling) => {
    if (!scrolling) {
      setLoading(true);
    }
    const response = await callFor(
      'api/v1.1/companies/' + companyId + '/ADMIN',
      // 'api/v1.1/companies/teams/invitations/' + type.toUpperCase(),
      'POST',
      '{"page":  ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (scrolling) {
        if (json1Response.data.content.length > 0) {
          setAdminInvite([
            ...adminInvite,
            ...json1Response.data.content
          ]);
        } else {
          setInfiniteDisabled(true);
        }
      } else {
        setAdminInvite(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setCount(page + 1);
    if (!scrolling) {
      setLoading(false);
    }
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getinvitedlist(count, true, type);
      ev.target.complete();
    }, 500);
  };
  const [removeAdminState, setRemoveAdminState] = useState(false);
  const [removeMemberState, setRemoveMemberState] = useState(false);
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <>
      <IonList className="my-account-pr">
        <IonItem
          lines="none"
          className="cursor-pointer"
          onClick={() =>{onHide();  setRemoveAdminState(true);  }}
        >
          <IonIcon icon={trashBinOutline} size="small" className="header-menu-img " />
          <p>{t('appproperties.text274')}</p>
        </IonItem>
        <IonItem
          lines="none"
          className="cursor-pointer"
          onClick={() =>{onHide();  setRemoveMemberState(true);  }}
        >
          <IonIcon icon={trashBinOutline} size="small" className="header-menu-img " />
          <p>{t('appproperties.text246')}</p>
        </IonItem>
      </IonList>
    </>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });

  // eslint-disable-next-line no-redeclare
  const ManageTeamPopover: React.FC<{
    onHide: () => void;
    // eslint-disable-next-line react/prop-types
  }> = ({ onHide }) => (
    <IonList lines="none">
      <IonItem>
        <div
          className="w-100 header-row-margin-left pr-0 text-dark cursor-pointer"
          onClick={memberinvite}
        >
          {t('appproperties.text194')}
        </div>
      </IonItem>
      <IonItem>
        <div
          className="w-100 header-row-margin-left pr-0 text-dark cursor-pointer"
          onClick={companyinvite}
        >
          {t('appproperties.text195')}
        </div>
      </IonItem>
      {companydata.CompanyOwner === 'false'
        ? companydata.CompanyAdmin === 'true'
          ? <>
            <IonItem>
              <div
                className="w-100 header-row-margin-left pr-0 text-dark cursor-pointer"
                // onClick={() => setLeaveAsAdminModel(true)}
                onClick={() => { setLeaveAsAdminModel(true); dismissManageTeam(); }}
              >
               {t('appproperties.text293')}
              </div>
            </IonItem>
            <IonItem>
              <div
                className="w-100 header-row-margin-left pr-0 text-dark cursor-pointer"
                onClick={() => { setLeaveAsMemberModel(true); dismissManageTeam(); }}
              >
               {t('appproperties.text282')}
              </div>
            </IonItem>
          </>
          : ''
        : ''
      }
    </IonList>
  );

  const [showManageTeam, dismissManageTeam] = useIonPopover(ManageTeamPopover, {
    onHide: () => dismissManageTeam()
  });
  // const invitationBtnHandler = async(type, requestId) => {
  //   const response = await callFor(
  //     'api/v1.1/companies/teams/invitations/' + requestId + '/' + type,
  //     'POST',
  //     null,
  //     'Auth'
  //   );
  //   if (response.status === 200) {
  //     setAdminInvite(adminInvite.filter((item) => item.requestId !== requestId));
  //   } else if (response.status === 401) {
  //     localStorage.clear();
  //     history.push('/login');
  //   }
  // };
  const leaveAsAdmin = async() => {
    const response = await callFor(
      'api/v1.1/companies/admin/leave/' + companyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast6'));
      setShowToast(true);
      setTimeout(() => {
        history.push('/companyDetail/' + companyId);
      }, 1000);
    } else if (response.status === 400) {
      const json1Response = await response.json();
      console.log(json1Response);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const leaveAsMember = async() => {
    const response = await callFor(
      'api/v1.1/companies/member/leave/' + companyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast2'));
      setShowToast(true);
      setTimeout(() => {
        history.push('/companyDetail/' + companyId);
      }, 1000);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const [removeConnectionModalData, setRemoveConnectionModalData] = useState({});
  const openThreeDot = (e, userId) => {
    present({ event: e.nativeEvent });
    const data = {};
    data.id = userId;
    setRemoveConnectionModalData(data);
    // setRemoveConnectionModal(true);
  };
  const removeAsAdmin = async() => {
    const response = await callFor(
      'api/v1.1/companies/admin/remove/' + removeConnectionModalData.id + '/' + companyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast7'));
      setShowToast(true);
      setTimeout(() => {
        history.push('/manageCompanyTeam/' + companyId + '/' + companyName);
      }, 1000);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const removeAsMember = async() => {
    const response = await callFor(
      'api/v1.1/companies/member/remove/' + removeConnectionModalData.id + '/' + companyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast1'));
      setShowToast(true);
      setTimeout(() => {
        history.push('/manageCompanyTeam/' + companyId + '/' + companyName);
      }, 1000);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const addMobileCss = () => {
    setClassMobile(true);
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  };

  const removeMobileCss = () => {
    setClassMobile(false);
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  };
  const goBackCompany = () => {
    history.push('/companyDetail/' + companyId);  
  }

  return (
    <>
      <IonRow className="plane-bg ">
        <IonRow className="container">
          <div className="row full-width-row main-page-content-row">
            <IonCol
              size-lg="4"
              size-md="12"
              size-xs="12"
              className="left-col ion-no-padding"
            >
              {/* <Notification /> */}
              <div className='sidebar-main'>
              <div className='mobile-back-screen show-mobile title-back back-with-heading position-sticky d-flex align-items-center ms-1 mt-2'> 
                <IonIcon className='icon-mobile' icon={chevronBack} onClick={goBackCompany}></IonIcon> <h3 className='m-0'>{t('appproperties.text191')}</h3>
              </div>
                <h3 className='ps-lg-3 ps-2 pb-2 dn-mobile'>{t('appproperties.text191')}</h3>
                <IonCard 
                className={classMobile ? 'showpage sdb-box profile-details left-cards no-shadow sidebar-pages data-saprate remove-connections-border p-0 m-0' : 'sdb-box profile-details left-cards no-shadow sidebar-pages data-saprater remove-connections-border p-0 m-0'}>
                  <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between dn-mobile">
                    <p className="ion-align-self-start">{t('appproperties.text193')}</p>
                  </IonHeader>
                  <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between show-mobile head-angle" onClick={addMobileCss}>
                    <p className="ion-align-self-start">{t('appproperties.text193')}</p>
                    <IonIcon className='icon-mobile' icon={chevronForward} onClick={removeMobileCss}></IonIcon>
                  </IonHeader>
                  {/* <IonHeader className="card-header-text ion-padding-start ion-padding-end card-header-text ">
                    <p className='ion-align-self-start'>Admins</p>
                    <div className="ml-auto">
                      <IonButton
                        className={
                          inviteReceivedBtnClass + ' ion-no-margin btn-sm-cn'
                        }
                        shape="round"
                        onClick={() => { getinvitedlist(0, false, 'received'); setInfiniteDisabled(false); } }
                      >
                        Admin
                      </IonButton>
                      <IonButton
                        className={
                          inviteSentBtnClass +
                          ' no-pd-r ion-no-margin btn-sm-cn '
                        }
                        shape="round"
                        onClick={() => { getinvitedlist(0, false, 'sent'); setInfiniteDisabled(false); } }
                      >
                        Team Member
                      </IonButton>
                    </div>
                  </IonHeader> */}
                  {loading
                    ? <SkeletonComonInvitaion />
                    : adminInvite.length > 0
                      ? (
                          <div className='mobile-overlay-screen  h-300 overflow-y'>
                            <div className='mobile-back-screen show-mobile title-back  back-with-heading position-sticky'>
                              <IonIcon className='icon-mobile' icon={arrowBack} onClick={removeMobileCss}></IonIcon> <h3>{t('appproperties.text193')}</h3>
                            </div>
                            {adminInvite.length > 4
                              ? <IonContent className='custom-scroll'>
                                {adminInvite.map((detail) => (
                                  <IonRow className="p-2 GroupInvitation-list-item position-relative border-bottom">
                                    <IonCol className="GroupInvitation-left-col">
                                      <div className="myprofile-feeds ion-no-padding cursor-pointer" >
                                        <IonAvatar className="MuiAvatar ion-margin-end" onClick={() => {
                                          history.push('/profile/' + detail.id);
                                        }}>
                                          {detail.img !== undefined &&
                                            detail.img !== null
                                            ? (
                                              <img onError={(ev) => { ev.target.src = userImage; }} src={detail.img} />
                                              )
                                            : (
                                              <img src={userImage} />
                                              )}
                                        </IonAvatar>
                                        <IonRow className="display-grid" onClick={() => {
                                          history.push('/profile/' + detail.id);
                                        }} >
                                          <span>{detail.name}</span>
                                          <span className="margin MuiTypography-caption group-model-text w-lg-85">
                                            {detail.designation}
                                          </span>
                                          <MutualConnectionRow id={detail.id} name={detail.name} key={detail.id}/>
                                        </IonRow>
                                        {detail.owner === true
                                          ? ''
                                          : <>{profileDetail.id !== detail.id
                                            ? <div className="dot-btn position-absolute right0">
                                              <IonIcon
                                                icon={ellipsisVertical}
                                                slot="start"
                                                className="color-theme font-20 text-grey report cursor-pointer"
                                                onClick={(e) => {
                                                  if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                                                    openThreeDot(e, detail.id);
                                                  } else {
                                                    // history.push('/addnewcompany');
                                                    setLoginModal(true);
                                                  }
                                                }
                                                }
                                              />
                                            </div>
                                            : ''}
                                          </>
                                        }
                                      </div>
                                    </IonCol>
                                  </IonRow>
                                ))}
                                <IonInfiniteScroll
                                  onIonInfinite={loadData}
                                  disabled={isInfiniteDisabled}
                                >
                                  <IonInfiniteScrollContent
                                    loadingSpinner="circular"
                                    loadingText={t('appproperties.text215')}
                                  ></IonInfiniteScrollContent>
                                </IonInfiniteScroll>
                              </IonContent>
                              : adminInvite.map((detail) => (
                                <IonRow className="p-2 GroupInvitation-list-item position-relative border-bottom">
                                  <IonRow className="GroupInvitation-left-col">
                                    <div className="myprofile-feeds ion-no-padding cursor-pointer">
                                      <IonAvatar className="MuiAvatar ion-margin-end"
                                        onClick={() => {
                                          if (detail.entityId !== undefined) {
                                            history.push('/companyDetail/' + detail.entityId);
                                          } else {
                                            history.push('/profile/' + detail.id);
                                          }
                                        }}>
                                        {detail.img !== undefined &&
                                          detail.img !== null
                                          ? (
                                            <img onError={(ev) => { ev.target.src = userImage; }} src={detail.img} />
                                            )
                                          : (
                                            <img src={userImage} />
                                            )}
                                      </IonAvatar>

                                      <IonRow className="display-grid"
                                        onClick={() => {
                                          if (detail.entityId !== undefined) {
                                            history.push('/companyDetail/' + detail.entityId);
                                          } else {
                                            history.push('/profile/' + detail.id);
                                          }
                                        }}>
                                        <span>{detail.name}</span>
                                        <span className="margin MuiTypography-caption group-model-text w-lg-85">
                                          {detail.designation}
                                          {/* {detail.userDesignation} */}
                                        </span>
                                      </IonRow>

                                      {detail.owner === true
                                        ? ''
                                        : <>{profileDetail.id !== detail.id
                                          ? <div className="dot-btn position-absolute right0">
                                            <IonIcon
                                              icon={ellipsisVertical}
                                              slot="start"
                                              className="color-theme font-20 text-grey report cursor-pointer"
                                              onClick={(e) => {
                                                if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                                                  openThreeDot(e, detail.id);
                                                } else {
                                                  // history.push('/addnewcompany');
                                                  setLoginModal(true);
                                                }
                                              }
                                              }
                                            />
                                          </div>
                                          : ''}
                                        </>
                                      }
                                    </div>
                                  </IonRow>
                                </IonRow>
                              ))}
                          </div>
                        )
                      : <>
                        <p className="p-3">
                        {t('nodatafound.text47')}
                        </p>
                      </>}

                </IonCard>
                <Footer />
              </div>
            </IonCol>
            <IonCol
              size-lg="8"
              size-md="12"
              size-xs="12"
              className="right-col ion-no-padding ion-margin-top"
            >
              <IonRow className="ion-justify-content-between ion-align-items-center mobile-pd-8 manage-admin-title">
                <h3>{t('appproperties.text192')}</h3>
                <IonButton
                  expand="block"
                  className='ion-button-color'
                  onClick={(e) =>
                    showManageTeam({
                      event: e.nativeEvent
                    })
                  }
                >
                  {t('appproperties.text191')}
                </IonButton>
              </IonRow>
              <AdminList />
            </IonCol>
          </div>
        </IonRow>
      </IonRow>
      <ConfirmModelCommon
        header={t('appproperties.text271')}
        message={t('appproperties.text272')}
        message2={t('appproperties.text273')}
        btn1={t('appproperties.text206')}
        btn2={t('appproperties.text247')}
        header={t('appproperties.text293')}
        message={t('appproperties.text272')}
        message2={t('appproperties.text273')}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text247')}
        confirmModel={leaveAsAdminModel}
        setConfirmModel={setLeaveAsAdminModel}
        deleteBtnHandler={leaveAsAdmin}
      />
      <ConfirmModelCommon
        header={t('appproperties.text282')}
        message={t('appproperties.text388')}
        message2={t('appproperties.text389')}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text247')}
        confirmModel={leaveAsMemberModel}
        setConfirmModel={setLeaveAsMemberModel}
        deleteBtnHandler={leaveAsMember}
      />
      <ConfirmModelCommon
        header={t('appproperties.text274')}
        message={t('appproperties.text385')}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text247')}
        confirmModel={removeAdminState}
        setConfirmModel={setRemoveAdminState}
        deleteBtnHandler={removeAsAdmin}
      />
      <ConfirmModelCommon
        header={t('appproperties.text246')}
        message={t('appproperties.text305')}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text247')}
        confirmModel={removeMemberState}
        setConfirmModel={setRemoveMemberState}
        deleteBtnHandler={removeAsMember}
      />
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}
    </>
  );
};
export default ManageCompanyTeam;
