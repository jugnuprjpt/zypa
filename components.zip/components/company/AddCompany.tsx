/* eslint-disable array-callback-return */
import {
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonTextarea
} from '@ionic/react';
import AsyncSelect from 'react-select/async';
import React, { useEffect, useState } from 'react';
import CallFor from '../../util/CallFor';
import { Controller, useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { getlocalStore } from '../../util/Common';
import { useHistory } from 'react-router';
import { close } from 'ionicons/icons';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import Select from 'react-select';
import Footer from '../Layout/Footer';
import ToastCommon from '../common/ToastCommon';
import PopoverCommon from '../common/PopoverCommon';
import { useTranslation } from 'react-i18next';
const customStyles = {
  control: (provided: any) => ({
    ...provided,
    height: 54,
    background: '#fff !important',
    border: '1px solid #d8d8d8',
    '&:focus': {
      border: '1px solid #0763b2'
    }
  }),
  multiValue: (styles, { data }) => {
    return {
      ...styles,
      padding: 4,
      backgroundColor: '#0073ae!important',
      borderRadius: '50px'
    };
  },
  multiValueLabel: (styles, { data }) => ({
    ...styles,
    color: '#fff'
  }),
  multiValueRemove: (styles, { data }) => ({
    ...styles,
    color: '#0073ae!important',
    borderRadius: '50px',
    margin: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    ':hover': {
      backgroundColor: '#fff'
    }
  }),
  indicatorSeparator: () => {}, //
  dropdownIndicator: (defaultStyles: any) => ({
    ...defaultStyles,
    '& svg': { display: 'none' }
  })
};
const AddCompany = () => {
  const { t } = useTranslation();
  const firmType = [
    {
      value: 'PROPRIETORSHIP',
      label: t('dropdownfields.text15')
    },
    {
      value: 'PARTNERSHIP_LLP',
      label: t('dropdownfields.text16')
    },
    {
      value: 'PUBLIC_LIMITED_COMPANY',
      label: t('dropdownfields.text17')
    },
    {
      value: 'PVT_LIMITED_COMPANY',
      label: t('dropdownfields.text18')
    },
    {
      value: 'TRUST',
      label: t('dropdownfields.text19')
    },
    {
      value: 'SOCIETIES',
      label: t('dropdownfields.text20')
    },
    {
      value: 'ASSOCIATIONS_CLUB',
      label: t('dropdownfields.text21')
    },
    {
      value: 'BANK_FINANCIAL_INSTITUTATION',
      label: t('dropdownfields.text22')
    },
    {
      value: 'EDUCATION_INSTUATION',
      label: t('dropdownfields.text23')
    },
    {
      value: 'GOVERNMENT_PUBLIC_SECTOR_Undertaking',
      label: t('dropdownfields.text24')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];

  const businessType = [
    {
      value: 'MANUFACTURING',
      label: t('dropdownfields.text7')
    },
    {
      value: 'TRADER',
      label: t('dropdownfields.text8')
    },
    {
      value: 'SERVICE_PROVIDER',
      label: t('dropdownfields.text9')
    },
    {
      value: 'WORKS_CONTRACT',
      label: t('dropdownfields.text10')
    },
    {
      value: 'FREELANCER',
      label: t('dropdownfields.text11')
    },
    {
      value: 'NON_PROFIT_ORGANIZATION',
      label: t('dropdownfields.text12')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];
  const profileDetail = useSelector(getProfileDetails);
  const [companyModel, setCompanyModel] = useState(false);
  const [stateCombo, setstate] = useState([]);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [formState, setformState] = useState({
    userMobile: profileDetail.mobileNo,
    userId: profileDetail.id,
    companyEmailId: '',
    contactNo2: null,
    designation: '',
    comments: '',
    contactNo1: null,
    addressLine2: '',
    identityType: getlocalStore('identityType'),
    identityNumber: getlocalStore('identityNumber')
  });
  const [buySelectedValue, setBuySelectedValue] = useState([]);
  const [saveDisabled, setSaveDisabled] = useState(false);
  const [characterCount, setCharacterCount] = useState(0);
  const maxCount = 500;
  const history = useHistory();

  useEffect(() => {
    comboData(101);
    if (
      getlocalStore('identityType') === undefined ||
      getlocalStore('identityType') === null ||
      getlocalStore('identityNumber') === undefined ||
      getlocalStore('identityNumber') === null
    ) {
      history.push('/home');
    }
    setTimeout(() => {
      localStorage.removeItem('identityType');
      localStorage.removeItem('identityNumber');
    }, 900000);
  }, []);
  const formDataChangeHandler = (value, name) => {
    if (value !== undefined && value !== null) {
      if (value !== undefined && value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setformState({
        ...formState,
        [name]: value
      });
    }
  };

  const stateDataChangeHandler = (event) => {
    if (event !== null && event.value !== undefined) {
      setformState({ ...formState, stateId: event.value });
    } else {
      setformState({ ...formState, stateId: null });
    }
  };

  const buyHandleChange = (e) => {
    setBuySelectedValue(Array.isArray(e) ? e.map((x) => x.value) : []);
  };

  const companyVerificationChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    setformState({ ...formState, [event.target.name]: event.target.value });
  };

  const validationSchema = Yup.object().shape({
    companyName: Yup.string()
      .trim()
      .required(t('commonproperties.text24'))
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length <= 200
      ),
    industryTypeText: Yup.string().required('Entity type is required'),
    businessTypeText: Yup.string().required('Nature of business is required'),
    addressLine1: Yup.string()
      .trim()
      .required(t('companyproperties.text16'))
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length <= 150
      ),
    companyEmailId: Yup.string().trim().email(t('commonproperties.text9')),
    contactNo1: Yup.string()
      .nullable()
      .optional()
      .test('typeError', 'Landline must be a number', (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return Number(val);
        } else {
          return true;
        }
      })
      .test('len', t('companyproperties.text18'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().length >= 6;
        } else {
          return true;
        }
      })
      .test('len', t('companyproperties.text19'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().length <= 10;
        } else {
          return true;
        }
      }),
    contactNo2: Yup.string()
      .optional()
      .nullable()
      .test('typeError', t('commonproperties.text23'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return Number(val);
        } else {
          return true;
        }
      })
      .test('len', t('commonproperties.text12'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().length >= 10;
        } else {
          return true;
        }
      })
      .test('len', 'Mobile No must be 10 digit', (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().length <= 10;
        } else {
          return true;
        }
      }),
    pincode: Yup.string()
      .required(t('companyproperties.text20'))
      .test('typeError', t('companyproperties.text21'), (val) => Number(val))
      .test(
        'len',
        t('companyproperties.text21'),
        (val) => val && val.toString().length === 6
      ),
    designation: Yup.string()
      .trim()
      .required(t('companyproperties.text22'))
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length <= 150
      ),
    cityName: Yup.string()
      .trim()
      .required(t('companyproperties.text23'))
      .matches(/^[A-Za-z-&-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('userproperties.text15'),
        (val) => val && val.toString().length <= 100
      ),
    aboutFirm: Yup.string()
      .trim()
      .required(t('companyproperties.text26'))
      .test(
        'len',
        t('companyproperties.text27'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('companyproperties.text27'),
        (val) => val && val.toString().length <= 500
      ),
    sales: Yup.array()
      .min(1, t('commonproperties.text36'))
      .of(
        Yup.object().shape({
          label: Yup.string().required(),
          value: Yup.string().required()
        })
      )
      .nullable()
      .required(t('commonproperties.text36'))
  });

  const comboData = async(companyId: string | number) => {
    const response = await CallFor(
      'api/v1.1/states/' + companyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      const states = await json1Response.data.map(
        (d: { id: any; name: any }) => ({
          value: d.id,
          label: d.name
        })
      );
      setstate(states);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  const promiseOptions = (inputValue: string) =>
    new Promise<any>((resolve) => {
      resolve(selectProducts(inputValue.trim()));
    });

  const selectProducts = async(inputValue: string) => {
    let productLists = [];
    if (inputValue.length >= 3) {
      const productsRes = await CallFor(
        'api/v1.1/searches/products/' + inputValue,
        'GET',
        null,
        'Auth'
      );
      if (productsRes.status === 200) {
        const json1Response = await productsRes.json();
        productLists = await json1Response.data.map(
          (d: { id: any; keyword: any }) => ({
            value: d.id,
            label: d.keyword
          })
        );
      } else if (productsRes.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    }
    return productLists;
  };

  const {
    register,
    handleSubmit,
    setError,
    resetField,
    control,
    formState: { errors, isValid }
  } = useForm({
    resolver: yupResolver(validationSchema),
    criteriaMode: 'all',
    reValidateMode: 'onTouched',
    mode: 'onChange'
  });

  const submitHandler = async(event: any) => {
    setSaveDisabled(true);
    let prodcustlist = null;
    const productsd = document.getElementsByName('sales');
    if (productsd.length > 0) {
      const sell = [];
      // sell = '[';
      for (let i = 0; i < productsd.length; i++) {
        sell.push(productsd[i].value);
      }
      // sell += ']';
      prodcustlist = sell;
    }
    let buys = null;
    if (buySelectedValue.length > 0) {
      // let buy = [];
      // // buy = '[';
      // buySelectedValue
      //   .join()
      //   .split(',')
      //   .map((v) => {
      //     buy += '"' + v + '",';
      //   });
      // // buy += ']';
      buys = buySelectedValue;
    }
    let contactNo1 = null;
    if (formState.contactNo1 !== null) {
      contactNo1 = formState.contactNo1;
    }
    let contactNo2 = null;
    if (formState.contactNo2 !== null) {
      contactNo2 = formState.contactNo2;
    }
    let stateId = null;
    if (formState.stateId !== null) {
      stateId = formState.stateId;
    }
    let companyname = '';
    let companyemail = '';
    let companydesignation = '';
    let add1 = '';
    let add2 = '';
    let companycity = '';
    let companyabout = '';

    if (formState.companyName !== undefined && formState.companyName !== null) {
      companyname = formState.companyName.trim();
      formState.companyName = companyname;
    }
    if (formState.designation !== undefined && formState.designation !== null) {
      companydesignation = formState.designation.trim();
      formState.designation = companydesignation;
    }
    if (
      formState.companyEmailId !== undefined &&
      formState.companyEmailId !== null
    ) {
      companyemail = formState.companyEmailId.trim();
      formState.companyEmailId = companyemail;
    }
    if (
      formState.addressLine1 !== undefined &&
      formState.addressLine1 !== null
    ) {
      add1 = formState.addressLine1.trim();
      formState.addressLine1 = add1;
    }
    if (
      formState.addressLine2 !== undefined &&
      formState.addressLine2 !== null
    ) {
      add2 = formState.addressLine2.trim();
      formState.addressLine2 = add2;
    }
    if (formState.cityName !== undefined && formState.cityName !== null) {
      companycity = formState.cityName.trim();
      formState.cityName = companycity;
    }
    if (formState.aboutFirm !== undefined && formState.aboutFirm !== null) {
      companyabout = formState.aboutFirm.trim();
      formState.aboutFirm = companyabout;
    }

    const companyData = {
      designation: formState.designation,
      contactNo1: contactNo1,
      verifiedBy: formState.identityType,
      identityNumber: formState.identityNumber,
      name: formState.companyName,
      type: formState.industryTypeText,
      natureOfBusiness: formState.businessTypeText,
      addressLine1: formState.addressLine1,
      addressLine2: formState.addressLine2,
      firmPincode: formState.pincode,
      city: formState.cityName,
      contactNo2: contactNo2,
      email: formState.companyEmailId,
      sales: prodcustlist,
      buys: buys,
      about: formState.aboutFirm,
      states: stateId,
      countries: '101',
      userMobile: profileDetail.mobileNo,
      userId: profileDetail.id
    };

    const data = JSON.stringify(companyData);
    const response = await CallFor(
      'api/v1.1/companies/users',
      'POST',
      data,
      'Auth'
    );
    if (response.status === 201) {
      setSaveDisabled(true);
      localStorage.removeItem('identityType');
      localStorage.removeItem('identityNumber');
      history.push('/');
    } else if (response.status === 400) {
      const datares = await response.json();
      datares.error.errors.map((details) => {
        setError(details.field, {
          type: 'server',
          message: details.message
        });
      });
      if (datares.error.errors[0].field === 'identityNumber') {
        if (
          datares.error.errors[0].message ===
          'Company is already registered with us'
        ) {
          setCompanyModel(true);
        }
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setSaveDisabled(false);
  };
  const validateIsNumericInput = (evt: { which: any; keyCode: any }) => {
    const ASCIICode = evt.which ? evt.which : evt.keyCode;
    const permittedKeys = [8, 9, 46, 37, 39, 13, 46, 116, 50];
    if (
      (ASCIICode >= 48 && ASCIICode <= 57) ||
      (ASCIICode >= 96 && ASCIICode <= 105)
    ) {
      return true;
    }
    if (permittedKeys.includes(ASCIICode)) {
      return true;
    }
    return false;
  };

  const sendTeamRequest = async() => {
    const response = await CallFor(
      'api/v1.1/company/user/request?IdentityNumber=' +
        formState.identityNumber,
      'POST',
      null,
      'Auth'
    );
    if (response.status === 201) {
      setCompanyModel(false);
      setShowToast(true);
      setShowToastMsg(t('appproperties.text262'));
      history.push('/login');
    } else if (response.status === 400) {
      setCompanyModel(false);
    }
  };
  const clickHereToReport = async() => {
    const reportsData =
      '{"originId": "' +
      formState.identityNumber.toUpperCase() +
      '","origin": "COMPANY","remarks":"User entity claim." }';
    const response = await CallFor(
      'api/v1.1/report/spam',
      'POST',
      reportsData,
      'registrationWithAuth'
    );
    if (response.status === 200) {
      setShowToastMsg(
        t('toastmessages.toast24')
      );
      setShowToast(true);
    }
  };

  const businessBlurHandler = () => {
    const businessTypeText = formState.businessTypeText;
    if (businessTypeText === undefined) {
      setError('businessTypeText', {
        type: 'required',
        message: t('companyproperties.text35')
      });
    }
  };

  const blurHandler = () => {
    const industryTypeText = formState.industryTypeText;
    if (industryTypeText === undefined) {
      setError('industryTypeText', {
        type: 'required',
        message: t('commonproperties.text25')
      });
    }
  };

  const aboutFirmChangeHandler = (value, name) => {
    if (value !== undefined) {
      setformState({
        ...formState,
        aboutFirm: value
      });
    }
    if (value !== undefined && value != null) {
      setCharacterCount(value.length);
    }
  };
  const resetHandler = (event) => {
    if (event.target.name === 'identityType' && event.target.value === '') {
      resetField('identityType');
    } else if (event.target.name === 'identityNumber' && event.target.value === '') {
      resetField('identityNumber');
    } else if (event.target.name === 'companyName' && event.target.value === '') {
      resetField('companyName');
    } else if (event.target.name === 'industryTypeText' && event.target.value === '') {
      resetField('industryTypeText');
    } else if (event.target.name === 'businessTypeText' && event.target.value === '') {
      resetField('businessTypeText');
    } else if (event.target.name === 'companyEmailId' && event.target.value === '') {
      resetField('companyEmailId');
    } else if (event.target.name === 'contactNo1' && event.target.value === '') {
      resetField('contactNo1');
    } else if (event.target.name === 'contactNo2' && event.target.value === '') {
      resetField('contactNo2');
    } else if (event.target.name === 'designation' && event.target.value === '') {
      resetField(t('companyproperties.text7'));
    } else if (event.target.name === 'addressLine1' && event.target.value === '') {
      resetField('addressLine1');
    } else if (event.target.name === 'addressLine2' && event.target.value === '') {
      resetField('addressLine2');
    } else if (event.target.name === 'pincode' && event.target.value === '') {
      resetField('pincode');
    } else if (event.target.name === 'stateId' && event.target.value === '') {
      resetField('stateId');
    } else if (event.target.name === 'cityName' && event.target.value === '') {
      resetField('cityName');
    } else if (event.target.name === 'sales' && event.target.value === '') {
      resetField('sales');
    } else if (event.target.name === 'buys' && event.target.value === '') {
      resetField('buys');
    } else if (event.target.name === 'aboutFirm' && event.target.value === '') {
      resetField('aboutFirm');
    }
  };
  return (
    <>
      <IonRow className="auth-screen with-header">
        <div className="auth-container company-container registration-page">
          <form
            data-testid="form-submit"
            autoComplete="off"
            noValidate
            onSubmit={handleSubmit(submitHandler)}
          >
            <div className="">
              <IonCol col-md-12>
                <IonCard className="MuiCard-root MuiPaper-rounded ">
                  <IonRow className="full-width-row">
                    <IonCol size-md="12">
                      <IonCardTitle>
                        <h3 className="ion-no-margin">{t('commonproperties.text30')}</h3>
                      </IonCardTitle>
                    </IonCol>
                    <IonCol
                      size-md="6"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <IonItem className="form-group input-label-box position-relative mb-0 pt-0">
                        <IonInput
                          className="input-box top0"
                          data-testid="identityType"
                          disabled={true}
                          placeholder={t('commonproperties.text37')}
                          onIonChange={companyVerificationChangeHandler}
                          value={formState.identityType}
                          id="identityType"
                          {...register('identityType')}
                        />
                      </IonItem>
                      <p className={errors.identityType ? 'error' : ''}>
                        {errors.identityType?.message}
                      </p>
                    </IonCol>
                    <IonCol
                      size-md="6"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <IonItem className="form-group input-label-box position-relative mb-0 pt-0">
                        <IonInput
                          className={
                            errors.identityNumber
                              ? 'error-border input-box top0'
                              : 'input-box top0'
                          }
                          data-testid="identityNumber"
                          disabled={true}
                          placeholder={t('commonproperties.text32')}
                          onIonChange={companyVerificationChangeHandler}
                          value={formState.identityNumber}
                          id="identityNumber"
                          {...register('identityNumber')}
                        />
                      </IonItem>
                      <p className={errors.identityNumber ? 'error' : ''}>
                        {errors.identityNumber?.message}
                      </p>
                    </IonCol>
                  </IonRow>
                </IonCard>
                <IonCard className="MuiCard-root MuiPaper-rounded ">
                  <IonRow className="full-width-row">
                    <IonCol size="12">
                      <IonCardTitle>
                        <h3 className="ion-no-margin">{t('companyproperties.text3')}</h3>
                      </IonCardTitle>
                    </IonCol>
                    <IonCol
                      size-md="12"
                      size-xs="12"
                      className="input-label-box pb-0"
                    >
                      <IonRow>
                        <IonCol
                          size-md="6"
                          size-xs="12"
                          className="input-label-box show-tooltip input-popover"
                        >
                          <IonItem
                            className={
                              errors.companyName
                                ? 'error-border form-group input-label-box position-relative mt-0 pt-0'
                                : 'form-group input-label-box position-relative mt-0 pt-0'
                            }
                          >
                            <IonLabel position="floating">
                              {' '}
                              {t('commonproperties.text27')}<sup>*</sup>{' '}
                            </IonLabel>
                            <Controller
                              name="companyName"
                              control={control}
                              defaultValue=""
                              render={({ field: { value, onChange, ...field } }) => (
                                <IonInput
                                  type="text"
                                  autocomplete="off"
                                  {...field}
                                  onIonChange={({ target: { value, name } }) => {
                                    onChange(value);
                                    formDataChangeHandler(value, name);
                                  }}
                                  onClick={resetHandler}
                                  placeholder=""
                                  className="input-box"
                                  id="companyName"
                                  data-testid="companyName"
                                  {...register('companyName')}
                                />
                              )}
                            />
                            <PopoverCommon
                              className="popover-zyapaar"
                              Description={t('appproperties.text160')}
                            />
                          </IonItem>
                          <p className={errors.companyName ? 'error' : ''}>
                            {errors.companyName?.message}
                          </p>
                        </IonCol>
                        <IonCol
                          size-md="6"
                          size-xs="12"
                          className=" show-tooltip input-popover d-block mb-lg-4"
                        >
                          <div className="select-input-box">
                              <Controller
                                name="industryTypeText"
                                control={control}
                                defaultValue=""
                                render={({ field: { value, onChange, ...field } }) => (
                              <IonSelect
                                interface="popover"
                                {...field}
                                onIonChange={({ target: { value, name } }) => {
                                  onChange(value);
                                  formDataChangeHandler(value, name);
                                }}
                                onClick={resetHandler}
                                onIonBlur={blurHandler}
                                placeholder=""
                                className="select-box"
                                id="industryTypeText"
                                data-testid="industryTypeText"
                                {...register('industryTypeText')}
                              >
                                {firmType.map((option) => (
                                <IonSelectOption
                                  key={option.value}
                                  value={option.value}
                                >
                                  {option.label}
                                </IonSelectOption>
                                ))}
                            </IonSelect>
                                )}
                          />
                            <span className="floating-label-outside">
                              {t('companyproperties.text37')}<sup>*</sup>
                            </span>
                            <PopoverCommon
                              className="popover-zyapaar"
                              Description={t('appproperties.text161')}
                            />
                          </div>
                          <p className={errors.industryTypeText ? 'error' : ''}>
                            {errors.industryTypeText?.message}
                          </p>
                        </IonCol>
                        <IonCol
                          size-md="6"
                          size-xs="12"
                          className=" show-tooltip input-popover d-block mb-0"
                        >
                          <div className="select-input-box mb-0">
                          <Controller
                                name="businessTypeText"
                                control={control}
                                defaultValue=""
                                render={({ field: { value, onChange, ...field } }) => (
                              <IonSelect
                                interface="popover"
                                {...field}
                                onIonChange={({ target: { value, name } }) => {
                                  onChange(value);
                                  formDataChangeHandler(value, name);
                                }}
                                onClick={resetHandler}
                                onIonBlur={businessBlurHandler}
                                placeholder=""
                                className="select-box"
                                id="businessTypeText"
                                data-testid="businessTypeText"
                                {...register('businessTypeText')}
                              >
                                {businessType.map((option) => (
                                <IonSelectOption
                                  key={option.value}
                                  value={option.value}
                                >
                                  {option.label}
                                </IonSelectOption>
                                ))}
                            </IonSelect>
                                )}
                          />
                            <span className="floating-label-outside">
                              {t('appproperties.text179')}<sup>*</sup>
                            </span>
                            <PopoverCommon
                              className="popover-zyapaar"
                              Description={t('appproperties.text162')}
                            />
                          </div>
                          <p className={errors.businessTypeText ? 'error' : ''}>
                            {errors.businessTypeText?.message}
                          </p>
                        </IonCol>
                        <IonCol
                          size-md="6"
                          size-xs="12"
                          className="input-label-box mb-0"
                        >
                          <IonItem
                            className={
                              errors.companyEmailId
                                ? 'error-border form-group input-label-box position-relative my-0 pt-0'
                                : 'form-group input-label-box position-relative my-0 pt-0'
                            }
                          >
                            <IonLabel position="floating">
                            {t('commonproperties.text33')}
                            </IonLabel>
                             <Controller
                              name="companyEmailId"
                              control={control}
                              defaultValue=""
                              render={({ field: { value, onChange, ...field } }) => (
                                <IonInput
                                  type="text"
                                  autocomplete="off"
                                  {...field}
                                  onIonChange={({ target: { value, name } }) => {
                                    onChange(value);
                                    formDataChangeHandler(value, name);
                                  }}
                                  onClick={resetHandler}
                                  placeholder=""
                                  className="input-box"
                                  id="companyEmailId"
                                  data-testid="companyEmailId"
                                  {...register('companyEmailId')}
                                />
                              )}
                            />
                          </IonItem>
                          <p
                            className={
                              errors.companyEmailId ? 'error left5' : ''
                            }
                          >
                            {errors.companyEmailId?.message}
                          </p>
                        </IonCol>
                      </IonRow>
                    </IonCol>
                    <IonCol
                      size-md="4"
                      size-xs="12"
                      className="input-label-box mb-lg-0 mb-3"
                    >
                      <IonItem
                        className={
                          errors.contactNo1
                            ? 'error-border form-group input-label-box position-relative pt-0 my-0'
                            : 'form-group input-label-box position-relative pt-0 my-0'
                        }
                      >
                        <IonLabel position="floating"> {t('companyproperties.text5')} </IonLabel>
                         <Controller
                              name="contactNo1"
                              inputmode="numeric"
                              pattern="[0-9]*"
                              control={control}
                              defaultValue=""
                              render={({ field: { value, onChange, ...field } }) => (
                                <IonInput
                                  type="text"
                                  pattern="[0-9]*"
                                  autocomplete="off"
                                  {...field}
                                  onIonChange={({ target: { value, name } }) => {
                                    onChange(value);
                                    formDataChangeHandler(value, name);
                                  }}
                                  onClick={resetHandler}
                                  onkeydown={validateIsNumericInput}
                                  maxlength={10}
                                  placeholder=""
                                  className="input-box"
                                  id="contactNo1"
                                  data-testid="contactNo1"
                                  {...register('contactNo1')}
                                />
                              )}
                            />
                      </IonItem>
                      <p className={errors.contactNo1 ? 'error left5' : ''}>
                        {errors.contactNo1?.message}
                      </p>
                    </IonCol>
                    <IonCol
                      size-md="4"
                      size-xs="12"
                      className="input-label-box mb-lg-0 mb-3"
                    >
                      <IonItem
                        className={
                          errors.contactNo2
                            ? 'error-border form-group input-label-box position-relative pt-0 my-0'
                            : 'form-group input-label-box position-relative pt-0 my-0'
                        }
                      >
                        <IonLabel position="floating">{t('userproperties.text6')}</IonLabel>
                            <Controller
                              name="contactNo2"
                              inputmode="numeric"
                              pattern="[0-9]*"
                              control={control}
                              defaultValue=""
                              render={({ field: { value, onChange, ...field } }) => (
                                <IonInput
                                  type="text"
                                  pattern="[0-9]*"
                                  autocomplete="off"
                                  {...field}
                                  onIonChange={({ target: { value, name } }) => {
                                    onChange(value);
                                    formDataChangeHandler(value, name);
                                  }}
                                  onClick={resetHandler}
                                  onkeydown={validateIsNumericInput}
                                  maxlength={10}
                                  placeholder=""
                                  className="input-box"
                                  id="contactNo2"
                                  data-testid="contactNo2"
                                  {...register('contactNo2')}
                                />
                              )}
                            />
                      </IonItem>
                      <p className={errors.contactNo2 ? 'error' : ''}>
                        {errors.contactNo2?.message}
                      </p>
                    </IonCol>
                    <IonCol
                      size-md="4"
                      size-xs="12"
                      className="input-label-box mb-lg-0 mb-3"
                    >
                      <IonItem
                        className={
                          errors.designation
                            ? 'error-border form-group input-label-box position-relative pt-0 my-0'
                            : 'form-group input-label-box position-relative pt-0 my-0'
                        }
                      >
                        <IonLabel position="floating">
                          {' '}
                          {t('companyproperties.text7')} <sup>*</sup>{' '}
                        </IonLabel>
                         <Controller
                              name="designation"
                              control={control}
                              defaultValue=""
                              render={({ field: { value, onChange, ...field } }) => (
                                <IonInput
                                  type="text"
                                  autocomplete="off"
                                  {...field}
                                  onIonChange={({ target: { value, name } }) => {
                                    onChange(value);
                                    formDataChangeHandler(value, name);
                                  }}
                                  onClick={resetHandler}
                                  placeholder=""
                                  className="input-box"
                                  id="designation"
                                  data-testid="designation"
                                  {...register('designation')}
                                />
                              )}
                            />
                      </IonItem>
                      <p className={errors.designation ? 'error' : ''}>
                        {errors.designation?.message}
                      </p>
                    </IonCol>
                  </IonRow>
                </IonCard>
                <IonCard className="MuiCard-root MuiPaper-rounded ">
                  <IonRow className="full-width-row">
                    <IonCol size="12">
                      <IonCardTitle>
                        <h3 className="ion-no-margin">Address</h3>
                      </IonCardTitle>
                    </IonCol>
                    <IonCol
                      size-md="6"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <IonItem
                        className={
                          errors.addressLine1
                            ? 'error-border form-group input-label-box position-relative pt-0 my-0'
                            : 'form-group input-label-box position-relative pt-0 my-0'
                        }
                      >
                        <IonLabel position="floating">
                          {' '}
                          {t('companyproperties.text8')} <sup>*</sup>{' '}
                        </IonLabel>
                         <Controller
                              name="addressLine1"
                              control={control}
                              defaultValue=""
                              render={({ field: { value, onChange, ...field } }) => (
                                <IonInput
                                  type="text"
                                  autocomplete="off"
                                  {...field}
                                  onIonChange={({ target: { value, name } }) => {
                                    onChange(value);
                                    formDataChangeHandler(value, name);
                                  }}
                                  onClick={resetHandler}
                                  placeholder=""
                                  className="input-box"
                                  id="addressLine1"
                                  data-testid="addressLine1"
                                  {...register('addressLine1')}
                                />
                              )}
                            />
                      </IonItem>
                      <p className={errors.addressLine1 ? 'error left5' : ''}>
                        {errors.addressLine1?.message}
                      </p>
                    </IonCol>
                    <IonCol
                      size-md="6"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <IonItem className="form-group input-label-box position-relative my-0 pt-0">
                        <IonLabel position="floating">{t('companyproperties.text9')}</IonLabel>
                         <Controller
                              name="addressLine2"
                              control={control}
                              defaultValue=""
                              render={({ field: { value, onChange, ...field } }) => (
                                <IonInput
                                  type="text"
                                  autocomplete="off"
                                  {...field}
                                  onIonChange={({ target: { value, name } }) => {
                                    onChange(value);
                                    formDataChangeHandler(value, name);
                                  }}
                                  onClick={resetHandler}
                                  placeholder=""
                                  className="input-box"
                                  id="addressLine2"
                                  data-testid="addressLine2"
                                  {...register('addressLine2')}
                                />
                              )}
                            />
                      </IonItem>
                    </IonCol>
                    <IonCol
                      size-md="4"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <IonItem
                        className={
                          errors.pincode
                            ? 'error-border form-group input-label-box position-relative pt-0 my-0'
                            : 'form-group input-label-box position-relative pt-0 my-0'
                        }
                      >
                        <IonLabel position="floating">
                          {' '}
                          {t('companyproperties.text10')} <sup>*</sup>{' '}
                        </IonLabel>
                        <Controller
                              name="pincode"
                              inputmode="numeric"
                              pattern="[0-9]*"
                              control={control}
                              defaultValue=""
                              render={({ field: { value, onChange, ...field } }) => (
                                <IonInput
                                  type="text"
                                  pattern="[0-9]*"
                                  autocomplete="off"
                                  {...field}
                                  onIonChange={({ target: { value, name } }) => {
                                    onChange(value);
                                    formDataChangeHandler(value, name);
                                  }}
                                  onClick={resetHandler}
                                  onkeydown={validateIsNumericInput}
                                  maxlength={6}
                                  placeholder=""
                                  className="input-box"
                                  id="pincode"
                                  data-testid="pincode"
                                  {...register('pincode')}
                                />
                              )}
                            />
                      </IonItem>
                      <p className={errors.pincode ? 'error' : ''}>
                        {errors.pincode?.message}
                      </p>
                    </IonCol>
                    <IonCol
                      size-md="4"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <Select
                        autocomplete="off"
                        type="text"
                        options={stateCombo}
                        className="selectOption moreimp v-imp borderradius6 form-group position-relative my-0 pt-0"
                        placeholder={t('companyproperties.text14')}
                        styles={customStyles}
                        id="stateId"
                        name="stateId"
                        onChange={stateDataChangeHandler}
                        noOptionsMessage={() => null}
                        isClearable
                      ></Select>
                      <p className={errors.stateId ? 'error' : ''}>
                        {errors.stateId?.message}
                      </p>
                    </IonCol>
                    <IonCol
                      size-md="4"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <IonItem
                        className={
                          errors.cityName
                            ? 'error-border form-group input-label-box position-relative pt-0 my-0'
                            : 'form-group input-label-box position-relative pt-0 my-0'
                        }
                      >
                        <IonLabel position="floating">
                          {' '}
                          {t('companyproperties.text11')} <sup>*</sup>{' '}
                        </IonLabel>
                        <Controller
                              name="cityName"
                              control={control}
                              defaultValue=""
                              render={({ field: { value, onChange, ...field } }) => (
                                <IonInput
                                  type="text"
                                  autocomplete="off"
                                  {...field}
                                  onIonChange={({ target: { value, name } }) => {
                                    onChange(value);
                                    formDataChangeHandler(value, name);
                                  }}
                                  onClick={resetHandler}
                                  placeholder=""
                                  className="input-box"
                                  id="cityName"
                                  data-testid="cityName"
                                  {...register('cityName')}
                                />
                              )}
                            />
                      </IonItem>
                      <p className={errors.cityName ? 'error' : ''}>
                        {errors.cityName?.message}
                      </p>
                    </IonCol>
                  </IonRow>
                </IonCard>
                <IonCard className="MuiCard-root MuiPaper-rounded ">
                  <IonRow className="full-width-row">
                    <IonCol size="12">
                      <IonCardTitle className="d-flex">
                        <h3 className="ion-no-margin">
                        {t('commonproperties.text7')} <sup className="mt-2">*</sup>
                        </h3>
                        <PopoverCommon
                          className="popover-zyapaar"
                          Description={t('appproperties.text163')}
                        />
                      </IonCardTitle>
                    </IonCol>
                    <IonCol
                      size-md="12"
                      size-xs="12"
                      className="show-tooltip input-popover d-block"
                    >
                      <Controller
                        name="sales"
                        control={control}
                        render={({ field }) => (
                          <AsyncSelect
                            {...field}
                            autocomplete="off"
                            type="text"
                            isMulti
                            autocomplete="off"
                            className="selectOption input-label-box borderradius6 pt-0 mb-0 zindex9 customselect moreimp"
                            placeholder={t('companyproperties.text15')}
                          
                            styles={customStyles}
                            loadOptions={promiseOptions}
                            components={{ LoadingIndicator: null }}
                            id="sales"
                          />
                        )}
                      />
                      <p className={errors.sales ? 'error' : ''}>
                        {errors.sales?.message}
                      </p>
                    </IonCol>
                  </IonRow>
                </IonCard>
                <IonCard className="MuiCard-root MuiPaper-rounded zindex1">
                  <IonRow className="full-width-row">
                    <IonCol size="12">
                      <IonCardTitle className="d-flex">
                        <h3 className="ion-no-margin">{t('commonproperties.text8')} </h3>
                        <PopoverCommon
                          className="popover-zyapaar"
                          Description={t('appproperties.text164')}
                        />
                      </IonCardTitle>
                    </IonCol>
                    <IonCol size-md="12" size-xs="12" className='show-tooltip input-popover d-block'>
                       <Controller
                        name="buys"
                        control={control}
                        render={({ field: { value, onChange, ...field } }) => (
                          <AsyncSelect
                          onChange={buyHandleChange}
                            autocomplete="off"
                            type="text"
                            isMulti
                            autocomplete="off"
                            className="selectOption input-label-box borderradius6 pt-0 mb-0 zindex9 customselect moreimp"
                            placeholder={t('companyproperties.text15')}
                            styles={customStyles}
                            loadOptions={promiseOptions}
                            id="buys"
                            components={{ LoadingIndicator: null }}
                          />
                        )}
                      />
                      <p className={errors.buys ? 'error' : ''}>
                        {errors.buys?.message}
                      </p>
                    </IonCol>
                  </IonRow>
                </IonCard>
                <IonCard className="MuiCard-root MuiPaper-rounded ">
                  <IonRow className="full-width-row">
                    <IonCol size="12">
                      <IonCardTitle>
                        <h3 className="ion-no-margin">
                        {t('commonproperties.text31')}<sup>*</sup>
                        </h3>
                      </IonCardTitle>
                    </IonCol>
                    <IonCol size-md="12" size-xs="12">
                      <IonItem
                        className={
                          errors.aboutFirm
                            ? 'error-border form-group input-label-box position-relative pt-0'
                            : 'form-group input-label-box position-relative pt-0'
                        }
                      >
                        <IonLabel position="floating">
                          {t('companyproperties.text12')}
                        </IonLabel>
                         <Controller
                          name="aboutFirm"
                          control={control}
                          defaultValue=""
                          render={({ field: { value, onChange, ...field } }) => (
                          <IonTextarea type='text' autocomplete='off'
                            {...field}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              aboutFirmChangeHandler(value, name);
                            }}
                            onClick={resetHandler}
                            placeholder=""
                            className='input-box'
                            id="aboutFirm"
                            rows={4}
                            maxlength={500}
                            // data-testid="name"
                            {...register('aboutFirm')} />
                          )}
                      />
                      </IonItem>
                      <p className={errors.aboutFirm ? 'error' : ''}>
                        {errors.aboutFirm?.message}
                      </p>
                      <p className="color-grey text-end font-14">
                        {characterCount}/{maxCount}
                      </p>
                    </IonCol>
                  </IonRow>
                </IonCard>
              </IonCol>
              <IonCol>
                <div className="ion-text-center mb-4">
                  <IonButton
                    disabled={saveDisabled || !isValid }
                    type="submit"
                    className="ion-button ion-button-color"
                  >
                    {t('appproperties.text64')}
                    {saveDisabled
                      ? (
                      <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                        )
                      : (
                          ''
                        )}
                  </IonButton>
                </div>
              </IonCol>
            </div>
          </form>
        </div>
        <IonModal
          isOpen={companyModel}
          cssClass="small-model"
          backdropDismiss={false}
          onDidDismiss={() => setCompanyModel(false)}
        >
          <IonContent>
            <IonRow className="full-width-row ion-padding-top ion-padding-bottom pt-0">
              <IonRow>
                <IonLabel className="MuiTypography-h6 ion-padding-start">
                  {' '}
                  {t('companyproperties.text13')}
                </IonLabel>
              </IonRow>
              <IonButton
                fill="clear"
                className="ion-activatable header-row-margin-left"
                onClick={() => setCompanyModel(false)}
              >
                <IonIcon
                  icon={close}
                  className="ion-button-color"
                  slot="start"
                  size="undefined"
                />
              </IonButton>
            </IonRow>
            <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom ion-justify-content-center">
              <span>
                Hi {profileDetail.name}, The entity is already registered by
                another user. To join the entity team click the below button.
              </span>
            </IonRow>
            <IonRow className="ion-padding-start">
              <IonButton
                className="ion-button ion-button-color"
                onClick={sendTeamRequest}
              >
               {t('appproperties.text237')}
              </IonButton>
            </IonRow>
            <IonRow className="ion-padding-start ion-padding-top">
              <span className="error">
                Note: {t('companyproperties.text38')}{' '}
                <a onClick={clickHereToReport}>{t('companyproperties.text39')}</a>.
              </span>
            </IonRow>
          </IonContent>
        </IonModal>
        <ToastCommon
          setShowToast={setShowToast}
          setShowToastMsg={setShowToastMsg}
          showToast={showToast}
          showToastMsg={showToastMsg}
          duration={5000}
        />
      </IonRow>
      <Footer />
    </>
  );
};
export default AddCompany;
