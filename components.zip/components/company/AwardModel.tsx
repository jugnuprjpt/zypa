import { IonButton, IonIcon, IonModal, IonRow } from '@ionic/react';
import { close } from 'ionicons/icons';
import React, { useState } from 'react';

const AwardModel = () => {
  const [showModal, setShowModal] = useState(false);

  return (
    <IonRow>
      <IonModal isOpen={showModal} onDidDismiss={() => setShowModal(false)}>
        <div>
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQA610EZrReTFsMcuTOiDYIh0ZPEnosQGSTTQ&usqp=CAU"
            className="model-fullimg"
          />
          <div className="edit-icon">
            <IonButton
              fill="clear"
              onClick={() => setShowModal(false)}
              className="header-row-margin-left pancil"
            >
              <IonIcon
                icon={close}
                slot="start"
                className="header-menu-account-img"
              />
            </IonButton>
          </div>
          <IonRow>
            <h2 className="hashtage-color ion-padding-start">
              <b>Top B2B Company in 2020 by Clutch</b>
            </h2>
          </IonRow>
          <IonRow className="ion-padding-start group-model-text ion-padding-end">
            <p>
              Find out which posts are a hit with Blogger’s built-in analytics.
              You’ll see where your audience is coming from and what they’re
              interested in. You can even connect your blog directly to Google
              Analytics for a more detailed look.
            </p>
            <span>
              Find out which posts are a hit with Blogger’s built-in analytics.
              You’ll see where your audience is coming from and what they’re
              interested in. You can even connect your blog directly to Google
              Analytics for a more detailed look.
            </span>
            <p>
              Find out which posts are a hit with Blogger’s built-in analytics.
              You’ll see where your audience is coming from and what they’re
              interested in. You can even connect your blog directly to Google
              Analytics for a more detailed look.
            </p>
          </IonRow>
        </div>
      </IonModal>
      <IonButton onClick={() => setShowModal(true)}>Show Modal</IonButton>
    </IonRow>
  );
};
export default AwardModel;
