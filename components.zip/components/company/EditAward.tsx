import {
  IonAvatar,
  IonButton,
  IonCol,
  IonContent,
  IonFooter,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonRow,
  IonTextarea
} from '@ionic/react';
import React, { useState } from 'react';
import CallFor from '../../util/CallFor';
import { useHistory, useParams } from 'react-router';
import { close, pencilOutline, trashBinOutline } from 'ionicons/icons';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';
import award from '../../assets/img/award.jpeg';
import edit from '../../assets/img/edit.svg';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const EditAward = (props: any) => {
  const { t } = useTranslation();
  const { companyId } = useParams();
  const history = useHistory();
  const [userFormState, setUserFormState] = useState({});
  const [file, setFile] = useState(null);
  const [updateDisabled, setUpdateDisabled] = useState(false);
  const [isValid, setIsValid] = useState(true);
  const [imageView, setImageView] = useState(false);
  const [characterCount, setCharacterCount] = useState(0);
  const maxCount = 250;
  const validationSchema = Yup.object().shape({
    title: Yup.string().trim()
      .required(t('awardproperties.text5'))
      .min(10, t('awardproperties.text6'))
      .max(100, t('userproperties.text15')),

    description: Yup.string().trim()
      .required(t('awardproperties.text8'))
      .min(10, t('awardproperties.text6'))
      .max(250, t('awardproperties.text9'))
  });
  const userformDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined) {
      if (event.target.value !== null && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setUserFormState({
        ...userFormState,
        [event.target.name]: event.target.value
      });
    }
  };

  const uploadFileHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('awardlogo', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        setIsValid(false);
      } else {
        if (event.target.files[0].size > 3145728) {
          setError('awardlogo', {
            type: 'required',
            message: t('commonproperties.text2')
          });
          setIsValid(false);
        } else {
          clearErrors('awardlogo');
          resetField('awardlogo');
          setIsValid(true);
        }
      }
      setFile(file1);
      setImageView(true);
    }
  };

  const {
    register,
    handleSubmit,
    setValue,
    resetField,
    setError,
    clearErrors,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });
  const testHandler = () => {
    const awardPhoto = document.getElementById('awardlogo');
    let isUserLogoValid = true;

    if (awardPhoto.files[0] !== undefined && awardPhoto.files[0] !== '') {
      if (awardPhoto.files[0].size > 3145728) {
        setError('awardlogo', {
          type: 'required',
          message: t('commonproperties.text2')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
      if (!awardPhoto.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('awardlogo', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
    }

    if (isUserLogoValid) {
      setIsValid(true);
      return true;
    } else {
      setIsValid(false);
      return false;
    }
  };
  const awardSubmitHandler = async() => {
    if (testHandler() && isValid) {
      setUpdateDisabled(true);
      const awardProfile = document.getElementById('awardlogo');
      const data = new FormData();
      if (awardProfile.files[0] !== undefined) {
        data.append('logo', awardProfile.files[0]);
        userFormState.img = null;
      } else {
        if (userFormState.img !== null) {
          userFormState.img = file;
        }
        data.append('logo', null);
      }
      let awardTitle = '';
      let awardDescription = '';

      if (userFormState.title !== undefined && userFormState.title !== null) {
        awardTitle = userFormState.title.trim();
        userFormState.title = awardTitle;
      }
      if (userFormState.description !== undefined && userFormState.description !== null) {
        awardDescription = userFormState.description.trim();
        userFormState.description = awardDescription;
      }
      const awardData = { companyId: companyId, id: props.awardId, title: userFormState.title, description: userFormState.description, img: userFormState.img };
      data.append('awardDto', JSON.stringify(awardData));

      const response = await CallFor(
        'api/v1.1/awards',
        'PUT',
        data,
        'authWithoutContentType'
      );
      if (response.status === 201) {
        setUpdateDisabled(true);
        const json1Response = await response.json();
        props.setEditAwardModal(false);
        const data = [];
        const scrollData = [];
        props.award.map((details) => {
          if (details.id === json1Response.data.id) {
            data.push({
              id: json1Response.data.id,
              title: json1Response.data.title,
              description: json1Response.data.description,
              companyId: json1Response.data.companyId,
              img: json1Response.data.img,
              createdOn: json1Response.data.createdOn,
              updatedOn: json1Response.data.updatedOn
            });
          } else {
            data.push(details);
          }
          return {};
        });
        props.scrollData.map((details) => {
          if (details.id === json1Response.data.id) {
            scrollData.push({
              id: json1Response.data.id,
              title: json1Response.data.title,
              description: json1Response.data.description,
              companyId: json1Response.data.companyId,
              img: json1Response.data.img,
              createdOn: json1Response.data.createdOn,
              updatedOn: json1Response.data.updatedOn
            });
          } else {
            scrollData.push(details);
          }
          return {};
        });
        props.setAwardDetail(data);
        props.setScrollData(scrollData);
        // history.push('/mediator/companyDetail/' + companyId + '/' + 1);
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else if (response.status === 400) {
        setUpdateDisabled(false);
        const datares = await response.json();
        datares.error.errors.map((details) => {
          setError(details.field, {
            type: 'server',
            message: details.message
          });
        });
      } else {
        setUpdateDisabled(false);
      }
    }
  };
  const getEditUserDetails = async() => {
    const response = await CallFor(
      'api/v1.1/awards/' + props.awardId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      console.log(json1Response);
      setUserFormState({
        id: json1Response.data.id,
        title: json1Response.data.title,
        description: json1Response.data.description
      });
      setFile(json1Response.data.img);
      const fields = ['id', 'title', 'description'];
      fields.forEach((field) => setValue(field, json1Response.data[field]));
      setImageView(true);
    }
  };
  const clear = () => {
    props.setEditAwardModal(false);
    setUpdateDisabled(false);
  };
  const imageEditHandle = () => {
    setImageView(false);
  };
  const deleteImageHandle = () => {
    // document.getElementById('groupImg').src = `${groupLogo}`;
    setIsValid(true);
    setFile(null);
    document.getElementById('awardlogo').value = '';
    clearErrors('awardlogo');
    setImageView(true);
  };
  const addImg = () => {
    setImageView(false);
  };
  // const getReachContent = (data) => {
  //   return <span dangerouslySetInnerHTML={{ __html: data.replace(/(\r\n|\r|\n)/g, '<br>') }}/>;
  // };
  const removeOverLay = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const addClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.add('imageHover');
  };
  const removeClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const descriptionChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setUserFormState({
        ...userFormState,
        description: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };
  return (
    <>
      <IonModal
        isOpen={props.EditAwardModal}
        onDidPresent={getEditUserDetails}
        cssClass="createGroupModal"
        onDidDismiss={() => clear()}
      >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6 ">
              {' '}
              {t('awardproperties.text12')} &amp; {t('awardproperties.text2')}{' '}
            </IonLabel>
            <div onClick={clear} className="close ion-no-padding cursor-pointer">
              <IonIcon
                icon={close}
                className="ion-button-color "
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <div className="modal-body">
            <form
              className="h-100"
              onSubmit={handleSubmit(awardSubmitHandler, testHandler)}
              data-testid="form-submit"
              noValidate
              autoComplete="off"
            >
              <div className="body-content">
                <IonRow className="MuiCardContent-root auth-form-width full-width-row ion-padding-horizontal">
                    <IonRow className='w-100 ion-text-center my-3'>
                      <input
                        type="file"
                        color="primary"
                        onChange={uploadFileHandleChange}
                        id="awardlogo"
                        accept="image/png, image/jpg, image/jpeg"
                        className="upload ion-padding-start"
                        disabled={imageView}
                      />
                      <label htmlFor="awardlogo" className="cursor-pointer up-img hover-avtar m-auto" id='lblupload' onClick={removeOverLay} onMouseEnter={addClass} onMouseLeave={removeClass}>
                        <IonAvatar
                          id="awardlogo"
                          slot="start"
                          className="MuiCardHeader-avatar avtar-img modal-avtar"
                        >
                          {file
                            ? (
                            <img
                              src={file}
                              className="group-img groupPhoto"
                            />
                              )
                            : (
                            <span className='svg-icon award-icon group-img'>
                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M223.7 130.8L149.1 7.77C147.1 2.949 141.9 0 136.3 0H16.03c-12.95 0-20.53 14.58-13.1 25.18l111.3 158.9C143.9 156.4 181.7 137.3 223.7 130.8zM256 160c-97.25 0-176 78.75-176 176S158.8 512 256 512s176-78.75 176-176S353.3 160 256 160zM348.5 317.3l-37.88 37l8.875 52.25c1.625 9.25-8.25 16.5-16.63 12l-46.88-24.62L209.1 418.5c-8.375 4.5-18.25-2.75-16.63-12l8.875-52.25l-37.88-37C156.6 310.6 160.5 299 169.9 297.6l52.38-7.625L245.7 242.5c2-4.25 6.125-6.375 10.25-6.375S264.2 238.3 266.2 242.5l23.5 47.5l52.38 7.625C351.6 299 355.4 310.6 348.5 317.3zM495.1 0H375.7c-5.621 0-10.83 2.949-13.72 7.77l-73.76 122.1c42 6.5 79.88 25.62 109.5 53.38l111.3-158.9C516.5 14.58 508.9 0 495.1 0z"/></svg>
                            </span>
                              )}
                        </IonAvatar>
                        <span className='addImage' onClick={addImg}></span>
                        {file
                          ? <><div className='avr-edit-del-icon'>
                                  <span className="icon edit cursor-pointer">
                                    <IonIcon icon={trashBinOutline} onClick={deleteImageHandle}/>
                                  </span>
                                  <span className="icon edit cursor-pointer">
                                    <IonIcon icon={pencilOutline} onClick={imageEditHandle}/>
                                </span>
                                </div>
                                </>
                          : ''}
                      </label>
                      <div className="error ion-text-center w-100 position-relative mt-1">
                        {errors.awardlogo?.message}
                      </div>
                  </IonRow>
                   <IonCol
                      size-md="12"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <IonItem
                        className={
                          errors.firstName
                          ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                          : 'form-group input-label-box position-relative pt-0 mb-0'
                        }
                      >
                        <IonLabel position="floating">{t('appproperties.text189')} <sup>*</sup>{' '}</IonLabel>
                        <IonInput
                          autocomplete="off"
                          type="text"
                          className={
                            errors.title ? 'error-border input-box w-full' : 'input-box w-full'
                          }
                          data-testid="title"
                          placeholder=""
                          id="title"
                          onIonChange={userformDataChangeHandler}
                          {...register('title')}
                        />
                      </IonItem>
                      <p className={errors.title ? 'error' : ''}>
                        {errors.title?.message}
                      </p>
                    </IonCol>
                    <IonCol
                      size-md="12"
                      sizeXs="12"
                       className="input-label-box"
                    >
                      <IonItem
                        className={
                          errors.firstName
                          ? 'error-border form-group input-label-box position-relative full-width-row pt-1 mb-0'
                          : 'form-group input-label-box position-relative full-width-row pt-1 mb-0'
                        }
                      >
                        <IonLabel position="floating">{t('commonproperties.text39')} <sup>*</sup>{' '}</IonLabel>
                        <IonTextarea
                          type="text"
                          className='input-box full-width-row'
                          onIonChange={descriptionChangeHandler}
                          value={userFormState.description}
                          errors={errors.description}
                          {...register('description')}
                          rows={6}
                          maxlength={250}
                          id='description'
                        />
                      </IonItem>
                      <p className={errors.description ? 'error' : ''}>
                        {errors.description?.message}
                      </p>
                      <p className='text-grey text-end font-14'>{userFormState.description !== undefined && userFormState.description !== null && userFormState.description.length > 0
                        ? userFormState.description.length
                        : characterCount}/{maxCount}
                      </p>
                    </IonCol>
                 </IonRow>
              </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
                <IonRow>
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto pr-0"
                    size="small"
                    type="submit"
                    disabled={updateDisabled}
                  >
                    {t('awardproperties.text12')} &amp;  {t('awardproperties.text2')}
                    {updateDisabled
                      ? <span className="loader" id="loader-2">
                  <span></span>
                  <span></span>
                  <span></span>
                </span>
                      : ''
                }
                  </IonButton>
                </IonRow>
              </IonFooter>
            </form>
          </div>
        </IonContent>
      </IonModal>
    </>
  );
};

export default EditAward;
