/* eslint-disable operator-linebreak */
/* eslint-disable prefer-const */
import { yupResolver } from '@hookform/resolvers/yup';
import { IonModal, IonRow, IonButton, IonIcon, IonContent, IonInput, IonCol, IonCard, IonLabel, IonTextarea } from '@ionic/react';
import { pencil, close } from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import CallFor from '../../util/CallFor';
import * as Yup from 'yup';
import award from '../../assets/img/award.jpeg';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const AwardDetail = (props: any) => {
  const { t } = useTranslation();
  const [awardData1, setAwardData1] = useState(props.formState);
  useEffect(() => {
    const fields = ['title', 'description'];
    fields.forEach(field => setValue(field, props.formState[field]));
    setFile(props.formState.img);
  }, []);
  const validationSchema = Yup.object().shape({
    title: Yup.string().required(t('awardproperties.text5'))
      .min(10, t('awardproperties.text6'))
      .max(100, t('userproperties.text15')),

    description: Yup.string().required(t('awardproperties.text8'))
      .min(10, t('awardproperties.text6'))
      .max(250, t('awardproperties.text9'))
  });
  const [file, setFile] = useState();
  const uploadProductlogoHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('companyproperties.text34')
        });
      } else {
        if (event.target.files[0].size > 3145728) {
          setError('upload', {
            type: 'required',
            message: t('commonproperties.text2')
          });
        } else {
          clearErrors('upload');
        }
      }
      setAwardData1(file1);
    }
  };

  const userformDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    setAwardData1({
      ...awardData1,
      [event.target.name]: event.target.value
    });
  };

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    clearErrors,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });

  const updateSubmitHandler = async() => {
    // const logo = document.getElementById('upload');
    // const data = new FormData();
    // if (logo.files[0] !== undefined) {
    //   data.append('logo', logo.files[0]);
    //   awardData1.logo = null;
    // } else {
    //   awardData1.logo = awardData1.img;
    //   data.append('logo', null);
    // }
    // data.append('productImage', logo.files[0]);
    // data.append('awardDto', JSON.stringify(awardData1));
    const response = await CallFor(
      'api/v1.1/awards',
      'PUT',
      JSON.stringify(awardData1),
      'Auth'
    );
    if (response.status === 201) {
      // const datares = await response.json();
      props.setAwardDetailShowModal(false);
      props.seteditFromShow(false);
    }
  };
  return (
    <IonModal isOpen={props.awardDetailShowModal} cssClass="sm-modal" onDidDismiss={() => props.setAwardDetailShowModal(false)}>
      <IonContent>
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          <IonLabel className="MuiTypography-h6">{t('awardproperties.text11')} </IonLabel>
          <div onClick={() => props.setAwardDetailShowModal(false)}
            className="close ion-no-padding cursor-pointer"
          ><IonIcon
              icon={close}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </div>
        </IonRow>
        <div className="modal-body">
          {!props.editFromshow
            ? <IonRow className='ion-padding-horizontal'>
              <IonCol size="12" className='ion-no-padding'>
                <div>
                  <IonRow className="ion-justify-content-center edit-pr-img">
                    {props.formState.img === null ||
                      props.formState.img === '' || props.formState.img === 'undefined'
                      ? (
                        <img src={award} />
                        )
                      : (
                        <img src={props.formState.img}
                        />
                        )}
                  </IonRow>
                </div>
                <IonRow className='full-width-row'>
                  <IonRow>
                    <span className="MuiTypography-body1">
                      <strong>{props.formState.title}</strong>
                    </span>
                  </IonRow>
                  <IonRow className='full-width-row'>
                    <IonLabel className="MuiTypography-body2 margin-top p_wrap">
                      {props.formState.description}
                    </IonLabel>
                  </IonRow>
                </IonRow>
              </IonCol>
            </IonRow>
            :
            ''}
        </div>
      </IonContent>
    </IonModal>
  );
};
export default AwardDetail;
