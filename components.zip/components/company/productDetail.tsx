import { yupResolver } from '@hookform/resolvers/yup';
import { IonModal, IonRow, IonButton, IonIcon, IonContent, IonCol, IonCard, IonLabel, IonTextarea, IonInput, IonFooter, IonAvatar, IonItem } from '@ionic/react';
import { add, close, closeOutline, cogSharp } from 'ionicons/icons';
import React, { useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import CallFor from '../../util/CallFor';
import * as Yup from 'yup';
import product from '../../assets/img/Product_default.png';
import rupee from '../../assets/img/Rupee-symbol.svg';
import PopoverCommon from '../common/PopoverCommon';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper';
import { useTranslation } from 'react-i18next';
import ImageGallery, { ReactImageGalleryItem } from 'react-image-gallery';

const ProductDetail = (props: any) => {
  const { t } = useTranslation();
  const [productData1, setProductData1] = useState(props.userFormState);
  const [characterCount, setCharacterCount] = useState(0);
  const [updateDisabled, setUpdateDisabled] = useState(false);
  const [moreImageModal, setMoreImageModal] = useState(false);
  const maxCount = 1000;
  const [isError, setIsError] = useState(false);
  const [showImgModal, setshowImgModal] = useState(false);
  const [photoGallery, setPhotoGallery] = useState<any>([]);
  const [selectedImgIndex, setSelectedImgIndex] = useState(0);

  useEffect(() => {
    let subscription = true;
    if (subscription) {
      setIsError(false);
      props.imageList?.map(image => {
        if (image.hasError) {
          setIsError(true);
        }
      });
    }

    return () => {
      subscription = false;
    };
  }, [props.imageList]);

  useEffect(() => {
    let subscription = true;
    if (subscription) {
      const fields = ['productName', 'price', 'brandName', 'minimumQty', 'paymentTerms', 'description'];
      fields.forEach(field => setValue(field, props.userFormState[field]));
      setFile(props.userFormState.logo);
      setImageForPreview()
    }

    return () => {
      subscription = false;
    };
  }, []);

  useEffect(() => {
    let subscription = true;
    if (subscription) {
      imageSetter();
    }
    return () => {
      subscription = false;
    };
  }, [props.userFormState.logo]);
  const setImageForPreview = () => {
    if (props.userFormState.logo?.length>0) {
      props.userFormState.logo.map((img: any) => setPhotoGallery((prev: any) => ([...prev, { original: img }])))
    }
  }
  function imageSetter() {
    if (props.setImagesList !== undefined) {
      for (let i = 0; i < props.userFormState.logo?.length; i++) {
        props.setImagesList(prev => ([...prev, { file: props.userFormState.logo[i], hasError: false, errorMsg: '' }]));
      }
    }
  }

  const numberRegex = /^[0-9.\b]+$/;
  const validationSchema = Yup.object().shape({
    productName: Yup.string().trim().required(t('productproperties.text8')).test(
      'len',
      t('productproperties.text9'),
      (val) => val && val.toString().length >= 2
    ).test(
      'len',
      t('productproperties.text10'),
      (val) => val && val.toString().length <= 150
    ),
    price: Yup.string()
      .nullable()
      .optional()
      .required(t('productproperties.text11'))
      .matches(numberRegex, t('productproperties.text12'))
      .test('typeError',
        t('productproperties.text11'),
        (val) => {
          if (val !== null && val !== '') {
            return Number(val);
          } else {
            return true;
          }
        }),
    brandName: Yup.string().nullable(true).optional().notRequired()
      .test(
        'len',
        t('productproperties.text9'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().length >= 2;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('productproperties.text10'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().length <= 150;
          } else {
            return true;
          }
        }
      ),
    minimumQty: Yup.string().required(t('productproperties.text18')).max(100, t('userproperties.text15')).trim()
      .test('typeError',
        t('groupproperties.text9'),
        (val) => {
          if (val <= 0) {
            return Number(val);
          } else {
            return true;
          }
        }),
    paymentTerms: Yup.string().trim().required(t('productproperties.text21')).test(
      'len',
      t('productproperties.text9'),
      (val) => val && val.toString().length >= 2
    ).test(
      'len',
      t('productproperties.text10'),
      (val) => val && val.toString().length <= 150
    ),
    description: Yup.string().trim().required(t('commonproperties.text34')).test(
      'len',
      t('groupproperties.text11'),
      (val) => val && val.toString().length >= 10
    ).test(
      'len',
      t('commonproperties.text21'),
      (val) => val && val.toString().length <= 1000
    )
  });
  const [file, setFile] = useState(null);

  const userformDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== null) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setProductData1({
        ...productData1,
        [event.target.name]: event.target.value
      });
    }
  };
  const {
    register,
    handleSubmit,
    setError,
    setValue,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });

  const updateSubmitHandler = async () => {
    setUpdateDisabled(true);
    const data = new FormData();
    const images: string | any | Blob = [];
    let productname = '';
    let brandname = '';
    let minqty = '';
    let price = '';
    let paymentteam = '';
    let productdescription = '';
    if (productData1.productName !== undefined && productData1.productName !== null) {
      productname = productData1.productName.trim();
      productData1.productName = productname;
    }
    if (productData1.brandName !== undefined && productData1.brandName !== null) {
      brandname = productData1.brandName.trim();
      productData1.brandName = brandname;
    }
    if (productData1.price !== undefined && productData1.price !== null) {
      price = productData1.price;
      productData1.price = price;
    }
    if (productData1.minimumQty !== undefined && productData1.minimumQty !== null) {
      minqty = productData1.minimumQty.trim();
      productData1.minimumQty = minqty;
    }
    if (productData1.paymentTerms !== undefined && productData1.paymentTerms !== null) {
      paymentteam = productData1.paymentTerms.trim();
      productData1.paymentTerms = paymentteam;
    }
    if (productData1.description !== undefined && productData1.description !== null) {
      productdescription = productData1.description.trim();
      productData1.description = productdescription;
    }
    // Handling Images for sending to the server
    // props.imageList.map(image => data.append("productImage", image.file))
    props.imageList.map(image => {
      if (typeof image.file === 'string') {
        data.append('oldImage', image.file);
      } else {
        data.append('productImage', image.file);
      }
    });

    if (props.imageList.length === 0) {
      data.append('productImage', images);
    }

    productData1.logo = [];
    data.append('dto', JSON.stringify(productData1));

    const response = await CallFor(
      'api/v1.1/products/' + productData1.id,
      'PUT',
      data,
      'authWithoutContentType'
    );
    if (response.status === 201) {
      setUpdateDisabled(true);
      const json1Response = await response.json();
      props.setProductDetailShowModal(false);
      props.seteditFromShow(false);
      const data = [];
      props.productData.map((details) => {
        if (details.id === json1Response.data.id) {
          data.push({
            id: json1Response.data.id,
            brandName: json1Response.data.brandName,
            companyId: json1Response.data.companyId,
            description: json1Response.data.description,
            price: json1Response.data.price,
            minimumQty: json1Response.data.minimumQty,
            paymentTerms: json1Response.data.paymentTerms,
            productName: json1Response.data.productName,
            logo: json1Response.data.logo,
            userId: json1Response.data.userId
          });
        } else {
          data.push(details);
        }
        return {};
      });
      props.setProductData(data);
    } else if (response.status === 400) {
      const datares = await response.json();
      if (datares.length > 0) {
        datares.map(data => props.setShowToastMsg(data.message));
      } else {
        props.setShowToastMsg(datares.error.message);
      }

      props.setShowToast(true);
      setUpdateDisabled(false);
    } else {
      setUpdateDisabled(false);
    }
    props.setImagesList([]);
  };

  const imgModalOpen = (index) => {
    setSelectedImgIndex(index);
    setshowImgModal(true);

  };

  const descriptionChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setProductData1({
        ...productData1,
        description: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };

  const getPhotoUrl = (img: any) => {
    if (img.file !== undefined) {
      return URL.createObjectURL(img.file);
    } else {
      return '';
    }
  };

  const deleteImage = (index) => {
    props.setImagesList(props.imageList.filter((img, i) => i !== index));
  };

  const uploadMoreImages = (event: { target: { files: string | any[]; }; }) => {
    if (event.target.files.length > 0) {
      const images: any = [];

      images.push(...props.imageList);

      const imgLength = (images?.length) + (event.target.files.length);
      if (imgLength <= 5) {
        for (let i = 0; i < event.target.files.length; i++) {
          if (!event.target.files[i].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
            images.push({ file: event.target.files[i], hasError: true, errorMsg: t('appproperties.text397') });
          } else if (event.target.files[i].size > 716800) {
            images.push({ file: event.target.files[i], hasError: true, errorMsg: t('appproperties.text391') });
          } else {
            images.push({ file: event.target.files[i], hasError: false, errorMsg: '' });
          }

          props.setImagesList(images);
        }
      } else {
        props.setShowToastMsg('Can not upload product more than 5');
        props.setShowToast(true);
        setMoreImageModal(false);
      }
    }
  };
  return (<>
    <IonModal cssClass="product-edit-modal" backdropDismiss={false} isOpen={props.productDetailShowModal} id="catalogue-detail">
      <div className='overflow-auto'>
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between poroduct-detail-header-sticky">
          <IonLabel className="MuiTypography-h6"> {!props.editFromshow
            ? t('appproperties.text327')
            : t('appproperties.text52')}</IonLabel>
          <div
            onClick={() => { props.setProductDetailShowModal(false); if (props.setImagesList !== undefined) { props.setImagesList([]); } }}
            className="close ion-no-padding cursor-pointer pt-0"
          >
            <IonIcon
              icon={close}
              className="ion-button-color pr-0 me-2"
              slot="start"
              size="undefined"
            />
          </div>
        </IonRow>
        <div className="mt-2">
          {!props.editFromshow
            ? <IonRow>
              <IonCol size="12" className='h-100'>
                <IonCard className='no-shadow'>
                  <div className="mb-0">
                    <IonRow className="ion-justify-content-center edit-pr-img" >
                      {
                        props.userFormState.logo === undefined || props.userFormState.logo === null || (props?.userFormState?.logo && props.userFormState.logo.length === 0)
                          ? (
                            <img src={product} alt={t('appproperties.text277')} />
                          )
                          : <>
                            {
                              props.userFormState.logo.length > 1
                                ? (
                                  <Swiper
                                    id="main"
                                    navigation={true}
                                    pagination={{
                                      clickable: true
                                    }}
                                    modules={[Navigation, Pagination]}
                                    spaceBetween={5}
                                    slidesPerView={1}
                                  >
                                    {
                                      props.userFormState.logo.map((photo, index) => (
                                        <SwiperSlide key={index}
                                          className='d-flex justify-content-center'
                                        >
                                          <img
                                            className='cursor-pointer'
                                            src={photo}
                                            onClick={() => imgModalOpen(index)}
                                          />
                                        </SwiperSlide>
                                      ))
                                    }
                                  </Swiper>)
                                : <img className='cursor-pointer' src={props.userFormState.logo} onClick={() => imgModalOpen(0)} />
                            }
                          </>
                      }

                    </IonRow>
                    <IonRow className='full-width-row'>
                      <IonRow className='w-100'>
                        <div className='product-detail-value'>
                          <span className="MuiTypography-body1 w-75">
                            <strong>{props.userFormState.productName}</strong>
                          </span>
                          <IonLabel className='MuiTypography-body2 text-right w-25'>
                            {props.userFormState.price &&
                              <>
                                {/* <span className='lb-title' >{t('productproperties.text3')} :</span> */}
                                <IonIcon
                                  icon={rupee}
                                />
                                <span className='price-val'>
                                  {props.userFormState.price}
                                </span>
                              </>
                            }
                          </IonLabel>
                        </div>
                      </IonRow>
                      <IonRow className='full-width-row'>
                        <span className="MuiTypography-body2 color-theme-dark">
                          {props.userFormState.brandName}
                        </span>
                      </IonRow>
                      <IonRow className='full-width-row'>
                        <IonLabel className="MuiTypography-body2 margin-top">
                          {props.userFormState.description}
                        </IonLabel>
                      </IonRow>
                      <div className='d-flex justify-content-between product-detail-value'>
                        <div className='w-60'>
                          {props.userFormState.minimumQty &&
                            <IonLabel className='full-width-row MuiTypography-body2 margin-top w-100 d-flex m-0'>
                              <span className='lb-title'> {t('productproperties.text6')} :</span><b> {props.userFormState.minimumQty}</b>
                            </IonLabel>
                          }
                          {props.userFormState.paymentTerms &&
                            <IonLabel className='full-width-row MuiTypography-body2 margin-top ion-padding-bottom w-100 m-0'>
                              <span className='lb-title'> {t('productproperties.text7')} : </span><b> {props.userFormState.paymentTerms}</b>
                            </IonLabel>}
                        </div>
                        <IonButton className='w-35'>Inquire now</IonButton>
                      </div>
                    </IonRow>
                  </div>
                  <IonRow className='ion-padding-start'>
                  </IonRow>
                </IonCard>
              </IonCol>
            </IonRow>
            : <form
              data-testid="form-submit"
              className='h-100'
              autoComplete="off"
              onSubmit={handleSubmit(updateSubmitHandler)}
            >
              <div className="body-content ion-padding-start ion-padding-end">
                <IonRow className="ion-padding-start ion-justify-content-center edit-catelogue-img h-auto border-0 mb-2">
                  <div className='cursor-pointer' onClick={() => setMoreImageModal(true)}>
                    {
                      props.imageList === undefined || props.imageList.length == 0
                        ? (
                          <img src={product} alt={t('appproperties.text277')} />
                        )
                        : <>
                          {
                            props.imageList.length >= 1 &&
                            <img
                              src={(typeof props.imageList[0].file) === 'string' ? props.imageList[0].file : getPhotoUrl(props.imageList[0])}
                            />
                          }
                          {isError && <p className='error ion-padding-start mt-0 mb-0 post-error ps-0 line-h-error erro-small-font position-relative'>{t('appproperties.text263')}</p>}
                        </>
                    }
                  </div>
                </IonRow>
                <IonRow className="MuiCardContent-root m-xr-5">
                  <IonCol size-md="12" size-xs="12" className='input-label-box'>
                    <IonItem
                      className={
                        errors.productName
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('productproperties.text2')}<sup>*</sup></IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box'
                        data-testid="productName"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="productName"
                        {...register('productName')}
                        value={productData1.productName}
                      />
                    </IonItem>
                    <p className={errors.productName ? 'error' : ''}>
                      {errors.productName?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className='input-label-box tooltipc input-popover'>
                    <IonItem
                      className={
                        errors.price
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0'
                      }
                    >
                      <IonLabel position="floating"> {t('productproperties.text3')} <sup>*</sup></IonLabel>
                      <IonInput
                        autocomplete="off"
                        type="text"
                        inputmode='numeric'
                        // onkeydown="javascript: return ['Backspace','Delete','ArrowLeft','ArrowRight','Period','Tab'].includes(event.code) ? true : !isNaN(Number(event.key)) && event.code!=='Space'"
                        className='input-box input-custom-width'
                        data-testid="price"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="price"
                        {...register('price')}
                        value={productData1.price}
                      />
                    </IonItem>
                    <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text248')} />
                    <p className={errors.price ? 'error' : ''}>
                      {errors.price?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className='input-label-box tooltipc input-popover'>
                    <IonItem
                      className={
                        errors.brandName
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('productproperties.text5')}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box input-custom-width'
                        data-testid="brandName"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="brandName"
                        {...register('brandName')}
                        value={productData1.brandName}
                      />
                    </IonItem>
                    <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text249')} />
                    <p className={errors.brandName ? 'error' : ''}>
                      {errors.brandName?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className='input-label-box tooltipc input-popover'>
                    <IonItem
                      className={
                        errors.minimumQty
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('productproperties.text6')} <sup>*</sup></IonLabel>
                      <IonInput
                        autocomplete="off"
                        type="text"
                        // onkeydown="javascript: return ['Backspace','Delete','ArrowLeft','ArrowRight','Period','Tab'].includes(event.code) ? true : !isNaN(Number(event.key)) && event.code!=='Space'"
                        className='input-box input-custom-width'
                        data-testid="minimumQty"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="minimumQty"
                        {...register('minimumQty')}
                        value={productData1.minimumQty}
                      />
                    </IonItem>
                    <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text250')} />
                    <p className={errors.minimumQty ? 'error' : ''}>
                      {errors.minimumQty?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className='input-label-box tooltipc input-popover'>
                    <IonItem
                      className={
                        errors.paymentTerms
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('productproperties.text7')} <sup>*</sup></IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box input-custom-width'
                        data-testid="paymentTerms"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="paymentTerms"
                        {...register('paymentTerms')}
                        value={productData1.paymentTerms}
                      />
                    </IonItem>
                    <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text251')} />
                    <p className={errors.paymentTerms ? 'error' : ''}>
                      {errors.paymentTerms?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="12" sizeXs="12" className='input-label-box mb-0'>
                    <IonItem
                      className={
                        errors.description
                          ? 'error-border form-group input-label-box position-relative full-width-row input-fill mb-0'
                          : 'form-group input-label-box position-relative full-width-row input-fill mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('commonproperties.text39')} <sup>*</sup></IonLabel>
                      <IonTextarea
                        type="text"
                        className='input-box full-width-row input-fill'
                        onIonChange={descriptionChangeHandler}
                        value={productData1.description}
                        // errors={errors.description}
                        {...register('description')}
                        data-testid="description"
                        id="description"
                        rows={3}
                        maxlength={1000}
                      />
                    </IonItem>
                    <p className={errors.description ? 'error' : ''}>
                      {errors.description?.message}
                    </p>
                    <p className='text-grey text-end font-14'>
                      {productData1.description !== undefined && productData1.description !== null && productData1.description.length > 0
                        ? productData1.description.length
                        : characterCount}/{maxCount}
                    </p>
                  </IonCol>
                </IonRow>
              </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
                <IonRow>
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto pe-0 pe-lg-2"
                    size="small"
                    type="submit"
                    disabled={updateDisabled || isError}
                  >
                    {t('appproperties.text52')}
                    {updateDisabled &&
                      <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                    }
                  </IonButton>
                </IonRow>
              </IonFooter>
            </form>
          }
        </div>
      </div>
    </IonModal>

    <IonModal
      isOpen={moreImageModal}
      onDidDismiss={() => setMoreImageModal(false)}
      cssClass="AddImages"
      backdropDismiss={false}
    >
      <IonRow className="MuiDialogTitle-root ion-padding pt-0 full-width-row modal-heading ion-align-items-center ion-justify-content-between bg-grey">
        <IonLabel className="MuiTypography-h6">{t('appproperties.text67')}</IonLabel>
        <div
          onClick={() => setMoreImageModal(false)}
          className="close ion-no-padding cursor-pointer"
        >
          <IonIcon
            icon={closeOutline}
            className="ion-button-color text-dark"
            slot="start"
            size="undefined"
          />
        </div>
      </IonRow>
      <div className='modal-body ion-padding pt-0'>
        <div className='d-md-flex ion-align-items-center moreimg h-75'>
          {props.imageList?.map((value, index) => {
            return <div key={index} className='moreimages position-relative' >
              <div>
                <img
                  src={(typeof value.file) === 'string' ? value.file : getPhotoUrl(value)}
                  alt={t('appproperties.text299')}
                />
                <span className="icon edit cursor-pointer">
                  <IonIcon
                    icon={closeOutline}
                    onClick={() => deleteImage(index)}
                  />
                </span>
              </div>
              <div className='error error-catelogue'>{value?.hasError && value?.errorMsg}</div>
            </div>;
          })}
          <div className='fileUpload d-flex flex-column flex-column-reverse position-relative'>
            <input
              type="file"
              accept="image/png, image/gif, image/jpg, image/jpeg"
              color="dark"
              onChange={uploadMoreImages}
              className="ion-text-capitalize ion-no-padding ion-padding-end upload"
              multiple
              id="image1"
            />
            <p><IonIcon className='font-22 d-flex d-lg-none me-2' icon={add} />  {t('appproperties.text68')}</p>
            <label
              htmlFor="image1"
              className="cursor-pointer iconAdd d-flex align-items-center justify-content-center"
              color="dark"
            >
              <IonIcon className='font-22 mt-n4' icon={add} />
            </label>
          </div>
        </div>

      </div>

    </IonModal>

    {/* show image zoom modal */}

    {showImgModal && <IonModal isOpen={showImgModal} cssClass="add-award-model awd-img-gallery" onDidDismiss={() => setshowImgModal(false)}>
      <IonContent>
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
          <div onClick={() => setshowImgModal(false)} className="close ion-no-padding">
            <IonIcon
              icon={close}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined" />
          </div>
        </IonRow>
        <IonRow className="overview-heigth ">
          <ImageGallery
            items={photoGallery}
            showPlayButton={false}
            autoPlay={false}
            startIndex={selectedImgIndex} />
        </IonRow>
      </IonContent>
    </IonModal>}
  </>
  );
};
export default ProductDetail;
