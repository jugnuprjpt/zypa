import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCol,
  IonHeader,
  IonIcon,
  IonItem,
  IonList,
  IonRow
} from '@ionic/react';
import { arrowBack, chevronForward, personAdd } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';

const People = () => {
  const { t } = useTranslation();
  const peoples = [
    {
      id: 1,
      name: 'Vaibhav Porwal',
      designation: 'Purchase Manager at Istpl',
      profileImg:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      verified: true
    },
    {
      id: 2,
      name: 'Udat Patel',
      designation: 'Purchase Manager at ISourcing',
      profileImg:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8JZb1dRwy8UxASU66Oit--WrtJr0beom2ww&usqp=CAU',
      verified: true
    },
    {
      id: 3,
      name: 'Arpan Shah',
      designation: 'Purchase Manager at Tender247',
      profileImg:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-yQN6LylHMN9BzuMpgr2OGLttCXfX0E9dCQ&usqp=CAU',
      verified: false
    },
    {
      id: 4,
      name: 'Chirag rathod ',
      designation: 'Purchase Manager at LTB',
      profileImg:
        'https://zyapaar-image-test.s3.ap-south-1.amazonaws.com/1634906976934_a.jpg',
      verified: true
    },
    {
      id: 5,
      name: 'Punit Shah',
      designation: 'Purchase Manager at Tender247',
      profileImg:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      verified: true
    }
  ];
  return (
    <IonCard className="profile-details left-cards MuiPaper-rounded custom-scroll-header">
      <IonHeader className="card-header-text ion-padding-start ion-padding-end ion-no-border db-mobile">
        <IonCol size="12">
          <p>{t('appproperties.text136')}</p>
        </IonCol>
      </IonHeader>
      <IonHeader className="card-header-text ion-padding-start ion-padding-end ion-no-border show-mobile">
          <p>{t('appproperties.text136')}</p>
          <IonIcon className='icon-mobile' icon={chevronForward}></IonIcon>
       </IonHeader>
      <IonRow className='mobile-overlay-screen'>
         <div className='mobile-back-screen show-mobile'>
            <IonIcon className='icon-mobile' icon={arrowBack}></IonIcon>
          </div>
        <IonList lines="none" className="full-width-row">
          {peoples.map((detail) => {
            return (
              <>
                <IonItem>
                  <IonCol size="10">
                    <div className="myprofile-feeds ion-no-padding">
                      <IonAvatar className="MuiAvatar ">
                        <img src={detail.profileImg} />
                      </IonAvatar>
                      <IonRow className="ion-padding-start">
                        {detail.name}
                        <span className="margin MuiTypography-caption">
                          {detail.designation}
                        </span>
                        <span> </span>
                      </IonRow>
                    </div>
                  </IonCol>
                  <IonCol size="3">
                    <div>
                      <IonButton fill="clear">
                        <IonIcon
                          icon={personAdd}
                          slot="start"
                          size="medium"
                          className="test"
                        />
                      </IonButton>
                    </div>
                  </IonCol>
                </IonItem>
              </>
            );
          })}
        </IonList>
      </IonRow>
    </IonCard>
  );
};
export default People;
