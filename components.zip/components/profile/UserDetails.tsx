/* eslint-disable no-lone-blocks */
/* eslint-disable multiline-ternary */
/* eslint-disable react/jsx-key */
/* eslint-disable prefer-const */
/* eslint-disable react/prop-types */
import {
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  IonTextarea,
  useIonPopover
} from '@ionic/react';
import React, { useEffect, useRef, useState } from 'react';
import {
  ellipsisVertical,
  close,
  callOutline,
  mailOutline,
  warningOutline,
  duplicateOutline,
  personOutline,
  eyeOutline
} from 'ionicons/icons';

import callFor from '../../util/CallFor';
import { Controller, useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import recommendation from '../../assets/img/icons/recommendation-icon.svg';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import edit from '../../assets/img/edit.svg';
import { NavLink, useHistory } from 'react-router-dom';
import SkeletonComonViewAll from '../common/skeleton/SkeletonComonViewAll';
import PopoverCommon from '../common/PopoverCommon';
import ToastCommon from '../common/ToastCommon';
import SkeletonComonProfile from '../common/skeleton/SkeletonComonProfile';
import MetaTage from '../common/MetaTage';
import ReportSpamCommon from '../common/ReportSpamCommon';
import MessageEditor from '../common/MessageEditor';
import ImageEditModal from '../myPage/ImageEditModal';
import CommonGridList from '../common/CommonGridList';
import ButtonComponent from '../common/ButtonComponent';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import MutualConnectionRow from '../common/MutualConnectionRow';

import userCoverDefaulImg from '../../assets/img/banner-placeholder.png';
import { Trans, useTranslation } from 'react-i18next';
import CompleteProfile from './CompleteProfile';
import NotAuthorizeModal from '../common/NotAuthorizeModal';
const UserDetails = (props: {
  getUserDetails: (arg0: any) => void;
  setReportHideState: boolean;
  userId: string;
  userProfileData: {
    isFollowing: boolean;
    name: {} | null | undefined;
    profileTitle: {} | null | undefined;
    profileImg: string | null | undefined;
    entityName: {} | null | undefined;
    isLocked: boolean;
    connection: {} | null | undefined;
    followerCount: {} | null | undefined;
    followingCount: {} | null | undefined;
    isConnected: boolean;
    isRequested: boolean;
    aboutUs:
    | boolean
    | React.ReactChild
    | React.ReactFragment
    | React.ReactPortal
    | null
    | undefined;
    mobileNo:
    | string
    | number
    | boolean
    | {}
    | React.ReactElement<any, string | React.JSXElementConstructor<any>>
    | React.ReactNodeArray
    | React.ReactPortal
    | null
    | undefined;
    emailId:
    | string
    | number
    | boolean
    | {}
    | React.ReactElement<any, string | React.JSXElementConstructor<any>>
    | React.ReactNodeArray
    | React.ReactPortal
    | null
    | undefined;
  };
  setUserProfileData: (arg0: any) => void;
}) => {
  const { t } = useTranslation();
  const [loginModal, setLoginModal] = useState(false);
  const label = [
    {
      id: 1,
      name: t('appproperties.text375')
    },
    {
      id: 2,
      name: t('appproperties.text376')
    },
    {
      id: 3,
      name: t('appproperties.text377')
    },
    {
      id: 4,
      name: t('companyproperties.text7')
    },
    {
      id: 5,
      name: t('appproperties.text147')
    },
    {
      id: 6,
      name: t('dropdownfields.text13')
    }
  ];
  const profileDetail = useSelector(getProfileDetails);
  const [showModal, setShowModal] = useState(false);
  const [editProfileFormState, setEditProfileFormState] = useState({});
  const [saveDisabled, setSaveDisabled] = useState(false);
  const history = useHistory();
  const [showToast, setShowToast] = useState(false);
  const [openModelFollowing, setModelFollowing] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [ScrollFollowingData, setScrollFollowingData] = useState([]);
  const [count, setCount] = useState(0);
  const [getType, SetType] = useState();
  const [loading, setloading] = useState(true);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [messageModal, setMessageModal] = useState(false);
  const [characterCount, setCharacterCount] = useState(0);
  const [characterMessageCount, setCharacterMessageCount] = useState(0);
  const [messageError, setMessageError] = useState('');
  const messageRef = useRef(null);
  const [ScrollconnectionData, setScrollconnectionData] = useState([]);
  const [openModelConnection, setModelConnection] = useState(false);
  const [showImgModal, setshowImgModal] = useState(false);
  const [reportModal, setReportModel] = useState(false);
  const [confirmModel, setConfirmModel] = useState(false);
  const [removeConnectionModalData, setRemoveConnectionModalData] = useState({});
  const [showContactInfo, setShowContactInfo] = useState(false);

  const validationSchema = Yup.object().shape({
    firstName: Yup.string()
      .trim()
      .required(t('commonproperties.text10'))
      .matches(/^[A-Za-z-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text14'),
        (val) => val && val.toString().length <= 50
      ),
    lastName: Yup.string()
      .trim()
      .required(t('commonproperties.text11'))
      .matches(/^[A-Za-z-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text14'),
        (val) => val && val.toString().length <= 50
      ),
    mobileNo: Yup.string()
      .typeError(t('commonproperties.text12'))
      .required(t('commonproperties.text12'))
      .matches(/^[0-9]+$/, t('commonproperties.text12'))
      .test(
        'len',
        t('commonproperties.text12'),
        (val) => val && val.toString().length >= 10
      )
      .test(
        'len',
        t('userproperties.text12'),
        (val) => val && val.toString().length <= 10
      ),
    profileTitle: Yup.string()
      .trim()
      .nullable()
      .required(t('userproperties.text13'))
      .min(2, t('commonproperties.text13'))
      .max(100, t('userproperties.text15')),
    emailId: Yup.string()
      .trim()
      .nullable(true)
      .notRequired()
      .optional()
      .matches(
        /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        { message: t('userproperties.text16'), excludeEmptyString: true }
      )
    // emailId: Yup.string().nullable().email('Enter valid email')
  });
  const maxCount = 100;
  const maxMessageCount = 500;
  useEffect(() => {
    props.getUserDetails(props.userId);
  }, []);

  const {
    register,
    handleSubmit,
    setValue,
    clearErrors,
    setError,
    resetField,
    control,
    formState: { errors, isValid }
  } = useForm({
    resolver: yupResolver(validationSchema),
    criteriaMode: 'all',
    reValidateMode: 'onTouched',
    mode: 'onChange'
  });

  const userformDataChangeHandler = (value, name) => {
    if (value !== undefined) {
      setEditProfileFormState({
        ...editProfileFormState,
        [name]: value
      });
    }
  };

  const userSubmitHandler = async () => {
    setSaveDisabled(true);
    let titleData = '';
    let firstname = '';
    let lastname = '';
    let email = '';
    if (
      editProfileFormState.profileTitle !== undefined &&
      editProfileFormState.profileTitle !== null
    ) {
      titleData = editProfileFormState.profileTitle.trim();
    }
    if (
      editProfileFormState.firstName !== undefined &&
      editProfileFormState.firstName !== null
    ) {
      firstname = editProfileFormState.firstName.trim();
    }
    if (
      editProfileFormState.lastName !== undefined &&
      editProfileFormState.lastName !== null
    ) {
      lastname = editProfileFormState.lastName.trim();
    }
    if (
      editProfileFormState.emailId !== undefined &&
      editProfileFormState.emailId !== null
    ) {
      email = editProfileFormState.emailId.trim();
    }
    const userData = {
      firstName: firstname,
      lastName: lastname,
      mobileNo: editProfileFormState.mobileNo,
      profileTitle: titleData,
      emailId: email,
      userId: props.userId
    };
    const data = JSON.stringify(userData);
    const response = await callFor('api/v1.1/users', 'PUT', data, 'Auth');
    if (response.status === 200) {
      setSaveDisabled(true);
      props.getUserDetails(props.userId);
      history.push('/profile/' + props.userId);
      setShowModal(false);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 400) {
      const datares = await response.json();
      datares.error.errors.map((details: { field: string; message: any }) => {
        setError(details.field, {
          type: 'server',
          message: details.message
        });
      });
    }
    setSaveDisabled(false);
  };
  const confirmMessage = (
    <IonLabel>
      {t('userproperties.text1')}
    </IonLabel>
  );
  let removeConfirmMessage = '';
  {
    removeConnectionModalData.name !== undefined
      ? removeConfirmMessage = <IonLabel>{t('appproperties.text9a')}<strong>{removeConnectionModalData.name}</strong>{t('appproperties.text9b')}</IonLabel>
      : '';
  }
  const getEditUserDetails = async () => {
    setShowModal(true);
    const response = await callFor('api/v1.1/user', 'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      setEditProfileFormState({
        firstName: json1Response.data.firstName,
        lastName: json1Response.data.lastName,
        mobileNo: json1Response.data.mobileNo,
        profileTitle: json1Response.data.profileTitle,
        emailId: json1Response.data.emailId
      });
      const fields = [
        'id',
        'firstName',
        'lastName',
        'mobileNo',
        'profileTitle',
        'emailId'
      ];
      fields.forEach((field) => setValue(field, json1Response.data[field]));
      let inputs, index;
      inputs = document.getElementsByTagName('ion-textarea');
      for (index = 0; index < inputs.length; ++index) {
        const val = inputs[index].value;
        if (val !== null && val.length > 0) {
          inputs[index].classList.add('input-fill');
        }
      }
    }
  };

  const connectionBtnHandler = async () => {
    const response = await callFor(
      'api/v1.1/connect/' + props.userId + '/INITIATE',
      'POST',
      '{"status": "INITIATE" }',
      'Auth'
    );
    if (response.status === 200) {
      props.getUserDetails(props.userId);
      setShowToastMsg(t('toastmessages.toast13'));
      setShowToast(true);
    } else if (response.status === 400) {
      const json1Response = await response.json();
      if (json1Response.error.message === t('userproperties.text21')) {
        setShowToastMsg(t('userproperties.text21'));
        setShowToast(true);
      }
    }
  };

  const openModelWithClearError = () => {
    setShowModal(true);
    clearErrors();
  };

  const requestBtnHandler = async (type: string) => {
    const response = await callFor(
      'api/v1.1/users/' + props.userId + '/' + type,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      if (props.userProfileData.isFollowing === false) {
        props.setUserProfileData({
          ...props.userProfileData,
          isFollowing: true
        });
      } else {
        props.setUserProfileData({
          ...props.userProfileData,
          isFollowing: false
        });
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  const validateIsNumericInput = (evt: { which: any; keyCode: any }) => {
    const ASCIICode = evt.which ? evt.which : evt.keyCode;
    const permittedKeys = [8, 9, 46, 37, 39, 13, 46, 116, 50];
    if (
      (ASCIICode >= 48 && ASCIICode <= 57) ||
      (ASCIICode >= 96 && ASCIICode <= 105)
    ) {
      return true;
    }
    if (permittedKeys.includes(ASCIICode)) {
      return true;
    }
    return false;
  };

  const getFollowListOnScroll = async (openType: string | undefined) => {
    const response = await callFor(
      'api/v1.1/users/' + props.userId + '/followers/' + openType,
      'POST',
      '{"page": ' + count + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setScrollFollowingData([
          ...ScrollFollowingData,
          ...json1Response.data.content
        ]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  const viewFollowingModel = async (
    openType: string | React.SetStateAction<undefined>
  ) => {
    SetType(openType);
    const data = await getFollowList(0, openType);
    if (data !== undefined && data.length > 0) {
      setModelFollowing(true);
      const data1 = await getFollowList(1, openType);
      if (data1.length > 0) {
        setScrollFollowingData([...data, ...data1]);
        setCount(2);
      } else {
        setScrollFollowingData(data);
        setInfiniteDisabled(true);
      }
    } else {
      setInfiniteDisabled(true);
    }
    setloading(false);
  };

  const closeModel = () => {
    setModelFollowing(false);
    setScrollFollowingData([]);
    setCount(0);
    setInfiniteDisabled(false);
    setloading(true);
  };

  const loadData = (ev: any) => {
    setTimeout(() => {
      getFollowListOnScroll(getType);
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  };

  // const og_title =
  //   `${props.userProfileData.name}` + ' | ' + `${props.userProfileData.profileTitle}`;
  // const og_image =
  //   `${props.userProfileData.name}` + ' | ' + `${props.userProfileData.profileImg}`;
  // const url_link = 'https://www.zyappar.com/' + `${userProfileData.name}`;
  const desc = `View Profile of ${props.userProfileData.name +
    ' on Zyapaar ' +
    props.userProfileData.name +
    ' now working at ' +
    props.userProfileData.entityName +
    ' as ' +
    props.userProfileData.profileTitle
    }`;
  const scriptData = {
    '@context': 'https://schema.org',
    '@type': 'Person',
    name: props.userProfileData.name,
    url: window.location.href,
    image: props.userProfileData.profileImg,
    jobTitle: desc
  };
  const schemaData = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: '1',
        name: 'zyapaar',
        item: 'https://www.zyapaar.com'
      },
      {
        '@type': 'ListItem',
        position: '2',
        name: props.userProfileData.name,
        item: window.location.href
      }
    ]
  };

  const openReportModelclearstate = () => {
    setReportModel(true);
    dismiss();
  };

  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr">
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => { onHide(); openReportModelclearstate(); }}
      >
        <IonIcon icon={warningOutline} size="small" className="header-menu-img " />
        <p className="ion-padding-start">{t('commonproperties.text19')}</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => {
          onHide();
          props.setCategoryState('MYCOMPANY');
        }}
      >
        <IonIcon icon={eyeOutline} size="small" className="header-menu-img " />
        <p className="ion-padding-start">View Company</p></IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => { onHide(); props.setCategoryState('RECOMMENDATIONS'); }}
      >
        <IonIcon icon={recommendation} size="small" className="header-menu-img " />
        <p className="ion-padding-start">Recommendations</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => { onHide(); setShowContactInfo(true); }}
      >
        <IonIcon icon={personOutline} size="small" className="header-menu-img " />
        <p className="ion-padding-start">Contact info</p>
      </IonItem>
    </IonList>
  );

  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });

  const showEditProfileList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr">
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => { setShowEditProfile(); openModelWithClearError() }}
      >
         <IonIcon icon={edit} size="small" className="header-menu-img " />
        <p className="ion-padding-start">{t('userproperties.text5')}</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => {
          onHide();
          props.setCategoryState('MYCOMPANY');
        }}
      >
        <IonIcon icon={edit} size="small" className="header-menu-img " />
        <p className="ion-padding-start">View/Edit Company</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => { setShowEditProfile(); setShowContactInfo(true); }}
      >
        <IonIcon icon={personOutline} size="small" className="header-menu-img " />
        <p className="ion-padding-start">Contact info</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer">
          <IonIcon icon={recommendation} size="small" className="header-menu-img " />
          <p className="ion-padding-start">{t('appproperties.text145')}</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer">
          <IonIcon icon={duplicateOutline} size="small" className="header-menu-img " />
          <p className="ion-padding-start">{t('companyproperties.text2')}</p>
      </IonItem>
    </IonList>
  );

  const RedirectAddNewcompany = () => {
    setShowEditProfile();
    history.push('/addnewcompany');
  };

  const [showEditProfile, setShowEditProfile] = useIonPopover(showEditProfileList, {
    onHide: () => setShowEditProfile()
  });

  const getConnectionListOnScroll = async () => {
    const response = await callFor(
      'api/v1.1/connection/list/ALL?userId=' + props.userId,
      'POST',
      '{"page": ' + count + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setScrollconnectionData([
          ...ScrollconnectionData,
          ...json1Response.data.content
        ]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setloading(false);
  };

  const viewConnectionModel = async () => {
    const data = await getConnectionList(0);
    if (data !== undefined && data.length > 0) {
      setModelConnection(true);
      const data1 = await getConnectionList(1);
      if (data1.length > 0) {
        setScrollconnectionData([...data, ...data1]);
        setCount(2);
      } else {
        setScrollconnectionData(data);
        setInfiniteDisabled(true);
      }
    } else {
      setScrollconnectionData([]);
      setModelConnection(false);
      setInfiniteDisabled(true);
    }
    setloading(false);
  };
  const closeConnectionModel = () => {
    setModelConnection(false);
    setScrollconnectionData([]);
    setCount(0);
    setInfiniteDisabled(false);
    setloading(true);
  };
  const loadDataConnection = (ev: any) => {
    setTimeout(() => {
      getConnectionListOnScroll();
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  };

  const getFollowList = async (page: string | number, openType: string) => {
    const response = await callFor(
      'api/v1.1/users/' + props.userId + '/followers/' + openType,
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      return json1Response.data.content;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
      return [];
    }
    setloading(false);
  };

  const getConnectionList = async (page: string | number) => {
    const response = await callFor(
      'api/v1.1/connection/list/ALL?userId=' + props.userId,
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      return json1Response.data.content;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
      return [];
    }
    setloading(false);
  };

  const viewMessageModal = () => {
    setMessageModal(true);
  };

  const messageSubmitHandler = async () => {
    let contantFlag = false;
    if (messageRef.current.editor.getContents().ops.length >= 2 && messageRef.current.editor.getContents().ops.length <= 500) {
      contantFlag = false;
    } else {
      if (messageRef.current.editor.getText().trim().length === 0) {
        setMessageError(t('signuprecommendation.text10'));
        contantFlag = true;
      } else if (messageRef.current.editor.getText().trim().length <= 10) {
        setMessageError(t('commonproperties.text28'));
        contantFlag = true;
      } else if (messageRef.current.editor.getText().trim().length > 500) {
        setMessageError(t('commonproperties.text40'));
        contantFlag = true;
      } else {
        setMessageError('');
        contantFlag = false;
      }
    }
    if (!contantFlag) {
      const d = messageRef.current.editor.getContents();
      let postData = '';
      const attributes: {
        type: string;
        start: number;
        length: any;
        id: any;
      }[] = [];
      // eslint-disable-next-line array-callback-return
      d.ops.map((object: { insert: string }) => {
        if (typeof object.insert === 'object') {
          postData += object.insert.mention.value;
          const data1 = {
            mention: 'PROFILE',
            start: postData.lastIndexOf(object.insert.mention.value),
            length: object.insert.mention.value.length,
            id: object.insert.mention.id
          };
          attributes.push(data1);
        } else {
          postData += object.insert;
        }
      });

      const messageData = { text: postData, attributes: attributes };
      const data = {
        userId: props.userId,
        message: JSON.stringify(messageData)
      };
      const response = await callFor(
        'api/v1/message',
        'POST',
        JSON.stringify(data),
        'Auth'
      );
      if (response.status === 200) {
        setMessageModal(false);
        setShowToastMsg('Message sent to ' + props.userProfileData.name);
        setShowToast(true);
      } else if (response.status === 400) {
        const json1Response = await response.json();
        if (json1Response.error.message === "You can't message yourself") {
          setShowToastMsg(t('userproperties.text20'));
          setMessageModal(false);
          setShowToast(true);
        }
      }
    }
  };

  const MetaTagProperties = {
    title:
      props.userProfileData.name + '|' + props.userProfileData.profileTitle,
    description: desc,
    keywords: '',
    ogurl: window.location.href
  };

  const profileTitleChangeHandler = (value, name) => {
    if (value !== undefined && value !== null && value.length > 0) {
      setEditProfileFormState({
        ...editProfileFormState,
        profileTitle: event.target.value
      });
    }
    if (value !== undefined && value != null) {
      setCharacterCount(value.length);
    }
  };

  const messageChangeHandler = (event) => {
    if (messageRef.current.editor.getContents().ops.length >= 2) {
      setMessageError('');
    } else {
      if (messageRef.current.editor.getText().trim().length === 0) {
        setMessageError(t('signuprecommendation.text9'));
      } else if (messageRef.current.editor.getText().trim().length <= 10) {
        setMessageError(t('commonproperties.text28'));
      } else if (messageRef.current.editor.getText().trim().length > 500) {
        setMessageError(t('commonproperties.text40'));
      } else {
        setMessageError('');
      }
      setCharacterMessageCount(
        messageRef.current.editor.getText().trim().length
      );
    }
  };

  const removeConnectBtnHandler = async () => {
    const response = await callFor(
      'api/v1.1/users/connections/' + props.userId + '/remove',
      'POST',
      '{ "message":"", "id":"' + props.userId + '"}',
      'Auth'
    );
    if (response.status === 200) {
      props.getUserDetails(props.userId);
      setShowToastMsg(t('toastmessages.toast16'));
      setShowToast(true);
    } else if (response.status === 404) {
      const json1Response = await response.json();
      setShowToastMsg(json1Response.error.message);
      setShowToast(true);
    }
  };

  const removeModalConnectionBtnHandler = async () => {
    const response = await callFor(
      'api/v1.1/users/connections/' + removeConnectionModalData.id + '/remove',
      'POST',
      '{ "message":"", "id":"' + removeConnectionModalData.id + '"}',
      'Auth'
    );
    if (response.status === 200) {
      viewConnectionModel();
      setShowToastMsg(t('toastmessages.toast16'));
      setShowToast(true);
    } else if (response.status === 404) {
      const json1Response = await response.json();
      setShowToastMsg(json1Response.error.message);
      setShowToast(true);
    }
  };
  const resetHandler = (event) => {
    if (event.target.name === 'firstName' && event.target.value === '') {
      resetField('firstName');
    } else if (event.target.name === 'lastName' && event.target.value === '') {
      resetField('lastName');
    } else if (event.target.name === 'mobileNo' && event.target.value === '') {
      resetField('mobileNo');
    } else if (event.target.name === 'emailId' && event.target.value === '') {
      resetField('emailId');
    } else if (event.target.name === 'profileTitle' && event.target.value === '') {
      resetField('profileTitle');
    }
  };
  const actionBtnHandler = async (fromUserId, type, id) => {
    const response = await callFor('api/v1.1/connect/action/' + fromUserId + '/' + type, 'POST', '{ "message":"' + type + '", "id":"' + id + '"}', 'Auth');
    if (response.status === 200) {
      history.push('/profile/' + props.userId);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      const jsonRes = response.json();
      console.log(jsonRes);
    }
  };
  const actionBtnHandlerReceived = async (requestId, type) => {
    const response = await callFor('api/v1.1/connect/action/' + props.userId + '/' + type.toUpperCase(), 'POST', '{ "message":"' + type + '", "id":"' + requestId + '"}', 'Auth');
    if (response.status === 200) {
      history.push('/profile/' + props.userId);
      // setAdminInvitation(adminInvite.filter((item) => item.requestId !== id));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      const jsonRes = response.json();
      console.log(jsonRes);
    }
  };
  const withdrawMobile = () => {
    setConfirmModel(true);
  };
  const [removeConfirmModel, setRemoveConfirmModel] = useState(false);

  const requestCall = () => {

  };

  return (
    <>
      <script type="application/ld+json">{JSON.stringify(scriptData)}</script>
      <script type="application/ld+json">{JSON.stringify(schemaData)}</script>
      <MetaTage metaDetails={MetaTagProperties} />
      {!props.loading ? (
        <IonCard className="MuiPaper-rounded ion-no-margin ion-margin-top ion-margin-bottom profile-user-details profile-card-content">

          <>

            <ImageEditModal
              id={props.userId}
              // image={null}
              image={props.userProfileData.cover}
              defultLogo={userCoverDefaulImg}
              serviceType='USER'
              getDetails={props.getUserDetails}
              logo='COVER'
              aspect={22 / 4.5}
              cropShape={'rect'}
              className='cover-photo'
              cssClass='edit-img model-img-hei-width CoverPhotoMain'
              isAdmin={profileDetail.id === props.userId}
              reportHideState={props.reportHideState}
              isHide={props.userProfileData.isHide}
            // background={true}
            />
            <div className='profile-card-body pb-0'><div className='profile-avt-content'>
              <ImageEditModal
                id={props.userId}
                image={props.userProfileData.profileImg}
                defultLogo={userProfile}
                serviceType='USER'
                getDetails={props.getUserDetails}
                logo='LOGO'
                aspect={1}
                cropShape={'round'}
                className='logo-photo'
                cssClass='edit-img model-img-hei-width'
                isAdmin={profileDetail.id === props.userId}
                reportHideState={props.reportHideState}
                isHide={props.userProfileData.isHide}
                background={true}
              />
              {!props.reportHideState &&
                props.userProfileData.isHide !== true &&
                <>
                  {profileDetail.id === props.userId &&
                    <div className="edit-icon zindex9">
                      <IonIcon
                        onClick={(e) =>
                          showEditProfile({
                            event: e.nativeEvent
                          })
                        }
                        icon={ellipsisVertical}
                        slot="start"
                        className="header-menu-account-img color-theme-dark"
                      />
                    </div>

                  }
                </>
              }
            </div>
              <div className="profileName w-100">
                <IonCardTitle>
                  <h4 className="margin fixed-textline2">
                    {props.userProfileData.name}
                  </h4>
                  <span className="margin MuiTypography-caption pcolor">
                    {props.userProfileData.profileTitle}
                  </span>
                  <p className="margin MuiTypography-caption color-grey ">
                    {props.userProfileData.entityName}
                  </p>
                  {!props.reportHideState && !props.userProfileData.isHide && props.userProfileData.isLocked === false
                    ? (
                      <>
                        {profileDetail.id === props.userId
                          ? <IonLabel
                            className="ion-text-capitalize cursor-pointer"
                            onClick={viewConnectionModel}
                          >
                            {props.userProfileData.connection !== null
                              ? (
                                <span className="textcolor fontsize for-mobile-grid ">
                                  {/* {props.userProfileData.connection} {t('appproperties.text142')} */}
                                  {props.userProfileData.connection} Zyapaari Connections
                                </span>
                              )
                              : (
                                <span className="textcolor fontsize for-mobile-grid ">
                                  0 Zyapaari Connections
                                  {/* {t('appproperties.text142')} */}
                                </span>
                              )}
                          </IonLabel>
                          : <MutualConnectionRow id={props.userProfileData.id} name={props.userProfileData.name} key={props.userProfileData.id} />
                        }
                      </>
                    )
                    : (
                      ''
                    )}
                </IonCardTitle>
              </div>
            </div>

          </>

          <IonModal
            isOpen={showImgModal}
            cssClass="add-award-model awd-img-gallery"
            onDidDismiss={() => setshowImgModal(false)}
          >
            <IonContent>
              <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
                <div
                  onClick={() => setshowImgModal(false)}
                  className="close ion-no-padding"
                >
                  <IonIcon
                    icon={close}
                    className="ion-button-color pr-0 "
                    slot="start"
                    size="undefined"
                  />
                </div>
              </IonRow>
              <IonRow className="mx-auto d-flex justify-content-center overview-heigth">
                <img src={props.userProfileData.profileImg} />
              </IonRow>
            </IonContent>
          </IonModal>
          {/*  Profile Picture Zoom  */}

          <div className="profile-user-details-bottom pt-0">
            {!props.reportHideState
              ? (
                props.userProfileData.isHide !== true
                  ? (
                    <>
                      <div className="ion-no-border headers">
                        <IonRow className="tow-colum-content">
                          {/* <IonCol sizeMd="7" sizeXs="12" className="left d-flex ps-0">
                            {props.userProfileData.isLocked === false
                              ? (
                                <>
                                  <IonLabel
                                    className="ion-text-capitalize cursor-pointer"
                                    onClick={viewConnectionModel}
                                  >
                                    {props.userProfileData.connection !== null
                                      ? (
                                        <span className="textcolor fontsize for-mobile-grid ">
                                          {props.userProfileData.connection}
                                        </span>
                                        )
                                      : (
                                        <span className="textcolor fontsize for-mobile-grid ">
                                          0
                                        </span>
                                        )}
                                    {t('appproperties.text142')}
                                  </IonLabel>
                                  <MutualConnectionRow id={props.userProfileData.id} name={props.userProfileData.name} key={props.userProfileData.id}/>
                                </>
                                )
                              : (
                                  ''
                                )}
                          </IonCol> */}
                          <IonCol sizeMd="5" sizeXs="12" className="right pr-details-action  pe-0 ps-0 profile-dotbtn">

                            {/* <IonButton size='small' className='btn-sm-cn call-btn me-2'>Request a Call</IonButton> */}

                            {profileDetail.id !== props.userId &&
                              profileDetail.id !== undefined &&
                              props.userId !== undefined
                              ? (
                                <>
                                  {props.userProfileData.connectionStatus === 'NEW'
                                    ? (
                                      <ButtonComponent
                                        btnClick={connectionBtnHandler}
                                        className='ion-button-color btn-sm-cn'
                                        size='small'
                                        name={t('appproperties.text28')}
                                        parametersPass={0}
                                      />
                                    )
                                    : props.userProfileData.connectionStatus === 'SENT'
                                      ? (
                                        <ButtonComponent
                                          btnClick={withdrawMobile}
                                          size="small"
                                          className="btn-sm-cn ion-button-color ion-padding-end pe-0 ion-margin-end me-2"
                                          name={t('appproperties.text40')}
                                          parametersPass={0}
                                        />
                                      )
                                      : props.userProfileData.connectionStatus === 'RECEIVED'
                                        ? (
                                          <>
                                            <ButtonComponent
                                              className="btn-sm-cn ion-button-color ion-padding-end pe-0 ion-margin-end me-2"
                                              btnClick={actionBtnHandlerReceived}
                                              field1={props.userProfileData.requestId}
                                              field2="ACCEPT"
                                              size='small'
                                              name={t('appproperties.text20')}
                                              parametersPass={2}
                                            />
                                            <ButtonComponent
                                              className="category-btn-color cursor-pointer btn-sm-cn pe-0 me-2"
                                              btnClick={actionBtnHandlerReceived}
                                              field1={props.userProfileData.requestId}
                                              field2="REJECT"
                                              size='small'
                                              name={t('appproperties.text19')}
                                              parametersPass={2}
                                            />
                                          </>
                                        )
                                        : (
                                          <>
                                            {props.userProfileData.isConnected === true &&
                                              props.userProfileData.isRequested !== true
                                              ? (
                                                <>
                                                  <ButtonComponent
                                                    btnClick={requestCall}
                                                    className='ion-button-color btn-sm-cn'
                                                    size='small'
                                                    name='Request a Call'
                                                    parametersPass={0}
                                                  />
                                                  <ButtonComponent
                                                    btnClick={removeConnectBtnHandler}
                                                    className='ion-button-color btn-sm-cn'
                                                    size='small'
                                                    name={t('appproperties.text370')}
                                                    parametersPass={0}
                                                  />
                                                  {props.userProfileData.isLocked === false
                                                    ? (
                                                      <ButtonComponent
                                                        btnClick={viewMessageModal}
                                                        className='ion-button-color btn-sm-cn'
                                                        size='small'
                                                        name={t('userproperties.text10')} parametersPass={0} />
                                                    )
                                                    : (
                                                      ''
                                                    )
                                                  }
                                                </>
                                              )
                                              : (
                                                ''
                                              )}
                                          </>
                                        )}
                                  {/* {props.userProfileData.isLocked === false
                                    ? (
                                      <>
                                        {props.userProfileData.connectionStatus === 'CONNECTED' !== true &&
                                          props.userProfileData.isRequested !== true
                                          ? (
                                            <>
                                              {props.userProfileData.isFollowing !==
                                                true
                                                ? (
                                                  <ButtonComponent
                                                    btnClick={requestBtnHandler}
                                                    field1='follow'
                                                    className='ion-button-color btn-sm-cn'
                                                    size='small'
                                                    name={t('appproperties.text364')} parametersPass={1} />
                                                )
                                                : (
                                                  <ButtonComponent
                                                    btnClick={requestBtnHandler}
                                                    field1='unfollow'
                                                    className='ion-button-color btn-sm-cn'
                                                    size='small'
                                                    name={t('appproperties.text332')} parametersPass={1} />
                                                )}
                                            </>
                                          )
                                          : (
                                            <>
                                              {props.userProfileData.connectionStatus === 'CONNECTED' &&
                                                props.userProfileData.isFollowing ===
                                                true
                                                ? (
                                                  <ButtonComponent
                                                    btnClick={requestBtnHandler}
                                                    field1='unfollow'
                                                    className='ion-button-color btn-sm-cn'
                                                    size='small'
                                                    name={t('appproperties.text332')} parametersPass={1} />
                                                )
                                                : (
                                                  ''
                                                )}
                                            </>
                                          )}
                                      </>
                                    )
                                    : (
                                      ''
                                    )} */}

                                  {props.userProfileData.isConnected === true &&
                                    props.userProfileData.isRequested !== true
                                    ? (
                                      <>
                                        {props.userProfileData.isLocked === false
                                          ? (
                                            <div className="dot-btn">
                                              <IonIcon
                                                icon={ellipsisVertical}
                                                slot="start"
                                                className="test report cursor-pointer"
                                                onClick={(e) => {
                                                  if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                                                    present({ event: e.nativeEvent });
                                                  } else {
                                                    // history.push('/addnewcompany');
                                                    setLoginModal(true);
                                                  }
                                                }
                                                }
                                              />
                                            </div>
                                          )
                                          : (
                                            ''
                                          )
                                        }
                                      </>
                                    ) : (
                                      ''
                                    )
                                  }
                                </>
                              )
                              : (
                                ''
                              )}
                          </IonCol>
                        </IonRow>
                      </div>
                      {props.userProfileData.aboutUs
                        ? (
                          <IonRow className="MuiCardActions-root">
                            <IonCol size="12">
                              <p className="ion-margin-start textcolour">
                                <b>{t('commonproperties.text17')}</b>
                              </p>
                              <p className="ion-padding-start ion-padding-end textcolour">
                                {props.userProfileData.aboutUs}
                              </p>
                            </IonCol>
                          </IonRow>
                        )
                        : (
                          ''
                        )}
                      {/* <div className="ion-no-border">
                        <div>
                          <IonRow className="user-pr-contact-content">
                            {props.userProfileData.isLocked === false
                              ? (
                                <>
                                  {profileDetail.id === props.userId
                                    ? (
                                      <div>
                                        {props.userProfileData.mobileNo
                                          ? (
                                            <IonLabel className="MuiTypography-body1 ion-text-cemter textcolour ion-padding-end d-flex align-items-center">
                                              <IonIcon
                                                icon={callOutline}
                                                className="icon-svg color-theme-dark me-2"
                                              />
                                              <a className='color-theme-dark' href={'tel::' + props.userProfileData.mobileNo}>{props.userProfileData.mobileNo}</a>
                                            </IonLabel>
                                            )
                                          : (
                                              ''
                                            )}
                                      </div>
                                      )
                                    : (
                                        ''
                                      )}
                                  {props.userProfileData.emailId
                                    ? (
                                      <IonLabel className="MuiTypography-body1 ion-text-cemter textcolour ion-padding-end d-flex align-items-center">
                                        <IonIcon
                                          icon={mailOutline}
                                          className="icon-svg color-theme-dark me-2"
                                        />
                                        <a className='color-theme-dark' href={'mailto::' + props.userProfileData.emailId}>{props.userProfileData.emailId}</a>
                                      </IonLabel>
                                      )
                                    : ''}
                                </>
                                )
                              : (
                                  ''
                                )}
                          </IonRow>
                        </div>
                      </div> */}
                    </>
                  )
                  : (
                    ''
                  )
              )
              : (
                ''
              )}
          </div>
        </IonCard>
      ) : (
        <SkeletonComonProfile />
      )}

      {profileDetail.id === props.userId &&
        <CompleteProfile />
      }

      <IonModal
        isOpen={showModal}
        onDidPresent={getEditUserDetails}
        className="createGroupModal"
        onDidDismiss={() => setShowModal(false)}
      >
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between mt-1">
          <IonLabel className="MuiTypography-h6 mt-3 ms-lg-3 ms-2">{t('userproperties.text5')}</IonLabel>
          <IonButton
            fill="clear"
            onClick={() => setShowModal(false)}
            className="close link-btn-tx ion-no-padding ion-no-margin"
          >
            <IonIcon
              icon={close}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </IonButton>
        </IonRow>
        <div className="modal-body overflow-auto">
          <form
            data-testid="form-submit"
            autoComplete="off"
            onSubmit={handleSubmit(userSubmitHandler)}
            className="h-100"
            noValidate
          >
            <div className='body-content mb-1'>
              <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row mt-3">
                <IonCol size-md="12" size-xs="12" className="pxm-0">
                  <IonRow>
                    <IonCol
                      size-md="6"
                      size-sm="12"
                      size-xs="12"
                      className="input-label-box mb-3"
                    >
                      <IonItem
                        className={
                          errors.firstName
                            ? 'error-border form-group input-label-box position-relative mb-0'
                            : 'form-group input-label-box position-relative mb-0'
                        }
                      >
                        <IonLabel position="floating">
                          {' '}
                          {t('commonproperties.text5')} <sup>*</sup>{' '}
                        </IonLabel>
                        <Controller
                          name="firstName"
                          control={control}
                          defaultValue=""
                          render={({ field: { value, onChange, ...field } }) => (
                            <IonInput type='text' autocomplete='off'
                              {...field}
                              onIonChange={({ target: { value, name } }) => {
                                onChange(value);
                                userformDataChangeHandler(value, name);
                              }}
                              onClick={resetHandler}
                              placeholder=""
                              className='input-box'
                              id="firstName"
                              {...register('firstName')} />
                          )}

                        />
                        <span
                          className={
                            errors.firstName ? 'error input-error' : ''
                          }
                        >
                          {errors.firstName?.message}
                        </span>
                      </IonItem>
                    </IonCol>
                    <IonCol
                      size-md="6"
                      size-sm="12"
                      size-xs="12"
                      className="input-label-box mb-3"
                    >
                      <IonItem
                        className={
                          errors.lastName
                            ? 'error-border form-group input-label-box position-relative mb-0'
                            : 'form-group input-label-box position-relative mb-0'
                        }
                      >
                        <IonLabel position="floating">
                          {' '}
                          {t('commonproperties.text6')} <sup>*</sup>{' '}
                        </IonLabel>
                        <Controller
                          name="lastName"
                          control={control}
                          defaultValue=""
                          render={({ field: { value, onChange, ...field } }) => (
                            <IonInput type='text' autocomplete='off'
                              {...field}
                              onIonChange={({ target: { value, name } }) => {
                                onChange(value);
                                userformDataChangeHandler(value, name);
                              }}
                              onClick={resetHandler}
                              placeholder=""
                              className='input-box'
                              id="lastName"
                              {...register('lastName')} />
                          )}
                        />
                        <span
                          className={
                            errors.lastName ? 'error input-error' : ''
                          }
                        >
                          {errors.lastName?.message}
                        </span>
                      </IonItem>
                    </IonCol>
                    <IonCol
                      size-md="12"
                      size-sm="12"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <IonItem
                        className={
                          errors.mobileNo
                            ? 'error-border form-group input-label-box position-relative mb-0'
                            : 'form-group input-label-box position-relative mb-0'
                        }
                      >
                        <IonLabel position="floating">
                          {' '}
                          {t('userproperties.text6')} <sup>*</sup>{' '}
                        </IonLabel>
                        <Controller
                          name="mobileNo"
                          control={control}
                          defaultValue=""
                          render={({ field: { value, onChange, ...field } }) => (
                            <IonInput
                              type="text"
                              inputmode="numeric"
                              pattern="[0-9]*"
                              autocomplete='off'
                              {...field}
                              onIonChange={({ target: { value, name } }) => {
                                onChange(value);
                                userformDataChangeHandler(value, name);
                              }}
                              onClick={resetHandler}
                              placeholder=""
                              onkeydown={validateIsNumericInput}
                              className='input-box'
                              id="mobileNo"
                              {...register('mobileNo')}
                              maxlength={10} />
                          )}
                        />
                        <span className={errors.mobileNo ? 'error input-error text-nowrap' : ''}>
                          {errors.mobileNo?.message}
                        </span>
                      </IonItem>
                    </IonCol>
                    <IonCol
                      size-md="12"
                      size-sm="12"
                      size-xs="12"
                      className="input-label-box"
                    >
                      <IonItem className="form-group input-label-box position-relative mb-0">
                        <IonLabel position="floating">{t('userproperties.text7')}</IonLabel>
                        <Controller
                          name="emailId"
                          control={control}
                          defaultValue=""
                          render={({ field: { value, onChange, ...field } }) => (
                            <IonInput type="email" autocomplete='off'
                              {...field}
                              onIonChange={({ target: { value, name } }) => {
                                onChange(value);
                                userformDataChangeHandler(value, name);
                              }}
                              onClick={resetHandler}
                              placeholder=""
                              className='input-box'
                              id="emailId"
                              {...register('emailId')} />
                          )}
                        />
                        <span
                          className={
                            errors.emailId ? 'error input-error' : ''
                          }
                        >
                          {errors.emailId?.message}
                        </span>
                      </IonItem>
                    </IonCol>
                    <IonCol
                      size-md="12"
                      size-sm="12"
                      size-xs="12"
                      className="input-popover groupdetailsRules position-relative"
                    >
                      <IonItem
                        className={
                          errors.profileTitle
                            ? 'error-border form-group input-label-box position-relative full-width-row mb-0'
                            : 'form-group input-label-box position-relative full-width-row mb-0'
                        }
                      >
                        <IonLabel position="floating">
                          {t('userproperties.text8')} <sup>*</sup>
                        </IonLabel>
                        <Controller
                          name="profileTitle"
                          control={control}
                          render={({ field: { value, onChange, ...field } }) => (
                            <IonTextarea
                              type='text'
                              autocomplete='off'
                              {...field}
                              onIonChange={({ target: { value, name } }) => {
                                onChange(value);
                                profileTitleChangeHandler(value, name);
                              }}
                              rows='4'
                              onClick={resetHandler}
                              placeholder=""
                              className='input-box full-width-row'
                              id="profileTitle"
                              {...register('profileTitle')}
                              maxlength={100} />
                          )}

                        />
                      </IonItem>
                      <p
                        className={
                          errors.profileTitle
                            ? 'error d-flex left w-100'
                            : 'd-flex justify-content-end'
                        }
                      >
                        {errors.profileTitle?.message}
                        <div className="d-flex ion-justify-content-end right0">
                          <p className="text-grey text-end font-14">
                            {editProfileFormState.profileTitle !==
                              undefined &&
                              editProfileFormState.profileTitle !== null &&
                              editProfileFormState.profileTitle.length > 0
                              ? editProfileFormState.profileTitle.length
                              : characterCount}
                            /{maxCount}
                          </p>
                          <PopoverCommon
                            className="popover-zyapaar"
                            Description={t('appproperties.text416')}
                          />
                        </div>
                      </p>
                    </IonCol>
                  </IonRow>
                </IonCol>
              </IonRow>
            </div>
            <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
              <IonRow>
                <IonButton
                  className="header-row-margin-left ion-button-color ml-auto pr-0"
                  size="small"
                  type="submit"
                  disabled={saveDisabled || !isValid}
                >
                  {t('appproperties.text149')}
                  {saveDisabled
                    ? (
                      <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                    )
                    : (
                      ''
                    )}
                </IonButton>
              </IonRow>
            </IonFooter>
          </form>
        </div>
      </IonModal>

      <IonModal
        isOpen={openModelFollowing}
        cssClass="pageModel"
        onDidDismiss={() => closeModel()}
      >
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          {getType === 'FOLLOWER'
            ? (
              <IonLabel className="MuiTypography-h6">{t('commonproperties.text38')}</IonLabel>
            )
            : (
              <IonLabel className="MuiTypography-h6">{t('userproperties.text4')}</IonLabel>
            )}
          <IonButton
            fill="clear"
            onClick={closeModel}
            className="close link-btn-tx ion-no-padding ion-no-margin"
          >
            <IonIcon
              icon={close}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </IonButton>
        </IonRow>
        <IonContent>
          <div className="modal-body">
            <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom member-listing">
              {loading
                ? (
                  <SkeletonComonViewAll
                    column={8}
                    sizeMd={3}
                    sizeXs={6}
                    name={true}
                    title={true}
                    distription={false}
                    link={false}
                  />
                )
                : ScrollFollowingData.length > 0
                  ? (
                    <>
                      {ScrollFollowingData.length >= 0 &&
                        ScrollFollowingData.map((list, i) => (
                          <CommonGridList key={i} id={list.id} defultImage={userProfile} img={list.img} name={list.name} subString={list.designation}
                            dots={false} redirectLink='profile' />
                        ))}
                    </>
                  )
                  : (
                    ''
                  )}
            </IonRow>
            <IonInfiniteScroll
              onIonInfinite={loadData}
              threshold="100px"
              disabled={isInfiniteDisabled}
            >
              <IonInfiniteScrollContent
                loadingSpinner="circular"
                loadingText={t('appproperties.text215')}
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </div>
        </IonContent>
      </IonModal>

      <IonModal
        isOpen={openModelConnection}
        cssClass="pageModel connectionModal"
        onDidDismiss={() => closeConnectionModel()}
        trigger="open-modal" initialBreakpoint={0.5} breakpoints={[0, 0.25, 0.5, 0.75, 1]}

      >
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          <IonLabel className="MuiTypography-h6 ms-lg-1 ms-2">{t('userproperties.text3')}</IonLabel>
          <IonButton
            fill="clear"
            onClick={closeConnectionModel}
            className="close link-btn-tx ion-no-padding ion-no-margin"
          >
            <IonIcon
              icon={close}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </IonButton>
        </IonRow>
        <IonContent>
          <div className="modal-body">
            <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom member-listing conmember">
              {loading
                ? (
                  <SkeletonComonViewAll
                    column={8}
                    sizeMd={3}
                    sizeXs={6}
                    name={true}
                    title={true}
                    distription={false}
                    link={false}
                  />
                )
                : ScrollconnectionData.length > 0
                  ? (
                    <>
                      {ScrollconnectionData.length >= 0 &&
                        ScrollconnectionData.map((list, i) => (
                          <CommonGridList key={i} id={list.id} defultImage={userProfile} img={list.img} name={list.name} subString={list.designation}
                            dots={true} redirectLink='profile' dotsEventLable1={t('appproperties.text5')}
                            setRemoveConfirmModel={setRemoveConfirmModel}
                            setRemoveConnectionModalData={setRemoveConnectionModalData} isAdmin={profileDetail.id === props.userId} />
                        ))}
                    </>
                  )
                  : (
                    ''
                  )}
            </IonRow>
            <IonInfiniteScroll
              onIonInfinite={loadDataConnection}
              threshold="100px"
              disabled={isInfiniteDisabled}
            >
              <IonInfiniteScrollContent
                loadingSpinner="circular"
                loadingText={t('appproperties.text215')}
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </div>
        </IonContent>
      </IonModal>

      <IonModal
        isOpen={messageModal}
        id="report-modal"
        onDidDismiss={() => {
          setMessageModal(false);
          setCharacterMessageCount(0);
        }}
        cssClass={'recommed-modal'}
      >

        <IonRow className="MuiDialogTitle-root full-width-row  ion-align-items-center ion-justify-content-between message-popclose">
          <IonLabel className="MuiTypography-h6 ion-padding-start ps-2">
            {t('userproperties.text10')}
          </IonLabel>
          <IonButton
            fill="clear"
            onClick={() => {
              setMessageModal(false);
              setCharacterMessageCount(0);
            }}
            className="close link-btn-tx ion-no-padding ion-no-margin"
          >
            <IonIcon
              icon={close}
              className="ion-button-color "
              slot="start"
              size="undefined"
            />
          </IonButton>
        </IonRow>

        <div className="modal-body">
          <form
            data-testid="form-submit"
            autoComplete="off"
          // onSubmit={messageSubmitHandler}
          // noValidate
          >
            <IonRow className="ion-padding full-width-row">
              <span className="mb-2">{t('appproperties.text171')}</span>
              <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                <MessageEditor
                  messageRef={messageRef}
                  messageChangeHandler={messageChangeHandler}
                />
                <p className={messageError ? 'error' : ''}>{messageError}</p>
                {/* <p className="text-grey text-end font-14">
                    {characterMessageCount}/{maxMessageCount}
                  </p> */}
              </IonCol>
              <IonCol className="header-row-margin-left ion-no-padding ion-padding-top ion-text-end">
                <IonButton
                  className="ion-button-color pr-0"
                  size="small"
                  type="button"
                  onClick={messageSubmitHandler}
                >
                  {t('appproperties.text365')}
                </IonButton>
              </IonCol>
            </IonRow>
          </form>
        </div>
      </IonModal>

      {/* Conatct Info Modal */}
      <IonModal isOpen={showContactInfo} cssClass="modelpadding post-modal" onDidDismiss={() => setShowContactInfo(false)} id="confirm-modal">
        <IonRow className='modalTitle p-3 ps-0'>
          <IonRow>
            <IonLabel className="MuiTypography-h6 ion-padding-start">Contact Inforamtion</IonLabel>
          </IonRow>
          <IonRow className='header-row-margin-left ion-align-items-center'>
            <IonButton
              fill="clear"
              className="ion-float-right close-btn-icon"
              onClick={() => setShowContactInfo(false)}
              size='small'
            >
              <div className='close-btn-icon'>
                <IonIcon icon={close} slot="start" />
              </div>
            </IonButton>
          </IonRow>
        </IonRow>
        <div className='modal-body ps-3'>
          {props.userProfileData === null && props.userProfileData === undefined && props.userProfileData === ''
            ? <p>No Contact Inforamtion Available here.</p>
            : <>
              {props.userProfileData.isLocked === false
                ? (
                  <>
                    {profileDetail.id === props.userId
                      ? (
                        <div>
                          {props.userProfileData.mobileNo
                            ? (
                              <IonLabel className="MuiTypography-body1 ion-text-cemter textcolour ion-padding-end d-flex align-items-center">
                                <IonIcon
                                  icon={callOutline}
                                  className="icon-svg color-theme-dark me-2 font-20"
                                />
                                <a className='color-theme-dark' href={'tel::' + props.userProfileData.mobileNo}>{props.userProfileData.mobileNo}</a>
                              </IonLabel>
                            )
                            : (
                              ''
                            )}
                        </div>
                      )
                      : (
                        ''
                      )}
                    {props.userProfileData.emailId
                      ? (
                        <IonLabel className="MuiTypography-body1 ion-text-cemter textcolour ion-padding-end d-flex align-items-center mt-3">
                          <IonIcon
                            icon={mailOutline}
                            className="icon-svg color-theme-dark me-2 font-20"
                          />
                          <a className='color-theme-dark' href={'mailto::' + props.userProfileData.emailId}>{props.userProfileData.emailId}</a>
                        </IonLabel>
                      )
                      : ''}
                  </>
                )
                : (
                  ''
                )
              }
            </>
          }

        </div>
      </IonModal>
      {/* End Conatct Info Modal */}

      <ToastCommon
        setShowToast={setShowToast}
        setShowToastMsg={setShowToastMsg}
        showToast={showToast}
        showToastMsg={showToastMsg}
        duration={5000}
      />
      <ReportSpamCommon
        reportModal={reportModal}
        setReportModel={setReportModel}
        reportId={props.userId}
        origin="USER"
        mapData={label}
        message={t('toastmessages.toast23')}
        setReportHideState={props.setReportHideState}
      />
      <ConfirmModelCommon
        header={t('appproperties.text22')}
        message={confirmMessage}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text21')}
        confirmModel={confirmModel}
        setConfirmModel={setConfirmModel}
        deleteBtnHandler={actionBtnHandler}
        iD={props.userProfileData.requestId}
        fromId={props.userId}
        type='CANCEL'
      />
      {removeConfirmModel
        ? <ConfirmModelCommon
          header={t('appproperties.text5')}
          message={removeConfirmMessage}
          btn1={t('appproperties.text11')}
          btn2={t('appproperties.text10')}
          confirmModel={removeConfirmModel}
          setConfirmModel={setRemoveConfirmModel}
          deleteBtnHandler={removeModalConnectionBtnHandler} />
        : ''}
      {loginModal
        ? <NotAuthorizeModal setAuthModal={setLoginModal} authModal={loginModal} />
        : ''}

    </>
  );
};
export default UserDetails;
