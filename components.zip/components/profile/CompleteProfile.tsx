/* eslint-disable indent */

import { IonCard, IonCol, IonRow } from '@ionic/react';
import React from 'react';
import { Link } from 'react-router-dom';
import ProfileIcon from '../../assets/img/complate-profile.svg';

const CompleteProfile = () => {
    return (
        <>
            <IonRow className='bg-white my-2 p-3 complete-profile'>
                <IonCol className='d-flex m-0'>
                    <div>
                        <img src={ProfileIcon} alt="Profile icon" />
                    </div>
                    <div className='ps-2 w-100 pt-1'>
                        <h4 className='p-0 m-0'>Complete  your profile</h4>
                        <div className='pt-1'>
                            <p>1 of 2 steps completed</p>
                        </div>
                        <div className='d-flex justify-content-between profileStep pb-2'>
                            <span className='borderRadius6'></span>
                            <span className='borderRadius6 grey-bg'></span>
                            </div>
                        <Link className='cp color-theme-dark' to={''}>
                            Complete Profile
                        </Link>
                    </div>
                </IonCol>
            </IonRow>
        </>
    );
};
export default CompleteProfile;
