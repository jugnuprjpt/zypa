/* eslint-disable react/jsx-key */
/* eslint-disable no-return-assign */
import {
  IonButton,
  IonCard,
  IonHeader,
  IonIcon,
  IonList,
  IonRow,
  useIonPopover
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import CallFor from '../../util/CallFor';
import { useHistory, useParams } from 'react-router';
import companyProfile from '../../assets/img/page-company-profile-placeholder.png';
import { add } from 'ionicons/icons';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import SkeletonComonList from '../common/skeleton/SkeletonComonList';
import CommonGridList from '../common/CommonGridList';
import { useTranslation } from 'react-i18next';

const Company = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const { userId } = useParams();
  const [companyDetail, setCompanyDetail] = useState([]);
  const profileDetail = useSelector(getProfileDetails);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    getComponyDetails();
  }, []);

  const getComponyDetails = async() => {
    setLoading(true);
    const companyData = await CallFor(
      'api/v1.1/companies?userId=' + userId,
      'GET',
      null,
      'Auth'
    );
    if (companyData.status === 200) {
      const json1Response = await companyData.json();
      if (json1Response.data !== null) {
        setCompanyDetail(json1Response.data);
      }
    }
    setLoading(false);
  };
  const openModelWithClearState = () => {
    history.push('/addnewcompany');
  };
  // for mobile
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr">
      <IonButton fill="clear" onClick={() => { onHide(); openModelWithClearState(); }} className="link-btn-tx ion-no-padding ion-no-margin" >
              <IonIcon
                icon={add}
                slot="start"
                size="default"
              /> {t('companyproperties.text2')}
              </IonButton>
    </IonList>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });
  return (
    <>
      <IonCard className="all-company-list-show profile-details MuiPaper-rounded ion-no-margin ion-margin-top ion-margin-bottom follower-list-card my-company-list grouplist-card ion-no-padding ion-padding-horizontal ion-padding-bottom shadow-none border-0 companylist">
        <IonHeader className="profile-header ion-no-border head-title-con">
          <div className='left-col-cn'>
            <h5>{t('companyproperties.text1')}</h5>
          </div>
          {profileDetail.id === userId
            ? <>
            {/* Add Company */}
            <div className='right-col-cn'>
              <div className="link-btn-tx ion-no-padding ion-no-margin font-regular" onClick={openModelWithClearState}>
                <IonIcon
                  icon={add}
                  slot="start"
                  size="default" /> {t('companyproperties.text2')}
              </div>
            </div>
            {/* End Add Company */}

              {/* for mobile */}
              {/* <div className="dot-btn show-mobile">
                <IonIcon
                  icon={ellipsisVertical}
                  slot="start"
                  className="test report cursor-pointer"
                  onClick={(e) => {
                    if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                      present({ event: e.nativeEvent });
                    } else {
                      // history.push('/addnewcompany');
                      setLoginModal(true);
                    }
                  } }
                 />
              </div> */}
              {/* for mobile */}
            </>
            : ''}
        </IonHeader>
        {loading
          ? <SkeletonComonList column={4} sizeMd={6} sizeXs={12} name={true} title={true} distription={true} link={false} />
          : <IonRow className="member-listing-group member-listing myconpanyilist">
            {companyDetail.length > 0
              ? (companyDetail.map((detail, i) => (
                  <CommonGridList key={i} id={detail.id} defultImage={companyProfile} img={detail.entityLogo} name={detail.name} subString={detail.city + ' ' + (detail.state ? ' | ' + detail.state : ' ')}
                    dots={false} redirectLink='companyDetail' DefaulCover={false} coverImg={false} />
                    // gotoProfile={'View Profile'} ..remove View Profile code
                ))
                )
              : ''}
          </IonRow>
        }
      </IonCard>
    </>
  );
};
export default Company;
