/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonChip,
  IonCol,
  IonFooter,
  IonHeader,
  IonIcon,
  IonLabel,
  IonRow
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import Like from '../../assets/img/emojis/like.svg';
import Celebrate from '../../assets/img/emojis/celebration.svg';
import ShakeHand from '../../assets/img/emojis/shakehands.svg';
import {
  arrowRedo,
  chatbox,
  ellipsisVertical,
  shareSocial
} from 'ionicons/icons';
import CallFor from '../../util/CallFor';
import { useTranslation } from 'react-i18next';

const Activity = () => {
  const { t } = useTranslation();
  const [activity, setActivityData] = useState([
    {
      _id: '907311478971146240',
      description:
        'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' +
        'Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s,' +
        'when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
      id: '907311478971146240',
      activityLogo:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'vaibhav',
      profileTitle: 'Purchase Manager at Istpl',
      tag: '#tag'
    }
  ]);
  useEffect(() => {
    getProductDetails();
  }, []);
  const getProductDetails = async() => {
    const response = await CallFor('api/v1/userdetail', 'GET', null, 'Auth');
    if (response.status === 201) {
      const json1Response = await response.json();
      setActivityData(json1Response.data);
    }
  };
  return (
    <>
      {activity.map((detail) => (
        <IonCard className="MuiPaper-rounded ion-no-margin ion-margin-top">
          <IonRow className="card-header-text ion-padding-start ion-padding-end ion-no-border">
            <p>shubham gupta {t('appproperties.text310')} </p>
          </IonRow>
          <IonRow>
            <IonHeader className="card-header">
              <div className="myprofile-feeds ion-padding-start ion-padding-top">
                <IonAvatar
                  slot="start"
                  className="MuiCardHeader-avatar MuiAvatar-circular"
                >
                  <img src={detail.activityLogo} />
                </IonAvatar>
                <IonRow className="profileName">
                  <IonCardTitle>
                    <p className="margin MuiTypography-body1">
                      {detail.name}
                    </p>
                    <span className="margin MuiTypography-caption">
                      {detail.profileTitle}
                    </span>
                  </IonCardTitle>
                </IonRow>
                <IonCol>
                  <IonRow className="ion-float-right">
                    <p className="ion-float-right ion-no-margin">20 min</p>
                    <IonButton
                      fill="clear"
                      size="small"
                      className="ion-no-margin"
                    >
                      <IonIcon icon={ellipsisVertical} className="test" />
                    </IonButton>
                  </IonRow>
                </IonCol>
              </div>
            </IonHeader>
          </IonRow>
          <IonRow>
            <IonRow>
              <IonButton
                className="ion-padding-start"
                color="warning"
                shape="round"
                size="small"
              >
                {t('postproperties.text5')}
              </IonButton>
            </IonRow>
            <IonRow className="ion-padding-top">
              <IonLabel className="MuiTypography-body1 ion-padding-start">
                {detail.description}
              </IonLabel>
            </IonRow>
            <IonRow>
              <IonLabel className="MuiTypography-body1 hashtage-color ion-padding-start">
                {detail.tag}
              </IonLabel>
            </IonRow>
          </IonRow>
          <IonRow className="card-header-text">
            <IonRow className="full-width-row">
              <IonCol size-md="6" size-xs="4" className="myprofile-feeds">
                <IonChip className="post-btn ion-no-padding ion-padding-start ion-padding-end">
                  <IonAvatar className="myprofile-feeds ion-no-padding reaction-btn">
                    <img src={Like} width='20'/>
                    <img src={Celebrate} width='20'/>
                    <img src={ShakeHand} width='20'/>
                  </IonAvatar>
                </IonChip>
                <p className="">112</p>
              </IonCol>
              <IonCol size-md="6" size-xs="8">
                <p className="ion-float-right ion-padding-end">
                  {' '}
                  258 {t('feedproperties.text11')} . 2,192 {t('feedproperties.text12')}
                </p>
              </IonCol>
            </IonRow>
            <IonFooter>
              <IonCol size-md="6" size-xs="2">
                <IonButton
                  fill="clear"
                  color="danger"
                  className="ion-text-capitalize ion-no-padding reaction-color-tab right-padding"
                >
                  <span>
                    <img src={Like} width='20'/>
                  </span>
                  &nbsp;{t('feedproperties.text6')}
                </IonButton>
                <IonButton
                  fill="clear"
                  className="ion-text-capitalize ion-no-padding reaction-color-tab right-padding"
                >
                  <span>
                    <IonIcon
                      icon={chatbox}
                      className="reaction-padding "
                      size="small"
                    />
                  </span>
                  &nbsp;{t('feedproperties.text13')}
                </IonButton>
                <IonButton
                  fill="clear"
                  className="ion-text-capitalize ion-no-padding reaction-color-tab right-padding"
                >
                  <span>
                    <IonIcon
                      icon={shareSocial}
                      className="reaction-padding "
                      size="small"
                    />
                  </span>
                  &nbsp;{t('feedproperties.text14')}
                </IonButton>
                <IonButton
                  fill="clear"
                  className="ion-text-capitalize ion-no-padding reaction-color-tab "
                >
                  <span>
                    <IonIcon
                      icon={arrowRedo}
                      className="reaction-padding "
                      size="large"
                    />
                  </span>
                  &nbsp;{t('feedproperties.text15')}
                </IonButton>
              </IonCol>
            </IonFooter>
          </IonRow>
        </IonCard>
      ))}
    </>
  );
};
export default Activity;
