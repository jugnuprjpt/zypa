      /* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  IonTextarea,
  useIonPopover
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { close, ellipsisVertical, informationCircle } from 'ionicons/icons';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import RecommendationInvitationList from './RecommendationInvitationList';
import callFor from '../../util/CallFor';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import AsyncSelect from 'react-select/async';
import { components } from 'react-select';
import { useHistory } from 'react-router';
import ToastCommon from '../common/ToastCommon';
import SkeletonRecommendation from '../common/skeleton/SkeletonRecommendation';
import { useTranslation } from 'react-i18next';
import NotAuthorizeModal from '../common/NotAuthorizeModal';
const Recommendations = (props: { userId: any; userName: any }) => {
  const { t } = useTranslation();
  const [loginModal, setLoginModal] = useState(false);
  const profileDetail = useSelector(getProfileDetails);
  const [userDetails, setuserDetails] = useState({});
  const [activeBtnClass, setActiveBtnClass] = useState('ion-button-color');
  const [formState, setformState] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [modalLable, setModalLable] = useState('');
  const [modalPlaceholder, setModalPlaceholder] = useState('');
  const [showToastMsg, setShowToastMsg] = useState('');
  const [invitationList, setInvitationList] = useState<object[]>([]);
  const [invitationListScroll, setInvitationListScroll] = useState<object[]>([]);
  const history = useHistory();
  const [scrollModel, setscrollModel] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [categoryCount, setCategoryCount] = useState();
  const [count, setCount] = useState(0);
  const [characterCount, setCharacterCount] = useState(0);
  const maxCount = 500;
  const [loading, setLoading] = useState(false);
  const [requestName, setRequestName] = useState('');
  useEffect(() => {
    getAllCategoryData('RECEIVED');
  }, []);
  const [recommendations, setRecommendations] = useState([]);
  const validationSchema = Yup.object().shape({
    // message: Yup.string().max(500).required('Message is required')
    message: Yup.string().trim().required(t('signuprecommendation.text9')).test(
      'len',
      t('commonproperties.text28'),
      (val) => val && val.toString().length >= 10
    ).test(
      'len',
      'Recommendation should be max 500 characters',
      (val) => val && val.toString().length <= 500
    )
  });
  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema)
  });
  const [myCompanyBtnClass, setMyCompanyBtnClass] =
    useState('category-btn-color');
  const getAllCategoryData = async(category: any) => {
    setLoading(true);
    setCategoryCount(category);
    let url = '';
    if (category === 'RECEIVED') {
      setActiveBtnClass('ion-button-color');
      setMyCompanyBtnClass('category-btn-color');
      url = 'api/v1.1/recommends/RECEIVED/' + props.userId;
    } else if (category === 'GIVEN') {
      setActiveBtnClass('category-btn-color');
      setMyCompanyBtnClass('ion-button-color');
      url = 'api/v1.1/recommends/GIVEN/' + props.userId;
    }
    const response = await callFor(url, 'POST', '{"page": 0 }', 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      setRecommendations(json1Response.data.content);
      setInvitationListScroll(json1Response.data.content);
    }
    setCount(1);
    setLoading(false);
  };
  const formDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    setformState({ ...formState, [event.target.name]: event.target.value });
  };
  const recommendModalHandler = (recommendType: string) => {
    setRequestName(recommendType);
    setModalLable(t('signuprecommendation.text8'));
    setModalPlaceholder(t('appproperties.text174'));
    if (recommendType === 'PENDING') {
      setModalLable(t('signuprecommendation.text7'));
      setModalPlaceholder(t('appproperties.text170'));
    }
    setformState({ status: recommendType });
    reset();
    setShowModal(true);
    setuserDetails({});
    dismiss();
  };
  const submitHandler = async() => {
    const data = formState;
    if (formState.status === 'PENDING') {
      data.recommendation = formState.message;
    }
    const response = await callFor('api/v1.1/user/recommendation/' + requestName, 'POST', JSON.stringify(data),
      'Auth');
    if (response.status === 200) {
      getAllCategoryData('RECEIVED');
      setShowModal(false);
      if (formState.status === 'PENDING') {
        setShowToastMsg(t('toastmessages.toast19'));
      } else {
        setShowToastMsg(t('toastmessages.toast17'));
      }
      setShowToast(true);
    } else if (response.status === 400) {
      const json1Response = await response.json();
      if (json1Response.error.message === 'You can not recommend your self') {
        setShowToastMsg(t('toastmessages.toast18'));
        setShowModal(false);
        setShowToast(true);
      } else {
        (
          setError('message', {
            type: 'required',
            message: json1Response.error.errors[0].message
          }));
      };
    }
  };
  const customStyles = {
    control: (provided: any) => ({
      ...provided,
      height: 48,
      background: 'fff !important',
      '&:focus': {
        border: '1px solid #d8d8d8 !important'
      }
    }),
    indicatorSeparator: () => { }, // removes the "stick"
    dropdownIndicator: (defaultStyles: any) => ({
      ...defaultStyles,
      '& svg': { display: 'none' }
    }),
    option: (provided: any) => ({
      padding: 0,
      paddingLeft: 10,
      paddingRight: 10,
      margin: 0
    })
  };
  const promiseOptions = (inputValue: string) =>
    new Promise<any>((resolve) => {
      resolve(filterSearchData(inputValue));
    });
  const filterSearchData = async(inputValue: string) => {
    if (inputValue.length >= 3) {
      const productsRes = await callFor('api/v1.1/searches/users/' + inputValue, 'GET', null, 'Auth');
      if (productsRes.status === 200) {
        const json1Response = await productsRes.json();
        const options = await json1Response.data.map(
          (d: { id: any; name: string; type: string; }) => ({
            value: d.id,
            label: <IonRow className='ion-align-items-center ion-no-margin ion-padding cursor-pointer' onClick={() => details(d.name, d.type, d.logo, d.id)}>
              <IonAvatar className="MuiAvatar ion-margin-end avr-small">
                {d.logo !== null
                  ? <img onError={(ev) => { ev.target.src = userProfile; }} src={d.logo} className='MuiAvatar-circular ion-no-margin' />
                  : <img src={userProfile} className='MuiAvatar-circular ion-no-margin' />
                }
              </IonAvatar>
              <span className="result-user-option ion-no-margin ion-no-padding"><b>{d.name} </b></span>
            </IonRow>
          })
        );
        return options;
      } else if (productsRes.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    }
    return '';
  };
  const details = (name, type, logo, id) => {
    if (name != null) {
      setuserDetails({ logo: logo, name: name, type: type });
    }
    setformState({ ...formState, to: id });
  };
  const handleSearch = (e) => {
    if (e.key === 'Enter' || e.key === 'Tab') {
      e.preventDefault();
      e.stopPropagation();
    }
  };
  const CustomOption = props => {
    const { data, innerRef, innerProps } = props;
    return data.custom
      ? (
        <div ref={innerRef} {...innerProps}>
          link
        </div>
        )
      : (
        <components.Option {...props} />
        );
  };
  // for mobile
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <><IonList className="my-account-pr">
      <IonButton fill="clear" onClick={() =>{onHide();  recommendModalHandler('PENDING')}} className="link-btn-tx ion-no-padding ion-no-margin ion-padding-end">
      {t('signuprecommendation.text7')}
      </IonButton>
    </IonList><IonList className="my-account-pr">
        <IonButton fill="clear" onClick={() =>{onHide();  recommendModalHandler('ASK')}} className="link-btn-tx ion-no-padding ion-no-margin" >
        {t('signuprecommendation.text8')}
        </IonButton>
      </IonList></>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });// for mobile
  const getAllCategoryDataScroll = async(category: any) => {
    let url = '';
    if (category === 'RECEIVED') {
      setActiveBtnClass('ion-button-color');
      setMyCompanyBtnClass('category-btn-color');
      url = 'api/v1.1/recommends/RECEIVED/' + props.userId;
    } else if (category === 'GIVEN') {
      setActiveBtnClass('category-btn-color');
      setMyCompanyBtnClass('ion-button-color');
      url = 'api/v1.1/recommends/GIVEN/' + props.userId;
    }
    const response = await callFor(url, 'POST', '{"page": ' + count + '}', 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setInvitationListScroll([...invitationListScroll, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const messageChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setformState({
        ...formState,
        message: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };
  const viewPaginaction = () => {
    setscrollModel(true);
    getAllCategoryDataScroll(categoryCount);
  };
  const closeScrollmodel = () => {
    setInvitationListScroll(recommendations);
    setCount(1);
    setscrollModel(false);
    setInfiniteDisabled(false);
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getAllCategoryDataScroll(categoryCount);
      ev.target.complete();
    }, 500);
  };
  return (
    <>{props.userId === profileDetail.id
      ? <RecommendationInvitationList userId={props.userId} userName={props.userName} />
      : ''}
      <IonCard className="profile-details MuiPaper-rounded ion-no-margin my-company-list ion-margin-top ion-margin-bottom follower-list-card shadow-none border-0">
        <IonHeader className="profile-header ion-no-border head-title-con">
          <div className='left-col-cn'>
            <h4>{t('appproperties.text145')}</h4>
          </div>
          <IonRow className='right-col-cn  gup-btn-action viewall-border'>
            {recommendations.length >= 5
              ? <IonButton fill="clear" onClick={viewPaginaction} className="ion-text-capitalize dn-mobile pr-0 link-btn-tx ion-no-padding ion-no-margin viewall-remove-border" >
               {t('commonproperties.text3')}
              </IonButton>
              : ''}
            <IonButton
              className={(activeBtnClass) + ' no-shadow ion-no-margin btn-sm-cn'}
              shape="round"
              size="small"
              onClick={() => getAllCategoryData('RECEIVED')}
            >
             {t('appproperties.text360')}
            </IonButton>
            <IonButton
              className={(myCompanyBtnClass) + ' no-shadow ion-no-margin btn-sm-cn pr-0 pe-1'}
              shape="round"
              size="small"
              onClick={() => getAllCategoryData('GIVEN')}
            >
              {t('appproperties.text168')}
            </IonButton>
            {props.userId === profileDetail.id
              ? <>
                {/* for mobile */}
                <div className="dot-btn pt-2">
                  <IonIcon
                    icon={ellipsisVertical}
                    slot="start"
                    className="test report cursor-pointer"
                    onClick={(e) => {
                      if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                        present({ event: e.nativeEvent });
                      } else {
                        // history.push('/addnewcompany');
                        setLoginModal(true);
                      }
                    }
                      }
                  />
                </div>{/* for mobile */}
              </>
              : ''
            }
          </IonRow>
        </IonHeader>
        {loading ? <SkeletonRecommendation column='3' />
          : recommendations.length > 0
            ? (
              <>      <IonRow>
                {recommendations.map((detail) => (
                  // eslint-disable-next-line react/jsx-key
                  <>
                    <IonRow className='border-bottom full-width-row sdb-box profile-details recommend-list-item recom-page-item-content'>
                      <IonCol size="12" className='d-flex'>
                        <IonAvatar className="MuiAvatar ion-margin-end cursor-pointer" onClick={() => { history.push('/profile/' + detail.userId); }}>
                          {detail.userProfile
                            ? <img onError={(ev) => { ev.target.src = userProfile; }} src={detail.userProfile} />
                            : <img src={userProfile} />}
                        </IonAvatar>
                        <IonRow className="display-grid">
                          <h6 className='cursor-pointer m-0' onClick={() => { history.push('/profile/' + detail.userId); }}>{detail.userName}</h6>
                          <span className="margin MuiTypography-caption group-model-text">
                            {detail.userDesignation}
                          </span>
                          <p>
                          {detail.recommendation}
                          </p>
                        </IonRow>
                      </IonCol>
                    </IonRow></>
                ))}
              </IonRow>
              </>
              )
            : <> {categoryCount === 'RECEIVED'
              ? props.userId === profileDetail.id
                ? <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text42')}</p>
                : <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text52')}</p>
              : props.userId === profileDetail.id
                ? <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text43')}</p>
                : <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text53')}</p>}</>
        }
        {recommendations.length >= 5
          ? <div className='right-col-cn gup-btn-action view-all-mobile'>
            <IonButton fill="clear" onClick={viewPaginaction} className="ion-text-capitalize link-btn-tx">
            {t('commonproperties.text3')}
            </IonButton>
          </div>
          : ''}
      </IonCard>
      <IonModal isOpen={showModal} onDidDismiss={() => { setShowModal(false); setCharacterCount(0); }} cssClass={'recommed-modal'}>
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between custom-modal-heading">
            <IonLabel className="MuiTypography-h6">
              {modalLable}
            </IonLabel>
            <IonButton fill="clear"
              onClick={() => { setShowModal(false); setCharacterCount(0); }}
              className="close link-btn-tx ion-no-padding ion-no-margin"
            >
              <IonIcon
                icon={close}
                className=""
                slot="start"
                size="undefined"
              />
            </IonButton>
          </IonRow>
          {userDetails.name == null
            ? <>
              <IonRow className='full-width-row ion-padding'>
                <span className='mb-2 full-width-row'>{t('appproperties.text169')}</span>
                <IonCol size-md="12" className='full-width-row ion-no-padding'>
                  <AsyncSelect
                    // placeholder= {<IonIcon icon={searchOutline} color='primary' className='reaction-padding top-padding' size='large' ></IonIcon>}
                    placeholder={modalPlaceholder}
                    id='comments' name='comments'
                    cacheOptions
                    loadOptions={promiseOptions}
                    className='selectOption recommendation-search'
                    onKeyDown={handleSearch}
                    defaultOptions
                    styles={customStyles}
                    components={{ Option: CustomOption }}
                    noOptionsMessage={() => {t('nodatafound.text10')}}
                  />
                </IonCol>
              </IonRow></>
            : <>
              <div className="modal-body">
                <IonRow className="MuiDialogTitle-root ion-padding-end ion-padding-start overflow-y">
                  <IonCol size="12">
                    <div className="myprofile-feeds ion-no-padding">
                      <IonAvatar
                        slot="start"
                        className="MuiCardHeader-avatar ion-margin-end"
                      >
                        {userDetails.logo !== null
                          ? <img onError={(ev) => { ev.target.src = userProfile; }} src={userDetails.logo} />
                          : <img src={userProfile} />}
                      </IonAvatar>
                      <IonRow className="profileName">
                        <IonCardTitle>
                          <p className="margin">
                            {userDetails.name}
                          </p>
                        </IonCardTitle>
                      </IonRow>
                    </div>
                  </IonCol>
                </IonRow>
                <form
                  data-testid="form-submit"
                  autoComplete="off"
                  onSubmit={handleSubmit(submitHandler)}
                >
                  <IonRow className='ion-padding full-width-row'>
                    {/* <span>The recommendation will appear on {profileDetail.name} profile</span>
                    <span>Include a personalized message with your request</span> */}
                    <span className='mb-2'>{t('appproperties.text171')}</span>
                    <IonCol size-md="12" size-xs="12" className='ion-no-padding'>
                      <div className='border borderRadius6 p-2 h-300'>
                        <IonTextarea
                          className={
                            errors.message
                              ? 'error-border input-box borderRadius6 overflow-y'
                              : 'input-box borderradius6 overflow-y'
                          }
                          data-testid="message"
                          placeholder={t('appproperties.text324')}
                          id="message"
                          onIonChange={messageChangeHandler}
                          value={formState.message}
                          {...register('message')}
                          maxlength={500}
                          rows="11"
                        />
                      </div>
                      <p className={errors.message ? 'error' : ''}>
                        {errors.message?.message}
                      </p>
                      <p className='text-grey text-end font-14'>{characterCount}/{maxCount}</p>
                    </IonCol>
                    <IonCol className='header-row-margin-left ion-no-padding ion-padding-top ion-text-end'>
                      <IonButton
                        className='ion-button-color pr-0'
                        size="small"
                        type='submit'
                      >
                       {t('feedproperties.text15')}
                      </IonButton>
                    </IonCol>
                  </IonRow>
                </form>
              </div>
            </>
          }
        </IonContent>
      </IonModal>
      <IonModal isOpen={scrollModel} cssClass="team-list-modal" onDidDismiss={() => closeScrollmodel()}>
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          <IonLabel className="MuiTypography-h6">{t('commonproperties.text3')}</IonLabel>
          <IonButton fill="clear" onClick={closeScrollmodel} className="close link-btn-tx ion-no-padding ion-no-margin" >
            <IonIcon
              icon={close}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </IonButton>
        </IonRow>
        <IonContent>
          <div className="modal-body">
            <IonRow>
              {invitationListScroll.map((detail) => (
                // eslint-disable-next-line react/jsx-key
                <>
                  <IonRow className='border-bottom full-width-row sdb-box profile-details recommend-list-item ion-padding-start ion-padding-end '>
                    <IonCol size="12">
                      <div className="myprofile-feeds ion-no-padding cursor-pointer float-left" onClick={() => { history.push('/profile/' + detail.userId); }} >
                        <IonAvatar className="MuiAvatar ion-margin-end">
                          {detail.userProfile
                            ? <img onError={(ev) => { ev.target.src = userProfile; }} src={detail.userProfile} />
                            : <img src={userProfile} />}
                        </IonAvatar>
                        <IonRow className="display-grid">
                          <b>{detail.userName}</b>
                          <span className="margin MuiTypography-caption group-model-text">
                            {detail.userDesignation}
                          </span>
                        </IonRow>
                      </div>
                    </IonCol>
                    <IonCol size='12'>
                      <p>
                      {detail.recommendation}
                      </p>
                    </IonCol>
                  </IonRow></>
              ))}
            </IonRow>
            <IonInfiniteScroll
              onIonInfinite={loadData}
              threshold="100px"
              disabled={isInfiniteDisabled}
            >
              <IonInfiniteScrollContent
                loadingSpinner="circular"
                loadingText={t('appproperties.text215')}
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </div>
        </IonContent>
      </IonModal>
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}
    </>
  );
};
export default Recommendations;
