/* eslint-disable react/jsx-key */
import { yupResolver } from '@hookform/resolvers/yup';
import {
  IonCard,
  IonHeader,
  IonRow,
  IonAvatar,
  IonCardTitle,
  IonButton,
  IonCol,
  IonContent,
  IonIcon,
  IonLabel,
  IonModal,
  IonTextarea,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonFooter
} from '@ionic/react';
import {
  checkmarkCircleOutline,
  close,
  closeCircleOutline
} from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import callFor from '../../util/CallFor';
import * as Yup from 'yup';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import { useHistory } from 'react-router';
import { Link } from 'react-router-dom';
import ToastCommon from '../common/ToastCommon';
import SkeletonRecommendation from '../common/skeleton/SkeletonRecommendation';
import ButtonComponent from '../common/ButtonComponent';
import { useTranslation } from 'react-i18next';

const RecommendationInvitationList = (props: {
  userId: any;
  userName: any;
}) => {
  const { t } = useTranslation();
  const profileDetail = useSelector(getProfileDetails);
  const [activeBtnClass, setActiveBtnClass] = useState('ion-button-color');
  const [userDetails, setUserDetails] = useState({});
  const [givenBtn, setGivenBtn] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [myCompanyBtnClass, setMyCompanyBtnClass] =
    useState('category-btn-color');
  const [invitationList, setInvitationList] = useState<object[]>([]);
  const [invitationListScroll, setInvitationListScroll] = useState<object[]>(
    []
  );
  const history = useHistory();
  const [scrollModel, setscrollModel] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [categoryCount, setCategoryCount] = useState();
  const [count, setCount] = useState(0);
  const [characterCount, setCharacterCount] = useState(0);
  const maxCount = 500;
  const [loading, setLoading] = useState(false);
  const validationSchema = Yup.object().shape({
    message: Yup.string()
      .required(t('userproperties.text17'))
      .test(
        'len',
        t('commonproperties.text28'),
        (val) => val && val.toString().length >= 10
      )
      .test(
        'len',
        t('commonproperties.text40'),
        (val) => val && val.toString().length <= 500
      )
  });
  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema)
  });
  useEffect(() => {
    getAllCategoryData(1);
  }, []);
  const [formState, setformState] = useState({ to: props.userId });
  const getAllCategoryData = async(category: any) => {
    setLoading(true);
    setCategoryCount(category);
    let url = '';
    if (category === 1) {
      setActiveBtnClass('ion-button-color');
      setMyCompanyBtnClass('category-btn-color');
      url = 'api/v1.1/recommends/PENDING';
      setGivenBtn(false);
    } else if (category === 2) {
      setGivenBtn(true);
      setActiveBtnClass('category-btn-color');
      setMyCompanyBtnClass('ion-button-color');
      url = 'api/v1.1/recommends/ASK';
    }
    const response = await callFor(url, 'POST', '{"page": 0 }', 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      setInvitationList(json1Response.data.content);
      setInvitationListScroll(json1Response.data.content);
    }
    setCount(1);
    setLoading(false);
  };
  const statusChangeHandler = async(
    id: any,
    status: string,
    message: string,
    name: string,
    logo: string
  ) => {
    setUserDetails({ id: id, name: name, logo: logo });
    setformState({ to: props.userId });
    if (givenBtn) {
      if (status === 'DELETE') {
        const response = await callFor(
          'api/v1.1/user/recommendation/' + status,
          'POST',
          JSON.stringify({ status: status, id: id }),
          'Auth'
        );
        if (response.status === 200) {
          setInvitationList(invitationList.filter((item) => item.id !== id));
        }
      } else {
        setformState({ status: 'PENDING', id: id });
        reset();
        setShowModal(true);
      }
    } else {
      const response = await callFor(
        'api/v1.1/user/recommendation/' + status,
        'POST',
        JSON.stringify({ status: status, id: id }),
        'Auth'
      );
      if (response.status === 200) {
        // getAllCategoryData(1);
        setInvitationList(invitationList.filter((item) => item.id !== id));
      }
    }
  };
  const formDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined && event.target.value.length > 0) {
      event.target.classList.add('input-fill');
    } else {
      event.target.classList.remove('input-fill');
    }
    setformState({ ...formState, [event.target.name]: event.target.value });
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };
  const submitHandler = async() => {
    const data = formState;
    if (formState.status === 'PENDING') {
      data.recommendation = formState.message;
    }
    const response = await callFor(
      'api/v1.1/user/recommendation/' + formState.status,
      'POST',
      JSON.stringify(data),
      'Auth'
    );
    if (response.status === 200) {
      setShowModal(false);
      setInvitationList(invitationList.filter((item) => item.id !== data.id));
      if (formState.status === 'PENDING') {
        setShowToastMsg(t('toastmessages.toast19'));
      } else {
        setShowToastMsg('Your Request sent successfully');
      }
      setShowToast(true);
    } else if (response.status === 400) {
      const datares = await response.json();
      setError('message', {
        type: 'required',
        message: datares.error.errors[0].message
      });
    }
  };
  const getAllCategoryDataScroll = async(category: any) => {
    let url = '';
    if (category === 1) {
      url = 'api/v1.1/recommends/PENDING';
      setGivenBtn(false);
    } else if (category === 2) {
      setGivenBtn(true);
      url = 'api/v1.1/recommends/ASK';
    }
    const response = await callFor(
      url,
      'POST',
      '{"page": ' + count + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setInvitationListScroll([
          ...invitationListScroll,
          ...json1Response.data.content
        ]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  const viewPaginaction = () => {
    setscrollModel(true);
    getAllCategoryDataScroll(categoryCount);
  };
  const closeScrollmodel = () => {
    setCount(1);
    setscrollModel(false);
    setInvitationListScroll(invitationList);
    setInfiniteDisabled(false);
  };

  const loadData = (ev: any) => {
    setTimeout(() => {
      getAllCategoryDataScroll(categoryCount);
      ev.target.complete();
    }, 500);
  };
  return (
    <>
      <IonCard className="profile-details MuiPaper-rounded ion-no-margin my-company-list ion-margin-top follower-list-card recom-list-for-invite mb-lg-0 mb-0 no-shadow">
        <IonHeader className="profile-header ion-no-border head-title-con ">
          <div className="left-col-cn">
            {/* <h4>Pending</h4> */}
          </div>
          <div className="right-col-cn gup-btn-action ">
            <IonButton
              className={activeBtnClass + ' no-shadow ion-no-margin btn-sm-cn '}
              shape="round"
              size="small"
              onClick={() => getAllCategoryData(1)}
            >
             {t('appproperties.text360')}
            </IonButton>
            <IonButton
              className={
                myCompanyBtnClass + ' no-shadow ion-no-margin btn-sm-cn pr-0'
              }
              shape="round"
              size="small"
              onClick={() => getAllCategoryData(2)}
            >
             {t('appproperties.text167')}
            </IonButton>
            {invitationList.length >= 5
              ? (
              <IonButton
                fill="clear"
                onClick={viewPaginaction}
                className=" ion-text-capitalize dn-mobile no-shadow ion-no-margin link-btn-tx btn-sm-cn pr-0"
              >
               {t('commonproperties.text3')}
              </IonButton>
                )
              : (
                  ''
                )}
          </div>
        </IonHeader>
        {loading
          ? <SkeletonRecommendation column='3' button={true}/>
          : invitationList.length > 0
            ? (
          <>
            {invitationList.map((invitationlist) => (
              <>
                <IonRow className="ion-bottom-padding-smallcom GroupInvitation-list-item rm-invitation">
                  <IonRow className="col-rm-left">
                    <div
                      className="myprofile-feeds ion-no-padding  cursor-pointer"
                      onClick={() => {
                        history.push('/profile/' + invitationlist.userId);
                      }}
                    >
                      <IonAvatar className="MuiAvatar ">
                        {invitationlist.userProfile !== null
                          ? (
                          <img onError={(ev) => { ev.target.src = userProfile; }} src={invitationlist.userProfile} />
                            )
                          : (
                          <img src={userProfile} />
                            )}
                      </IonAvatar>
                      <IonRow className="profileName ion-padding-start">
                        <IonCardTitle className="ion-no-padding">
                          <p className="margin fixed-textline">{invitationlist.userName}</p>
                          <span className="margin MuiTypography-caption pcolor fixed-textline1">
                            {invitationlist.userDesignation}
                          </span>
                          <p className='fixed-textline'>
                            {invitationlist.message}
                          </p>
                        </IonCardTitle>
                      </IonRow>
                    </div>
                  </IonRow>
                  <IonRow className="header-row-margin-left col-rm-right">
                    <ButtonComponent
                      btnClick={statusChangeHandler}
                      size="small"
                      className='no-shadow btn-sm-cn ion-button-color btnIgnore'
                      field1={invitationlist.id} field2='DELETE' field3={invitationlist.message}
                      field4={invitationlist.userName} field5 ={invitationlist.userProfile}
                      name={t('appproperties.text19')} parametersPass={5} />
                     <ButtonComponent
                        btnClick={statusChangeHandler}
                        size="small"
                        className='category-btn-color h-ion-btn-cl btn-sm-cn pr-0 btnAccept ms-2'
                        field1={invitationlist.id} field2='ACCEPT' field3={invitationlist.message}
                        field4={invitationlist.userName} field5 ={invitationlist.userProfile}
                        name={t('appproperties.text20')} parametersPass={5} />
                  </IonRow>
                </IonRow>
              </>
            ))}
          </>
              )
            : (
          <>
            {categoryCount === 1
              ? (
              <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">
                {t('nodatafound.text44')}
              </p>
                )
              : (
              <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">
                {t('nodatafound.text44')}
              </p>
                )}
          </>
              )}
        {invitationList.length >= 5
          ? (
          <div className="right-col-cn gup-btn-action view-all-mobile">
            <IonButton
              fill="clear"
              onClick={viewPaginaction}
              className="link-btn-tx ion-text-capitalize"
            >
             {t('commonproperties.text3')}
            </IonButton>
          </div>
            )
          : (
              ''
            )}
      </IonCard>
      <IonModal 
        isOpen={showModal}
        onDidDismiss={() => { setShowModal(false); setCharacterCount(0); }}
        cssClass={'recommed-modal'}
        id="report-modal"
      >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6 ion-padding-start p-0">
            {t('appproperties.text398')}
            </IonLabel>
            <IonButton
              fill="clear"
              onClick={() => { setShowModal(false); setCharacterCount(0); } }
              className="close link-btn-tx ion-no-padding ion-no-margin"
            >
              <IonIcon
                icon={close}
                className="ion-button-color "
                slot="start"
                size="undefined"
              />
            </IonButton>
          </IonRow>
          <div className="modal-body">
            <form
              data-testid="form-submit"
              autoComplete="off"
              onSubmit={handleSubmit(submitHandler)}
              className="h-100"
            >
              <div className="body-content overflow-hidden">
                <IonRow className="MuiDialogTitle-root ion-padding-start">
                  <IonCol size="12">
                    <div className="myprofile-feeds ion-no-padding">
                      <IonAvatar
                        slot="start"
                        className="MuiCardHeader-avatar ion-margin-end md hydrated"
                      >
                        {userDetails.logo !== null
                          ? (
                          <img onError={(ev) => { ev.target.src = userProfile; }} src={userDetails.logo} />
                            )
                          : (
                          <img src={userProfile} />
                            )}
                      </IonAvatar>
                      <IonRow className="profileName">
                        <IonCardTitle class="ion-inherit-color md hydrated">
                          <p className="margin">
                            <b>{userDetails.name}</b>
                          </p>
                        </IonCardTitle>
                      </IonRow>
                    </div>
                  </IonCol>
                </IonRow>
                <IonRow className="ion-padding full-width-row">
                  <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                    <div className="input-label-box p-1">
                      <IonTextarea
                        rows="5"
                        className={
                          errors.message
                            ? 'error-border input-box border borderRadius10 textarea-spacing'
                            : 'input-box border borderRadius10 textarea-spacing'
                        }
                        data-testid="message"
                        id="message"
                        placeholder={t('appproperties.text324')}
                        onIonChange={formDataChangeHandler}
                        value={formState.message}
                        {...register('message')}
                        maxlength={500}
                      />
                      <p className={errors.message ? 'error' : ''}>
                      {errors.message?.message}
                    </p>
                    <p className='text-grey text-end font-14'>{characterCount}/{maxCount}</p>
                    </div>
                  </IonCol>
                </IonRow>
              </div>
              
              <IonRow className='pe-2'>
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto pr-0"
                    size="small"
                    type="submit"
                  >
                   {t('feedproperties.text15')}
                  </IonButton>
                </IonRow>
              
            </form>
          </div>
        </IonContent>
      </IonModal>
      <IonModal
        isOpen={scrollModel}
        cssClass="team-list-modal"
        onDidDismiss={() => closeScrollmodel()}
      >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">{t('commonproperties.text3')} </IonLabel>
            <IonButton
              fill="clear"
              onClick={closeScrollmodel}
              className="close link-btn-tx ion-no-padding ion-no-margin"
            >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined"
              />
            </IonButton>
          </IonRow>
          <div className="modal-body">
            <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom my-company-list">
              {invitationListScroll.map((invitationlist) => (
                <>
                  <IonRow className="ion-bottom-padding-smallcom full-width-row GroupInvitation-list-item rm-invitation">
                    <IonRow className="col-rm-left">
                      <div
                        className="myprofile-feeds ion-no-padding  cursor-pointer"
                        onClick={() => {
                          history.push('/profile/' + invitationlist.userId);
                        }}
                      >
                        <IonAvatar className="MuiAvatar ">
                          {invitationlist.userProfile !== null
                            ? (
                            <img onError={(ev) => { ev.target.src = userProfile; }} src={invitationlist.userProfile} />
                              )
                            : (
                            <img src={userProfile} />
                              )}
                        </IonAvatar>
                        <IonRow className="profileName ion-padding-start">
                          <IonCardTitle>
                            <p className="margin">{invitationlist.userName}</p>
                            <span className="margin MuiTypography-caption">
                              {invitationlist.userDesignation}
                            </span>
                            <p>
                              {invitationlist.message}
                              {/* {invitationlist.recommendation} */}
                            </p>
                          </IonCardTitle>
                        </IonRow>
                      </div>
                    </IonRow>
                    <IonRow className="header-row-margin-left col-rm-right">
                      <IonButton
                        className="link-btn-tx btn-sm-cn"
                        fill="clear"
                        size="small"
                        onClick={() =>
                          statusChangeHandler(
                            invitationlist.id,
                            'DELETE',
                            invitationlist.message,
                            invitationlist.userName,
                            invitationlist.userProfile
                          )
                        }
                      >
                        <span className="dn-mobile">ignore</span>
                        <IonIcon
                          className="show-mobile"
                          icon={closeCircleOutline}
                        ></IonIcon>
                      </IonButton>
                      <IonButton
                        className="category-btn-color h-ion-btn-cl btn-sm-cn pr-0"
                        size="small"
                        onClick={() =>
                          statusChangeHandler(
                            invitationlist.id,
                            'ACCEPT',
                            invitationlist.message,
                            invitationlist.userName,
                            invitationlist.userProfile
                          )
                        }
                      >
                        <span className="dn-mobile">{t('appproperties.text20')}</span>
                        <IonIcon
                          className="show-mobile"
                          icon={checkmarkCircleOutline}
                        ></IonIcon>
                      </IonButton>
                    </IonRow>
                  </IonRow>
                </>
              ))}
            </IonRow>
            <IonInfiniteScroll
              onIonInfinite={loadData}
              threshold="100px"
              disabled={isInfiniteDisabled}
            >
              <IonInfiniteScrollContent
                loadingSpinner="circular"
                loadingText={t('appproperties.text215')}
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </div>
        </IonContent>
      </IonModal>
      <ToastCommon
        setShowToast={setShowToast}
        setShowToastMsg={setShowToastMsg}
        showToast={showToast}
        showToastMsg={showToastMsg}
        duration={5000}
      />
    </>
  );
};
export default RecommendationInvitationList;
