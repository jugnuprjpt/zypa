/* eslint-disable react/jsx-key */
import {
  IonRow,
  IonButton,
  IonCard,
  IonAvatar,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonCol,
  IonContent,
  IonFooter,
  IonIcon,
  IonLabel,
  IonModal
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import CallFor from '../../util/CallFor';
import notificationimage from '../../assets/img/user-profile-placeholder.png';
import { useHistory } from 'react-router';
import { close } from 'ionicons/icons';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Device } from '@capacitor/device';
import SkeletonNotification from '../common/skeleton/SkeletonNotification';
import companyProfile from '../../assets/img/page-company-profile-placeholder.png';
import groupLogo from '../../assets/img/group-profile-placeholder.png';
import pageLogo from '../../assets/img/page-logo-default.png';
import ToastCommon from '../common/ToastCommon';
import ButtonComponent from '../common/ButtonComponent';
import { useTranslation } from 'react-i18next';
const NotificationDetails = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const [allBtnClass, setAllBtnClass] = useState('ion-button-color');
  const [notificationData, setNotificationData] = useState([]);
  const [viewBtnClass, setViewBtnClass] = useState('category-btn-color');
  const [requestBtnClass, setRequestBtnClass] = useState('category-btn-color');
  const [postBtnClass, setPostBtnClass] = useState('category-btn-color');
  const [messageBtnClass, setMessageBtnClass] = useState('category-btn-color');
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [categoryType, setCategoryType] = useState('ALL');
  const [modelJsonData, setModelJsonData] = useState({});
  const [showToastMsg, setShowToastMsg] = useState('');
  const [confirmModel, setConfirmModel] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [count, setCount] = useState(0);
  const deviceDetails = Device.getInfo();
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    getNotificationData('ALL', 0);
  }, []);

  const getNotificationData = async(category: string, page: number) => {
    setLoading(true);
    setInfiniteDisabled(false);
    if (category === 'ALL') {
      setAllBtnClass('ion-button-color');
      setViewBtnClass('category-btn-color');
      setRequestBtnClass('category-btn-color');
      setPostBtnClass('category-btn-color');
      setMessageBtnClass('category-btn-color');
    } else if (category === 'VIEW') {
      setAllBtnClass('category-btn-color');
      setViewBtnClass('ion-button-color');
      setRequestBtnClass('category-btn-color');
      setPostBtnClass('category-btn-color');
      setMessageBtnClass('category-btn-color');
    } else if (category === 'REQUEST') {
      setAllBtnClass('category-btn-color');
      setViewBtnClass('category-btn-color');
      setRequestBtnClass('ion-button-color');
      setPostBtnClass('category-btn-color');
      setMessageBtnClass('category-btn-color');
    } else if (category === 'POST') {
      setAllBtnClass('category-btn-color');
      setViewBtnClass('category-btn-color');
      setRequestBtnClass('category-btn-color');
      setPostBtnClass('ion-button-color');
      setMessageBtnClass('category-btn-color');
    } else if (category === 'MESSAGE') {
      setAllBtnClass('category-btn-color');
      setViewBtnClass('category-btn-color');
      setRequestBtnClass('category-btn-color');
      setPostBtnClass('category-btn-color');
      setMessageBtnClass('ion-button-color');
    }
    const data = await getAllFeedDataFirstTime(0, category, false);
    if (data.length > 0) {
      const data1 = await getAllFeedDataFirstTime(1, category, false);
      if (data1.length > 0) {
        setNotificationData([...data, ...data1]);
        setCount(2);
      } else {
        setNotificationData(data);
        setInfiniteDisabled(true);
      }
    } else {
      setNotificationData([]);
      setInfiniteDisabled(true);
    }
    setCategoryType(category);
    setLoading(false);
  };
  const getAllFeedData = async(
    page: string | number,
    category: string,
    scrolling: boolean
  ) => {
    const allFeedDataResponse = await CallFor(
      'api/v1.1/notifications/' + category,
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      if (json1Response.data.content !== null) {
        if (scrolling) {
          if (json1Response.data.content.length > 0) {
            setNotificationData([
              ...notificationData,
              ...json1Response.data.content
            ]);
          } else {
            setInfiniteDisabled(true);
          }
        } else {
          setNotificationData(json1Response.data.content);
        }
      }
    } else {
      return [];
    }
  };
  const getAllFeedDataFirstTime = async(
    page: string | number,
    category: string,
    scrolling: boolean
  ) => {
    const allFeedDataResponse = await CallFor(
      'api/v1.1/notifications/' + category,
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      if (json1Response.data.content !== null) {
        return json1Response.data.content;
      } else {
        return [];
      }
    } else {
      return [];
    }
  };
  const changeContent = (contentObj, type) => {
    let finalString = contentObj.text;
    if (contentObj.attributes.length > 0) {
      contentObj.attributes.map(
        (element, index) => {
          const res = contentObj.text.substring(
            element.start,
            element.start + element.length
          );
          if (element.mention === 'PROFILE' || element.mention === 'COMPANY' || element.mention === 'PAGE' || element.mention === 'GROUP') {
            if (type === 1 || type === 9 || type === 10 || type === 11 || type === 12 || type === 13) {
              // finalString = finalString.replace(
              //   res,
              //   '<a style="text-decoration: none;" class = "font-color">' +
              //     res +
              //     '</a>'
              // );
              const stringlength = '<a class="color-theme fw-bold text-deco-none btn-watch"></a>';
              if (element.start === 0) {
                finalString = finalString.substr(0, element.start) + '<a class="color-theme fw-bold text-deco-none btn-watch">' +
                res +
                '</a>' + finalString.substr(element.start + element.length);
              } else {
                if (contentObj.attributes.length === 1) {
                  finalString = finalString.substr(0, (element.start)) + '<a class="color-theme fw-bold text-deco-none btn-watch">' +
                  res +
                  '</a>' + finalString.substr((element.start + stringlength.length) + element.length);
                } else if (index > 1) {
                  finalString = finalString.substr(0, (element.start + (stringlength.length * index))) + '<a style="text-decoration: none;" class = "btn-watch">' +
                  res +
                  '</a>' + finalString.substr((element.start + (stringlength.length * index)) + element.length);
                } else {
                  finalString = finalString.substr(0, (element.start + stringlength.length)) + '<a class="color-theme fw-bold text-deco-none btn-watch">' +
                  res +
                  '</a>' + finalString.substr((element.start + stringlength.length) + element.length);
                }
              }
            } else {
              const stringlength = '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer"></span>';
              if (element.start === 0) {
                finalString = finalString.substr(0, element.start) + '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer">' + res + '</span>' + finalString.substr(element.start + element.length);
              } else {
                if (contentObj.attributes.length === 1) {
                  finalString = finalString.substr(0, (element.start + stringlength.length + element.length)) + '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer">' + res + '</span>' + finalString.substr((element.start + stringlength.length) + element.length);
                } else if (index > 1) {
                  finalString = finalString.substr(0, (element.start + (stringlength.length * index))) + '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer">' +
                  res +
                  '</span>' + finalString.substr((element.start + (stringlength.length * index)) + element.length);
                } else {
                  finalString = finalString.substr(0, (element.start + stringlength.length)) + '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer">' +
                  res +
                  '</span>' + finalString.substr((element.start + stringlength.length) + element.length);
                }
              }
              // finalString = finalString.replace(
              //   res,
              //   '<span class="font-color cursor-pointer">' + res + '</span>'
              // );
            }
          }
        }
      );
    }
    if (type === 13) {
      finalString = finalString.replace(finalString.split('message : ')[1], messageConvert(finalString.split('message : ')[1]));
    }
    finalString = finalString.replace(/(\r\n|\r|\n)/g, '<br>');
    return <span dangerouslySetInnerHTML={{ __html: finalString }} />;
  };
  const messageConvert = (value: string) => {
    if (value.startsWith('{') && value.endsWith('}')) {
      const data = JSON.parse(value);
      let finalString = data.text;
      if (data.attributes.length > 0) {
        data.attributes.map(
          (element: { start: number; length: any; }, index: number) => {
            const res = data.text.substring(
              element.start,
              element.start + element.length
            );
            const stringlength = '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer"></span>';
            if (element.start === 0) {
              finalString = finalString.substr(0, element.start) + '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer">' + res + '</span>' + finalString.substr(element.start + element.length);
            } else {
              if (data.attributes.length === 1) {
                finalString = finalString.substr(0, (element.start + stringlength.length + element.length)) + '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer">' + res + '</span>' + finalString.substr((element.start + stringlength.length) + element.length);
              } else if (index > 1) {
                finalString = finalString.substr(0, (element.start + (stringlength.length * index))) + '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer">' +
                res +
                '</span>' + finalString.substr((element.start + (stringlength.length * index)) + element.length);
              } else {
                finalString = finalString.substr(0, (element.start + stringlength.length)) + '<span class="color-theme fw-bold text-deco-none btn-watch cursor-pointer">' +
                res +
                '</span>' + finalString.substr((element.start + stringlength.length) + element.length);
              }
            }
          });
      }
      return finalString;
    }
    return value;
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getAllFeedData(count, categoryType, true);
      notificationData.map((notification) => (
        removeNotificationCount(notification.id, notification.isRead)
      ));
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  };
  const viewPost = (content, type, originId) => {
    if (type === 2 || type === 3 || type === 4 || type === 5 || type === 6 || type === 7 || type === 8 || type === 15 || type === 16 || type === 17 || type === 19 || type === 20 || type === 21 || type === 22) {
      history.push('/viewfeed/' + originId);
    } else if (type === 9) {
      history.push('/companyDetail/' + originId);
    } else if (type === 10) {
      history.push('/groups/' + originId);
    } else if (type === 11) {
      history.push('/pageDetails/' + originId);
    } else {
      history.push('/profile/' + content.attributes[0].id);
    }
  };
  const viewProfile = (content, type, originId) => {
    if (content.attributes[0].mention === 'PROFILE') {
      history.push('/profile/' + content.attributes[0].id);
    }
    // } else {
    //   if (type === 9) {
    //     history.push('/companyDetail/' + originId);
    //   } else if (type === 10) {
    //     history.push('/groups/' + originId);
    //   } else if (type === 11) {
    //     history.push('/pageDetails/' + originId);
    //   } else if (type === 12) {
    //     history.push('/network/');
    //   }
    // }
  };
  const removeNotificationCount = async(id, isRead) => {
    if (!isRead) {
      const stateres = await CallFor(
        'api/v1.1/notifications/' + id,
        'GET',
        null,
        'Auth'
      );
      if (stateres.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    }
  };
  const imgChange = (content, type) => {
    if (type === 1) {
      if (content.attributes[0].img === null) {
        return notificationimage;
      } else {
        return content.attributes[0].img;
      }
    } else if (type === 2 || type === 3 || type === 4 || type === 5 || type === 6 || type === 7 || type === 8 || type === 15 || type === 16 || type === 17 || type === 19 || type === 20 || type === 21 || type === 22) {
      // console.log(content.attributes);
      if (content.attributes[0].img === null) {
        return notificationimage;
      } else {
        return content.attributes[0].img;
      }
    } else if (type === 9) {
      if (content.attributes[0].mention === 'PROFILE') {
        if (content.attributes[0].img === null) {
          return notificationimage;
        } else {
          return content.attributes[0].img;
        }
      } else {
        if (content.attributes[0].img === null) {
          return companyProfile;
        } else {
          return content.attributes[0].img;
        }
      }
    } else if (type === 10) {
      if (content.attributes[0].mention === 'PROFILE') {
        if (content.attributes[0].img === null) {
          return notificationimage;
        } else {
          return content.attributes[0].img;
        }
      } else {
        if (content.attributes[0].img === null) {
          return groupLogo;
        } else {
          return content.attributes[0].img;
        }
      }
    } else if (type === 11) {
      if (content.attributes[0].mention === 'PROFILE') {
        if (content.attributes[0].img === null) {
          return notificationimage;
        } else {
          return content.attributes[0].img;
        }
      } else {
        if (content.attributes[0].img === null) {
          return pageLogo;
        } else {
          return content.attributes[0].img;
        }
      }
    } else if (type === 12) {
      if (content.attributes[0].img === null) {
        return notificationimage;
      } else {
        return content.attributes[0].img;
      }
    } else if (type === 13) {
      if (content.attributes[0].img === undefined || content.attributes[0].img === null) {
        return notificationimage;
      } else {
        return content.attributes[0].img;
      }
    }
    return notificationimage;
  };
  const manageRequest = (actionType, notification) => {
    if (notification.type === 9) {
      companyInvitaionBtnHandler(actionType, notification.requestId, notification.id);
    } else if (notification.type === 10) {
      groupInvitationBtnHandler(actionType, notification.requestId, notification.id);
    } else if (notification.type === 11) {
      pageInvitationBtnHandler(actionType, notification.requestId, notification.id);
    } else if (notification.type === 12) {
      connectionRequestHandler(actionType, notification.requestId, notification.id, JSON.parse(notification.content).attributes[0].id);
    }
    setConfirmModel(false);
  };
  const groupInvitationBtnHandler = async(type, requestId, notificationId) => {
    const response = await CallFor(
      'api/v1.1/group/request/' + type + '/' + requestId,
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      if (type === 'accept') {
        setShowToastMsg(t('toastmessages.toast31'));
      } else {
        setShowToastMsg(modelJsonData.toastMsg);
      }
      setShowToast(true);
      setNotificationData(notificationData.filter((item) => item.id !== notificationId));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      setShowToastMsg(t('toastmessages.toast32'));
      setShowToast(true);
    } else {
      setShowToastMsg(t('toastmessages.toast33'));
      setShowToast(true);
    }
  };
  const companyInvitaionBtnHandler = async(type, requestId, notificationId) => {
    const response = await CallFor(
      'api/v1.1/companies/teams/invitations/' + requestId + '/' + type.toUpperCase(),
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      if (type === 'accept') {
        setShowToastMsg(t('appproperties.text428'));
      } else {
        setShowToastMsg(modelJsonData.toastMsg);
      }
      setShowToast(true);
      setNotificationData(notificationData.filter((item) => item.id !== notificationId));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      setShowToastMsg(t('toastmessages.toast32'));
      setShowToast(true);
    } else {
      setShowToastMsg(t('toastmessages.toast33'));
      setShowToast(true);
    }
  };
  const pageInvitationBtnHandler = async(type, requestId, notificationId) => {
    const response = await CallFor(
      'api/v1.1/pages/request/' + requestId + '/' + type,
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      if (type === 'accept') {
        setShowToastMsg(t('toastmessages.toast31'));
      } else {
        setShowToastMsg(modelJsonData.toastMsg);
      }
      setShowToast(true);
      setNotificationData(notificationData.filter((item) => item.id !== notificationId));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      setShowToastMsg(t('toastmessages.toast32'));
      setShowToast(true);
    } else {
      setShowToastMsg(t('toastmessages.toast33'));
      setShowToast(true);
    }
  };
  const connectionRequestHandler = async(type, id, notificationId, userId) => {
    const data = '{ "message":"' + type.toUpperCase() + '", "id":"' + id + '"}';
    const response = await CallFor(
      'api/v1.1/connect/action/' + userId + '/' + type.toUpperCase(),
      'POST',
      data,
      'Auth'
    );
    if (response.status === 200) {
      if (type === 'accept') {
        setShowToastMsg(t('toastmessages.toast31'));
      } else {
        setShowToastMsg(modelJsonData.toastMsg);
      }
      setShowToast(true);
      setNotificationData(notificationData.filter((item) => item.id !== notificationId));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      setShowToastMsg(t('toastmessages.toast32'));
      setShowToast(true);
    } else {
      setShowToastMsg(t('toastmessages.toast33'));
      setShowToast(true);
    }
  };
  const ignoreModelBox = (actionType, notification) => {
    // notification.type, notification.requestId, notification.id, JSON.parse(notification.content).attributes[0].id;
    const jsonData = {};
    jsonData.actionType = actionType;
    jsonData.notification = notification;
    jsonData.toastMsg = t('appproperties.text429');
    if (notification.type === 9) {
      jsonData.modelMsg = t('appproperties.text380');
    } else if (notification.type === 10) {
      jsonData.modelMsg = t('appproperties.text381');
    } else if (notification.type === 11) {
      jsonData.modelMsg = t('appproperties.text382');
    } else if (notification.type === 12) {
      jsonData.modelMsg = t('appproperties.text383');
    }
    setModelJsonData(jsonData);
    setConfirmModel(true);
  };
  const addDefaultSrc = (ev, type, content) => {
    if (type === 1 || type === 2 || type === 3 || type === 4 || type === 5 || type === 6 || type === 7 || type === 8 || type === 12 || type === 13 || type === 15 || type === 16 || type === 17 || type === 19 || type === 20 || type === 21 || type === 22) {
      ev.target.src = notificationimage;
    } else if (type === 9) {
      if (content.attributes[0].mention === 'PROFILE') {
        ev.target.src = notificationimage;
      } else {
        ev.target.src = companyProfile;
      }
    } else if (type === 10) {
      if (content.attributes[0].mention === 'PROFILE') {
        ev.target.src = notificationimage;
      } else {
        ev.target.src = groupLogo;
      }
    } else if (type === 11) {
      if (content.attributes[0].mention === 'PROFILE') {
        ev.target.src = notificationimage;
      } else {
        ev.target.src = pageLogo;
      }
    }
  };
  return (
    <><IonRow className="display-grid full-width-row">
      <h4 className='ps-3 ps-lg-0'>{t('appproperties.text70')} </h4>
      <IonRow class="gup-btn-action swiper-btn-content position-sticky bg-default py-lg-2 px-2 px-lg-0">
        {deviceDetails.platform === 'ios' || deviceDetails.platform === 'android'
          ? <Swiper
            id="ka-swiper2"
            pagination={{
              clickable: true
            }}
            className="mySwiper full-width-row"
            autoHeight={true}
            slidesPerView="auto"
            breakpoints={{
              // when window width is >= 640px
              360: {
                width: 360,
                slidesPerView: 2
              },
              // when window width is >= 768px
              768: {
                width: 768,
                slidesPerView: 4
              }
            }}
          >
            <SwiperSlide className="swiper-slide-btn">
              <IonButton
                className={allBtnClass + ' button-small'}
                shape="round"
                onClick={() => getNotificationData('ALL', 0)}
              >
                {t('appproperties.text15')}
              </IonButton>
            </SwiperSlide>
            <SwiperSlide className="swiper-slide-btn">
              <IonButton
                className={viewBtnClass + ' button-small'}
                shape="round"
                onClick={() => getNotificationData('VIEW', 0)}
              >
               {t('appproperties.text37')}
              </IonButton>
            </SwiperSlide>
            <SwiperSlide className="swiper-slide-btn">
              <IonButton
                className={postBtnClass + ' button-small'}
                shape="round"
                onClick={() => getNotificationData('POST', 0)}
              >
               {t('appproperties.text73')}
              </IonButton>
            </SwiperSlide>
            <SwiperSlide className="swiper-slide-btn">
              <IonButton
                className={requestBtnClass + ' button-small'}
                shape="round"
                onClick={() => getNotificationData('REQUEST', 0)}
              >
               {t('appproperties.text74')}
              </IonButton>
            </SwiperSlide>
            <SwiperSlide className="swiper-slide-btn">
              <IonButton
                className={messageBtnClass + ' button-small'}
                shape="round"
                onClick={() => getNotificationData('MESSAGE', 0)}
              >
               {t('userproperties.text10')}
              </IonButton>
            </SwiperSlide>
          </Swiper>
          : <><IonButton
            className={allBtnClass + ' button-small'}
            shape="round"
            onClick={() => getNotificationData('ALL', 0)}
          >
            {t('appproperties.text15')}
          </IonButton>
            <IonButton
              className={viewBtnClass + ' button-small'}
              shape="round"
              onClick={() => getNotificationData('VIEW', 0)}
            >
              {t('appproperties.text37')}
            </IonButton>
            <IonButton
              className={postBtnClass + ' button-small'}
              shape="round"
              onClick={() => getNotificationData('POST', 0)}
            >
              {t('appproperties.text73')}
            </IonButton>
            <IonButton
              className={requestBtnClass + ' button-small'}
              shape="round"
              onClick={() => getNotificationData('REQUEST', 0)}
            >
             {t('appproperties.text74')}
            </IonButton><IonButton
              className={messageBtnClass + ' button-small'}
              shape="round"
              onClick={() => getNotificationData('MESSAGE', 0)}
            >
             {t('userproperties.text10')}
            </IonButton></>}
      </IonRow>
      {loading ? <SkeletonNotification />
        : notificationData.length > 0
          ? (
            <IonRow className="ion-margin-top full-width-row notification-page position-relative">
              {notificationData.map((notification) => (
                <IonCard className={notification.isRead ? 'MuiPaper-rounded full-width-row ion-no-margin shadow-none notification-list' : 'MuiPaper-rounded full-width-row ion-no-margin shadow-none notification-list unreadNotification'}>
                <IonRow className='full-width-row notify-content ' onClick={() => removeNotificationCount(notification.id, notification.isRead)}>
                    <div className="myprofile-feeds ion-no-padding full-width-row ion-align-items-start d-block d-md-flex">
                      <div className='d-flex w-100'>
                        <IonAvatar className="MuiAvatar ion-margin-end" onClick={() => viewProfile(JSON.parse(notification.content), notification.type, notification.originId)}>
                          <img onError={(e) => addDefaultSrc(e, notification.type, JSON.parse(notification.content))} src={imgChange(JSON.parse(notification.content), notification.type)} />
                        </IonAvatar>
                        <IonRow
                          className="full-width-row cursor-pointer ion-align-self-center"
                          onClick={() => viewPost(
                            JSON.parse(notification.content),
                            notification.type,
                            notification.originId
                          )}
                        >
                          <b>{notification.userName}</b>
                          <div className='w-lg-75 w-75'>
                            <div className="margin MuiTypography-caption group-model-text full-width-row notify-inner-content w-100">
                              <span className='description fixed-textline2'>{changeContent(
                                JSON.parse(notification.content),
                                notification.type
                              )}
                              </span>
                            </div>
                          </div>
                          <div className="margin ion-padding-start MuiTypography-caption ion-float-right position-absolute notify-time">
                            {notification.ageOfNotification}
                          </div>
                        </IonRow>
                      </div>
                      <IonRow className="margin ion-padding-start MuiTypography-caption group-model-text position-absolute notify-button swiper-slide-btn mt-1 mt-lg-0 ms-5 ms-lg-0">
                        {notification.requestId !== '0' && (notification.type === 12 || notification.type === 10 || notification.type === 11)
                          ? <>
                              <ButtonComponent
                                className='font-11 description ion-button-color cursor-pointer btn-sm-cn pe-0 me-2'
                                btnClick ={manageRequest} field1='accept' size="small" field2={notification} name={t('appproperties.text20')} parametersPass={2}
                              />
                              <ButtonComponent
                                className='font-11 description category-btn-color me-lg-5 cursor-pointer btn-sm-cn'
                                btnClick={ignoreModelBox} field1='reject' size="small" field2={notification} name={t('appproperties.text19')} parametersPass={2}
                              />
                            </>
                          : notification.requestId !== '0' && notification.type === 9
                            ? <>
                                  <IonButton size="small" className='font-11 description ion-button-color cursor-pointer btn-sm-cn pe-0 me-2' shape="round" onClick={() => manageRequest('accept', notification)}>{t('appproperties.text20')}</IonButton>
                                  <IonButton size="small" className='font-11 description category-btn-color me-lg-5 cursor-pointer btn-sm-cn' shape="round" onClick={() => ignoreModelBox('reject', notification)}>{t('appproperties.text19')}</IonButton>
                                </>
                            : ''}
                      </IonRow>
                    </div>
                  </IonRow>
                </IonCard>
              ))}
              <IonInfiniteScroll
                onIonInfinite={loadData}
                threshold="100px"
                disabled={isInfiniteDisabled}
              >
                <IonInfiniteScrollContent
                  loadingSpinner="circular"
                  loadingText={t('appproperties.text215')}
                ></IonInfiniteScrollContent>
              </IonInfiniteScroll>
            </IonRow>
            )
          : <>
            {(() => {
              if (categoryType === 'ALL') {
                return (
                  <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text34')}</p>
                );
              } else if (categoryType === 'VIEW') {
                return (
                  <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text39')}</p>
                );
              } else if (categoryType === 'REQUEST') {
                return (
                  <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text41')}</p>
                );
              } else if (categoryType === 'POST') {
                return (
                  <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text37')}</p>
                );
              } else if (categoryType === 'MESSAGE') {
                return (
                  <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text36')}</p>
                );
              }
            })()}
          </>}
    </IonRow>
    <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
    <IonModal id="confirm-modal" isOpen={confirmModel} className="addCompany-modal report-modal" onDidDismiss={() => setConfirmModel(false)}>
        <div className="report-spam-type">
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <div className="MuiTypography-h6 ms-lg-3 ms-1">
            {t('appproperties.text394')}
            </div>
            <IonButton fill="clear" onClick={() => setConfirmModel(false)} className="close link-btn-tx ion-no-padding ion-no-margin pt-0">
            <IonIcon
                icon={close}
                className="ion-button-color me-0 p-0"
                slot="start"
                size="undefined" />
            </IonButton>
          </IonRow>
          <div className="modal-body">
            <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
              <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                <IonLabel className='msg-text'>
                  {modelJsonData.modelMsg}
                </IonLabel>
              </IonCol>
            </IonRow>
          </div>
        </div>
        <IonFooter className="ion-no-border px-lg-3 pb-lg-3">
          <IonRow>
            <IonButton
              className="btn-secondry"
              size="small"
              onClick={() => manageRequest(modelJsonData.actionType, modelJsonData.notification)}
            >
              {t('appproperties.text241')}
            </IonButton>
            <IonButton
              className="ion-button-color ms-lg-2"
              size="small"
              onClick={() => setConfirmModel(false)}
            >
              {t('appproperties.text242')}
            </IonButton>
          </IonRow>
        </IonFooter>
      </IonModal></>
  );
};
export default NotificationDetails;
