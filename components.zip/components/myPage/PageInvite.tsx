/* eslint-disable react/jsx-key */
/* eslint-disable react/no-unescaped-entities */
/* eslint-disable multiline-ternary */
/* eslint-disable react/prop-types */
import {
  IonAvatar,
  IonButton,
  IonCardTitle,
  IonCol,
  IonHeader,
  IonIcon,
  IonInput,
  IonRow
} from '@ionic/react';
import { close, searchOutline } from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router';
import CallFor from '../../util/CallFor';
import userLogo from '../../assets/img/user-profile-placeholder.png';
import Footer from '../Layout/Footer';
import ToastCommon from '../common/ToastCommon';
import { InputChangeEventDetail } from '@ionic/core';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
// import SwiperCore, { Navigation } from 'swiper/core';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import { useTranslation } from 'react-i18next';
import { Navigation, Pagination } from 'swiper';
// SwiperCore.use([Navigation]);
const PageInvite = () => {
  const { t } = useTranslation();
  const { pageId, pageName } = useParams();
  const history = useHistory();
  const [searchValue, setSearchValue] = useState();
  const [isSelectedCheck, setIsSelectedCheck] = useState([]);
  const [inviteConnection, setInviteConnection] = useState([]);
  const [selectedInviteConnection, setSelectedInviteConnection] = useState([]);
  const [inviteConnectionNew, setInviteConnectionNew] = useState([]);
  const [errorMsg, setErrorMsg] = useState('');
  const [btnShow, setBtnShow] = useState(false);
  const [isCheck, setIsCheck] = useState([]);
  const [isCheckAll, setIsCheckAll] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const decodedCompanyName = decodeURIComponent(escape(window.atob(pageName.replace('&quot;', '/'))));
  const [confirmModel, setConfirmModel] = useState(false);
  const addAdmin = async () => {
    if (isSelectedCheck.length > 0) {
      const response = await CallFor(
        // `api/v1/company/${companyId}/member/ADMIN`
        'api/v1.1/pages/' + pageId + '/admins',
        'POST',
        JSON.stringify(isSelectedCheck),
        'Auth'
      );
      if (response.status === 201) {
        // setShowToastMsg('Admin rights given to ' + isSelectedCheck.length + ' person');
        setShowToastMsg(t('toastmessages.toast10'));
        setShowToast(true);
        setTimeout(() => {
          history.push('/pageDetails/' + pageId);
        }, 1000);
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    } else {
      setErrorMsg(t('appproperties.text281'));
    }
  };
  const checkboxChangeHandler = (event: any) => {
    setErrorMsg('');
    const { id, checked } = event.target;
    if (!checked) {
      setIsCheck(isCheck.filter((item) => item !== id));
    } else {
      if (
        selectedInviteConnection.filter((item) => item.id === id).length === 0
      ) {
        setSelectedInviteConnection([
          ...selectedInviteConnection,
          ...inviteConnection.filter((item) => item.id === id)
        ]);
        setIsSelectedCheck([...isSelectedCheck, id]);
      }
      setInviteConnectionNew(
        inviteConnectionNew.filter((item) => item.id !== id)
      );
      setInviteConnection(inviteConnectionNew.filter((item) => item.id !== id));
      setIsCheck([...isCheck, id]);
    }
    const checkboxes = document.querySelectorAll(
      'input[type=checkbox]:checked'
    ).length;
    if (checkboxes === inviteConnectionNew.length) {
      setIsCheck([]);
      setBtnShow(false);
      setInviteConnection([]);
      setSearchValue('');
    } else {
      setIsCheck([]);
      setSearchValue('');
      setIsCheckAll(false);
    }
  };
  const selectAllBtnHandler = (selected: boolean) => {
    setErrorMsg('');
    // setIsCheckAll(!isCheckAll);
    setIsCheck(inviteConnection.map((li) => li.id));
    if (isCheckAll) {
      setIsCheck([]);
    } else {
      const dataIds = [];
      const data: never[] = [];
      inviteConnection.map((details) => {
        if (
          selectedInviteConnection.filter((item) => item.id === details.id)
            .length === 0
        ) {
          dataIds.push(details.id);
          data.push(details);
        }
      });
      setSelectedInviteConnection([...selectedInviteConnection, ...data]);
      setIsSelectedCheck([...isSelectedCheck, ...dataIds]);
      if (data.length === inviteConnectionNew.length) {
        setInviteConnection([]);
        setInviteConnectionNew([]);
        setIsCheck([]);
        setBtnShow(false);
        setSearchValue('');
      } else {
        const datac: React.SetStateAction<never[]> = [];
        inviteConnectionNew.map((details) => {
          if (!data.includes(details)) {
            datac.push(details);
          }
        });
        setInviteConnection(datac);
        setInviteConnectionNew(datac);
      }
    }
  };
  function searchFilter(event: CustomEvent<InputChangeEventDetail>) {
    if (event.target.value !== undefined) {
      setSearchValue(event.target.value);
      setInviteConnection(
        inviteConnectionNew.filter((item) => {
          return Object.values(item)
            .join('')
            .toLowerCase()
            .includes(event.target.value.toLowerCase());
        })
      );
    }
  }
  useEffect(async () => {
    // callInviction();
    const data = await callInviction(0);
    if (data.length > 0) {
      const data1 = await callInviction(1);
      if (data1.length > 0) {
        setInviteConnection([...data, ...data1]);
        setInviteConnectionNew([...data, ...data1]);
        // setCount(2);
      } else {
        setInviteConnection(data);
        setInviteConnectionNew(data);
        // setInfiniteDisabled(true);
      }
      if (inviteConnection.length >= 0) {
        setBtnShow(true);
      } else {
        setBtnShow(false);
      }
    } else {
      setInviteConnection([]);
      setInviteConnectionNew([]);
      // setInfiniteDisabled(true);
    }
  }, []);
  const callInviction = async (page: string | number) => {
    const response = await CallFor(
      'api/v1.1/pages/' + pageId + '/members',
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        return json1Response.data.content.filter((item) => item.isAdmin === false);
      } else {
        return [];
      }
    } else {
      return [];
    }
  };
  const removeUser = (id: any) => {
    setInviteConnection([
      ...inviteConnection,
      ...selectedInviteConnection.filter((item) => item.id === id)
    ]);
    setInviteConnectionNew([
      ...inviteConnection,
      ...selectedInviteConnection.filter((item) => item.id === id)
    ]);
    setSelectedInviteConnection(
      selectedInviteConnection.filter((item) => item.id !== id)
    );
    setIsSelectedCheck(isSelectedCheck.filter((item) => item !== id));
    setBtnShow(true);
    setIsCheckAll(false);
  };
  const removeAll = () => {
    if (inviteConnection.length > 0) {
      const data: never[] = [];
      selectedInviteConnection.map((details) => {
        if (
          inviteConnection.filter((item) => item.id === details.id).length === 0
        ) {
          data.push(details);
        }
        setInviteConnection([...inviteConnection, ...data]);
        setInviteConnectionNew([...inviteConnection, ...data]);
      });
    } else {
      setInviteConnection(selectedInviteConnection);
      setInviteConnectionNew(selectedInviteConnection);
    }
    setConfirmModel(false);
    setSelectedInviteConnection([]);
    setIsSelectedCheck([]);
    setBtnShow(true);
    setIsCheckAll(false);
  };
  return (
    <>
      <div className="plane-bg">
        <div className="container">
          <div className="invite-page-content p-0">
          <IonRow className='member-listing-fixed'>
            <IonHeader>
              <h2>{decodedCompanyName} - {t('appproperties.text195')}</h2>
            </IonHeader>
            <IonCol
                sizeMd="4"
                sizeXs="12"
                className="profile-details ion-no-margin full-width-row left-cards MuiPaper-rounded show-mobile p-0"
              >
                {
                  selectedInviteConnection.length > 0 ? (
                    <div className="bg-white p-2 invite-connnections mt-lg-4 mt-2">
                      <p className='pe-2'>{selectedInviteConnection.length} {t('appproperties.text200')}</p>
                      <div className="award-slider-aw product-slider-cn select-profile pe-2 mt-1">
                        <IonRow className="d-flex">
                          {selectedInviteConnection.length > 2 ? (
                            <Swiper
                              id="ka-swiper2"
                              navigation={true}
                              modules={[Navigation, Pagination]}
                              className="mySwiper"
                              autoHeight={true}
                              breakpoints={{
                                320: {
                                  width: 330,
                                  slidesPerView: 2
                                },
                                640: {
                                  width: 500,
                                  slidesPerView: 2
                                },
                                768: {
                                  width: 768,
                                  slidesPerView: 3
                                }
                              }}
                            >
                              {selectedInviteConnection.map((detail, i) => (
                                // eslint-disable-next-line react/jsx-key
                                <SwiperSlide className="swiper-slide-btn ms-2" key={i}>
                                  <div className="myprofile-feeds position-relative mobile-contions">
                                    <div
                                      onClick={() => removeUser(detail.id)}
                                      className="close ion-no-padding profile-remove zindex9"
                                    >
                                      <IonIcon
                                        icon={close}
                                        className="ion-button-color pr-0 "
                                        slot="start"
                                        size="undefined"
                                      />
                                    </div>
                                    <IonAvatar
                                      slot="start"
                                      className="MuiCardHeader-avatar cursor-pointer mt-2"
                                      onClick={() => {
                                        history.push('/profile/' + detail.id);
                                      }}
                                    >
                                      {detail.profileImg === null ||
                                        detail.profileImg === '' ? (
                                        <img src={userLogo} />
                                      ) : (
                                        <img onError={(ev) => { ev.target.src = userLogo; }} src={detail.profileImg} />
                                      )}
                                    </IonAvatar>
                                    <IonRow
                                      className="profileName cursor-pointer mt-2"
                                      onClick={() => {
                                        history.push('/profile/' + detail.id);
                                      }}
                                    >
                                      <IonCardTitle className='text-center'>
                                        <p className="margin MuiTypography-body1 fixed-textline1">
                                          {detail.firstName}
                                        </p>
                                      </IonCardTitle>
                                    </IonRow>
                                  </div>
                                </SwiperSlide>
                              ))}
                            </Swiper>
                          ) : (
                            <>
                              {selectedInviteConnection.map((detail, i) => (
                                <div className="myprofile-feeds position-relative mobile-contions  ms-2" key={i}>
                                  <div
                                    onClick={() => removeUser(detail.id)}
                                    className="close ion-no-padding profile-remove zindex9"
                                  >
                                    <IonIcon
                                      icon={close}
                                      className="ion-button-color pr-0 "
                                      slot="start"
                                      size="undefined"
                                    />
                                  </div>
                                  <IonAvatar
                                    slot="start"
                                    className="MuiCardHeader-avatar cursor-pointer mt-2"
                                    onClick={() => {
                                      history.push('/profile/' + detail.id);
                                    }}
                                  >
                                    {detail.profileImg === null ||
                                      detail.profileImg === '' ? (
                                      <img src={userLogo} />
                                    ) : (
                                      <img onError={(ev) => { ev.target.src = userLogo; }} src={detail.profileImg} />
                                    )}
                                  </IonAvatar>
                                  <IonRow
                                    className="profileName cursor-pointer"
                                    onClick={() => {
                                      history.push('/profile/' + detail.id);
                                    }}
                                  >
                                    <IonCardTitle className='text-center'>
                                      <p className="margin MuiTypography-body1 fixed-textline2">
                                        {detail.firstName}
                                      </p>
                                    </IonCardTitle>
                                  </IonRow>
                                </div>
                              ))}
                            </>
                          )}
                        </IonRow>
                      </div>
                      <div className="d-flex justify-content-end mt-3">
                        <IonButton
                          className="invite-btn pr-0 btn-sm-cn me-2"
                          onClick={addAdmin}
                        >
                          {t('appproperties.text337')}
                        </IonButton>
                        <IonButton
                          className="category-btn-color pr-0 btn-sm-cn"
                          onClick={() => setConfirmModel(true)}
                        >
                          {t('appproperties.text202')}
                        </IonButton>
                      </div>
                    </div>
                  ) : (
                    ''
                  )
                  // <div className='bg-white p-1 border-radius'>
                  // <h4 className='ion-text-center'>No Data Found</h4></div>
                }
              </IonCol>

              <div className="filter-col ps-2 pe-2 mt-2 w-100">
              <div className="search-control">
                <div className="input-box-old ion-no-padding mb-0">
                  <IonIcon icon={searchOutline} />
                  <IonInput
                    value={searchValue}
                    placeholder={t('appproperties.text198')}
                    id="inviteSearch"
                    name="inviteSearch"
                    className=" ion-padding-start pt-lg-0 pt-2 ps-lg-0 ps-3"
                    onIonChange={(e) => searchFilter(e)}
                    enterkeyhint="search"
                  />
                </div>
                <div className="select-btn">
                  {btnShow ? (
                    <>
                      {!isCheckAll ? (
                        <IonButton
                          className="ion-button-color m-0"
                          onClick={selectAllBtnHandler}
                        >
                          {t('appproperties.text199')}
                        </IonButton>
                      ) : (
                        <IonButton
                          className="ion-button-color m-0"
                          onClick={selectAllBtnHandler}
                        >
                          {t('appproperties.text413')}
                        </IonButton>
                      )}
                    </>
                  ) : (
                    ''
                  )}
                </div>
              </div>
              <IonRow className="full-width-row show-mobile">
                <span className="error ion-no-margin ">{errorMsg}</span>
              </IonRow>
            </div>
            <IonRow className="full-width-row dn-mobile">
              <span className="error ion-no-margin ion-margin-bottom">
                {errorMsg}
              </span>
            </IonRow>
            </IonRow>
            
            <ToastCommon
              setShowToast={setShowToast}
              setShowToastMsg={setShowToastMsg}
              showToast={showToast}
              showToastMsg={showToastMsg}
              duration={5000}
            />
            
            <IonRow className="member-reverse">
              <IonCol
                sizeMd="8"
                sizeXs="12"
                className="profile-details ion-no-margin full-width-row left-cards MuiPaper-rounded p-0"
              >
                <div className="bg-white p-2 mt-lg-4 mt-2">
                  {inviteConnection.length > 0 ? (
                    <IonRow>
                      {inviteConnection.map((detail, index) => (
                        // eslint-disable-next-line react/jsx-key
                        <IonCol sizeMd="6" sizeXs="12" className='pb-0' key={index}>
                          <div className="myprofile-feeds h-100">
                            <div>
                              <input
                                id={detail.id}
                                name={detail.firstName}
                                type="checkbox"
                                onChange={checkboxChangeHandler}
                                checked={isCheck.includes(detail.id)}
                              />
                            </div>
                            <div className="d-flex ion-align-items-center ion-justify-content-start">
                              <IonAvatar
                                slot="start"
                                className="MuiCardHeader-avatar cursor-pointer me-3"
                                onClick={() => {
                                  history.push('/profile/' + detail.id);
                                }}
                              >
                                {detail.profileImg === null ||
                                  detail.profileImg === '' ? (
                                  <img src={userLogo} />
                                ) : (
                                  <img onError={(ev) => { ev.target.src = userLogo; }} src={detail.profileImg} />
                                )}
                              </IonAvatar>
                              <IonRow
                                className="profileName cursor-pointer"
                                onClick={() => {
                                  history.push('/profile/' + detail.id);
                                }}
                              >
                                <IonCardTitle>
                                  <p className="margin MuiTypography-body1 fixed-textline2">
                                    {detail.firstName} {detail.lastName}
                                  </p>
                                </IonCardTitle>
                              </IonRow>
                            </div>
                          </div>
                        </IonCol>
                      ))}
                    </IonRow>
                  ) : (
                    <h4 className="ion-text-center">
                      {t('commonproperties.text16')}
                    </h4>
                  )}
                </div>
              </IonCol>
            </IonRow>
          </div>
        </div>
      </div>
      <Footer />
      <ConfirmModelCommon
        header={t('appproperties.text400')}
        message={t('appproperties.text204')}
        btn1={t('appproperties.text206')}
        btn2={t('appproperties.text205')}
        confirmModel={confirmModel}
        setConfirmModel={setConfirmModel}
        deleteBtnHandler={removeAll}
      />
    </>
  );
};
export default PageInvite;
