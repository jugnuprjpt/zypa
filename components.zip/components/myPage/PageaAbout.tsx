import { IonCard, IonIcon, IonLabel } from '@ionic/react';
import { link } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';

const PageAbout = (props: any) => {
  const { t } = useTranslation();
  let urlData;
  if (props.pageAbout.url !== null) {
    const result1 = props.pageAbout.url.indexOf('http://');
    const result2 = props.pageAbout.url.indexOf('https://');
    if (result1 === 0) {
      urlData = props.pageAbout.url;
    } else {
      urlData = 'http://' + props.pageAbout.url;
    }
    if (result2 === 0) {
      urlData = props.pageAbout.url;
    } else {
      urlData = 'https://' + props.pageAbout.url;
    }
  }

  return (
    <IonCard className="MuiPaper-rounded ion-margin-top ion-padding ion-margin-bottom ion-no-margin about-details-content">
      <h4 className="ion-margin-start textcolour"> {t('commonproperties.text17')}</h4>
      {props.pageAbout.description
        ? <p className='p_wrap'>
            {props.pageAbout.description}
          </p>
        : ''}
         <div className='category-dtl'>
         {props.pageAbout.catagory
           ? <><span className='title'>{t('appproperties.text265')}:</span><span>{props.pageAbout.catagoryName}</span></>
           : t('nodatafound.text28')}
        </div>
        <div className='contact-dtl'>
              {props.pageAbout.url
                ? <IonLabel>
                    <IonIcon icon={link} className="test icon-svg " />
                    <a href={urlData} target='_blank' rel="noopener noreferrer external" >{props.pageAbout.url}</a>
                  </IonLabel>
                : ''}
        </div>
    </IonCard>
  );
};
export default PageAbout;
