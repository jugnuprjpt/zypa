/* eslint-disable no-return-assign */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInput,
  IonLabel,
  IonModal,
  IonRow,
  IonTextarea
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import CallFor from '../../util/CallFor';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import { add, close } from 'ionicons/icons';
import cameraImg from '../../assets/img/camera.svg';
import { useTranslation } from 'react-i18next';

function PageAward() {
  const { t } = useTranslation();
  const [award, setAwardDetail] = useState([
    {
      _id: '907311478971146240',
      description:
        'A mobile app could be the next big step for your company...',
      Logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTuHEq7b875QLbFH4rsBf2x0FzgLrmLx4DuWg&usqp=CAU',
      productName: 'Top B2B Company in 2020 by Clutch'
    },
    {
      _id: '907311478971146240',
      description:
        'A mobile app could be the next big step for your company...',
      Logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTuHEq7b875QLbFH4rsBf2x0FzgLrmLx4DuWg&usqp=CAU',
      productName: 'Top B2B Company in 2020 by Clutch'
    },
    {
      _id: '907311478971146240',
      description:
        'A mobile app could be the next big step for your company...',
      Logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTuHEq7b875QLbFH4rsBf2x0FzgLrmLx4DuWg&usqp=CAU',
      productName: 'Top B2B Company in 2020 by Clutch'
    },
    {
      _id: '907311478971146240',
      description:
        'A mobile app could be the next big step for your company...',
      Logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTuHEq7b875QLbFH4rsBf2x0FzgLrmLx4DuWg&usqp=CAU',
      productName: 'Top B2B Company in 2020 by Clutch'
    }
  ]);
  useEffect(() => {
    getAwardDetail();
  }, []);
  const [showModal, setShowModal] = useState(false);
  const [file, setFile] = useState('');
  const uploadFileHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      setFile(file1);
    }
  };
  const getAwardDetail = async() => {
    const response = await CallFor('', 'GET', null, 'Auth');
    if (response.status === 201) {
      const json1Response = await response.json();
      setAwardDetail(json1Response.data);
    }
  };
  return (
    <IonCard className="MuiPaper-rounded ion-margin-top ion-margin-bottom ion-no-margin">
      <IonHeader className="profile-header ion-no-border">
        <IonRow>
          <IonRow>
            <p className="ion-margin-start textcolour">
              <b className="fontsize">Award &amp; {t('awardproperties.text2')}</b>
            </p>
          </IonRow>
          <IonRow className="header-row-margin-left ion-padding-end">
            <a className="ion-padding-top" onClick={() => setShowModal(true)}>
              <IonIcon icon={add} className="ion-text-center" /> {t('awardproperties.text1')} &
              {t('awardproperties.text2')}
            </a>
          </IonRow>
        </IonRow>
      </IonHeader>
      <IonRow>
        <IonCol size="12">
          <Swiper
            id="ka-swiper2"
            pagination={{
              clickable: true
            }}
            className="mySwiper"
            autoHeight={true}
            breakpoints={{
              640: {
                width: 640,
                slidesPerView: 1
              },
              768: {
                width: 768,
                slidesPerView: 3
              }
            }}
          >
            {award.map((detail) => (
              <>
                {' '}
                <SwiperSlide>
                  <div className="ion-padding-start ion-padding-end ion-padding-bottom">
                    <IonRow className="profileName">
                      <img className="br model-fullimg" src={detail.Logo} />
                      <IonCardTitle>
                        <p>
                          <b>{detail.productName}</b>
                        </p>
                        <p className="group-model-text MuiTypography-body1">
                          {detail.description}
                        </p>
                        <a className="MuiTypography-caption">{t('commonproperties.text29')}</a>
                      </IonCardTitle>
                    </IonRow>
                  </div>
                </SwiperSlide>
              </>
            ))}
          </Swiper>
        </IonCol>
      </IonRow>
      <IonModal isOpen={showModal} cssClass="add-award-model" onDidDismiss={() => setShowModal(false)}>
        <IonRow className="MuiDialogTitle-root">
          <IonCol sizeMd="11" sizeXs="10" className="ion-padding-start">
            <IonLabel className="MuiTypography-h6  ion-padding-top">
              {t('awardproperties.text1')} &amp; Cirtification
            </IonLabel>
          </IonCol>
          <IonCol
            sizeMd="1"
            sizeXs="2"
            className="ion-padding-end header-row-margin-left"
          >
            <IonButton
              fill="clear"
              className="ion-activatable"
              onClick={() => setShowModal(false)}
            >
              <IonIcon
                icon={close}
                className="ion-button-color"
                slot="start"
                size="undefined"
              />
            </IonButton>
          </IonCol>
        </IonRow>
        <IonRow className="ion-padding-start award-row">
          <input
            type="file"
            color="primary"
            onChange={uploadFileHandleChange}
            id="upload"
            accept="image/*"
            className="upload"
          />
          <label htmlFor="upload">
            <IonAvatar
              id="avatar"
              slot="start"
              className="MuiCardHeader-avatar"
            >
              {file
                ? (
                <img src={file} className="profileAvtar" />
                  )
                : (
                <img src={cameraImg} className="profileAvtar" />
                  )}
            </IonAvatar>
          </label>
        </IonRow>
        <IonRow className="group-input-box ion-padding-start ion-padding-top ion-padding-end">
          <IonInput
            className="input-box ion-no-margin"
            placeholder="Title"
          />
        </IonRow>
        <IonRow className="ion-padding-start ion-padding-end">
          <IonTextarea
            className="input-box ion-padding-end ion-no-margin"
            placeholder="Group Rule"
            rows={5}
            value=""
          />
        </IonRow>
        <IonFooter className="ion-no-border ion-padding-end ion-padding-bottom">
          <IonRow className="header-row-margin-left">
            <IonButton className="header-row-margin-left ion-button-color" size="small">
              {t('awardproperties.text1')} &amp; Cirtification
            </IonButton>
          </IonRow>
        </IonFooter>
      </IonModal>
    </IonCard>
  );
}
export default PageAward;
