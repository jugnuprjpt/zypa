/* eslint-disable react/jsx-key */
/* eslint-disable multiline-ternary */
import {
  IonCard,
  IonCol,
  IonContent,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonLabel,
  IonModal,
  IonRow,
  useIonViewWillEnter
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router';
import CallFor from '../../util/CallFor';
import userLogo from '../../assets/img/user-profile-placeholder.png';
import { close } from 'ionicons/icons';
import SkeletonComonViewAll from '../common/skeleton/SkeletonComonViewAll';
import CommonGridList from '../common/CommonGridList';
import { useTranslation } from 'react-i18next';

const PageFollowers = () => {
  const { t } = useTranslation();
  const { pageId } = useParams();
  const [count, setCount] = useState(0);
  const [scrollData, setScrollData] = useState<object[]>([]);
  const [teamMember, setTeamMember] = useState<object[]>([]);
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  useEffect(() => {
    getTeamMember();
  }, []);
  const getTeamMember = async() => {
    setLoading(true);
    const response = await CallFor('api/v1.1/pages/' + pageId + '/members', 'post', '{"page": 0 }', 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        const spanText = document.getElementById('pageData').innerText;
        if (spanText < json1Response.data.content.length) {
          document.getElementById('pageData').innerHTML = json1Response.data.content.length;
        } else if (spanText > 10) {
          document.getElementById('pageData').innerHTML = spanText;
        }

        setScrollData(json1Response.data.content);
        setTeamMember(json1Response.data.content);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const getTeamMemberOnScroll = async() => {
    const response = await CallFor('api/v1.1/pages/' + pageId + '/members', 'post', '{"page": ' + count + '}', 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setScrollData([...scrollData, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  useIonViewWillEnter(async() => {
    getTeamMemberOnScroll();
  });

  const searchNext = (ev: any) => {
    setTimeout(() => {
      getTeamMemberOnScroll();
      ev.target.complete();
    }, 500);
  };
  const viewPaginaction = () => {
    setShowModal(true);
    getTeamMemberOnScroll();
  };
  const closemodel = () => {
    setCount(1);
    setShowModal(false);
    setScrollData(teamMember);
    setInfiniteDisabled(false);
  };
  const [showModal, setShowModal] = useState(false);
  return (
    <>
      <IonCard className="MuiPaper-rounded ion-margin-top ion-margin-bottom ion-padding ion-no-margin follower-list-card shadow-none border-0">
        <IonHeader className="profile-header ion-no-border head-title-con">
          <div className='left-col-cn'>
                <h4 className='mt-0'>{t('commonproperties.text38')}</h4>
           </div>
           {teamMember.length >= 12
             ? <div className='right-col-cn dn-mobile'>
              <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
              {t('commonproperties.text3')}
              </div>
            </div>
             : ''}
        </IonHeader>
        {loading ? <SkeletonComonViewAll column={4} sizeMd={3} sizeXs={12} name={true} title={true} distription={false} link={false} />
          : teamMember.length > 0
            ? <IonRow className='member-listing'>
          {teamMember.map((detail, i) => (
            <CommonGridList key={i} id={detail.id} defultImage={userLogo} img={detail.profileImg} name={detail.firstName + ' ' + detail.lastName} 
              subString={detail.profileTitle} dots={false} redirectLink='profile' showAdminTag={true} isAdmin={detail.isAdmin}/>
          ))}
        </IonRow>
            : t('nodatafound.text29')}
          {teamMember.length >= 12
            ? <div className='right-col-cn gup-btn-action view-all-mobile'>
              <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
              {t('commonproperties.text3')}
              </div>
            </div>
            : ''}
      </IonCard>
      <IonModal isOpen={showModal} onDidDismiss={closemodel}>
      <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          <IonLabel className="MuiTypography-h6">
          {t('commonproperties.text3')}
          </IonLabel>
          <div onClick={closemodel} className="close ion-no-padding cursor-pointer">
            <IonIcon
              icon={close}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </div>
        </IonRow>
        <IonContent>
        <div className='modal-body'>
         <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom member-listing">
          {scrollData.map((detail, i) => (
            <CommonGridList key={i} id={detail.id} defultImage={userLogo} img={detail.profileImg} name={detail.firstName + ' ' + detail.lastName}
              subString={detail.profileTitle} btnFnc={null} dots={false} redirectLink='profile' showAdminTag={true} isAdmin={detail.isAdmin}/>
          ))}
          <IonInfiniteScroll
            onIonInfinite={searchNext}
            threshold="100px"
            disabled={isInfiniteDisabled}
          >
          <IonInfiniteScrollContent
            loadingSpinner="circular"
            loadingText={t('appproperties.text215')}
          ></IonInfiniteScrollContent>
        </IonInfiniteScroll>
         </IonRow>
        </div>
        </IonContent>
      </IonModal>
    </>
  );
};
export default PageFollowers;
