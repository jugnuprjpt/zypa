import { IonIcon } from '@ionic/react';
import React from 'react';
import Cropper from 'react-easy-crop';
import { closeSharp, refresh } from 'ionicons/icons';
import { useTranslation } from 'react-i18next';

const ImageCropModal = (props) => {
  const { t } = useTranslation();
  const imagestyle = {
    height: props.heightNew,
    width: props.widthNew,
  };
  return (
    <>
      <div className="crop-container-main">
        <div className="backdrop"></div>
        <div className="header-part">
          <span className='editprofile-design'>{t('appproperties.text139')}</span>
          <IonIcon onClick={() => {
            props.setImageSrc(null); props.setRotation(0); props.setZoom(1);
            props.setCrop({ x: 0, y: 0 });
            props.setCroppedAreaPixels(null);
            { (props.croppedImage !== null) && props.setOpenModal(true); }
          }} className='closed-icons-dismiss' icon={closeSharp} />
        </div>
        <div className="crop-container absc corp-image-profile" style={imagestyle}>
          <Cropper
            image={props.imageSrc}
            crop={props.crop}
            objectFit="vertical-cover"
            rotation={props.rotation}
            zoom={props.zoom}
            aspect={props.aspect}
            cropShape={props.cropShape}
            onCropChange={props.setCrop}
            onRotationChange={props.setRotation}
            onCropComplete={props.onCropComplete}
            onZoomChange={props.setZoom}
            restrictPosition={props.restrictPosition}
            zoomWithScroll={props.zoomWithScroll}
            cropSize={props.cropSize}
          />
        </div>
        <div className="controls-modal d-flex justify-content-center mobileview-center">
          <div className="controls-upper-area ion-justify-content-start ps-4 w-100">
            <span>{t('appproperties.text140')}</span>
            <input
              type='range'
              value={props.zoom}
              min={1}
              max={3}
              step={0.1}
              aria-labelledby="Zoom"
              className='slider'
              onChange={(e) => {
                props.setZoom(e.target.value);
              }}
            />
            <IonIcon style={{ cursor: 'pointer' }} icon={refresh} onClick={() => props.setRotation(props.rotation + 90)} />
          </div>
          <div className="button-area">
            <span>{props.errormessage}</span>
            <button className='savebutton' onClick={props.showCroppedImage}>{t('appproperties.text141')}</button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ImageCropModal;
