/* eslint-disable multiline-ternary */
/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import {
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonFooter,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  IonTextarea,
  useIonPopover
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import CallFor from '../../util/CallFor';
import { useHistory } from 'react-router';
import backgroundImg from '../../assets/img/banner-placeholder.png';
import { close, ellipsisVertical, shareSocialOutline, trashBinOutline, warningOutline } from 'ionicons/icons';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import edit from '../../assets/img/icons/pencil-line-blue.svg';
import ManageTeam from '../../assets/img/icons/teams-icon.svg';
import Select from 'react-select';
import pageLogo from '../../assets/img/page-logo-default.png';
import SkeletonComonViewDetais from '../common/skeleton/SkeletonComonViewDetail';
import PopoverCommon from '../common/PopoverCommon';
import ToastCommon from '../common/ToastCommon';
import ImageEditModal from './ImageEditModal';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import ButtonComponent from '../common/ButtonComponent';
import { Device } from '@capacitor/device';
import { Share } from '@capacitor/share';
import { useTranslation, Trans } from 'react-i18next';
import NotAuthorizeModal from '../common/NotAuthorizeModal';

const customStyles = {
  control: (provided: any) => ({
    ...provided,
    height: 50,
    background: '#fff !important',
    border: 'none',
    '&:focus': {
      border: '1px solid #00529C'
    }
  }),
  multiValue: (styles, { data }) => {
    return {
      ...styles,
      padding: 4,
      backgroundColor: '#0073ae!important',
      borderRadius: '50px'
    };
  },
  multiValueLabel: (styles, { data }) => ({
    ...styles,
    color: '#fff'
  }),
  multiValueRemove: (styles, { data }) => ({
    ...styles,
    color: '#0073ae!important',
    borderRadius: '50px',
    margin: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    ':hover': {
      backgroundColor: '#fff'
    }
  }),
  indicatorSeparator: () => { }, // removes the "stick"
  dropdownIndicator: (defaultStyles: any) => ({
    ...defaultStyles,
    '& svg': { display: 'none' }
  })
};

const PageDetails = (props: any) => {
  const { t } = useTranslation();
  const [loginModal, setLoginModal] = useState(false);
  const [industry, setIndustry] = useState([]);
  const history = useHistory();
  const divclick = () => {
    const pageName = encodedString(props.page.name);
    history.push('/invitePage/' + props.pageId + '/' + pageName.replace('/', '&quot;'));
  };
  const encodedString = (str) => {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
      return String.fromCharCode(parseInt(p1, 16));
    }));
  };
  const [showModal, setShowModal] = useState(false);
  const [userFormState, setUserFormState] = useState({});
  const [createDisabled, setCreateDisabled] = useState(false);
  const [characterCount, setCharacterCount] = useState(0);
  const [showModelProfilePicture, setshowModelProfilePicture] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [resetFieldDisable, setResetFieldDisable] = useState(false);
  const profileDetail = useSelector(getProfileDetails);
  const maxCount = 250;

  useEffect(() => {
    props.getPageDetail(props.pageId);
  }, []);

  const validationSchema = Yup.object().shape({
    name: Yup.string().trim()
      .required(t('pageproperties.text7'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        (t('pageproperties.text9')),
        (val) => val && val.toString().length <= 150
      ),
    url: Yup
      .string().nullable(true).notRequired().optional().nullable()
      .matches(
        /^((ftp|http|https):\/\/)?(www.)?(?!.*(ftp|http|https|www.))[a-zA-Z0-9_-]+(\.[a-zA-Z]+)+((\/)[\w#]+)*(\/\w+\?[a-zA-Z0-9_]+=\w+(&[a-zA-Z0-9_]+=\w+)*)?$/gi,
        { message: t('pageproperties.text11'), excludeEmptyString: true }
      ),
    description: Yup.string().trim().nullable(true).optional().notRequired()
      .test(
        'len',
        t('commonproperties.text28'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length >= 10;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('awardproperties.text9'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length <= 250;
          } else {
            return true;
          }
        }
      )
  });
  const userformDataChangeHandler = (value, name) => {
    if (value !== undefined) {
      setUserFormState({
        ...userFormState,
        [name]: value
      });
    }
  };
  const descriptionChangeHandler = (value, name) => {
    if (value !== undefined && value !== null && value.length > 0) {
      setUserFormState({
        ...userFormState,
        description: event.target.value
      });
    } else {
      setUserFormState({
        ...userFormState,
        description: null
      });
    }
    if (value !== undefined && value != null) {
      setCharacterCount(value.length);
    }
  };
  const catagoryChangeHandler = (event) => {
    if (event !== null && event.value !== undefined) {
      setUserFormState({ ...userFormState, catagory: event.value });
      if (event.value !== 0) {
        setTimeout(function() {
          clearErrors('catagory');
          resetField('catagory');
        }, 1);
      }
    } else {
      setUserFormState({ ...userFormState, catagory: null });
      setError('catagory', {
        type: 'server',
        message: t('pageproperties.text10')
      });
    }
  };
  const getIndustry = async() => {
    const response = await CallFor('api/v1.1/industries', 'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      const states = await json1Response.data.map(
        (d: { subIndustryID: any; subIndustry: any }) => ({
          value: d.subIndustryID,
          label: d.subIndustry
        })
      );
      setIndustry(states);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const {
    register,
    handleSubmit,
    setValue,
    resetField,
    setError,
    control,
    clearErrors,
    formState: { errors, isValid }
  } = useForm({
    resolver: yupResolver(validationSchema),
    criteriaMode: 'all',
    reValidateMode: 'onTouched',
    mode: 'onChange'
  });

  const pageSubmitHandler = async() => {
    setCreateDisabled(true);
    if (userFormState.url === '') {
      userFormState.url = null;
    }
    let pageNameData = '';
    let pageAboutData = '';
    let pageUrl = '';
    if (userFormState.name !== undefined && userFormState.name !== null) {
      pageNameData = userFormState.name.trim();
      userFormState.name = pageNameData;
    }
    if (userFormState.description !== undefined && userFormState.description !== null) {
      pageAboutData = userFormState.description.trim();
      userFormState.description = pageAboutData;
    }
    if (userFormState.url !== undefined && userFormState.url !== null) {
      pageUrl = userFormState.url.trim();
      userFormState.url = pageUrl;
    }
    const response = await CallFor(
      'api/v1.1/pages/' + props.pageId,
      'PUT',
      JSON.stringify(userFormState),
      'Auth'
    );
    if (response.status === 201) {
      setResetFieldDisable(false);
      setCreateDisabled(true);
      setShowModal(false);
      props.getPageDetail(props.pageId);
      props.getPageList();
      // const datares = await response.json();
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 400) {
      setResetFieldDisable(true);
      const datares = await response.json();
      datares.error.errors.map((details) => {
        setError(details.field, {
          type: 'server',
          message: details.message
        });
      });
    }
    setResetFieldDisable(true);
    setCreateDisabled(false);
  };
  const getEditPageDetails = async() => {
    const response = await CallFor(
      'api/v1.1/pages/data/' + props.pageId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      setUserFormState({
        id: json1Response.data.id,
        name: json1Response.data.name,
        url: json1Response.data.url,
        description: json1Response.data.description,
        catagory: industry.filter(function(option) {
          return option.value === json1Response.data.catagory;
        })
      });
      const fields = ['id', 'name', 'url', 'description'];
      fields.forEach((field) => setValue(field, json1Response.data[field]));
      const catagory = industry.filter(option => {
        return option.value === json1Response.data.catagory;
      });
      setValue('catagory', catagory[0].label);
      let inputs, index;
      inputs = document.getElementsByTagName('ion-textarea');
      for (index = 0; index < inputs.length; ++index) {
        const val = inputs[index].value;
        if (val !== null && val.length > 0) {
          inputs[index].classList.add('input-fill');
        }
      }
    }
  };
  const joinBtnHandler = async(id) => {
    const response = await CallFor(
      'api/v1.1/pages/' + id + '/request/join',
      'POST',
      null,
      'Auth'
    );
    if (response.status === 201) {
      setShowToastMsg(t('toastmessages.toast9', { message: props.page.name }));
      setShowToast(true);
      props.getPageDetail(props.pageId);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 400) {
      const datares = await response.json();
      setShowToastMsg(datares.error.message);
      setShowToast(true);
    }
  };

  const leaveBtnHandler = async() => {
    const response = await CallFor(
      'api/v1.1/pages/' + props.page.id + '/leave/user',
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      props.getPageDetail(props.pageId);
      history.push('/page');
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const acceptBtnHandler = async(id, type) => {
    const response = await CallFor(
      'api/v1.1/pages/request/' + id + '/' + type,
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      props.getPageDetail(props.pageId);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 400) {
      const datares = await response.json();
      setShowToastMsg(datares.error.message);
      setShowToast(true);
    }
  };

  const clearState = () => {
    getIndustry();
    clearErrors();
    setShowModal(true);
  };

  const [reportModal, setReportModel] = useState(false);
  const [reason, setReason] = useState('');
  const openReportModelclearstate = () => {
    setReportModel(true);
    setReason('');
    clearErrors();
    dismiss();
  };
  const [confirmModel, setConfirmModel] = useState(false);
  const [followConfirm, setFollowConfirm] = useState(false);
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <>
      {props.page.isAdmin === true
        ? <IonList className="my-account-pr">
          <IonItem
            lines="none"
            className="cursor-pointer"
            onClick={() => { onHide(); clearState(); }}
          >
            <IonIcon icon={edit} size="small" className="header-menu-img " />
            <p>{t('appproperties.text330')}</p>
          </IonItem>
          {/* <IonItem
        lines="none"
        className="cursor-pointer">
          <IonIcon icon={ManageTeam} size="small" className="header-menu-img " />
          <p>{t('teamproperties.text3')}</p>
      </IonItem> */}
          <IonItem
            lines="none"
            className="cursor-pointer"
            onClick={sharePageHandler}
          >
            <IonIcon icon={shareSocialOutline} size="small" className="header-menu-img " />
            <p>{t('appproperties.text279')}</p>
          </IonItem>
          {props.page.isOwner === true
            ? <IonItem
              lines="none"
              className="cursor-pointer"
              onClick={() => { onHide(); setConfirmModel(true); }}
            >
              <IonIcon icon={trashBinOutline} size="small" className="header-menu-img " />
              <p>{t('appproperties.text278')}</p>
            </IonItem>
            : ''}
        </IonList>
        : <IonList className="my-account-pr">
          <IonItem
            lines="none"
            className="cursor-pointer"
            onClick={openReportModelclearstate}
          >
            <IonIcon icon={warningOutline} size="small" className="header-menu-img " />
            <p>{t('commonproperties.text19')}</p>
          </IonItem>
          <IonItem
            lines="none"
            className="cursor-pointer"
            onClick={sharePageHandler}
          >
            <IonIcon icon={shareSocialOutline} size="small" className="header-menu-img " />
            <p>{t('appproperties.text279')}</p>
          </IonItem>
        </IonList>}
    </>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });

  const reportChangeHandler = (event: { target: { name: any; value: any } }) => {
    if (event.target.value !== undefined) {
      setReason(event.target.value);
    }
    if (event.target.value !== undefined) {
      event.target.value;
    }
    if (event.target.value !== undefined && event.target.value != null) {
      setCharacterCount(event.target.value.length);
    }
  };
  const clickHereToReport = async() => {
    if (reason !== undefined && reason !== '') {
      if (reason.length <= 1000) {
        const reportsData = JSON.stringify({ originId: props.pageId, origin: 'PAGE', remarks: reason });
        const response = await CallFor(
          'api/v1.1/spam-report',
          'POST',
          reportsData,
          'Auth'
        );
        if (response.status === 201) {
          setReportModel(false);
          props.setReportHideState(true);
        }
      } else {
        setError('reason', {
          type: 'required',
          message: t('commonproperties.text21')
        });
      }
    } else {
      setError('reason', {
        type: 'required',
        message: t('commonproperties.text20')
      });
    }
  };
  const maxCountReport = 500;
  const restHandler = (event) => {
    if (resetFieldDisable) {
      if (event.target.name === 'name' && event.target.value === '') {
        resetField('name');
      } else if (event.target.name === 'url' && event.target.value === '') {
        resetField('url');
      } else if (event.target.name === 'description' && event.target.value === '') {
        resetField('description');
      } else if (event.target.name === 'catagory' && event.target.value === '') {
        resetField('catagory');
      }
    }
  };
  const sharePageHandler = async() => {
    const deviceDetails = await Device.getInfo();
    if (deviceDetails.platform === 'ios' || deviceDetails.platform === 'android') {
      await Share.share({
        text: 'Zyapaar - View Page Details',
        url: 'https://zyapaar.com/pageDetails/' + props.pageId
      });
    } else {
      let url = 'https://web.whatsapp.com/send?';
      url += '&text=https://www.zyapaar.com/pageDetails/' + props.pageId;
      window.open(url);
    }
  };
  const deletePage = async() => {
    const response = await CallFor(
      'api/v1.1/pages/' + props.pageId,
      'DELETE',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg('followers removed');
      setShowToast(true);
      history.push('/page');
    } else if (response.status === 400) {
      const json1Response = await response.json();
      setShowToastMsg(json1Response.error.message);
      setShowToast(true);
    }
  };
  const [pageRequestedModel, setPageRequestedModel] = useState(false);
  const [pageRequestedModelMsg, setPageRequestedModelMsg] = useState('');
  const withdrawMobile = () => {
    setPageRequestedModelMsg(t('appproperties.text26'));
    setPageRequestedModel(true);
  };
  const actionBtnHandler = async() => {
    const response = await CallFor('api/v1.1/pages/request/' + props.page.memberId + '/cancel', 'POST', null, 'Auth');
    if (response.status === 200) {
      props.getPageDetail(props.pageId);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      const jsonRes = response.json();
      console.log(jsonRes);
    }
  };
  return (
    <>
      {/*  Profile Picture Zoom  */}
      <IonModal isOpen={showModelProfilePicture} cssClass="add-award-model awd-img-gallery" onDidDismiss={() => setshowModelProfilePicture(false)}>
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
            <div onClick={() => setshowModelProfilePicture(false)} className="close ion-no-padding">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined" />
            </div>
          </IonRow>
          <IonRow className="mx-auto d-flex justify-content-center overview-heigth">
            {props.page.img === null || props.page.img === ''
              ? (
                <span className='svg-icon avtr-icon'>
                  <img src={pageLogo} />
                </span>
                )
              : (
                <img onError={(ev) => { ev.target.src = pageLogo; }} src={props.page.img} />
                )}
          </IonRow>
        </IonContent>
      </IonModal>
      {/*  Profile Picture Zoom  */}
      <IonCard className="MuiPaper-rounded ion-no-margin ion-margin-top profile-card-content mtm-0">
        {!props.loading
          ? <>
            {!props.page.isDeleted
              ? <><div className="groupsize-group">
                <ImageEditModal
                  id={props.pageId}
                  image={props.page.coverLogo}
                  defultLogo={backgroundImg}
                  serviceType='pages'
                  getDetails={props.getPageDetail}
                  logo='COVER'
                  cropShape={'rect'}
                  aspect={22 / 4.5}
                  className='cover-photo'
                  cssClass='edit-img model-img-hei-width CoverPhotoMain'
                  isAdmin={props.page.isAdmin}
                  reportHideState={props.reportHideState}
                  isHide={props.page.isHide} />
                <div className="edit-icon">
                </div>
              </div><div className="profile-card-body">
                  <div className="profile-avt-content">
                    <ImageEditModal
                      id={props.pageId}
                      image={props.page.img}
                      defultLogo={pageLogo}
                      serviceType='pages'
                      getDetails={props.getPageDetail}
                      logo='LOGO'
                      aspect={1}
                      cropShape={'round'}
                      className='logo-photo'
                      cssClass='edit-img model-img-hei-width'
                      isAdmin={props.page.isAdmin}
                      reportHideState={props.reportHideState}
                      isHide={props.page.isHide}
                      background={true}
                    />
                    {!props.reportHideState ? !props.page.isHide
                      ? <div className="dot-btn">
                        <IonIcon
                          icon={ellipsisVertical}
                          slot="start"
                          className="test report cursor-pointer"
                          onClick={(e) => {
                            if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                              present({ event: e.nativeEvent });
                            } else {
                              // history.push('/addnewcompany');
                              setLoginModal(true);
                            }
                          }} />
                      </div>
                      : '' : ''}
                  </div>
                  <div className="profileName w-100">
                    <IonCardTitle>
                      <h4 className="margin fixed-textline2">
                        {props.page.name}
                      </h4>
                      <span className='fixed-textline2 w-85'>{props.page.catagoryName}</span>
                    </IonCardTitle>
                    <div className="profile-card-follow">
                      <IonLabel className="follower-text">
                        <span id='pageData'>{props.page.followers}</span>{' '}
                        <IonLabel className="group-model-text group-text-center">
                          {t('pageproperties.text14')}
                        </IonLabel>
                      </IonLabel>
                      {!props.reportHideState ? !props.page.isHide ? <>
                        {(() => {
                          if (props.page.isAdmin === true) {
                            return (
                              <IonButton
                                className="ion-button-color pr-0"
                                size="small"
                                onClick={divclick}
                              >
                                + {t('appproperties.text362')}
                              </IonButton>
                            );
                            // DEFAULT("0") INVITE("1"), JOIN("2"),ACCEPT("3"),
                          } else if (props.page.isAdmin === false && props.page.status === 'accept') {
                            return (
                              <IonButton
                                className="ion-button-color pr-0"
                                size="small"
                                onClick={() => setFollowConfirm(true)}
                              >
                                {t('appproperties.text332')}
                              </IonButton>
                            );
                          } else if (props.page.isAdmin === false && props.page.status === 'inviate') {
                            return (
                              <><div><IonButton
                                className="ion-button-color pr-0 me-2"
                                size="small"
                                onClick={() => acceptBtnHandler(props.page.memberId, 'accept')}
                              >
                                {t('appproperties.text20')}
                              </IonButton><IonButton
                                className="category-btn-color pr-0 "
                                size="small"
                                onClick={() => acceptBtnHandler(props.page.memberId, 'reject')}
                              >
                                  {t('appproperties.text19')}
                                </IonButton>
                              </div>
                              </>
                            );
                          } else if (props.page.isAdmin === false && props.page.status === 'default') {
                            return (
                              <ButtonComponent
                                btnClick={joinBtnHandler}
                                size="small"
                                className='ion-button-color ion-padding-end'
                                field1={props.page.id} name={t('appproperties.text364')} parametersPass={1} />
                            );
                          } else if (props.page.isAdmin === false && props.page.status === 'join') {
                            return (
                              <ButtonComponent
                                btnClick={withdrawMobile}
                                size="small"
                                className='ion-button-color ion-padding-end'
                                name={t('appproperties.text40')} parametersPass={0} />
                            );
                          }
                        })()} </> : '' : ''}
                      {/* {props.page.isAdmin !== true
      ? <div className="dot-btn">
        <IonIcon
          icon={ellipsisVertical}
          slot="start"
          className="test report cursor-pointer"
          onClick={(e) => {
            if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
              present({ event: e.nativeEvent });
            } else {
              // history.push('/addnewcompany');
              setLoginModal(true);
            }
          }}
        />
      </div>
      : ''} */}
                    </div>
                  </div>
                </div></>
              : <p className='ion-padding ps-5 ps-md-3'>{t('appproperties.text280')}</p>}
          </>
          : <SkeletonComonViewDetais />}
      </IonCard>
      <IonModal
        isOpen={showModal}
        onDidPresent={getEditPageDetails}
        cssClass="createGroupModal"
        onDidDismiss={() => setShowModal(false)}
      >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">
              {t('pageproperties.text15')}
            </IonLabel>
            <div
              onClick={() => setShowModal(false)}
              className="close ion-no-padding cursor-pointer"
            >
              <IonIcon
                icon={close}
                className="ion-button-color "
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <div className="modal-body">
            <form className="h-100" onSubmit={handleSubmit(pageSubmitHandler)} data-testid="form-submit"
              noValidate
              autoComplete="off">
              <div className="body-content">
                <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">

                  <IonCol size-md="12" size-sm="12" size-xs="12" className='my-3'>
                    <IonItem
                      className={
                        errors.name
                          ? 'error-border form-group input-label-box position-relative d-block py-0 mb-0'
                          : 'form-group input-label-box position-relative d-block py-0 mb-0'
                      }
                    >
                      <IonLabel position="floating">{' '}{t('pageproperties.text4')} <sup>*</sup>{' '}</IonLabel>
                      <Controller
                        name="name"
                        control={control}
                        defaultValue=""
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonInput type='text' autocomplete='off'
                            {...field}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              userformDataChangeHandler(value, name);
                            }}
                            onClick={restHandler}
                            placeholder=""
                            className='input-box'
                            id="name"
                            {...register('name')} />
                        )}
                      />
                    </IonItem>
                    <span className={errors.name ? 'error mt-1' : ''}>
                      {errors.name?.message}
                    </span>
                  </IonCol>
                  <IonCol size-md="12" size-sm="12" size-xs="12" className='show-tooltip input-popover d-block mb-3 pagetooltip'>
                    <IonItem
                      className={
                        errors.name
                          ? 'error-border form-group input-label-box position-relative d-block py-0 mb-0'
                          : 'form-group input-label-box position-relative d-block py-0 mb-0 prefillData'
                      }
                    >
                      <IonLabel position="floating">{t('appproperties.text265')} <sup>*</sup></IonLabel>
                      <Controller
                        name="catagory"
                        control={control}
                        defaultValue=""
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonInput type='text' autocomplete='off'
                            {...field}
                            disabled={true}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              userformDataChangeHandler(value, name);
                            }}
                            onClick={restHandler}
                            placeholder=""
                            className='input-box'
                            id="catagory"
                            {...register('catagory')} />
                        )}
                      />
                    </IonItem>
                  </IonCol>
                  <IonCol size-md="12" size-sm="12" size-xs="12" className='show-tooltip input-popover'>
                    <IonItem
                      className={
                        errors.url
                          ? 'error-border form-group input-label-box position-relative pt-0'
                          : 'form-group input-label-box position-relative pt-0'
                      }
                    >
                      <IonLabel position="floating">{t('pageproperties.text5')}</IonLabel>
                      <Controller
                        name="url"
                        control={control}
                        defaultValue=""
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonInput type='text' autocomplete='off'
                            {...field}
                            onClick={restHandler}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              userformDataChangeHandler(value, name);
                            }}
                            placeholder=""
                            className='input-box input-custom-width'
                            id="url"
                            {...register('url')} />
                        )}
                      />
                      <span className={errors.url ? 'error input-error' : ''}>
                        {errors.url?.message}
                      </span>
                    </IonItem>
                    <PopoverCommon className='popover-zyapaar' Description='(http:// or https:// or www)domain.com' />
                  </IonCol>
                  <IonCol size-md="12" size-sm="12" size-xs="12">
                    <IonItem
                      className={
                        errors.description
                          ? 'error-border form-group input-label-box position-relative py-0 mb-0'
                          : 'form-group input-label-box position-relative py-0 mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('pageproperties.text6')}</IonLabel>
                      <Controller
                        name="description"
                        control={control}
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonTextarea type='text' autocomplete='off'
                            {...field}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              descriptionChangeHandler(value, name);
                            }}
                            onClick={restHandler}
                            placeholder=""
                            className='input-box'
                            id="description"
                            {...register('description')} rows={4}
                            maxlength={250} />
                        )}
                      />
                    </IonItem>
                    <p className={errors.description ? 'error' : ''}>
                      {errors.description?.message}
                    </p>
                    <p className='text-grey text-end font-14'>{userFormState.description !== undefined && userFormState.description !== null && userFormState.description.length > 0
                      ? userFormState.description.length
                      : characterCount}/{maxCount}</p>
                  </IonCol>
                </IonRow>
              </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
                <IonRow>
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto pr-0"
                    type="submit"
                    size="small"
                    disabled={createDisabled || !isValid}
                  >
                    {t('pageproperties.text15')}
                    {createDisabled
                      ? <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                      : ''
                    }
                  </IonButton>
                </IonRow>
              </IonFooter>
            </form>
          </div>
        </IonContent>
      </IonModal>
      <IonModal
        isOpen={reportModal}
        className="createGroupModal recommed-modal reportModal"
        onDidDismiss={() => setReportModel(false)}
        id='report-modal'
      >

        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
          <IonLabel className="MuiTypography-h6 ion-padding-start ">
            {t('commonproperties.text19')}
          </IonLabel>
          <div
            onClick={() => setReportModel(false)}
            className="close ion-no-padding pe-2"
          >
            <IonIcon
              icon={close}
              className="ion-button-color "
              slot="start"
              size="undefined"
            />
          </div>
        </IonRow>
        <div className="modal-body pb-2">
          <div className="body-content overflow-hidden">
            <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row px-1 mt-2">
              <IonCol size-md="12" size-xs="12" className="ion-no-padding p-lg-3 p-2">
                <IonItem
                  className={
                    errors.reason
                      ? 'error-border form-group input-label-box position-relative pt-0 mb-0 reportmsg'
                      : 'form-group input-label-box position-relative pt-0 mb-0 reportmsg'
                  }
                >
                  <IonLabel position="floating">{t('commonproperties.text18')}</IonLabel>
                  <IonTextarea
                    type="text"
                    autocomplete="off"
                    placeholder=''
                    rows="15"
                    className='input-box mt-0'
                    value={reason}
                    maxlength={500}
                    onIonChange={reportChangeHandler}
                  />
                  <span className={errors.reason ? 'error input-error' : ''}>
                    {errors.reason?.message}
                  </span>
                </IonItem>
                <p className="text-grey text-end font-14 mt-3">
                  {characterCount}/{maxCountReport}
                </p>
              </IonCol>
            </IonRow>
          </div>
          <IonRow className='pe-2'>
            {/* <IonButton
                  className="header-row-margin-left ion-button-color ml-auto pr-0"
                  size="small"
                  type="button"
                  onClick={clickHereToReport}
                >
                  Spam
                </IonButton> */}
            <ButtonComponent btnClick={clickHereToReport} size="small"
              className='header-row-margin-left ion-button-color ml-auto pr-0' name={t('commonproperties.text19')} parametersPass={0} />
          </IonRow>
        </div>

      </IonModal>
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={3000} />
      <ConfirmModelCommon header={t('appproperties.text278')} message={t('appproperties.text384')} btn1={t('appproperties.text11')} btn2={t('appproperties.text247')} confirmModel={confirmModel} setConfirmModel={setConfirmModel} deleteBtnHandler={deletePage} />
      <IonModal isOpen={followConfirm} className="addCompany-modal report-modal" id="confirm-modal" onDidDismiss={() => setFollowConfirm(false)}>
        <IonContent className="report-spam-type report-popuowhite">
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between pt-2 mt-lg-0">
            <div className="MuiTypography-h4 font-18 ms-lg-3 ms-2">
              {t('appproperties.text332')}
            </div>
            <IonButton fill="clear" onClick={() => setFollowConfirm(false)} className="close link-btn-tx ion-no-padding ion-no-margin pt-0">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0"
                slot="start"
                size="undefined" />
            </IonButton>
          </IonRow>
          <div className="mt-4">
            <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
              <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                <IonLabel className='msg-text' >
                  {t('pageproperties.text2')}
                </IonLabel>
              </IonCol>
            </IonRow>
          </div>
        </IonContent>
        <IonFooter className="ion-no-border px-lg-3 pb-lg-3">
          <IonRow>
            <IonButton
              className="btn-secondry mr-2"
              size="small"
              onClick={() => setFollowConfirm(false)}
            >
              {t('appproperties.text11')}
            </IonButton>
            <ButtonComponent size='small' className='ion-button-color' btnClick={leaveBtnHandler} name={t('appproperties.text247')} parametersPass={0} />
          </IonRow>
        </IonFooter>
      </IonModal>
      <ConfirmModelCommon
        header={t('appproperties.text22')}
        message={pageRequestedModelMsg}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text21')}
        confirmModel={pageRequestedModel}
        setConfirmModel={setPageRequestedModel}
        deleteBtnHandler={actionBtnHandler}
      />
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}
    </>
  );
};

export default PageDetails;
