import {
  IonAvatar, IonButton, IonCard, IonCardTitle, IonCol, IonContent, IonIcon, IonInfiniteScroll, IonInfiniteScrollContent,
  IonLabel, IonModal, IonRow
} from '@ionic/react';
import { close } from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router';
import CallFor from '../../util/CallFor';
import userLogo from '../../assets/img/user-profile-placeholder.png';
import Footer from '../Layout/Footer';
import ToastCommon from '../common/ToastCommon';
import { Trans, useTranslation } from 'react-i18next';
const InviteUserCommon = (props: any) => {
  const { t } = useTranslation();
  const history = useHistory();
  const [isCheck, setIsCheck] = useState([]);
  const [errorMsg, setErrorMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [count, setCount] = useState(0);
  const inviteFun = async() => {
    if (isCheck.length > 0) {
      let url = '';
      if (props.type === 'page') {
        url = 'api/v1.1/pages/' + props.modalData.id + '/request/invite';
      } else if (props.type === 'group') {
        url = 'api/v1.1/group/request/invite/' + props.modalData.id;
      }
      const response = await CallFor(url, 'POST', JSON.stringify(isCheck), 'Auth');
      if (response.status === 201) {
        if (props.type === 'page') {
          setShowToastMsg(t('toastmessages.toast8', { name: isCheck.length }));
        } else if (props.type === 'group') {
          setShowToastMsg(t('toastmessages.toast8', { name: isCheck.length }));
        }
        // setShowToast(true);
        // setTimeout(() => {
        history.push(props.redirectUrl);
        // }, 1000);
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    } else {
      setErrorMsg(t('appproperties.text419'));
    }
  };

  const checkboxChangeHandler = (event: any) => {
    setErrorMsg('');
    const { id, checked } = event.target;
    if (!checked) {
      setIsCheck(isCheck.filter(item => item !== id));
    } else {
      setIsCheck([...isCheck, id]);
    }
  };
  const getConnectionList = async(page: string | number) => {
    const response = await CallFor(
      'api/v1.1/connection/list/ALL',
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      return json1Response.data.content;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
      return [];
    }
  };
  const getConnectionListOnScroll = async(page: string | number) => {
    const response = await CallFor(
      'api/v1.1/connection/list/ALL',
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        props.setInviteConnection([...props.inviteConnection, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  useEffect(async() => {
    if (props.inviteConnection !== undefined && props.inviteConnection.length > 0) {
      const data1 = await getConnectionList(1);
      if (data1.length > 0) {
        props.setInviteConnection([...props.inviteConnection, ...data1]);
        setCount(2);
      } else {
        setInfiniteDisabled(true);
      }
    } else {
      setInfiniteDisabled(true);
    }
  }, []);
  const loadData = (ev: any) => {
    setTimeout(() => {
      getConnectionListOnScroll(count);
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  };
  return (
      <>
      <IonModal
        isOpen={props.invitationModal}
        cssClass="pageModel invite-connections"
        onDidDismiss={() => props.setInvitationModal(false)}
      >
       <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end  ion-justify-content-between">
                <IonLabel className="MuiTypography-h6 w-85 title-line-h">{t('appproperties.text341')} {props.modalData.name}</IonLabel>
                <IonButton
                    fill="clear"
                    onClick={() => { props.setInvitationModal(false); history.push(props.redirectUrl); }}
                    className="close link-btn-tx ion-no-padding ion-no-margin cursor-pointer"
                >
                    <IonIcon
                    icon={close}
                    className="ion-button-color pr-0 "
                    slot="start"
                    size="small"
                    />
                </IonButton>
            </IonRow>
            <IonContent>
            {props.inviteConnection.length > 0
              ? <>
              <div className='d-flex justify-content-end pe-3'>
              <IonButton className="ion-button-color pr-0" onClick={inviteFun}>
              {t('appproperties.text362')}
              </IonButton>
            </div>
            <IonRow className='full-width-row ps-lg-4 ps-3 pb-2'>
                <h2 className='error ion-no-margin ion-margin-bottom'>{errorMsg}</h2>
              </IonRow>
              </>
              : ''}
            <div className="profile-details ion-no-margin full-width-row left-cards MuiPaper-rounded ion-padding">
              {props.inviteConnection.length > 0
                ? <IonRow>
                  {props.inviteConnection.map((detail, index) => (
                    // eslint-disable-next-line react/jsx-key
                    <IonCol
                      sizeMd="6"
                      sizeXs="12"
                    >
                      <div className="myprofile-feeds">
                        <input
                          id={detail.id}
                          name={detail.name}
                          type="checkbox"
                          className='me-2'
                          onChange={checkboxChangeHandler}
                          checked={isCheck.includes(detail.id)} />
                        <IonAvatar slot="start" className="MuiCardHeader-avatar cursor-pointer" onClick={() => { history.push('/profile/' + detail.id); } }>
                          {detail.img === null || detail.img === ''
                            ? (
                            <img src={userLogo} />
                              )
                            : (
                            <img onError={(ev) => { ev.target.src = userLogo; }} src={detail.img} />
                              )}
                        </IonAvatar>
                        <IonRow className="profileName cursor-pointer" onClick={() => { history.push('/profile/' + detail.id); } }>
                          <IonCardTitle>
                            <p className="margin MuiTypography-body1">
                              {detail.name}
                            </p>
                            <span className="margin MuiTypography-caption group-model-text">
                              {detail.designation}
                            </span>
                          </IonCardTitle>
                        </IonRow>
                      </div>
                    </IonCol>
                  ))}
                  <IonInfiniteScroll
                onIonInfinite={loadData}
                threshold="100px"
                disabled={isInfiniteDisabled}
              >
                <IonInfiniteScrollContent
                  loadingSpinner="circular"
                  loadingText={t('appproperties.text215')}
                ></IonInfiniteScrollContent>
              </IonInfiniteScroll>
                </IonRow>
                : <h4 className='ion-text-center'>Build your Network to Invite your Connections !!</h4>}
            </div>
            </IonContent>
      </IonModal>
      <Footer />
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000}/>
  </>
  );
};
export default InviteUserCommon;
