/* eslint-disable react/jsx-key */
import {
  IonCard,
  IonHeader,
  IonRow,
  IonList
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router';
import CallFor from '../../util/CallFor';
import image from '../../assets/img/user-profile-placeholder.png';
import Footer from '../Layout/Footer';
import SkeletonActivityComon from '../common/skeleton/SkeletonActivityComon';
import CommonGridList from '../common/CommonGridList';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import { useTranslation } from 'react-i18next';

const TeamMember = (props: any) => {
  const { t } = useTranslation();
  const { companyId } = useParams();
  const profileDetail = useSelector(getProfileDetails);
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [company, setCompany] = useState([]);

  useEffect(() => {
    getComanyData()
  }, [])

  const getComanyData = async () => {
    setLoading(true);
    const companyData = await CallFor(
      'api/v1.1/companies?userId=' + props.userId,
      'GET',
      null,
      'Auth'
    );
    if (companyData.status === 200) {
      const json1Response = await companyData.json();
      if (json1Response.data !== null) {
        if (json1Response.data.length < 2) {
          props.setClassMobile(true);
        }
        setCompany(json1Response.data);
      }
    }
    setLoading(false);
  };

  // const myCompanyDetails = (id) => {
  //   props.getTeamMember(id);
  //   props.getcompanyDetail(id);
  //   props.setClassMobile(true);
  //   document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  //   history.push('/teams/' + props.userId + '/' + id);
  // };
  if (props.classMobile) {
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  } else {
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  }
  return (
    <>
      <IonCard className={props.classMobile ? 'showpage sdb-box profile-details left-cards no-shadow sidebar-pages md hydrated my-company-details-mobile' : 'sdb-box profile-details left-cards no-shadow sidebar-pages md hydrated my-company-details-mobile'}>
        <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between md header-md header-collapse-none hydrated  mtm-0 mbm-0">
          <p className="ion-align-self-start">{t('companyproperties.text1')}</p>
        </IonHeader>
        <IonRow className='custom-scroll'>
          {loading
            ? <SkeletonActivityComon />
            : company.length > 0
              ? <div className='company-list-details company-bottom-border w-100 p-0'>
                {
                  company.map((detail, i) => {
                    return (
                      <IonList lines="none" key={i}
                        className={companyId === detail.id ? 'full-width-row py-0 activeCatalogue' : 'full-width-row py-0'}
                      >
                        <CommonGridList userId={profileDetail.id} id={detail.id} defultImage={image} img={detail.entityLogo} name={detail.name}
                          subString={detail.city + ' ' + (detail.state ? ' | ' + detail.state : ' ')} dots={false} redirectLink='teams' />
                      </IonList>
                    );
                  })
                }
              </div>
              : ''}
        </IonRow>
      </IonCard>
      <Footer />
    </>
  );
};
export default TeamMember;
