import { IonCard, IonCol, IonRow } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory, useParams } from 'react-router';
import CallFor from '../../util/CallFor';

const PageAnalystics = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const { pageId } = useParams();
  useEffect(() => {
    getPageAnalytics();
  }, []);
  const [pageAnalyticsList, setaPageAnalyticsList] = useState([]);
  const getPageAnalytics = async() => {
    const response = await CallFor(
      'api/v1.1/pages/analytics/' + pageId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 201) {
      const json1Response = await response.json();
      if (json1Response.data !== null) {
        setaPageAnalyticsList(json1Response.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  return (
    <IonCard className="MuiPaper-rounded ion-margin-top p-2 ion-margin-bottom ion-no-margin analytics-page">
        <IonRow>
            <IonCol size-md="6" size-xs="6" className="ion-padding-start ps-2" >
            <div className='analytics-box h-100'>
            <p className="ion-no-padding font-medium">{t('appproperties.text112')}</p>
            {pageAnalyticsList.comments}
            </div>
            </IonCol>
            <IonCol size-md="6" size-xs="6" className="ion-padding-start ps-2" >
            <div className='analytics-box h-100'>
            <p className="ion-no-padding font-medium">{t('appproperties.text253')}</p>
            {pageAnalyticsList.commentsChange}
            </div>
            </IonCol>

            <IonCol size-md="6" size-xs="6" className="ion-padding-start ps-2" >
            <div className='analytics-box h-100'>
            <p className="ion-no-padding font-medium">{t('commonproperties.text38')}</p>
            {pageAnalyticsList.followers}
            </div>
            </IonCol>

            <IonCol size-md="6" size-xs="6" className="ion-padding-start ps-2" >
            <div className='analytics-box h-100'>
            <p className="ion-no-padding font-medium">{t('appproperties.text254')}</p>
            {pageAnalyticsList.followersChange}
            </div>
            </IonCol>

            <IonCol size-md="6" size-xs="6" className="ion-padding-start ps-2" >
            <div className='analytics-box h-100'>
            <p className="ion-no-padding font-medium">{t('feedproperties.text5')}</p>
            {pageAnalyticsList.reactions}
            </div>
            </IonCol>

            <IonCol size-md="6" size-xs="6" className="ion-padding-start ps-2" >
            <div className='analytics-box h-100'>
            <p className="ion-no-padding font-medium">{t('appproperties.text255')}</p>
            {pageAnalyticsList.reactionsChange}
            </div>
            </IonCol>

            <IonCol size-md="6" size-xs="6" className="ion-padding-start ps-2" >
            <div className='analytics-box h-100'>
            <p className="ion-no-padding font-medium">{t('appproperties.text256')}</p>
            {pageAnalyticsList.reshares}
            </div>
            </IonCol>

            <IonCol size-md="6" size-xs="6" className="ion-padding-start ps-2" >
            <div className='analytics-box h-100'>
            <p className="ion-no-padding font-medium">{t('appproperties.text257')}</p>
            {pageAnalyticsList.resharesChange}
            </div>
            </IonCol>
        </IonRow>
  </IonCard>
  );
};
export default PageAnalystics;
