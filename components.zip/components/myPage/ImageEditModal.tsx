import { IonIcon, IonModal } from '@ionic/react';
import React, { useCallback, useState } from 'react';
import {
  cameraOutline,
  close,
  trashBinOutline
} from 'ionicons/icons';
import { getCroppedImg } from './canvasUtils';
import CallFor from '../../util/CallFor';
import ToastCommon from '../common/ToastCommon';
import ImageCropModal from './ImageCropModal';
import ProfilePicture from '../common/ProfilePicture';
import CoverImage from '../common/CoverImage';
import { browserName, isAndroid, isIOS } from 'react-device-detect';
import { useTranslation } from 'react-i18next';
const ImageEditModal = (props: any) => {
  const { t } = useTranslation();
  const [openModal, setOpenModal] = useState(false);
  const [imageSrc, setImageSrc] = React.useState(null);
  const [showToast, setShowToast] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [errormessage, setErrorMessage] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileType, setFileType] = useState('');
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [rotation, setRotation] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState(null);
  const [croppedImage, setCroppedImage] = useState(null);
  const [heightNew, setHeight] = useState();
  const [widthNew, setWidth] = useState();

  let maxWidth;
  let maxHeight;

  if ((isAndroid || isIOS) && (browserName === 'Chrome WebView' || browserName === 'WebKit')) {
    if (props.background) {
      // logo
      maxHeight = '400px';
      maxWidth = '225px';
    } else {
      // cover
      maxWidth = '450';
      maxHeight = 'auto';
    }
  } else {
    if (props.background) {
      // logo
      maxWidth = '400';
      maxHeight = '400';
    } else {
      // cover
      maxWidth = 750;
      maxHeight = 750;
    }
  }
  const onFileChange = async (e: { target: { files: string | any[]; }; }) => {
    if (e.target.files && e.target.files.length > 0) {
      if (
        !e.target.files[0].name.match(
          /\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/
        )
      ) {
        setShowToastMsg(t('commonproperties.text1'));
        setShowToast(true);
      } else if (e.target.files[0].size > 3051356) {
        setShowToastMsg(t('commonproperties.text2'));
        setShowToast(true);
      } else {
        setErrorMessage('');
        const file = e.target.files[0];
        const imageDataUrl = window.URL.createObjectURL(file);
        const img = new Image();
        img.src = window.URL.createObjectURL(file);
        img.onload = () => {
          let ratio = 0;
          let height = img.height;
          let width = img.width;
          if (width > maxWidth && width > height) {
            ratio = width / height;
            height = maxWidth / ratio;
            width = maxWidth;
          } else if (height > maxHeight && height > width) {
            ratio = height / width;
            width = maxHeight / ratio;
            height = maxHeight;
          } else {
            width = maxWidth;
            height = maxHeight;
          }
          setHeight(height);
          setWidth(width);
        };
        setFileName(e.target.files[0].name);
        setFileType(e.target.files[0].type);
        setImageSrc(imageDataUrl);
      }
    }
    setRotation(0);
    setZoom(1);
  };
  const deleteImage = async () => {
    document.getElementById('imagefile').value = '';
    setCroppedImage(null);
    setOpenModal(false);
    const data = new FormData();
    data.append('logo', null);
    let type;
    let methodType;
    if (props.serviceType === 'COMPANY' || props.serviceType === 'USER') {
      type = 'logo';
      methodType = 'POST';
    } else {
      type = 'image';
      methodType = 'PUT';
    }
    const response = await CallFor('api/v1.1/' + props.serviceType + '/' + props.id + '/' + type + '/' + props.logo,
      methodType,
      data,
      'authWithoutContentType');
    if (response.status === 201) {
      // setShowToastMsg('Logo Deleted Successfully');
      // setShowToast(true);
      props.getDetails(props.id);
    } else if (response.status === 500) {
      setShowToastMsg(t('appproperties.text238'));
      setShowToast(true);
    }
  };
  const openEditModal = () => {
    setOpenModal(true);
    setImageSrc(null);
  };
  const onCropComplete = useCallback((croppedArea, croppedAreaPixels) => {
    setCroppedAreaPixels(croppedAreaPixels);
  }, []);

  const showCroppedImage = useCallback(async () => {
    try {
      const croppedImage = await getCroppedImg(imageSrc,
        croppedAreaPixels,
        rotation
      );
      setCroppedImage(croppedImage);
      setCrop({ x: 0, y: 0 });
      setImageSrc(null);
      setCroppedAreaPixels(null);
      setOpenModal(false);
      const newfile = await fetch(croppedImage).then(r => r.blob()).then(blobFile => new File([blobFile], fileName, { type: fileType }));

      const data = new FormData();
      data.append('logo', newfile);
      let type;
      let methodType;
      if (props.serviceType === 'COMPANY' || props.serviceType === 'USER') {
        type = 'logo';
        methodType = 'POST';
      } else {
        type = 'image';
        methodType = 'PUT';
      }
      const response = await CallFor('api/v1.1/' + props.serviceType + '/' + props.id + '/' + type + '/' + props.logo,
        methodType,
        data,
        'authWithoutContentType');
      if (response.status === 201) {
        // setShowToastMsg(props.message);
        // setShowToast(true);
        setOpenModal(false);
      } else if (response.status === 500) {
        setShowToastMsg(t('appproperties.text238'));
        setShowToast(true);
      }
    } catch (e) {
      console.error(e);
    }
  }, [imageSrc, croppedAreaPixels, rotation]);

  return (
    <>
      {props.logo !== 'LOGO'
        ? <>

          <CoverImage logo={props.logo} croppedImage={croppedImage} openEditModal={openEditModal} image={props.image} defultLogo={props.defultLogo} isAdmin={props.isAdmin} reportHideState={props.reportHideState} isHide={props.isHide} />
        </>
        : <>
          <ProfilePicture width={78} logo={props.logo} croppedImage={croppedImage} openEditModal={openEditModal} image={props.image} defultLogo={props.defultLogo} isAdmin={props.isAdmin} reportHideState={props.reportHideState} isHide={props.isHide} />
        </>
      }
      <IonModal
        cssClass={props.cssClass}
        isOpen={openModal}
        onDidDismiss={() => setOpenModal(false)}
      >
        {!imageSrc

          ? <div className='edit-image-modal edit-image-modal-popup d-lg-block flex-column justfy-mobile-center'>
            <div className='d-flex justify-content-between p-3 model-title edit-logo-xs'>
              <span>{t('appproperties.text138')}</span>
              <span>
                <IonIcon
                  style={{ cursor: 'pointer', color: '#fff' }}
                  className={'model-button-btn'}
                  icon={close}
                  onClick={() => setOpenModal(false)} />{' '}
              </span>
            </div>

            <div className={props.className}>
              {
                croppedImage !== null && croppedImage !== ''
                  ? <img src={croppedImage} alt="cropImage" />
                  : props.image !== null && props.image !== ''
                    ? <img src={props.image} alt="defultLogo" />
                    : croppedImage === null && props.image === null
                      ? <img src={props.defultLogo} className="default-logo" alt="defultLogo" />
                      : ''
              }
            </div>
            <div className="button-edit btn-space-edit w-100">
              <input
                className='upload'
                id="imagefile"
                type="file"
                style={{ display: 'none' }}
                onChange={onFileChange}
                accept="image/png, image/jpg, image/jpeg" />
              <label htmlFor="imagefile" className='cursor-pointer'>
                <IonIcon
                  style={{ cursor: 'pointer', color: '#fff' }}
                  icon={cameraOutline}
                  className={'model-button-btn'} />
              </label>
              <button
                className='ms-3'
                onClick={deleteImage}
                style={{ background: 'none' }}
              >
                <IonIcon
                  style={{ cursor: 'pointer', color: '#fff' }}
                  icon={trashBinOutline}
                  className={'model-button-btn'} />
              </button>
            </div>
          </div>
          : <ImageCropModal
            imageSrc={imageSrc}
            crop={crop}
            rotation={rotation}
            zoom={zoom}
            setCrop={setCrop}
            setRotation={setRotation}
            onCropComplete={onCropComplete}
            setZoom={setZoom}
            showCroppedImage={showCroppedImage}
            setImageSrc={setImageSrc}
            setOpenModal={setOpenModal}
            setCroppedAreaPixels={setCroppedAreaPixels}
            errormessage={errormessage}
            croppedImage={croppedImage}
            restrictPosition={true}
            aspect={props.aspect}
            cropShape={props.cropShape}
            heightNew={heightNew}
            widthNew={widthNew}
            cropSize={props.cropSize}
          />
        }
      </IonModal>
      <ToastCommon
        setShowToast={setShowToast}
        setShowToastMsg={setShowToastMsg}
        showToast={showToast}
        showToastMsg={showToastMsg}
        duration={3000}
      />
    </>
  );
};

export default ImageEditModal;
