/* eslint-disable multiline-ternary */
/* eslint-disable no-new */
/* eslint-disable react/jsx-key */

import {
  IonButton,
  IonCard,
  IonCol,
  IonContent,
  IonFooter,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonRow,
  IonTextarea,
  useIonViewWillEnter
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router';
import CallFor from '../../util/CallFor';
import pageLogo from '../../assets/img/page-logo-default.png';
import { close } from 'ionicons/icons';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import Select from 'react-select';
import SkeletonComonList from '../common/skeleton/SkeletonComonList';
import SkeletonComonViewAll from '../common/skeleton/SkeletonComonViewAll';
import PopoverCommon from '../common/PopoverCommon';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import CommonGridList from '../common/CommonGridList';
import InviteUserCommon from './InviteUserCommon';
import CustomeFirebaseEvent from '../common/CustomFirebaseEvent';
import { Device } from '@capacitor/device';
import { useTranslation } from 'react-i18next';

const customStyles = {
  control: (provided: any) => ({
    ...provided,
    height: 50,
    background: '#fff !important',
    border: 'none',
    '&:focus': {
      border: '1px solid #0763b2'
    }
  }),
  multiValue: (styles, { data }) => {
    return {
      ...styles,
      padding: 4,
      backgroundColor: '#0073ae!important',
      borderRadius: '50px'
    };
  },
  multiValueLabel: (styles, { data }) => ({
    ...styles,
    color: '#fff'
  }),
  multiValueRemove: (styles, { data }) => ({
    ...styles,
    color: '#0073ae!important',
    borderRadius: '50px',
    margin: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    ':hover': {
      backgroundColor: '#fff'
    }
  }),
  indicatorSeparator: () => {}, // removes the "stick"
  dropdownIndicator: (defaultStyles: any) => ({
    ...defaultStyles,
    '& svg': { display: 'none' }
  })
};
export const isValidUrl = (url) => {
  try {
    new URL(url);
  } catch (e) {
    console.error(e);
    return false;
  }
  return true;
};
const PageList = (props: any) => {
  const { t } = useTranslation();
  const history = useHistory();
  const [diviceInfo, setDiviceInfo] = useState();
  const [loading, setLoading] = useState(false);
  const [pageList, setPageList] = useState<object[]>([]);
  const [userFormState, setUserFormState] = useState({});
  const [invitationModal, setInvitationModal] = useState(false);
  const [industry, setIndustry] = useState([]);
  const [createDisabled, setCreateDisabled] = useState(false);
  const [modalData, setModalData] = useState({});
  const [scrollData, setScrollData] = useState<object[]>([]);
  const [count, setCount] = useState(0);
  const [showModal, setShowModal] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [characterCount, setCharacterCount] = useState(0);
  const [confirmModel, setConfirmModel] = useState(false);
  const [inviteConnection, setInviteConnection] = useState([]);
  const [pageName, setPageName] = useState('');
  const [PageId, setPageId] = useState('');
  const confirmMessage = (
    <IonLabel>
      {t('pageproperties.text2')}
    </IonLabel>
  );

  const getIndustry = async() => {
    const response = await CallFor('api/v1.1/industries', 'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      const states = await json1Response.data.map(
        (d: { subIndustryID: any; subIndustry: any }) => ({
          value: d.subIndustryID,
          label: d.subIndustry
        })
      );
      setIndustry(states);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  const validationSchema = Yup.object().shape({
    name: Yup.string().trim()
      .required(t('pageproperties.text7'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('pageproperties.text9'),
        (val) => val && val.toString().length <= 150
      ),
    catagory: Yup.object()
      .shape({
        label: Yup.string().required(t('pageproperties.text10')),
        value: Yup.string().required(t('pageproperties.text10'))
      })
      .nullable() // for handling null value when clearing options via clicking "x"
      .required(t('pageproperties.text10')),
    url: Yup.string()
      .nullable(true)
      .notRequired()
      .optional()
      .nullable()
      .matches(
        /^((ftp|http|https):\/\/)?(www.)?(?!.*(ftp|http|https|www.))[a-zA-Z0-9_-]+(\.[a-zA-Z]+)+((\/)[\w#]+)*(\/\w+\?[a-zA-Z0-9_]+=\w+(&[a-zA-Z0-9_]+=\w+)*)?$/gi,
        { message: t('pageproperties.text11'), excludeEmptyString: true }
      ),
    description: Yup.string()
      .trim()
      .nullable(true)
      .optional()
      .notRequired()
      .test('len', t('commonproperties.text13'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().trim().length >= 10;
        } else {
          return true;
        }
      })
      .test('len', t('awardproperties.text9'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().trim().length <= 250;
        } else {
          return true;
        }
      })
  });

  const {
    register,
    handleSubmit,
    setError,
    clearErrors,
    resetField,
    control,
    formState: { errors, isValid }
  } = useForm({
    resolver: yupResolver(validationSchema),
    criteriaMode: 'all',
    reValidateMode: 'onTouched',
    mode: 'onChange'
  });
  const userformDataChangeHandler = (value, name) => {
    if (value !== undefined) {
      setUserFormState({
        ...userFormState,
        [name]: value
      });
    }
  };
  useEffect(async() => {
    setDiviceInfo(await Device.getInfo());
    getPageList();
    getIndustry();
  }, []);
  const getPageList = async() => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/pages/list',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      setPageList(json1Response.data.content);
      setScrollData(json1Response.data.content);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
    setCount(1);
  };
  const getPageListOnScroll = async() => {
    const response = await CallFor(
      'api/v1.1/pages/list',
      'POST',
      '{"page": ' + count + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setScrollData([...scrollData, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const leavePageHandler = async() => {
    const response = await CallFor(
      'api/v1.1/pages/' + PageId + '/leave/user',
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setPageList(pageList.filter((item) => item.id !== PageId));
      setScrollData(scrollData.filter((item) => item.id !== PageId));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const getConnectionList = async(page: string | number) => {
    const response = await CallFor(
      'api/v1.1/connection/list/ALL',
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      return json1Response.data.content;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
      return [];
    }
  };

  const pageSubmitHandler = async() => {
    setCreateDisabled(true);
    const catagoryName = document.formName.elements.catagory.value;
    let pageNameData = '';
    let pageAboutData = null;
    if (userFormState.name !== undefined && userFormState.name !== null) {
      pageNameData = userFormState.name.trim();
    }
    if (
      userFormState.description !== undefined &&
      userFormState.description !== null
    ) {
      pageAboutData = userFormState.description.trim();
    }
    const pageData = {
      name: pageNameData,
      catagory: catagoryName,
      url: userFormState.url,
      description: pageAboutData
    };

    const response = await CallFor(
      'api/v1.1/pages',
      'POST',
      JSON.stringify(pageData),
      'Auth'
    );
    if (response.status === 201) {
      const datares = await response.json();
      const inviteData = await getConnectionList(0);
      if (inviteData.length > 0) {
        const data = {};
        data.id = datares.data.id;
        data.name = datares.data.name;
        setModalData(data);
        setInviteConnection(inviteData);
        setInvitationModal(true);
      } else {
        history.push('page');
      }
      openModelWithClearState();
      CustomeFirebaseEvent('pages_event', diviceInfo);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 400) {
      setLoading(false);
      const datares = await response.json();
      datares.error.errors.map((details) => {
        setError(details.field, {
          type: 'server',
          message: details.message
        });
      });
    }
    setCreateDisabled(false);
    // }
  };
  const restHandler = (event) => {
    if (event.target.name === 'name' && event.target.value === '') {
      resetField('name');
    } else if (event.target.name === 'url' && event.target.value === '') {
      resetField('url');
    } else if (event.target.name === 'description' && event.target.value === '') {
      resetField('description');
    } else if (event.target.name === 'industry' && event.target.value === '') {
      resetField('industry');
    }
  };
  const openModelWithClearState = () => {
    props.setShowModal(false);
    setUserFormState('');
    clearErrors();
    resetField('name');
    resetField('catagory');
    resetField('url');
    resetField('description');
    setCharacterCount(0);
    setCreateDisabled(false);
  };
  useIonViewWillEnter(async() => {
    getPageListOnScroll();
  });
  function searchNext(ev: any) {
    setTimeout(() => {
      getPageListOnScroll();
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  }
  const viewPaginaction = () => {
    setShowModal(true);
    getPageListOnScroll();
  };
  const closemodel = () => {
    setCount(1);
    setShowModal(false);
    setScrollData(pageList);
    setInfiniteDisabled(false);
  };
  const maxCount = 250;
  const descriptionChangeHandler = (value, name) => {
    if (value !== undefined) {
      setUserFormState({
        ...userFormState,
        description: value
      });
    }
    if (value !== undefined && value != null) {
      setCharacterCount(value.length);
    }
  };

  return (
    <>
      <IonCard className=" profile-details ion-no-margin my-company-list MuiPaper-rounded grouplist-card ion-no-padding ion-padding-horizontal ion-padding-bottom">
        <div className="ion-text-right mt-3">
          {pageList.length >= 10 ? (
            <IonButton
              fill="clear"
              size="small"
              className="ml-auto link-btn link-btn-tx dn-mobile "
              onClick={viewPaginaction}
            >
             {t('commonproperties.text3')}
            </IonButton>
          ) : (
            ''
          )}
        </div>
        {pageList.length > 0 ? (
          <IonRow className="grouplist-card-mb-list member-listing-group member-listing comopany-listing">
            {pageList.map((list, i) => (
              <CommonGridList key={i} id={list.id} defultImage={pageLogo} img={list.img} name={list.name} subString2={list.followers +  t('commonproperties.text38')} dots={false} DefaulCover={false} coverImg={false}
                redirectLink='pageDetails' isHide={list.isHide} btnLeave={() => { setConfirmModel(true); setPageId(list.id); setPageName(list.name); setShowModal(false); } } isAdmin={list.isAdmin} isAdminText={t('appproperties.text332')} />
            ))}
          </IonRow>
        ) : loading ? (
          <>
            <SkeletonComonList
              column={6}
              sizeMd={6}
              sizeXs={12}
              name={true}
              title={true}
              distription={true}
              link={false}
            />
          </>
        ) : (
          <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">
            {t('nodatafound.text27')}
          </p>
        )}
        {pageList.length >= 10 ? (
          <div className="right-col-cn gup-btn-action view-all-mobile">
            <div onClick={viewPaginaction} className="link-btn-tx">
            {t('commonproperties.text3')}
            </div>
          </div>
        ) : (
          ''
        )}
      </IonCard>
      <IonModal
        isOpen={props.showModal}
        cssClass="createGroupModal"
        onDidDismiss={() => openModelWithClearState()}
      >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between ">
            <IonLabel className="MuiTypography-h6 ps-lg-2 ps-3">{t('pageproperties.text3')}</IonLabel>
            <div
              onClick={openModelWithClearState}
              className="close ion-no-padding cursor-pointer"
            >
              <IonIcon
                icon={close}
                className="ion-button-color "
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <div className="modal-body">
            <form
              onSubmit={handleSubmit(pageSubmitHandler)}
              className="h-100"
              noValidate
              data-testid="form-submit"
              name="formName"
              autoComplete="off"
            >
              <div className="body-content">
                <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
                  <IonCol
                    size-md="12"
                    size-xs="12"
                    size-sm="12"
                    className="my-3"
                  >
                    <IonItem
                      className={
                        errors.name
                          ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                          : 'form-group input-label-box position-relative pt-0 mb-0'
                      }
                    >
                      <IonLabel position="floating">
                        {' '}
                        {t('pageproperties.text4')} <sup>*</sup>{' '}
                      </IonLabel>
                      <Controller
                        name="name"
                        control={control}
                        defaultValue=""
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonInput
                            type="text"
                            autocomplete="off"
                            {...field}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              userformDataChangeHandler(value, name);
                            }}
                            placeholder=""
                            onClick={restHandler}
                            className="input-box"
                            id="name"
                            {...register('name')}
                          />
                        )}
                      />
                      <span className={errors.name ? 'error input-error' : ''}>
                        {errors.name?.message}
                      </span>
                    </IonItem>
                  </IonCol>
                  <IonCol
                    size-md="12"
                    size-xs="12"
                    size-sm="12"
                    className="show-tooltip input-popover d-block select-cross group-notification"
                  >
                    <Controller
                      name="catagory"
                      control={control}
                      render={({ field }) => (
                        <Select
                          {...field}
                          autocomplete="off"
                          type="text"
                          isClearable
                          isSearchable={true}
                          className={
                            errors.catagory
                              ? 'error-border selectOption moreimp v-imp borderradius6 border'
                              : 'selectOption moreimp v-imp borderradius6 border selectcorss-btn'
                          }
                          placeholder={t('pageproperties.text10') + '*'}
                          // onChange={industrySelectHandler}
                          onClick={restHandler}
                          styles={customStyles}
                          options={industry}
                          id="catagory"
                          menuPlacement="bottom"
                          menuPosition="absolute"
                        />
                      )}
                    />
                    <span className={errors.catagory ? 'error' : ''}>
                      {errors.catagory?.message ||
                        errors.catagory?.label.message}
                    </span>
                    <PopoverCommon
                      className="popover-zyapaar"
                      Description={t('appproperties.text434')}
                    />
                  </IonCol>
                  <IonCol
                    size-md="12"
                    size-xs="12"
                    size-sm="12"
                    className="show-tooltip input-popover mt-2 pt-2"
                  >
                    <IonItem
                      className={
                        errors.url
                          ? 'error-border form-group input-label-box position-relative'
                          : 'form-group input-label-box position-relative'
                      }
                    >
                      <IonLabel position="floating">{t('pageproperties.text5')}</IonLabel>
                      <Controller
                        name="url"
                        control={control}
                        defaultValue=""
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonInput
                            type="text"
                            autocomplete="off"
                            {...field}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              userformDataChangeHandler(value, name);
                            }}
                            onClick={restHandler}
                            placeholder=""
                            className="input-box input-custom-width"
                            id="url"
                            {...register('url')}
                          />
                        )}
                      />
                      <span className={errors.url ? 'error input-error' : ''}>
                        {errors.url?.message}
                      </span>
                    </IonItem>
                    <PopoverCommon
                      className="popover-zyapaar mt-2"
                      Description="(http:// or https:// or www)domain.com"
                    />
                  </IonCol>
                  <IonCol size-md="12" size-xs="12" size-sm="12">
                    <IonItem
                      className={
                        (errors.description
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0') +
                        ' mt-0 '
                      }
                    >
                      <IonLabel position="floating">{t('pageproperties.text6')}</IonLabel>
                      <Controller
                        name="description"
                        control={control}
                        defaultValue=""
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonTextarea
                            type="text"
                            autocomplete="off"
                            {...field}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              descriptionChangeHandler(value, name);
                            }}
                            onClick={restHandler}
                            placeholder=""
                            className="input-box"
                            id="description"
                            rows={4}
                            maxlength={250}
                            {...register('description')}
                          />
                        )}
                      />
                    </IonItem>
                    <p className={errors.description ? 'error' : ''}>
                      {errors.description?.message}
                    </p>
                    <p className="text-grey text-end font-14">
                      {characterCount}/{maxCount}
                    </p>
                  </IonCol>
                </IonRow>
              </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-bottom">
                <IonRow>
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto"
                    type="submit"
                    size="small"
                    disabled={createDisabled || !isValid}
                  >
                    {t('pageproperties.text3')}
                    {createDisabled ? (
                      <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                    ) : (
                      ''
                    )}
                  </IonButton>
                </IonRow>
              </IonFooter>
            </form>
          </div>
        </IonContent>
      </IonModal>
      {/* Modal
      ""
      */}
      <IonModal
        isOpen={showModal}
        cssClass="pageModel"
        onDidDismiss={() => closemodel()}
      >
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          <IonLabel className="MuiTypography-h6">{t('commonproperties.text3')}</IonLabel>
          <div
            onClick={closemodel}
            className="close ion-no-padding cursor-pointer"
          >
            <IonIcon
              icon={close}
              className="ion-button-color "
              slot="start"
              size="undefined"
            />
          </div>
        </IonRow>
        <IonContent>
          <div className="modal-body pagelistmodal">
            <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom member-listing">
              {!loading ? (
                <>
                  {scrollData.map((list, i) => (
                    <CommonGridList key={i} id={list.id} defultImage={pageLogo} img={list.img} name={list.name} subString2={list.followers +  t('commonproperties.text38')} dots={false} DefaulCover={false} coverImg={false}
                      redirectLink='pageDetails' isHide={list.isHide} btnLeave={() => { setConfirmModel(true); setPageId(list.id); setPageName(list.name); setShowModal(false); } } isAdmin={list.isAdmin} isAdminText={t('appproperties.text332')} />
                  ))}
                </>
              ) : (
                <SkeletonComonViewAll
                  column={8}
                  sizeMd={3}
                  sizeXs={12}
                  name={true}
                  title={true}
                  distription={true}
                  link={false}
                />
              )}
            </IonRow>
            <IonInfiniteScroll
              onIonInfinite={searchNext}
              threshold="100px"
              disabled={isInfiniteDisabled}
              className='mx-auto'
            >
              <IonInfiniteScrollContent
                loadingSpinner="circular"
                loadingText={t('appproperties.text215')}
                className='font-regular text-grey'
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </div>
        </IonContent>
      </IonModal>
      <ConfirmModelCommon
        header={t('appproperties.text396')}
        message={confirmMessage}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text332')}
        confirmModel={confirmModel}
        setConfirmModel={setConfirmModel}
        deleteBtnHandler={leavePageHandler}
        iD={PageId}
      />
      {invitationModal && modalData.id !== undefined
        ? <InviteUserCommon invitationModal ={invitationModal} setInvitationModal ={setInvitationModal}
        inviteConnection ={inviteConnection}
        setInviteConnection={setInviteConnection}
        modalData ={modalData} redirectUrl = {'/pageDetails/' + modalData.id} type ={'page'} />
        : ''}
    </>
  );
};
export default PageList;
