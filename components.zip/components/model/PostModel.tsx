import {
  IonAvatar,
  IonButton,
  IonCol,
  IonFooter,
  IonIcon,
  IonInput,
  IonLabel,
  IonModal,
  IonRadio,
  IonRadioGroup,
  IonRow,
  IonTextarea,
  IonThumbnail
} from '@ionic/react';
import React, { useState } from 'react';
import { close, image, videocam, megaphone, document } from 'ionicons/icons';
import { useTranslation } from 'react-i18next';

const PostModel = () => {
  const { t } = useTranslation();
  const [showModal, setShowModal] = useState(false);
  const [selected, setSelected] = useState<string>('radio');

  return (
    <IonRow>
      <IonModal isOpen={showModal} cssClass="modelpadding" onDidDismiss={() => setShowModal(false)}>
        <IonRow className="MuiDialogTitle-root">
          <IonCol size="10" className="ModalTitle">
            <IonLabel className="MuiTypography-h6 ion-padding-start ion-padding-top">{t('postproperties.text1')}</IonLabel>
          </IonCol>
          <IonCol size="2" className='ion-align-items-center'>
            <IonButton
              fill="clear"
              className="cancel ion-activatable close-btn-icon"
              onClick={() => setShowModal(false)}
            >
              <div className='close-btn-icon'>
              <IonIcon icon={close} slot="start" size="undefined"/>
              </div>
            </IonButton>
          </IonCol>
        </IonRow>
        <IonRow>
          <IonCol size-md="1">
            <div>
              <IonAvatar
                className="MuiAvatar-img ion-padding-start ion-margin-end">
                <img src="https://zyapaar-image-test.s3.ap-south-1.amazonaws.com/1634906976934_a.jpg" />
              </IonAvatar>
            </div>
          </IonCol>
          <IonCol>
            <p className="MuiTypography MuiTypography-colorTextPrimary MuiTypography-body1 ">
            <span>&nbsp;&nbsp;</span> vaibhav porwal
            </p>
          </IonCol>
        </IonRow>
        <IonRow>
          <IonCol>
            <IonLabel className="MuiFormLabel-root ion-padding-start label-legend">
            {t('postproperties.text2')}
            </IonLabel>
            <h6></h6>
            <IonRow>
              <IonRadioGroup
                value={selected}
                onIonChange={(e) => setSelected(e.detail.value)}
              >
                <IonCol className="privacy ion-padding-start">
                  <IonRadio mode="md" value="A"></IonRadio>
                  <IonLabel className="MuiTypography-root MuiFormControlLabel-root">
                  {t('postproperties.text3')}
                  </IonLabel>
                  <IonRadio mode="md" value="B"></IonRadio>
                  <IonLabel className="MuiTypography-root MuiFormControlLabel-root">
                  {t('postproperties.text4')}
                  </IonLabel>
                  <IonRadio mode="md" value="c"></IonRadio>
                  <IonLabel className="MuiTypography-root MuiFormControlLabel-root">
                  {t('postproperties.text5')}
                  </IonLabel>
                </IonCol>
              </IonRadioGroup>
            </IonRow>
          </IonCol>
          <IonCol>
            <IonLabel className="MuiFormLabel-root ion-padding-start label-legend">
              Privacy
            </IonLabel>
            <h6></h6>
            <IonRow>
              <IonRadioGroup>
                <IonCol className="privacy ion-padding-start">
                  <IonRadio mode="md" item-left value="A"></IonRadio>
                  <IonLabel className="MuiTypography-root MuiFormControlLabel-root">
                    Anyone
                  </IonLabel>
                  <IonRadio mode="md" value="B"></IonRadio>
                  <IonLabel className="MuiTypography-root MuiFormControlLabel-root">
                    Connection Only
                  </IonLabel>
                </IonCol>
              </IonRadioGroup>
            </IonRow>
          </IonCol>
        </IonRow>
        <IonRow className="ion-padding-top ion-padding-start">
          <IonTextarea
            placeholder="Let's Talk Business..."
            rows={7}
            value=""
          />
        </IonRow>
        <IonRow className="ion-padding-start">
          <IonInput
            placeholder="Add a #tag"
            value=""
          />
        </IonRow>
        <IonRow className="ion-padding-start">
          <IonCol>
            <IonThumbnail>
              <img src="https://gravatar.com/avatar/dba6bae8c566f9d4041fb9cd9ada7741?d=identicon&f=y" />
            </IonThumbnail>
          </IonCol>
          <IonCol>
            <IonThumbnail>
              <img src="https://gravatar.com/avatar/dba6bae8c566f9d4041fb9cd9ada7741?d=identicon&f=y" />
            </IonThumbnail>
          </IonCol>
          <IonCol>
            <IonThumbnail>
              <img src="https://gravatar.com/avatar/dba6bae8c566f9d4041fb9cd9ada7741?d=identicon&f=y" />
            </IonThumbnail>
          </IonCol>
          <IonCol>
            <IonThumbnail>
              <img src="https://gravatar.com/avatar/dba6bae8c566f9d4041fb9cd9ada7741?d=identicon&f=y" />
            </IonThumbnail>
          </IonCol>
        </IonRow>
        <IonFooter className="ion-no-border MuiButton-label">
          <IonCol size="10">
          <IonCol size="2">
            <IonButton
              color="light"
              className="ion-activatable button"
            >
              <IonIcon icon={image} slot="start" className="icon-color" size="undefined"/>
              <IonLabel className="ion-text-capitalize">{t('appproperties.text83')}</IonLabel>
            </IonButton>
          </IonCol>
          <IonCol size="2">
            <IonButton color="light">
              <IonIcon icon={videocam} slot="start" className="icon-color" size="undefined"/>
              <IonLabel className="ion-text-capitalize">{t('appproperties.text84')}</IonLabel>
            </IonButton>
          </IonCol>
          <IonCol size="2">
            <IonButton color="light">
            <IonIcon icon={document} slot="start" size="undefined" className="icon-color"/>
              <IonLabel className="ion-text-capitalize">file</IonLabel>
            </IonButton>
          </IonCol>
          <IonCol size="2">
            <IonButton color="light">
            <IonIcon icon={megaphone} slot="start" size="undefined" className="icon-color"/>
              <IonLabel className="ion-text-capitalize">announce</IonLabel>
            </IonButton>
          </IonCol>
          </IonCol>
          <IonCol size="2">
            <IonButton className="ion-padding-end post-button ion-panding-bottom">
              <IonLabel className="post">{t('appproperties.text73')}</IonLabel>
            </IonButton>
          </IonCol>
        </IonFooter>
      </IonModal>
      <IonButton onClick={() => setShowModal(true)}>Show Modal</IonButton>
    </IonRow>
  );
};
export default PostModel;
