import { IonCardSubtitle } from '@ionic/react';
import React from 'react';

const TimeText = (props: any) => {
  return (
    <IonCardSubtitle color="textSecondary" className="otp-text ion-text-center">
      0:{props.resendButtonDisabledTime < 10 ? '0' + props.resendButtonDisabledTime : props.resendButtonDisabledTime}
    </IonCardSubtitle>
  );
};
export default TimeText;
