import {
  IonButton,
  IonCardSubtitle,
  IonItemGroup,
  IonRouterLink,
  IonRow
} from '@ionic/react';
import React, { useEffect, useRef, useState } from 'react';
import { useHistory } from 'react-router';
import CallFor from '../../util/CallFor';
import Input from '../common/Input';
import TimeText from './TimeText';
import { setLocalStore, setUserSession } from '../../util/Common';
import GetRegisteredId from '../common/pushNotification/GetRegisteredId';
import { Device } from '@capacitor/device';
import CustomeFirebaseEvent from '../common/CustomFirebaseEvent';
import { useTranslation } from 'react-i18next';

const RESEND_OTP_TIME_LIMIT = 60;
let resendOtpTimerInterval: any;

const VerifyOtp = (props: any) => {
  const { t } = useTranslation();
  const [divMsg, setDivMsg] = useState('');
  const [deviceInfo, setDeviceInfo] = useState();
  const [divMsgClass, setDivMsgClass] = useState('');
  const [error, setError] = useState(false);
  const [verifyButton, setVeriffyButton] = useState(false);
  const inputRef = useRef(null);
  const history = useHistory();
  const [resendButtonDisabledTime, setResendButtonDisabledTime] = useState(
    RESEND_OTP_TIME_LIMIT
  );
  const [refcode, setRefcode] = useState("");
  useEffect(() => {
    // change by Prachi solve By Mayur Patel
    const data = JSON.parse(localStorage.getItem('refcode') || null);
    setRefcode(data);
  }, [])
  const refCallback = (textInputRef: any) => (node: any) => {
    textInputRef.current = node;
  };
  useEffect(async () => {
    setDeviceInfo(await Device.getInfo());
    setTimeout(function () {
      inputRef.current.setFocus();
    }, 200);
  }, []);
  useEffect(() => {
    startResendOtpTimer();
  }, [resendButtonDisabledTime]);

  const startResendOtpTimer = async () => {
    if (resendOtpTimerInterval) {
      clearInterval(resendOtpTimerInterval);
    }

    resendOtpTimerInterval = setInterval(() => {
      if (resendButtonDisabledTime <= 0) {
        clearInterval(resendOtpTimerInterval);
      } else {
        setResendButtonDisabledTime(resendButtonDisabledTime - 1);
      }
    }, 1000);
  };

  const onResendOtpButtonPress = async () => {
    setResendButtonDisabledTime(RESEND_OTP_TIME_LIMIT);
    startResendOtpTimer();
    inputRef.current.value = '';
    inputRef.current.setFocus();
    await CallFor('api/v1.1/signup/otp', 'POST', JSON.stringify(props), 'withoutAuth');
  };

  const wrongNumber = () => {
    history.push('/login');
  };
  const loginHandler = async (e) => {
    setVeriffyButton(true);
    e.preventDefault();
    const otp =
      inputRef.current.value;

    if (otp.length === 6) {
      setError(false);
      const data = {
        otp: otp,
        mobileNo: props.mobileNo,
        userCode: refcode
      }

      const response = await CallFor('api/v1.1/signup/verify', 'POST',
        JSON.stringify(data), 'withoutAuth');
      const jsonResponse = await response.json();

      if (response.status === 200) {
        CustomeFirebaseEvent('otpsubmit_success_event', deviceInfo);
        setDivMsgClass('auth-sub-title ion-text-center successDiv ion-margin-top');
        setDivMsg(jsonResponse.message);
        if (jsonResponse.data.flag === 'SIGNUP') {
          setLocalStore('mobileNo', props.mobileNo);
          setLocalStore('signuptoken', jsonResponse.data.token);
          GetRegisteredId(deviceInfo, 'registrationWithAuth');
          history.push('/registration');
        } else if (jsonResponse.data.flag === 'FULL' || jsonResponse.data.flag === 'REG') {
          setLocalStore('flag', jsonResponse.data.flag);
          setUserSession(jsonResponse.data.token);
          GetRegisteredId(deviceInfo, 'Auth');
          history.push('/home');
        }
      } else if (response.status === 500) {
        setDivMsgClass('auth-sub-title ion-text-center errorDiv mb-lg-4 mb-3 text-nowrap');
        setDivMsg(jsonResponse.message);
        CustomeFirebaseEvent('otpsubmit_failure_event', deviceInfo);
      } else if (response.status === 400) {
        inputRef.current.value = '';
        inputRef.current.setFocus();
        setDivMsgClass('auth-sub-title ion-text-center errorDiv mb-lg-4 mb-3 text-nowrap');
        if (jsonResponse.error.errors !== undefined && jsonResponse.error.errors !== null) {
          setDivMsg(jsonResponse.error.errors[0].message);
        } else {
          setDivMsg(jsonResponse.error.message);
        }
        CustomeFirebaseEvent('otpsubmit_failure_event', deviceInfo);
      } else {
        setDivMsgClass('auth-sub-title ion-text-center errorDiv mb-lg-4 mb-3 text-nowrap');
        if (jsonResponse.error.errors === null) {
          setDivMsg(jsonResponse.error.message);
        } else {
          setDivMsg(jsonResponse.error.errors[0].message);
        }
        CustomeFirebaseEvent('otpsubmit_failure_event', deviceInfo);
      }
    } else {
      setError(true);
    }
    setVeriffyButton(false);
  };
  const validateIsNumericInput = (evt) => {
    const ASCIICode = (evt.which) ? evt.which : evt.keyCode;
    const permittedKeys = [8, 9, 46, 37, 39, 13, 46, 116, 50];
    if ((ASCIICode >= 48 && ASCIICode <= 57) || (ASCIICode >= 96 && ASCIICode <= 105)) {
      return true;
    };
    if (permittedKeys.includes(ASCIICode)) {
      return true;
    };
    return false;
  };
  return (
    <div className="auth-container otp-container">
      <div className='pb-lg-0'>
        <div className="auth-title ion-text-center mb-3 font-28 color-theme-dark mt-3 mt-lg-0">
          <h2>{t('appproperties.text353')}</h2>
        </div>
        <div
          color="textSecondary"
          className="auth-sub-title ion-text-center mb-lg-4 mb-2"
        >
          <h3>
            <strong>{t('appproperties.text354')} +91 {props.mobileNo}</strong>
          </h3>
        </div>
        {divMsg !== ''
          ? (
            <IonCardSubtitle className={divMsgClass}>{divMsg}</IonCardSubtitle>
          )
          : (
            ''
          )}
        <div className="auth-form otp-verify">
          <form
            onSubmit={loginHandler}
            data-testid="form-submit"
            autoComplete="off"
          >
            <IonItemGroup className='form-group input-label-box position-relative'>
              <IonRow className="grid-item-spacing">
                <Input
                  containerStyle={error
                    ? 'error-border input-box border borderRadius4 top0 otpinput w-lg-100 w-75 m-auto'
                    : 'input-box border borderRadius4 top0 otpinput w-lg-100 w-75 m-auto'}
                  maxlength={6}
                  keyboardType={'numeric'}
                  inputmode='numeric'
                  autoFocus={true}
                  data-testid="MobileNo"
                  placeholder=""
                  onkeydown={validateIsNumericInput}
                  refCallback={refCallback(inputRef)}
                />
              </IonRow>
              {error ? <p className='error pt-1 d-lg-block d-flex ion-justify-content-center w-100'>{t('signuprecommendation.text3')}</p> : ''}
            </IonItemGroup>
            <IonItemGroup className="form-group ion-margin-top ion-text-center input-label-box">
              <IonCardSubtitle
                color="textSecondary"
                className="otp-text ion-text-center"
              >
                {resendButtonDisabledTime > 0
                  ? (
                    <TimeText resendButtonDisabledTime={resendButtonDisabledTime} />
                  )
                  : (
                    <span> {t('appproperties.text356a')} {' '}
                      <IonRouterLink onClick={onResendOtpButtonPress}>
                        <a>{t('appproperties.text356b')}</a>
                      </IonRouterLink>
                    </span>
                  )}
              </IonCardSubtitle>
              <IonCardSubtitle
                color="textSecondary"
                className="ion-margin-top otp-text ion-text-center enter-wrong mt-lg-3 mt-2"
              >
                <IonRouterLink onClick={wrongNumber}>
                  <a> {t('appproperties.text355')}</a>
                </IonRouterLink>
              </IonCardSubtitle>
            </IonItemGroup>
            <IonItemGroup className="form-group ion-margin-top ">
              <IonButton
                type="submit"
                size='large'
                disabled={verifyButton}
                className="ion-button login-button "
              >
                {t('appproperties.text357')}
                {verifyButton
                  ? <span className="loader" id="loader-2">
                    <span></span>
                    <span></span>
                    <span></span>
                  </span>
                  : ''
                }
              </IonButton>
            </IonItemGroup>
          </form>
        </div>
      </div>
    </div>
  );
};
export default VerifyOtp;
