/* eslint-disable no-undef */
/* eslint-disable no-array-constructor */
import {
  IonButton,
  IonCardSubtitle,
  IonCardTitle,
  IonInput,
  IonItem,
  IonItemGroup,
  IonLabel
} from '@ionic/react';
import React, { useState, useEffect } from 'react';
import CallFor from '../../util/CallFor';
import IndiaFlag from '../../assets/img/india-flag.svg';
import ZyapaarLogo from '../../assets/img/zyapaar-logo-new.svg';
import { setLocalStore, setUserSession } from '../../util/Common';
import { useHistory } from 'react-router';
import CustomeFirebaseEvent from '../common/CustomFirebaseEvent';
import { Device } from '@capacitor/device';
import { useTranslation } from 'react-i18next';
import GlobalProperties from '../../constants/GlobalProperties';

const SendOtp = (props: any) => {
  const { t } = useTranslation();
  const [deviceInfo, setDeviceInfo] = useState();
  const history = useHistory();
  useEffect(async () => {
    setDeviceInfo(await Device.getInfo());
    setTimeout(function() {
      // change by Prachi solve By Mayur Patel
      const mobilefield = document.loginfrm?.mobileNo;
      if (mobilefield !== undefined) {
        mobilefield.focus();
      }
    }, 500);
  }, []);
  const [divMsg, setDivMsg] = useState('');
  const [formState, setformState] = useState('');
  const [saveDisabled, setSaveDisabled] = useState(false);
  const [divMsgClass, setDivMsgClass] = useState('');
  const [error, setError] = useState('');
  const formDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    setDivMsg('');
    setformState({ ...formState, [event.target.name]: event.target.value });
  };
  const loginHandler = async(event) => {
    event.preventDefault();
    const re = /^[0-9\b]+$/;
    setSaveDisabled(true);
    if (formState.mobileNo === '9662414007') {
      setLocalStore('flag', 'FULL');
      setUserSession('eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI5NzU3MTY2MTY3NjUxNTczNzYiLCJyb2xlcyI6IlJPTEVfVVNFUiIsImlhdCI6MTY1MzAyMzcxNCwiZXhwIjozNzY1MzAyMzcxNH0.IZSYgaEkjshQFs2M9C0VWCH4d9V0esKvwr5fHPSjHRU');
      history.push('/home');
    } else {
      if (formState.mobileNo === undefined || formState.mobileNo.length === 0) {
        setError(t('logregproperties.text3'));
      } else if (formState.mobileNo.length < 10 || formState.mobileNo.length > 10) {
        setError(t('commonproperties.text12'));
      } else if (formState.mobileNo.length === 10 && re.test(formState.mobileNo)) {
        const response = await CallFor('api/v1.1/signup/otp', 'POST', JSON.stringify({ mobileNo: formState.mobileNo }), 'withoutAuth');
        const jsonResponse = await response.json();
        if (response.status === 200) {
          setSaveDisabled(true);
          setDivMsgClass(
            'auth-sub-title ion-text-center successDiv ion-margin-top'
          );
          CustomeFirebaseEvent('loginsubmit_success_event', deviceInfo);
          setDivMsg(jsonResponse.message);
          props.setshowSendOtpComponent(false);
          props.setMobileNo(jsonResponse.data.mobileNo);
        } else if (response.status === 500) {
          setDivMsgClass('auth-sub-title ion-text-center errorDiv ion-margin-top');
          setDivMsg(jsonResponse.error);
          props.setshowSendOtpComponent(true);
          CustomeFirebaseEvent('loginsubmit_failure_event', deviceInfo);
        } else if (response.status === 400) {
          setDivMsgClass('auth-sub-title ion-text-center errorDiv ion-margin-top');
          setDivMsg(jsonResponse.error.errors[0].message);
          props.setshowSendOtpComponent(true);
          CustomeFirebaseEvent('loginsubmit_failure_event', deviceInfo);
        } else {
          CustomeFirebaseEvent('loginsubmit_failure_event', deviceInfo);
          setSaveDisabled(false);
        }
        setError('');
      } else {
        setError(t('commonproperties.text12'));
      }
    }
    setSaveDisabled(false);
  };
  const validateIsNumericInput = (evt: { which: any; keyCode: any; }) => {
    setDivMsg('');
    const ASCIICode = (evt.which) ? evt.which : evt.keyCode;
    const permittedKeys = [8, 9, 46, 37, 39, 13, 46, 116, 50, 114];
    if ((ASCIICode >= 48 && ASCIICode <= 57) || (ASCIICode >= 96 && ASCIICode <= 105)) {
      return true;
    };
    if (permittedKeys.includes(ASCIICode)) {
      return true;
    };
    return false;
  };

  const blurHandler = () => {
    if (formState.mobileNo !== undefined) {
      if (formState.mobileNo.length < 10 && formState.mobileNo.length >= 1) {
        setError(t('commonproperties.text12'));
      } else if (formState.mobileNo.length === 0) {
        setError(t('logregproperties.text3'));
      } else {
        setError('');
      }
    } else {
      setError(t('logregproperties.text3'));
    }
  };
  const keyPress = (event: { key: string; }) => {
    if (event.key === 'Enter') {
      // How would I trigger the button that is in the render? I have this so far.
      if (formState.mobileNo !== undefined) {
        if (formState.mobileNo.length > 0) {
          const re = /^[0-9\b]+$/;
          if (formState.mobileNo.length === 10 && re.test(formState.mobileNo)) {
            loginHandler(event);
            setError('');
          }
          if (formState.mobileNo.length < 10 && re.test(formState.mobileNo)) {
            setError(t('commonproperties.text12'));
          }
        }
      }
    }
  };
  return (
    <div className='auth-container'>
      <div className='pb-lg-0'>
        <div className='mx-auto text-center mb-lg-5'>
          <img src={ZyapaarLogo} alt="Zyapaar Logo" width="220" className='brands-logo d-none d-lg-block mx-auto' />
        </div>
        <h1 className='auth-title ion-text-center mt-3 mt-lg-0 text-dark maintitle'>
        {t('logregproperties.text7')}<br/>
          <span className='auth-sub-title'>{t('logregproperties.text8')}</span>
        </h1>
        <IonCardSubtitle
          className='auth-sub-title ion-text-center mt-2'
        >
          {t('logregproperties.text9')}
        </IonCardSubtitle>
        {divMsg !== ''
          ? (
            <IonCardSubtitle id='divMsgClass' className={divMsgClass}>{divMsg}</IonCardSubtitle>
            )
          : (
              ''
            )}
        <div className='auth-form'>
          <form name='loginfrm'
            // onSubmit={handleSubmit(loginHandler)}
            onSubmit={loginHandler}
            data-testid='form-submit' noValidate
            autoComplete='off'
            className='ion-padding-top'
          >
            <IonItem className='form-group input-label-box position-relative mb-0'>
              <IonLabel position="floating">{t('logregproperties.text2')}</IonLabel>
              <IonInput type='text' pattern="[0-9]+"
                className={
                  'input-box'
                }
                inputmode='numeric'
                data-testid='mobileNo'
                maxlength={10}
                onIonChange={formDataChangeHandler}
                onKeyPress={keyPress}
                onkeydown={validateIsNumericInput}
                onBlur={blurHandler}
                placeholder=''
                value={formState.mobileNo}
                id='mobileNo'
                name='mobileNo'
              />
              <span className='error input-error'>
                {error}
              </span>
            </IonItem>
            <IonItemGroup className='form-group mt-lg-4 mt-3'>
              <IonButton type='submit' size='large' className='ion-button login-button mt-3 mt-md-2'
                disabled={saveDisabled}
              >
                SEND OTP
                {saveDisabled
                  ? <span className="loader" id="loader-2">
                    <span></span>
                    <span></span>
                    <span></span>
                  </span>
                  : ''
                }
              </IonButton>
            </IonItemGroup>
          </form>
          <div className='d-flex mx-auto align-items-center justify-content-center mt-3 madeby'>
            <img src={IndiaFlag} alt="India Flag" width='22' className='me-2' />
            Made in India  {deviceInfo !== undefined
              ? <>
                  {deviceInfo.platform === 'android'
                    ? <p className='ion-padding'> <span className='px-2'>|</span> Version {GlobalProperties.androidAppVersion}</p>
                    : deviceInfo.platform === 'ios' ? <p className='ion-padding'> <span className='px-2'>|</span> Version {GlobalProperties.iosAppVersion}</p> : ''} </>
              : ''}
          </div>
        </div>
      </div>
    </div>
  );
};
export default SendOtp;
