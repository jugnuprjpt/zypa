import { IonButton, IonCard, IonCardContent, IonCol, IonRow, IonSlide, IonSlides } from '@ionic/react';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router';

import Slider1 from '../../assets/img/get-started/slider-1.svg';
import Slider2 from '../../assets/img/get-started/slider-2.svg';
import Slider3 from '../../assets/img/get-started/slider-3.svg';

const slideOpts = {
  initialSlide: 0,
  slidesPerView: 1,
  getActiveIndex: 2,
  speed: 400,
  pauseOnMouseEnter: true,
  autoplay: true,
  ABC: true
};
const GetStartScreen = () => {
    const { t } = useTranslation();
  const history = useHistory();
  const [btnhide, setbtnhide] = useState(false);
  const LastSlider = (event: { target: { swiper: { isEnd: any; }; }; }) => {
    if (event.target.swiper.isEnd) {
      setbtnhide(true);
    } else {
      setbtnhide(false);
    }
  };
  return (
        <IonRow className='getstarted position-relative'>
            <IonCol>
                <IonSlides
                    pager={true}
                    options={slideOpts}
                    autoplay={{
                        delay: 3500,
                        pauseOnMouseEnter: true
                    }}
                    className='d-flex ion-justify-content-center ion-align-items-center h-100'
                    onIonSlideWillChange={LastSlider}

                >
                    <IonSlide className='flex-column'>
                        <img src={Slider1} alt="Login Slider" />
                        <div className='slider-text mt-4 text-white'>
                            <h2 className='mb-3 '>Zyada Network</h2>
                            <p>Connect with your industry professionals and entrepreneurs across India.</p>
                        </div>
                    </IonSlide>
                    <IonSlide className='flex-column'>
                        <img src={Slider2} alt="Login Slider" />
                        <div className='slider-text mt-4 text-white'>
                            <h2 className='mb-3'>Zyada Leads</h2>
                            <p>Showcase and promote your products and services to a larger audience.</p>
                        </div>
                    </IonSlide>
                    <IonSlide className='flex-column lastslide'>
                        <img src={Slider3} alt="Login Slider" />
                        <div className='slider-text mt-4 text-white'>
                            <h2 className='mb-3'>Zyada Business</h2>
                            <p>Grow your business with larger audiences, bigger market presence and specific buyers and seller requirements.</p>
                        </div>
                        <IonButton
                            type='button'
                            size='large'
                            onClick={() => history.push('/login')}
                            className='btn-skip position-absolute btnstarted ion-button-color pe-0 d-block w-100'
                        >
                            Get started
                        </IonButton>
                    </IonSlide>
                </IonSlides>
                {!btnhide
                  ? <IonButton
                        type='button'
                        onClick={() => history.push('/login')}
                        className='btn-skip position-absolute ion-button-color pe-0'
                    >
                        {t('appproperties.text348')}
                    </IonButton>
                  : ''}
            </IonCol>
            <ul className="circles position-absolute overflow-hidden d-block d-md-none">
                <li /><li /><li /><li /><li /><li /><li /><li /><li /><li />
            </ul>
        </IonRow>
  );
};
export default GetStartScreen;
