import React from 'react';
import { useLocation } from 'react-router';
import { setUserSession } from '../../util/Common';

const SocialRedication = () => {
  const localtion = useLocation();
  const queryParams = new URLSearchParams(localtion.search);

  setUserSession(queryParams.get('token'));
  window.close();

  return (
    <h1></h1>
  );
};

export default SocialRedication;
