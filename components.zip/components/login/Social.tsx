import { IonButton, IonItemGroup } from '@ionic/react';
import React from 'react';
import { Browser } from '@capacitor/browser';
import facebook from '../../assets/img/icons/facebook.svg';
import google from '../../assets/img/icons/google.svg';
import ios from '../../assets/img/icons/ios.svg';
import linkedin from '../../assets/img/icons/linkedin.svg';

const Social = () => {
  const handleClick = (page:string) => {
    Browser.open({ url: 'https://chirag.com:7001/oauth2/authorize/' + page });
  };

  return (
    <IonItemGroup className="MuiFormGroup-root ion-margin-top ion-text-center">
      <IonButton onClick={() => handleClick('facebook')} data-testid="facebook" className="social-media-btns fb-btn">
        <img src={facebook} alt="facebook" />
      </IonButton>
      <IonButton onClick={() => handleClick('google')} data-testid="google" className="social-media-btns google-btn" >
      <img src={google} alt="google" />
      </IonButton>
      <IonButton onClick={() => handleClick('apple')} data-testid="apple" className="social-media-btns ios-btn">
        <img src={ios} alt="ios" />
      </IonButton>
      <IonButton onClick={() => handleClick('linkedin')} data-testid="linkedin" className="social-media-btns linkedin-btn">
        <img src={linkedin} alt="Linkedin" />
      </IonButton>
    </IonItemGroup>
  );
};
export default Social;
