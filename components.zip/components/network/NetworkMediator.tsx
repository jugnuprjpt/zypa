import { useHistory, useParams } from 'react-router';

const NetworkMediator = () => {
  const { urlName, urlName2, id } = useParams();
  const history = useHistory();
  let url ='';
  if(urlName2=== 'My Network'){
    url ='mynetwork';
  }
  history.push('/' + urlName + '/' + url + '/' + id);
  return (
    ''
  );
};
export default NetworkMediator;
