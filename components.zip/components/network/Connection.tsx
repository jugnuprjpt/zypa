/* eslint-disable multiline-ternary */
/* eslint-disable react/jsx-key */
import {
  IonCard,
  IonCol,
  IonContent,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonLabel,
  IonModal,
  IonRow,
  useIonViewWillEnter
} from '@ionic/react';
import { arrowBack, caretForward, close } from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router';
import CallFor from '../../util/CallFor';
import ActivityCard from '../common/ActivityCard';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import ConnectionCard from '../common/ConnectionCard';
import Footer from '../Layout/Footer';
import SkeletonComonViewAll from '../common/skeleton/SkeletonComonViewAll';
import ToastCommon from '../common/ToastCommon';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import CommonGridList from '../common/CommonGridList';
import { useTranslation } from 'react-i18next';
const Connection = () => {
  const { t } = useTranslation();
  const [removeConfirmModel, setRemoveConfirmModel] = useState(false);
  const { networkName, networkId } = useParams();
  const [teamMember, setTeamMember] = useState<object[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [count, setCount] = useState(0);
  const [scrollData, setScrollData] = useState<object[]>([]);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [paramNetworkId, setParamNetworkId] = useState(networkId);
  const [paramNetworkName, setParamNetworkName] = useState('');
  const [classMobile, setClassMobile] = useState(true);
  const [loading, setLoading] = useState(false);
  const history = useHistory();
  const [showToast, setShowToast] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [removeConnectionModalData, setRemoveConnectionModalData] = useState({});
  const [industryloading, setIndustryLoading] = useState(true);
  const [connectionIndustry, setConnectionIndustry] = useState<object[]>([]);
  useEffect(() => {
    if(networkName ==='mynetwork'){
      setParamNetworkName(t('appproperties.text4'));
    } else {
      setParamNetworkName(networkName);
    }
    getTeamMemberList(paramNetworkId);
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
    getPageListOnScroll();
    getnetworkCount();
    getIndustryData();
  }, []);
  const network = [
    {
      id: 'ALL',
      name: (t('appproperties.text4'))
    }
  ];
  let removeConfirmMessage = '';
  { removeConnectionModalData.name !== undefined
    ? removeConfirmMessage = <IonLabel>{t('appproperties.text9a')} <strong>{removeConnectionModalData.name}</strong>{t('appproperties.text9b')}</IonLabel>
    : ''; }
  const getTeamMemberList = async(networkId) => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/connection/list/' + networkId,
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setTeamMember(json1Response.data.content);
        if (scrollData.length > 0) {
          setScrollData(json1Response.data.content);
          setCount(1);
        }
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };

  const getPageListOnScroll = async() => {
    const response = await CallFor(
      'api/v1.1/connection/list/' + networkId,
      'POST',
      '{"page": ' + count + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      setCount(count + 1);
      if (json1Response.data.content !== null && json1Response.data.content.length > 0) {
        setScrollData([...scrollData, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  useIonViewWillEnter(async() => {
    getPageListOnScroll();
  });
  function searchNext(ev: any) {
    setTimeout(() => {
      getPageListOnScroll();
      ev.target.complete();
    }, 500);
  }
  const viewPaginaction = () => {
    setShowModal(true);
    getPageListOnScroll();
    //  setCount(1);
  };

  const closemodel = () => {
    setCount(1);
    setShowModal(false);
    setScrollData(teamMember);
    setInfiniteDisabled(false);
  };
  const backBtn = () => {
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
    history.goBack();
  };
  if (classMobile) {
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  } else {
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  }
  const [networkCount, setNetworkCount] = useState('');
  const getnetworkCount = async() => {
    const response = await CallFor(
      'api/v1.1/users/connection/count',
      'get',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data !== null) {
        setNetworkCount(json1Response.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  const removeModalConnectionBtnHandler = async() => {
    const response = await CallFor(
      'api/v1.1/users/connections/' + removeConnectionModalData.id + '/remove',
      'POST',
      '{ "message":"", "id":"' + removeConnectionModalData.id + '"}',
      'Auth'
    );
    if (response.status === 200) {
      setTeamMember(teamMember.filter((item) => item.id !== removeConnectionModalData.id));
      setScrollData(scrollData.filter((item) => item.id !== removeConnectionModalData.id));
      setNetworkCount(networkCount - 1);
      setShowToastMsg(t('toastmessages.toast16'));
      setShowToast(true);
      getIndustryData();
    } else if (response.status === 404) {
      const json1Response = await response.json();
      setShowToastMsg(json1Response.error.message);
      setShowToast(true);
    }
  };
  const getIndustryData = async() => {
    setIndustryLoading(true);
    const response = await CallFor(
      'api/v1.1/users/industries',
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data !== null) {
        setConnectionIndustry(json1Response.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setIndustryLoading(false);
  };
  return (
    <><link rel="canonical" href={window.location.href}></link><>
      <IonRow className="plane-bg connections">
        <IonRow className="container">
          <div className={classMobile ? 'showpage row full-width-row main-page-content-row remove-connections-border' : 'row full-width-row main-page-content-row remove-connections-border'}>
            <IonCol
              size-lg="4"
              size-md="12"
              className="left-col col-mobile-none ion-no-padding connection-sapce"
            >
              <div className='sidebar-main'>
              <ActivityCard
                header={t('appproperties.text3')}
                mapData={network}
                icon={caretForward}
                fieldLink="/networkMediator/connection"
                sublink={4}
                className="sidebar-pages pages-scroll"
                heightlightClass="IsactiveConnection"
                paramNetworkName={paramNetworkName}
                noDataFound={t('nodatafound.text12')}
                loading={loading}
                networkCount={networkCount}
                />
              <ConnectionCard
                  setParamNetworkId ={setParamNetworkId}
                  setParamNetworkName= {setParamNetworkName}
                  getTeamMemberList={getTeamMemberList}
                  setClassMobile={setClassMobile}
                  classMobile={classMobile}
                  paramNetworkName={paramNetworkName}
                  industryloading= {industryloading}
                  connectionIndustry={connectionIndustry}
              />
              {/* <ConnectionScrollCard setConClassMobile ={setConClassMobile} conClassMobile={conClassMobile}/> */}
              <Footer/>
              </div>
            </IonCol>
            <IonCol
              size-lg="8"
              size-md="12"
              size-xs="12"
              className="right-col ion-no-padding ion-padding-top "
            >
              <div className='mobile-overlay-screen with-sb-box'>
               {/* <div className='mobile-back-screen show-mobile'></div> */}
               <div className= 'mobile-back-screen show-mobile title-back ion-margin-bottom back-with-heading'>
                <IonIcon className='icon-mobile' icon={arrowBack} onClick={backBtn}></IonIcon> <h3>  {paramNetworkName}</h3>
              </div>
              <h3 className='dn-mobile'>{paramNetworkName}</h3>
              <IonCard className="profile-details left-cards ion-no-margin ion-margin-bottom ">
                {loading ? <SkeletonComonViewAll column={4} sizeMd={12} sizeXs={12} name={true} title={false} mutual={true} designation={true} request={false} distription={false} link={false} /> : teamMember.length > 0 ? (
                  <>
                  {teamMember.length >= 8
                    ? <IonRow className="ion-padding-start ion-padding-top viewall-button dn-mobile">
                      <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
                      {t('commonproperties.text3')}
                      </div>
                    </IonRow>
                    : ''}
                    <div className='mobile-spaces'>
                      <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom mobile-pd-8 mt-8 member-listing">
                        {teamMember.map((detail, i) => (
                          // eslint-disable-next-line react/jsx-key
                          <CommonGridList key={i} id={detail.id} defultImage={userProfile} img={detail.img} name={detail.name} subString={detail.designation}
                            subString2={detail.request} dots={true} redirectLink='profile' dotsEventLable1={t('appproperties.text5')}
                            setRemoveConfirmModel ={setRemoveConfirmModel}
                            setRemoveConnectionModalData = {setRemoveConnectionModalData} isAdmin ={true} />
                        ))}
                      </IonRow>
                      {teamMember.length >= 8
                        ? <div className='right-col-cn gup-btn-action view-all-mobile mobile-pd-8 ion-padding-bottom mb-5 pb-4 pb-lg-0 mb-xl-0'>
                          <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
                          {t('commonproperties.text3')}
                          </div>
                        </div>
                        : ''}
                    </div>
                  </>
                ) : (
                  <IonRow className="ion-padding-top ion-padding-bottom ion-padding-start">
                   <p className='ion-padding-start ps-0 text-center w-100'>{t('nodatafound.text12')}</p>
                  </IonRow>
                )}
              </IonCard>
              </div>
            </IonCol>
          </div>
        </IonRow>
      </IonRow>
      <IonModal isOpen={showModal} cssClass="team-list-modal connections" onDidDismiss={() => closemodel()}>
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">{t('commonproperties.text3')}</IonLabel>
            <div
             onClick={closemodel}
              className="close ion-no-padding"
            >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 cursor-pointer"
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <IonContent>
        <div className="modal-body">
          <div className="no-footer">
          <IonRow className="ion-padding-start ion-padding-end  ion-padding-bottom member-listing">
          { scrollData.length > 0
            ? (
                scrollData.map((detail, i) => (
                  <CommonGridList key={i} id={detail.id} defultImage={userProfile} img={detail.img} name={detail.name} subString={detail.designation}
                  subString2={detail.request} dots={true} redirectLink='profile' dotsEventLable1={t('appproperties.text5')}
                  setRemoveConfirmModel ={setRemoveConfirmModel}
                  setRemoveConnectionModalData = {setRemoveConnectionModalData} isAdmin ={true} />
                ))) : loading }
            </IonRow>
            <div className='d-flex ion-justify-content-center'>
              <IonInfiniteScroll
                onIonInfinite={searchNext}
                threshold="100px"
                disabled={isInfiniteDisabled}
              >
                <IonInfiniteScrollContent
                  loadingSpinner="circular"
                  loadingText={t('appproperties.text215')}
                ></IonInfiniteScrollContent>
              </IonInfiniteScroll>
            </div>
          </div>
          </div>
        </IonContent>
      </IonModal>
    </>
    {removeConfirmModel
      ? <ConfirmModelCommon
      header={t('appproperties.text5')}
      message={removeConfirmMessage}
      btn1={t('appproperties.text11')}
      btn2={t('appproperties.text10')}
      confirmModel={removeConfirmModel}
      setConfirmModel={setRemoveConfirmModel}
      deleteBtnHandler={removeModalConnectionBtnHandler}/>
      : ''}
    <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000}/>
    </>
  );
};
export default Connection;
