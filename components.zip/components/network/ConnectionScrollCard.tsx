import {
  IonCard,
  IonHeader,
  IonRow,
  IonList,
  IonIcon,
  IonBadge
} from '@ionic/react';
import { arrowBack, chevronForward } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router';
import SkeletonConnectionList from '../common/skeleton/SkeletonConnectionList';

const ConnectionScrollCard = (props) => {
  const { t } = useTranslation();
  const history = useHistory();

  const detaillink = (name, id) => {
    history.push('/connection/' + name + '/' + id);
  };

  const addMobileCss = () => {
    props.setConClassMobile(true);
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  };

  const removeMobileCss = () => {
    props.setConClassMobile(false);
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  };
  return (
    <>
      <IonCard className={props.conClassMobile ? 'showpage sdb-box profile-details left-cards no-shadow sidebar-pages data-saprate remove-connections-border' : 'sdb-box profile-details left-cards no-shadow sidebar-pages data-saprater remove-connections-border' }>
        <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between dn-mobile">
          <p className="ion-align-self-start">{t('appproperties.text8')}</p>
        </IonHeader>
        <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between show-mobile head-angle" onClick ={addMobileCss}>
          <p className="ion-align-self-start">{t('appproperties.text8')}</p>
          <IonIcon className='icon-mobile' icon={chevronForward}></IonIcon>
        </IonHeader>
        <div className='mobile-overlay-screen  h-300 overflow-y'>
          <div className= 'mobile-back-screen show-mobile title-back  back-with-heading position-sticky'>
            <IonIcon className='icon-mobile' icon={arrowBack} onClick ={removeMobileCss}></IonIcon> <h3> {t('appproperties.text8')}</h3>
          </div>
          <IonRow className='connection-sapce'>
            <IonList lines="none" className="full-width-row mb-4 pb-5 mb-lg-0 pb-lg-0">
              {props.industryloading
                ? <SkeletonConnectionList column='5'/>
                : props.connectionIndustry.length > 0
                  ? props.connectionIndustry.map((detail) => {
                    return (
                      <>
                        <IonRow
                          onClick={() => detaillink(detail.name, detail.id)}
                          className='border-0'
                        >
                          <IonRow className="cursor-pointer item d-flex align-items-center justify-content-between">
                            <div className="myprofile-feeds ion-no-paddingc w-85">
                              <IonRow className="display-grid">
                                {detail.name}
                              </IonRow>
                            </div>
                            <IonBadge className='custom-bage'>
                                {detail.count}
                            </IonBadge>
                          </IonRow>
                        </IonRow>
                      </>
                    );
                  })
                  : <p className='ion-padding-start position-absolute pt-1 text-center w-100 ps-0'>{t('nodatafound.text13')}</p>}
            </IonList>
          </IonRow>
        </div>
      </IonCard>
    </>
  );
};
export default ConnectionScrollCard;
