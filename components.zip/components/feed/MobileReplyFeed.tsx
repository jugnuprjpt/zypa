import {
  IonButton,
  IonCol,
  IonContent,
  IonIcon,
  IonModal,
  IonRow
} from '@ionic/react';
import React from 'react';
import { arrowBack } from 'ionicons/icons';
import MobileReplyBoxComon from './MobileReplyBoxComon';
import { useDispatch } from 'react-redux';
const MobileReplyFeed = (props) => {
  const dispatch = useDispatch();
  const replyBoxHide = () => {
    props.setReplyMobileViewModel(false);
    dispatch({
      type: 'reply_btn_feedsData_new',
      showReplyBox: false,
      index: props.feedKey,
      commentIndex: props.commentKey
    });
  };
  return (
    <>
      <IonModal
        isOpen={props.replyMobileViewModel}
        onDidDismiss={replyBoxHide}
        cssClass="postCommentModal"
        id = 'reply-modal'
      >
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          <IonButton
            fill="clear"
            onClick={replyBoxHide}
            className="close link-btn-tx ion-no-padding ion-no-margin pt-0"
          >
            <IonIcon
              icon={arrowBack}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </IonButton>
        </IonRow>
        <IonContent>
          <IonRow className="plane-bg">
            <IonRow className="container">
              <div className="row full-width-row main-page-content-row">
                <IonCol
                  size-lg="12"
                  size-md="12"
                  size-xs="12"
                  className="right-col"
                >
                  {props.commentobj != null
                    ? (
                    <MobileReplyBoxComon
                    commentObj={props.commentobj}
                    commentKey={props.commentKey}
                      feedKey={props.feedKey}
                      opId={props.opId}
                      postUserId={props.postUserId}
                      commentInput={true}
                    />
                      )
                    : (
                        ''
                      )}
                </IonCol>
              </div>
            </IonRow>
          </IonRow>
        </IonContent>
      </IonModal>
    </>
  );
};
export default MobileReplyFeed;
