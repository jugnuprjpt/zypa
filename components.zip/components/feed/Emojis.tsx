import { IonButton, IonRow } from '@ionic/react';
import React, { useState } from 'react';
import Like from '../../assets/img/emojis/like.svg';
import Celebrate from '../../assets/img/emojis/celebration.svg';
import ShakeHand from '../../assets/img/emojis/shakehands.svg';
import Interest from '../../assets/img/emojis/interest.svg';
import Supports from '../../assets/img/emojis/support.svg';
import ThumbLikeIcon from '../../assets/img/like-icon-light.svg';
import callFor from '../../util/CallFor';
import { useDispatch, useSelector } from 'react-redux';
import { getFeedData } from '../../Redux/reducers/feeds';
import { useTranslation } from 'react-i18next';
import NotAuthorizeModal from '../common/NotAuthorizeModal';

const Emojis = (props: any) => {
  const { t } = useTranslation();
  const [loginModal, setLoginModal] = useState(false);
  const dispatch = useDispatch();
  const uniqueClassid = props.commentId === undefined ? props.id + '_' + Math.random() : props.commentId + '_' + Math.random();
  const getFeedDatas = useSelector(getFeedData);
  const reactionHandler = async(reaction: string | number, id: string) => {
    if (props.profileDetail.entityId !== undefined && props.profileDetail.entityId !== null) {
      let reactions = '';
      document.getElementById('removeHover_' + uniqueClassid).classList.add('removeHover');
      if (reaction === 1) {
        reactions = 'LIKE';
      } else if (reaction === 2) {
        reactions = 'CELEBRATE';
      } else if (reaction === 3) {
        reactions = 'INTEREST';
      } else if (reaction === 4) {
        reactions = 'SHAKEHANDS';
      } else if (reaction === 5) {
        reactions = 'SUPPORT';
      }
      let data = '';
      let oldReaction = 'NONE';
      if (props.reaction !== null) {
        if (props.reaction === '1') {
          oldReaction = 'LIKE';
        } else if (props.reaction === '2') {
          oldReaction = 'CELEBRATE';
        } else if (props.reaction === '3') {
          oldReaction = 'INTEREST';
        } else if (props.reaction === '4') {
          oldReaction = 'SHAKEHANDS';
        } else if (props.reaction === '5') {
          oldReaction = 'SUPPORT';
        }
        data = '{"newReaction": "' + reactions + '", "oldReaction": "' + oldReaction + '", "id": "0","postUserId": "' + props.postUserId + '"}';
      } else {
        data = '{"newReaction": "' + reactions + '","postUserId": "' + props.postUserId + '","oldReaction": "NONE"}';
      }
      if (props.type === 'comment') {
        if (props.reaction === null) {
          dispatch({
            type: 'add_comment_reactionCount',
            reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reactionCount + 1,
            index: props.feedIndex,
            commentIndex: props.commentIndex
          });
        } else {
          if (oldReaction === 'NONE') {
            dispatch({
              type: 'add_comment_reactionCount',
              reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reactionCount + 1,
              index: props.feedIndex,
              commentIndex: props.commentIndex
            });
          }
        }
        dispatch({
          type: 'add_comment_reaction',
          reaction: reaction,
          index: props.feedIndex,
          commentIndex: props.commentIndex
        });
      // dispatch({
      //   type: 'add_comment_reactionId',
      //   reactionId: jsonResponse.data,
      //   index: props.feedIndex,
      //   commentIndex: props.commentIndex
      // });
      } else if (props.type === 'reply') {
        if (props.reaction === null) {
          dispatch({
            type: 'add_reply_reactionCount',
            reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reply[props.replyIndex].reactionCount + 1,
            index: props.feedIndex,
            commentIndex: props.commentIndex,
            replyIndex: props.replyIndex
          });
        } else {
          if (oldReaction === 'NONE') {
            dispatch({
              type: 'add_reply_reactionCount',
              reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reply[props.replyIndex].reactionCount + 1,
              index: props.feedIndex,
              commentIndex: props.commentIndex,
              replyIndex: props.replyIndex
            });
          }
        }
        dispatch({
          type: 'add_reply_reaction',
          reaction: reaction,
          index: props.feedIndex,
          commentIndex: props.commentIndex,
          replyIndex: props.replyIndex
        });
      // dispatch({
      //   type: 'add_reply_reactionId',
      //   reactionId: jsonResponse.data,
      //   index: props.feedIndex,
      //   commentIndex: props.commentIndex,
      //   replyIndex: props.replyIndex
      // });
      } else {
        if (props.reaction === null) {
          dispatch({
            type: 'add_post_reactionCount',
            reactionCount: getFeedDatas[props.feedIndex].reactionCount + 1,
            index: props.feedIndex
          });
        } else {
          if (oldReaction === 'NONE') {
            dispatch({
              type: 'add_post_reactionCount',
              reactionCount: getFeedDatas[props.feedIndex].reactionCount + 1,
              index: props.feedIndex
            });
          }
        }
        dispatch({
          type: 'add_post_reaction',
          reaction: reaction,
          index: props.feedIndex
        });
      // dispatch({
      //   type: 'add_post_reactionId',
      //   reactionId: jsonResponse.data,
      //   index: props.feedIndex
      // });
      }
      if (oldReaction !== reactions) {
        let url = 'api/v1/post/' + id + '/reaction';
        if (props.type === 'comment' || props.type === 'reply') {
          url = 'api/v1/comment/' + id + '/' + props.commentId + '/reaction';
        }
        const response1 = await callFor(url, 'POST', data, 'Auth');
        if (response1.status === 200) {
        // const jsonResponse = await response1.json();
          console.log('');
        } else {
          if (props.type === 'comment') {
            if (props.reaction === null) {
              dispatch({
                type: 'add_comment_reactionCount',
                reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reactionCount,
                index: props.feedIndex,
                commentIndex: props.commentIndex
              });
            } else {
              if (oldReaction === 'NONE') {
                dispatch({
                  type: 'add_comment_reactionCount',
                  reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reactionCount,
                  index: props.feedIndex,
                  commentIndex: props.commentIndex
                });
              }
            }
            dispatch({
              type: 'add_comment_reaction',
              reaction: props.reaction,
              index: props.feedIndex,
              commentIndex: props.commentIndex
            });
          // dispatch({
          //   type: 'add_comment_reactionId',
          //   reactionId: jsonResponse.data,
          //   index: props.feedIndex,
          //   commentIndex: props.commentIndex
          // });
          } else if (props.type === 'reply') {
            if (props.reaction === null) {
              dispatch({
                type: 'add_reply_reactionCount',
                reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reply[props.replyIndex].reactionCount,
                index: props.feedIndex,
                commentIndex: props.commentIndex,
                replyIndex: props.replyIndex
              });
            } else {
              if (oldReaction === 'NONE') {
                dispatch({
                  type: 'add_reply_reactionCount',
                  reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reply[props.replyIndex].reactionCount,
                  index: props.feedIndex,
                  commentIndex: props.commentIndex,
                  replyIndex: props.replyIndex
                });
              }
            }
            dispatch({
              type: 'add_reply_reaction',
              reaction: props.reaction,
              index: props.feedIndex,
              commentIndex: props.commentIndex,
              replyIndex: props.replyIndex
            });
          // dispatch({
          //   type: 'add_reply_reactionId',
          //   reactionId: jsonResponse.data,
          //   index: props.feedIndex,
          //   commentIndex: props.commentIndex,
          //   replyIndex: props.replyIndex
          // });
          } else {
            if (props.reaction === null) {
              dispatch({
                type: 'add_post_reactionCount',
                reactionCount: getFeedDatas[props.feedIndex].reactionCount,
                index: props.feedIndex
              });
            } else {
              if (oldReaction === 'NONE') {
                dispatch({
                  type: 'add_post_reactionCount',
                  reactionCount: getFeedDatas[props.feedIndex].reactionCount,
                  index: props.feedIndex
                });
              }
            }
            dispatch({
              type: 'add_post_reaction',
              reaction: props.reaction,
              index: props.feedIndex
            });
          // dispatch({
          //   type: 'add_post_reactionId',
          //   reactionId: jsonResponse.data,
          //   index: props.feedIndex
          // });
          };
        }
      }
    } else {
      // history.push('/addnewcompany');
      setLoginModal(true);
    }
  };
  const unlikeBtn = async(id) => {
    let data = '';
    let oldReaction = 'NONE';
    if (props.reaction !== null) {
      if (props.reaction === '1') {
        oldReaction = 'LIKE';
      } else if (props.reaction === '2') {
        oldReaction = 'CELEBRATE';
      } else if (props.reaction === '3') {
        oldReaction = 'INTEREST';
      } else if (props.reaction === '4') {
        oldReaction = 'SHAKEHANDS';
      } else if (props.reaction === '5') {
        oldReaction = 'SUPPORT';
      }
      data = '{"newReaction": "NONE", "oldReaction": "' + oldReaction + '", "id": "0","postUserId": "' + props.postUserId + '"}';
      let url = 'api/v1/post/' + id + '/reaction';
      if (props.type === 'comment' || props.type === 'reply') {
        url = 'api/v1/comment/' + id + '/' + props.commentId + '/reaction';
      }
      if (oldReaction !== 'NONE') {
        const response1 = await callFor(url, 'POST', data, 'Auth');
        if (response1.status === 200) {
          const jsonResponse = await response1.json();
          if (props.type === 'comment') {
            if (getFeedDatas[props.feedIndex].comments[props.commentIndex].reactionCount > 0) {
              dispatch({
                type: 'add_comment_unLikeReactionCount',
                reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reactionCount - 1,
                index: props.feedIndex,
                commentIndex: props.commentIndex
              });
            }
            dispatch({
              type: 'add_comment_unLikeRreaction',
              reaction: '0',
              index: props.feedIndex,
              commentIndex: props.commentIndex
            });
            // dispatch({
            //   type: 'add_comment_unLikeReactionId',
            //   reactionId: jsonResponse.data,
            //   index: props.feedIndex,
            //   commentIndex: props.commentIndex
            // });
          } else if (props.type === 'reply') {
            if (getFeedDatas[props.feedIndex].comments[props.commentIndex].reply[props.replyIndex].reactionCount > 0) {
              dispatch({
                type: 'add_reply_unLikeReactionCount',
                reactionCount: getFeedDatas[props.feedIndex].comments[props.commentIndex].reply[props.replyIndex].reactionCount - 1,
                index: props.feedIndex,
                commentIndex: props.commentIndex,
                replyIndex: props.replyIndex
              });
            }
            dispatch({
              type: 'add_reply_unLikeReaction',
              reaction: '0',
              index: props.feedIndex,
              commentIndex: props.commentIndex,
              replyIndex: props.replyIndex
            });
            // dispatch({
            //   type: 'add_reply_unLikeReactionId',
            //   reactionId: jsonResponse.data,
            //   index: props.feedIndex,
            //   commentIndex: props.commentIndex,
            //   replyIndex: props.replyIndex
            // });
          } else {
            if (getFeedDatas[props.feedIndex].reactionCount > 0) {
              dispatch({
                type: 'add_post_unLikeReactionCount',
                reactionCount: getFeedDatas[props.feedIndex].reactionCount - 1,
                index: props.feedIndex
              });
            }
            dispatch({
              type: 'add_post_unLikeReaction',
              reaction: '',
              index: props.feedIndex
            });
            dispatch({
              type: 'add_post_UnLikeReactionId',
              reactionId: jsonResponse.data,
              index: props.feedIndex
            });
          }
        }
      }
    }
  };
  const addCssClass = () => {
    document.getElementById('removeHover_' + uniqueClassid).classList.remove('removeHover');
    document.getElementById('likeHover_' + uniqueClassid).classList.add('activeHover');
  };
  const removeCssClass = () => {
    document.getElementById('likeHover_' + uniqueClassid).classList.remove('activeHover');
  };
  return (
      <>
       <IonRow className="like-hover" id={'likeHover_' + uniqueClassid} onTouchStart={addCssClass} onMouseEnter={addCssClass} onMouseLeave={removeCssClass}>
      <IonButton
          fill="clear"
          className="ion-no-padding ion-paddin-start ion-text-capitalize vertical-btn reaction-color-tab"
          onClick ={() => unlikeBtn(props.id)}
      >
          <div className="vertical-btn">
          {(() => {
            if (props.reaction === '1') {
              return (
                    <>{props.type === 'post'
                      ? <img src={Like} width="20" />
                      : ''}<span>{t('feedproperties.text6')}</span></>
              );
            } else if (props.reaction === '2') {
              return (
                    <>{props.type === 'post'
                      ? <img src={Celebrate} width="20" />
                      : '' }
                    <span>{t('feedproperties.text7')}</span></>
              );
            } else if (props.reaction === '3') {
              return (
                <>{props.type === 'post'
                  ? <img src={Interest} width="20" />
                  : '' }
                <span>{t('feedproperties.text8')}</span></>
              );
            } else if (props.reaction === '4') {
              return (
                <> {props.type === 'post'
                  ? <img src={ShakeHand} width="20" />
                  : '' }
                <span>{t('feedproperties.text9')}</span></>
              );
            } else if (props.reaction === '5') {
              return (
                <>{props.type === 'post'
                  ? <img src={Supports} width="20" />
                  : '' }
                <span>{t('feedproperties.text10')}</span></>
              );
            } else {
              return (
                <><span className='svg-icon like'>
                  {props.type === 'post'
                    ? <img src={ThumbLikeIcon} alt='Like Icon' width='20' className='me-lg-2 me-0' />
                    : '' }
                  </span><span>{t('feedproperties.text6')}</span></>
              );
            }
          })()}
          </div>
      </IonButton>
      <IonRow className='like-popover' id ={'removeHover_' + uniqueClassid}>
              <IonButton
                  fill="clear"
                  className="ion-no-padding ion-paddin-start"
                  onClick={() => reactionHandler(1, props.id)}
              >
                <img src={Like} width="20"/>
                <span className='custom-tooltip'>{t('appproperties.text220')}</span>
              </IonButton>
              <IonButton
                  fill="clear"
                  className="ion-no-padding ion-paddin-start"
                  onClick={() => reactionHandler(2, props.id)}
              >
                <img src={Celebrate} width="20"/>
                <span className='custom-tooltip'>{t('appproperties.text221')}</span>
              </IonButton>
              <IonButton
                  fill="clear"
                  className="ion-no-padding ion-paddin-start"
                  onClick={() => reactionHandler(3, props.id)}
              >
                  <img src={Interest} width="20"/>
                  <span className='custom-tooltip'>{t('appproperties.text222')}</span>
              </IonButton>
              <IonButton
                  fill="clear"
                  className="ion-no-padding ion-paddin-start"
                  onClick={() => reactionHandler(4, props.id)}
              >
                  <img src={ShakeHand} width="20"/>
                  <span className='custom-tooltip'>{t('feedproperties.text9')}</span>
              </IonButton>
              <IonButton
                  fill="clear"
                  className="ion-no-padding ion-paddin-start"
                  onClick={() => reactionHandler(5, props.id)}
              >
                <img src={Supports} width="20"/>
                <span className='custom-tooltip'>{t('feedproperties.text10')}</span>
              </IonButton>
          </IonRow></IonRow>
          {loginModal
            ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
            : ''}
          </>
  );
};
export default Emojis;
