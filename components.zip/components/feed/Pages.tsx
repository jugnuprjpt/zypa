import React from 'react';
import { useTranslation } from 'react-i18next';
import ActivityCard from '../common/ActivityCard';

const Pages = () => {
  const { t } = useTranslation();
  const pages = [
    {
      key: '1',
      name: 'Product Page',
      img:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg'
    },
    {
      key: '2',
      name: 'Personal Page',
      img:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg'
    }
  ];
  return (
        <ActivityCard header = 'Pages' headerLinkLable={t('commonproperties.text3')} headerLink='/home' mapData={pages}
        footerLinkLable='+New Page' footerLink='/home' className="sidebar-pages"/>
  );
};
export default Pages;
