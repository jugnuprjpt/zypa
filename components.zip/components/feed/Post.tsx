/* eslint-disable react/prop-types */
import {
  IonAvatar, IonButton, IonCard, IonCardTitle, IonCol, IonContent, IonFooter, IonIcon, IonItem,
  IonLabel, IonList, IonModal, IonRadio, IonRadioGroup, IonRouterLink, IonRow
} from '@ionic/react';
import React, { useEffect, useRef, useState } from 'react';
import { close, imageOutline, videocamOutline, documentOutline, trashBinOutline } from 'ionicons/icons';
import CallFor from '../../util/CallFor';
import { useDispatch, useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import Editor from '../common/Editor2';
import { useHistory } from 'react-router-dom';
import ReactPlayer from 'react-player';
import { Device } from '@capacitor/device';
import CustomeFirebaseEvent from '../common/CustomFirebaseEvent';
import { useTranslation } from 'react-i18next';
import NotAuthorizeModal from '../common/NotAuthorizeModal';

const Post = (props) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const [diviceInfo, setDiviceInfo] = useState();
  const [loginModal, setLoginModal] = useState(false);
  const history = useHistory();
  const postref = useRef(null);
  const profileDetail = useSelector(getProfileDetails);
  const [typeError, setTypeError] = useState('');
  const [privacyError, setPrivacyError] = useState('');
  const [firmType, setFirmType] = useState('ANYONE');
  const [showModal, setShowModal] = useState(false);
  const [photogalary, setPhotoGalary] = useState<string[]>([]);
  const [btnDisabled, setBtnDisabled] = useState(false);
  const [isValid, setIsValid] = useState(true);
  const buttonPhotoRef = useRef();
  const buttonVideoRef = useRef();
  const buttonFileRef = useRef();
  const [fileType, setFileType] = useState('');
  // const [showToast, setShowToast] = useState(false);
  const [outsideModal, setOutsideModel] = useState(false);
  const [btnSubmit, setBtnSubmit] = useState(false);
  const [loading, setloading] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const openModal = () => {
    if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
      setShowModal(true);
    } else {
      // history.push('/addnewcompany');
      setLoginModal(true);
    }
  };
  useEffect(async() => {
    setDiviceInfo(await Device.getInfo());
    if (props.postFlag !== undefined && props.postFlag) {
      setShowModal(true);
    }
  }, []);

  const postHandler = async() => {
    if (checkValidation() && isValid) {
      setloading(true);
      setBtnSubmit(true);
      const d = postref.current.editor.getContents();
      let postData = '';
      let hashData = '';
      const attributes: { type: string; start: number; length: any; id: any; }[] = [];
      // eslint-disable-next-line array-callback-return
      d.ops.map((object: { insert: string; }) => {
        if (typeof object.insert === 'object') {
          postData += object.insert.mention.value;
          if (object.insert.mention.value.charAt(0) !== '#') {
            console.log(postData.lastIndexOf(object.insert.mention.value));
            const data1 = {
              mention: 'PROFILE',
              start: postData.lastIndexOf(object.insert.mention.value),
              length: object.insert.mention.value.length,
              id: object.insert.mention.id
            };
            attributes.push(data1);
          } else {
            hashData += object.insert.mention.value;
          }
        } else {
          if (object.insert.match(/#[a-z]+/gi) != null) {
            hashData += object.insert.match(/#[a-z]+/gi);
          }
          postData += object.insert;
        }
      });
      let firmType = '';
      let privacy = '';

      if (props.origin !== 'USER') {
        if (props.origin === 'PAGE') {
          firmType = 'GENERAL';
          privacy = 'ANYONE';
        } else {
          firmType = document.getElementsByName('firmType')[0].value;
          privacy = 'ANYONE';
        }
      } else {
        firmType = document.getElementsByName('firmType')[0].value;
        // rivacy = document.getElementsByName('privacy')[0].value;
        privacy = 'ANYONE';
      }

      const postComment = { text: postData, attributes: attributes };
      const post = '{"content":' + JSON.stringify(postComment) + ',"originId":"' + props.originId + '","origin":"' + props.origin + '","hashTag":"' + hashData.split(',').join('') + '","type":"' + firmType + '","privacy":"' + privacy + '"}';
      const data = new FormData();
      data.append('post', post);
      photogalary.forEach((item) => {
        data.append('media', item);
      });
      const response = await CallFor('api/v1/post', 'POST', data, 'authWithoutContentType');
      if (response.status === 201) {
        if (props.origin === 'USER') {
          CustomeFirebaseEvent('post_event', diviceInfo);
          if (window.location.pathname.includes('home')) {
            const json1Response = await response.json();
            let type = '1';
            if (firmType === 'BUY') {
              type = '1';
            } else if (firmType === 'SELL') {
              type = '2';
            } else {
              type = '3';
            }
            dispatch({
              type: 'add_feedsData_newPost',
              Feeds: {
                id: json1Response.data.id,
                userId: profileDetail.id,
                postOf: null,
                content: JSON.stringify(postComment),
                hashTag: hashData.split(',').join(''),
                mediaUrl: json1Response.data.mediaUrl,
                products: null,
                type: type,
                privacy: '1',
                status: '1',
                ageOfPost: t('appproperties.text232'),
                commentCount: 0,
                reactionCount: 0,
                userProfile: profileDetail.profileImg,
                userName: profileDetail.name,
                userDesignation: profileDetail.profileTitle,
                sendTo: [],
                aboutUser: null,
                reactionId: null,
                reaction: null,
                viewCount: 0,
                comments: [],
                userCompany: profileDetail.entityName
              }
            });
            closeHandler();
          } else {
            closeHandler();
            history.push('/home');
          }
        } else {
          const json1Response = await response.json();
          let type = '1';
          if (firmType === 'BUY') {
            type = '1';
          } else if (firmType === 'SELL') {
            type = '2';
          } else {
            type = '3';
          }
          dispatch({
            type: 'add_feedsData_newPost',
            Feeds: {
              id: json1Response.data.id,
              userId: profileDetail.id,
              postOf: null,
              content: JSON.stringify(postComment),
              hashTag: hashData.split(',').join(''),
              mediaUrl: json1Response.data.mediaUrl,
              products: null,
              type: type,
              privacy: '1',
              status: '1',
              ageOfPost: t('appproperties.text232'),
              commentCount: 0,
              reactionCount: 0,
              userProfile: profileDetail.profileImg,
              userName: profileDetail.name,
              userDesignation: profileDetail.profileTitle,
              sendTo: [],
              aboutUser: null,
              reactionId: null,
              reaction: null,
              viewCount: 0,
              comments: [],
              userCompany: profileDetail.entityName
            }
          });
          closeHandler();
        }
      } else if (response.status === 400) {
        const json1Response = await response.json();
        setToastMsg(json1Response.error.errors[0].message);
        setloading(false);
        setBtnSubmit(false);
      } else {
        setloading(false);
        setBtnSubmit(false);
      }
    }
  };

  const checkValidation = () => {
    let isPostTypeValid = false;
    let isPrivacyValid = false;
    let ismsgValidate = false;
    let isPhotoSelected = false;
    if (props.origin !== 'USER') {
      if (props.origin !== 'PAGE') {
        const firmType = document.getElementsByName('firmType')[0].value;
        if (firmType !== undefined && firmType !== null && firmType !== '') {
          isPostTypeValid = true;
        } else {
          setTypeError(t('postproperties.text6'));
        }
        isPrivacyValid = true;
      } else {
        isPrivacyValid = true;
        isPostTypeValid = true;
      }
    } else {
      const firmType = document.getElementsByName('firmType')[0].value;
      // const privacy = document.getElementsByName('privacy')[0].value;
      if (firmType !== undefined && firmType !== null && firmType !== '') {
        isPostTypeValid = true;
      } else {
        setTypeError(t('postproperties.text6'));
      }
      isPrivacyValid = true;
      // if (privacy !== undefined && privacy !== null && privacy !== '') {
      //   isPrivacyValid = true;
      // } else {
      //   setPrivacyError('Privacy is required');
      // }
    }
    let contantFlag = false;
    if (postref.current.editor.getContents().ops.length >= 2) {
      contantFlag = false;
    } else {
      if (postref.current.editor.getText().trim().length > 1) {
        contantFlag = false;
      } else {
        contantFlag = true;
      };
    }
    if (isValid) {
      if (!contantFlag) {
        ismsgValidate = true;
        setToastMsg('');
      } else {
        setToastMsg(t('postproperties.text7'));
      }
      if (!ismsgValidate) {
        if (photogalary.length > 0) {
          isPhotoSelected = true;
          setToastMsg('');
        } else {
          setToastMsg(t('postproperties.text7'));
        }
      }
    }
    if (isPostTypeValid && isPrivacyValid && (ismsgValidate || isPhotoSelected)) {
      return true;
    }
    return false;
  };
  const uploadFileHandleChange = (event, type) => {
    if (event.target.files.length > 0) {
      const images: any[] = [];
      setFileType(type);
      let totalLength = 0;
      setBtnDisabled(true);
      let isValid = false;
      let errorMsg = '';
      let errortype = '';
      if (type === 'image') {
        errorMsg = t('commonproperties.text1');
        errortype = /\.(jpg|jpeg|png|gif|jfif|PNG|JPEG|JPG|JFIF|GIF)$/;
      } else if (type === 'video') {
        errorMsg = t('postproperties.text9');
        errortype = /\.(mp4|MP4|mov|MOV)$/;
      } else if (type === 'file') {
        errorMsg = t('postproperties.text10');
        errortype = /\.(pdf)$/;
      }

      if (event.target.files.length <= 10) {
        for (let i = 0; i < event.target.files.length; i++) {
          if (!event.target.files[i].name.match(errortype)) {
            // setShowToast(true);
            setIsValid(false);
            isValid = false;
            setToastMsg(errorMsg);
          } else {
            totalLength += event.target.files[i].size;
            isValid = true;
            setToastMsg('');
          }
          images.push(event.target.files[i]);
        }
        if (isValid) {
          if (totalLength > 100000000) {
            // setShowToast(true);
            setBtnDisabled(true);
            setIsValid(false);
            if (type === 'image') {
              setToastMsg(t('postproperties.text11'));
            } else if (type === 'video') {
              setToastMsg(t('postproperties.text12'));
            } else if (type === 'file') {
              setToastMsg(t('postproperties.text13'));
            }
          } else {
            setIsValid(true);
            // setShowToast(false);
            setToastMsg('');
          }
        }
        const input = document.getElementById('postDisable');
        input.classList.add('postDisable');
        setPhotoGalary(images);
      } else {
        for (let i = 0; i < event.target.files.length; i++) {
          images.push(event.target.files[i]);
        }
        const input = document.getElementById('postDisable');
        input.classList.add('postDisable');
        // setShowToast(true);
        setIsValid(false);
        setBtnDisabled(false);
        setToastMsg(t('postproperties.text14'));
        setPhotoGalary(images);
      }
    }
  };
  const closeHandler = () => {
    setShowModal(false);
    setPhotoGalary([]);
    setBtnDisabled(false);
    // setShowToast(false);
    setOutsideModel(false);
    setTypeError('');
    setPrivacyError('');
    setBtnSubmit(false);
    setloading(false);
    setToastMsg('');
    if (props.setPostFlag !== undefined) {
      props.setPostFlag(false);
    }
  };
  let pdfFileName = '';
  const getPhotoUrl = (file) => {
    pdfFileName = file.name;
    return URL.createObjectURL(file);
  };
  const changeHandler = (event) => {
    if (event.target.value !== undefined) {
      if (event.target.name === 'firmType') {
        setTypeError('');
      }
      if (event.target.name === 'privacy') {
        setPrivacyError('');
        setFirmType(event.target.value);
      }
    }
  };
  const deleteImg = () => {
    setPhotoGalary(new Map());
    setBtnDisabled(false);
    document.getElementById('image').value = '';
    document.getElementById('video').value = '';
    document.getElementById('file').value = '';
    const input = document.getElementById('postDisable');
    input.classList.remove('postDisable');
    // setShowToast(false);
    setToastMsg('');
    setIsValid(true);
  };
  const openModal2 = (type) => {
    if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
      setShowModal(true);
      setOutsideModel(true);
      setFileType(type);
    } else {
      // history.push('/addnewcompany');
      setLoginModal(true);
    }
  };
  const selectFiles = () => {
    if (outsideModal) {
      if (fileType === 'image') {
        buttonPhotoRef.current.click();
      } else if (fileType === 'video') {
        buttonVideoRef.current.click();
      } else if (fileType === 'file') {
        buttonFileRef.current.click();
      }
    }
  };
  const deleteFile = (key) => {
    if (photogalary.length < 2) {
      setPhotoGalary([]);
      setBtnDisabled(false);
      document.getElementById('image').value = '';
      document.getElementById('video').value = '';
      document.getElementById('file').value = '';
      const input = document.getElementById('postDisable');
      input.classList.remove('postDisable');
      setToastMsg('');
      setIsValid(true);
    }
    const s = photogalary.filter((item, index) => index !== key);
    if (s.length <= 10) {
      setToastMsg('');
      setIsValid(true);
    }
    setPhotoGalary(s);
  };

  return (
    <>{props.postFlag === undefined
      ? <IonCard className={props.origin === 'USER' ? 'MuiPaper-rounded ion-no-margin ion-margin-top ion-margin-bottom post-content' : 'MuiPaper-rounded ion-no-margin ion-margin-top ion-margin-bottom post-content'}>
        <div className='myprofile-feeds'>
          <IonAvatar slot="start" className="MuiCardHeader-avatar MuiAvatar-circular">
            {profileDetail.profileImg !== null
              ? <img onError={(ev) => { ev.target.src = userProfile; }} src={profileDetail.profileImg} style={{ cursor: 'auto' }} />
              : <img src={userProfile} />
            }
          </IonAvatar>
          <IonRouterLink onClick={openModal}>
            <IonCardTitle>
              <p className='home-font-color font-regular'>{t('appproperties.text82')}</p>
            </IonCardTitle>
          </IonRouterLink>
        </div>
        <IonRow className='card-header-text ion-padding post-up-item'>
          <label className="right-padding ps-2" onClick={() => openModal2('image')}>
            <IonRow>
              <IonIcon icon={imageOutline} className='font-24 me-2 color-theme-dark'></IonIcon>
              <span className='color-theme'>{t('appproperties.text83')}</span>
            </IonRow>
          </label>
          <label className="right-padding ps-4" onClick={() => openModal2('video')}>
            <IonRow>
              <IonIcon icon={videocamOutline} className='font-24 me-2 color-orange'></IonIcon>
              <span className='color-theme'>{t('appproperties.text84')} </span>
            </IonRow>
          </label>
          <label className="right-padding ps-4" onClick={() => openModal2('file')}>
            <IonRow>
              <IonIcon icon={documentOutline} className='font-24 me-2 color-green '></IonIcon>
              <span className='color-theme'>{t('appproperties.text85')}</span>
            </IonRow>
          </label>
        </IonRow>
      </IonCard>
      : ''
    }
      <IonModal isOpen={showModal} onDidPresent={selectFiles} cssClass="modelpadding post-modal" onDidDismiss={() => closeHandler()}>
        <IonRow className='modalTitle pt-lg-3 pt-3'>
          <IonRow>
            <IonLabel className="MuiTypography-h6 ion-padding-start">{t('postproperties.text1')}</IonLabel>
          </IonRow>
          <IonRow className='header-row-margin-left ion-align-items-center'>
            <IonButton
              fill="clear"
              className="ion-float-right close-btn-icon"
              onClick={closeHandler}
              size='small'
            >
              <div className='close-btn-icon'>
                <IonIcon icon={close} slot="start" />
              </div>
            </IonButton>
          </IonRow>
        </IonRow>
        <IonContent className='middel-content'>
          <IonRow>
            <div className='myprofile-feeds ion-padding-start cursor-pointer pt-0'>
              <IonAvatar slot="start" className="MuiCardHeader-avatar MuiAvatar-circular ion-margin-end" >
                {profileDetail.profileImg !== null
                  ? <img onError={(ev) => { ev.target.src = userProfile; }} src={profileDetail.profileImg} />
                  : <img src={userProfile} />
                }
              </IonAvatar>
              <IonRow className='profileName '>
                <IonCardTitle>
                  <p className='margin MuiTypography-body1'><strong>{profileDetail.name} </strong></p>
                </IonCardTitle>
              </IonRow>
            </div>
          </IonRow>
          <IonRow className='ion-padding-top'>
            {props.origin !== 'PAGE'
              ? <IonCol className='profileName nowrap-normal' size-md="7" size-xs="12">
                <IonLabel className="ion-padding-start">
                  {t('postproperties.text2')}
                </IonLabel>
                <IonRadioGroup
                  onIonChange={changeHandler}
                  name='firmType'
                >
                  <IonRow className="ion-padding-start">
                    <IonItem lines="none" >
                      <IonRadio mode="md" value="BUY"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root font-16">
                        {t('postproperties.text3')}
                      </IonLabel>
                    </IonItem>
                    <IonItem lines="none" >
                      <IonRadio mode="md" value="SELL"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                        {t('postproperties.text4')}
                      </IonLabel>
                    </IonItem>
                    <IonItem lines="none" >
                      <IonRadio mode="md" value="GENERAL"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                        {t('postproperties.text5')}
                      </IonLabel>
                    </IonItem>
                  </IonRow>
                </IonRadioGroup>
                <p className='error ion-padding-start mt-0 mb-0 post-error position-relative'>{typeError}</p>
              </IonCol>
              : ''}
            {/* {props.origin === 'USER'
            ? <IonCol className='profileName nowrap-normal'size-md="5" size-xs="12">
            <IonLabel className="ion-padding-start">
              Privacy
            </IonLabel>
            <IonRadioGroup
                onIonChange={changeHandler} name='privacy' value={firmType}>
                <IonRow className="ion-padding-start">
                  <IonItem lines="none" >
                  <IonRadio mode="md" item-left value="ANYONE"></IonRadio>
                  <IonLabel className="MuiFormControlLabel-root">
                    Anyone
                  </IonLabel>
                  </IonItem>
                  <IonItem lines="none" >
                  <IonRadio mode="md" value="CONNECTION_ONLY"></IonRadio>
                  <IonLabel className="MuiFormControlLabel-root">
                    Connection Only
                  </IonLabel>
                  </IonItem>
                </IonRow>
              </IonRadioGroup>
              <p className='error ion-padding-start mt-0 mb-3 post-error'>{privacyError}</p>
          </IonCol>
            : ''
        } */}
          </IonRow>
          <Editor postref={postref} />
          <div className="addPhoto-editor">
            <IonList>
              {photogalary.length > 0
                ? <>
                  {photogalary.map((value, index) => {
                    if (fileType === 'image') {
                      return (
                        <><IonItem lines='none' className="ion-no-padding">
                          <div className="img-list-item position-relative">
                            <img draggable="false" src={getPhotoUrl(value)} />
                            <IonIcon icon={trashBinOutline} className='text-dark position-absolute cursor-pointer delete-btn' onClick={() => deleteFile(index)} />
                          </div>
                        </IonItem></>
                      );
                    } else if (fileType === 'video') {
                      return (
                        <><IonItem lines='none' className="ion-no-padding">
                          <div className="img-list-item" draggable="false">
                            <ReactPlayer
                              width="100%"
                              height="100%"
                              controls={true}
                              url={getPhotoUrl(value)}
                              config={{ file: { attributes: { controlsList: 'nodownload' } } }}
                            />
                          </div>
                        </IonItem></>
                      );
                    } else if (fileType === 'file') {
                      return (
                        <><IonItem lines='none' className="ion-no-padding pdfFile">
                          <a href={getPhotoUrl(value)} draggable="false">{pdfFileName}</a>
                        </IonItem></>
                      );
                    }
                  })}
                  <IonItem lines='none' className="ion-no-padding removePdf">
                    <div onClick={deleteImg} className="link-btn-tx cursor-pointer text-center" >
                      {photogalary.length > 1
                        ? t('appproperties.text202')
                        : t('appproperties.text10')
                      }
                    </div>
                  </IonItem>
                </>
                : ''
              }
            </IonList>
          </div>
          <p className='error ion-padding-start mt-1 mb-0 post-error'>{toastMsg}</p>
        </IonContent>
        <IonFooter className="ion-no-border MuiButton-label">
          <IonRow className='ion-padding-start full-width-row footer-action'>
            <IonRow id='postDisable'>
              <input ref={buttonPhotoRef} type="file" disabled={btnDisabled} accept="image/png, image/gif, image/jpg, image/jpeg" color='dark' onChange={(e) => uploadFileHandleChange(e, 'image')} className='ion-text-capitalize ion-no-padding ion-padding-end upload' multiple id='image'>
              </input>
              <label htmlFor="image" className='ion-text-capitalize ion-no-padding ion-padding-end cursor-pointer' color='dark' >
                <IonRow className='d-flex align-items-center'>
                  <IonIcon icon={imageOutline} className='test font-24 me-2 color-theme-dark'></IonIcon>
                  <span className='mt-0'>{t('appproperties.text83')}</span>
                </IonRow>
              </label>
              <input type="file" ref={buttonVideoRef} disabled={btnDisabled} accept="video/mp4, video/mov" color='dark' onChange={(e) => uploadFileHandleChange(e, 'video')} className='ion-text-capitalize ion-no-padding ion-padding-end upload' id='video'>
              </input>
              <label htmlFor="video" className='ion-text-capitalize ion-no-padding ion-padding-end cursor-pointer' color='dark' >
                <IonRow className='d-flex align-items-center'>
                  <IonIcon icon={videocamOutline} className='font-26 me-2 color-orange'></IonIcon>
                  <span className='mt-0'>{t('appproperties.text84')}</span>
                </IonRow>
              </label>
              <input type="file" ref={buttonFileRef} disabled={btnDisabled} accept="application/pdf" color='dark' onChange={(e) => uploadFileHandleChange(e, 'file')} className='ion-text-capitalize ion-no-padding ion-padding-end upload' id='file'>
              </input>
              <label htmlFor="file" className='ion-text-capitalize ion-no-padding ion-padding-end cursor-pointer' color='dark' >
                <IonRow className='d-flex align-items-center'>
                  <IonIcon icon={documentOutline} className='font-24 me-2 color-green'></IonIcon>
                  <span className='mt-0'>{t('appproperties.text85')}</span>
                </IonRow>
              </label>
            </IonRow>
            <IonRow className='header-row-margin-left'>
              <IonButton className="ion-float-right ion-button ion-button-color" onClick={postHandler} size='default' disabled={btnSubmit}>
                {t('appproperties.text73')}
                {loading
                  ? <span className="loader" id="loader-2">
                    <span></span>
                    <span></span>
                    <span></span>
                  </span>
                  : ''
                }
              </IonButton>
            </IonRow>
          </IonRow>
        </IonFooter>
      </IonModal>
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}
    </>
  );
};
export default Post;
