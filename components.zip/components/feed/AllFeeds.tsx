import { IonCard, IonInfiniteScroll, IonInfiniteScrollContent, IonRefresher, IonRefresherContent } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import CallFor from '../../util/CallFor';
import { useDispatch, useSelector } from 'react-redux';
import { getFeedData } from '../../Redux/reducers/feeds';
import ConnectionSuggestion from '../common/ConnectionSuggestion';
import FeedCard from '../common/FeedCard';
import { useHistory } from 'react-router';
import { RefresherEventDetail } from '@ionic/core';
import { Device } from '@capacitor/device';
import SkeletonFeedComon from '../common/skeleton/SkeletonFeedComon';
import { useTranslation } from 'react-i18next';

const AllFeeds = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const [count, setCount] = useState(0);
  const getFeedDatas = useSelector(getFeedData);
  const [allBtnClass, setAllBtnClass] = useState('ion-button-color');
  const [buyBtnClass, setBuyBtnClass] = useState('category-btn-color');
  const [sellBtnClass, setSellBtnClass] = useState('category-btn-color');
  // const [generalBtnClass, setGeneralBtnClass] = useState('category-btn-color');
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [categoryType, setCategoryType] = useState('All');
  const [diviceInfo, setDeviceInfo] = useState();
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [showMainMenu, setShowMainMenu] = useState<string>('ALL');
  const [knowledgePartnerData, setKnowledgePartnerData] = useState([]);

  useEffect(async () => {
    dispatch({
      type: 'add_feedsData',
      Feeds: []
    });
    setDeviceInfo(await Device.getInfo());
    getAllFeedData('ALL');
    getconnectionList();
    // getKnowledgePartnerDetails();
  }, []);

  // const getKnowledgePartnerDetails = async() => {
  //   setLoading(true);
  //   // const response =  await fetch('http://192.168.7.119:7072/knowledge-customers/knowledgePartner',{
  //   //     method:'GET'
  //   // })
  //   const response = await callFor('api/v1/knowledge-customers/knowledgePartner', 'GET', null, 'Auth');
  //   if (response.status === 200) {
  //     const json1Response = await response.json();
  //     setKnowledgePartnerData(json1Response.data);
  //   }
  // };

  const [connectionData, setConnectionData] = useState([]);
  const getAllFeedData = async (category: string) => {
    setLoading(true);
    setInfiniteDisabled(false);
    if (category === 'ALL') {
      setAllBtnClass('pe-0');
      setBuyBtnClass('pe-0');
      setSellBtnClass('pe-0');
      // setGeneralBtnClass('category-btn-color');
    } else if (category === 'BUY') {
      setAllBtnClass('pe-0');
      setBuyBtnClass('pe-0');
      setSellBtnClass('pe-0');
      // setGeneralBtnClass('category-btn-color');
    } else if (category === 'SELL') {
      setAllBtnClass('pe-0');
      setSellBtnClass('pe-0');
      setBuyBtnClass('pe-0');
      // setGeneralBtnClass('category-btn-color');
    } else if (category === 'GENERAL') {
      setAllBtnClass('pe-0');
      setBuyBtnClass('pe-0');
      // setGeneralBtnClass('ion-button-color');
      setSellBtnClass('pe-0');
    }
    setCategoryType(category);
    const allFeedDataResponse = await CallFor('api/v1/feeds/USER/' + category,
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      if (json1Response.data.content.length > 0) {
        dispatch({
          type: 'add_feedsData',
          Feeds: json1Response.data.content
        });
      } else {
        dispatch({
          type: 'add_feedsData',
          Feeds: []
        });
      }
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setCount(1);
    setLoading(false);
  };

  const getconnectionList = async () => {
    const response = await CallFor('api/v1.2/suggestions/users', 'POST', '{"page": 0 }', 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setConnectionData(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const scrollData = async () => {
    const allFeedDataResponse = await CallFor('api/v1/feeds/USER/' + categoryType,
      'POST',
      '{"page": ' + count + ' }',
      'Auth'
    );
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      if (json1Response.data.content.length > 0) {
        json1Response.data.content.map((details) => {
          dispatch({
            type: 'add_feedsData_new',
            Feeds: details
          });
        });
      } else {
        setInfiniteDisabled(true);
      }
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const loadData = (ev: any) => {
    setCount(count + 1);
    setTimeout(() => {
      scrollData();
      ev.target.complete();
    }, 500);
  };
  const doRefresh = (event: CustomEvent<RefresherEventDetail>) => {
    setTimeout(() => {
      getAllFeedData(categoryType);
      event.detail.complete();
    }, 5000);
  };
  const onChangeFeedData = (event) => {
    setShowMainMenu(event.detail.value);
    getAllFeedData(event.detail.value);
  };
  return (
    <>
      {/* <div className='d-flex align-items-center categorySorting mt-2'>
        <hr className="w-100" />
        <div className='d-flex align-items-center'>
          <IonLabel className='text-nowrap ms-2 me-1 font-13'>{t('appproperties.text88')}</IonLabel>
          <IonSelect
            value={showMainMenu}
            interface='popover'
            className='mainPageDropdown font-13 font-medium py-0'
            onIonChange={onChangeFeedData}
          >
            <IonSelectOption value="ALL" className={allBtnClass} >{t('appproperties.text89')}</IonSelectOption>
            <IonSelectOption value="BUY" className={buyBtnClass} >{t('postproperties.text3')}</IonSelectOption>
            <IonSelectOption value="SELL" className={sellBtnClass} >{t('postproperties.text4')}</IonSelectOption>
          </IonSelect>
        </div>
      </div> */}

      {diviceInfo !== undefined && (diviceInfo.platform === 'ios' || diviceInfo.platform === 'android')
        ? <div>
          <IonRefresher slot="fixed" onIonRefresh={doRefresh}>
            <IonRefresherContent></IonRefresherContent>
          </IonRefresher>
        </div>
        : ''
      }
      {getFeedDatas.length > 0 && !loading
        ? Object.entries(getFeedDatas).map(([feedKey, feeds]) => (
          <>
            <FeedCard feeds={feeds} feedKey={feedKey} origin='USER' originId='0' />
            {feedKey === '2'
              ? (
                <>
                  <ConnectionSuggestion
                    connectionData={connectionData}
                    header={t('appproperties.text27')}
                    footer={t('appproperties.text28')}
                    setConnectionData={setConnectionData}
                    loading={loading}
                    getconnectionList={getconnectionList}

                  />
                  {/* <KnowledgePartner header="Exclusive Knowledge Partners"  KnowledgePartnerData={knowledgePartnerData} /> */}
                </>
              )
              : (
                ''
              )}
          </>
        ))
        : loading
          ? <SkeletonFeedComon column={5} />
          : <>
            <IonCard className='ion-padding ion-no-margin ion-margin-bottom ion-margin-top'>
              {categoryType === 'ALL'
                ? t('feedproperties.text1')
                : categoryType === 'BUY'
                  ? t('feedproperties.text2')
                  : categoryType === 'SELL'
                    ? t('feedproperties.text3')
                    : t('feedproperties.text4')}
            </IonCard>
            <ConnectionSuggestion
              connectionData={connectionData}
              header={t('appproperties.text27')}
              footer={t('appproperties.text28')}
              setConnectionData={setConnectionData}
              loading={loading}
              getconnectionList={getconnectionList}
            />
          </>
      }
      {!loading
        ? <IonInfiniteScroll
          onIonInfinite={loadData}
          threshold="100px"
          disabled={isInfiniteDisabled}
        >
          <IonInfiniteScrollContent
            loadingSpinner="circular"
            loadingText={t('appproperties.text215')}
          ></IonInfiniteScrollContent>
        </IonInfiniteScroll>
        : ''}
    </>
  );
};
export default AllFeeds;
