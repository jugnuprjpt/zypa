/* eslint-disable react/jsx-key */
/* eslint-disable multiline-ternary */
/* eslint-disable react/prop-types */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonLabel,
  IonList,
  IonModal,
  IonRow
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../../Redux/reducers/UserProfile';
import userProfile from '../../../assets/img/user-profile-placeholder.png';
import CallFor from '../../../util/CallFor';
import MetaTags from 'react-meta-tags';
import SkeletonComonOverView from '../../common/skeleton/SkeletonComonOverView';
import { close } from 'ionicons/icons';
import SkeletonComonViewAll from '../../common/skeleton/SkeletonComonViewAll';
import CommonGridList from '../../common/CommonGridList';
import { useTranslation } from 'react-i18next';

const ProfileDetails = () => {
  const { t } = useTranslation();
  const profileDetail = useSelector(getProfileDetails);
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const divclick = () => {
    history.push('/profile/' + profileDetail.id);
  };
  const [profileDetailsCount, setProfileDetailsCount] = useState([
    {
      connections: 0,
      views: 0,
      postView: 0,
      following: 0,
      follower: 0,
      post: 0
    }
  ]);
  useEffect(() => {
    getUserProfileDetailCount();
  }, []);
  const getMutualConnectionCount = (id) => {
    (async() => {
        const meta = await getMutualConnectionCountApi(id);
        console.log(meta);
        return meta + 'Mutual Connections'; // {"metadata": "for: test.png"}
      })();
    setTimeout(() => {
      
    }, 100);
    // const cnt = getMutualConnectionCountApi(id).then((data) => { return data; });
    // console.log(cnt);
    // return 'Mutual Connections'; // {"metadata": "for: test.png"}
  };
  const getMutualConnectionCountApi = async(id) => {
    const response = await CallFor(
      'api/v1.1/mutual/count/' + id,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      return json1Response.data;
    }
  };
  const getUserProfileDetailCount = async() => {
    setLoading(true);
    const stateres = await CallFor('api/v1.1/users/overview', 'GET', null, 'Auth');
    if (stateres.status === 200) {
      const json1Response = await stateres.json();
      if (json1Response.data !== null) {
        setProfileDetailsCount(json1Response.data);
      }
    } else if (stateres.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const [ScrollViewData, setScrollViewData] = useState([]);
  const [openViewModel, setViewModel] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [count, setCount] = useState(0);
  const getViewsList = async(page: string | number) => {
    const response = await CallFor(
      'api/v1.1/users/view',
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      return json1Response.data.content;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
      return [];
    }
  };
  const getConnectionListOnScroll = async() => {
    const response = await CallFor(
      'api/v1.1/users/view',
      'POST',
      '{"page": ' + count + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setScrollViewData([
          ...ScrollViewData,
          ...json1Response.data.content
        ]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const closeViewsModel = () => {
    setViewModel(false);
    setScrollViewData([]);
    setCount(0);
    setInfiniteDisabled(false);
  };
  const viewViewsModel = async() => {
    const data = await getViewsList(0);
    if (data !== undefined && data.length > 0) {
      setViewModel(true);
      const data1 = await getViewsList(1);
      if (data1.length > 0) {
        setScrollViewData([...data, ...data1]);
        setCount(2);
      } else {
        setScrollViewData(data);
        setInfiniteDisabled(true);
      }
    } else {
      setInfiniteDisabled(true);
    }
  };
  const loadDataConnection = (ev: any) => {
    setTimeout(() => {
      getConnectionListOnScroll();
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  };
  return (
    <>
      <MetaTags>
        <title>Zyapaar</title>
      </MetaTags>
      <IonCard className="profile-details left-cards">
        <>
          {!loading ? (
            <>
              {/* <IonHeader className="card-header" onClick={divclick}> old Profile code */}
              <IonHeader className="card-header d-flex justify-content-center profile-border" onClick={divclick}>
                {/* <div className="myprofile-feeds light-gradient-to-bottom cursor-pointer"> old Profile code */}
                <div className="cursor-pointer">
                  <IonAvatar
                    slot="start"
                    // className="MuiCardHeader-avatar cursor-pointer -- old Profile code"
                    className="cursor-pointer profilebig-icon m-auto mb-2 mt-3"
                  >
                    {profileDetail.profileImg !== null ? (
                      <img onError={(ev) => { ev.target.src = userProfile; }} src={profileDetail.profileImg} />
                    ) : (
                      <img src={userProfile} />
                    )}
                  </IonAvatar>
                  <IonRow className="profileName nowrap-normal text-center">
                    <IonCardTitle className='d-inline-block'>
                      <p className="margin MuiTypography-body1 fw-bold">
                        {profileDetail.name}{' '}
                      </p>
                      {/* <span className="margin MuiTypography-caption color-theme fixed-textline2">
                        {profileDetail.profileTitle !== null && profileDetail.profileTitle !== '' && profileDetail.profileTitle ? profileDetail.profileTitle + ' at ' : ''}
                        {profileDetail.entityName}
                      </span> */}
                      <span className="margin MuiTypography-caption color-theme fixed-textline2">
                        {profileDetail.profileTitle}
                        {profileDetail.profileTitle !== null &&
                        profileDetail.profileTitle !== '' &&
                        profileDetail.entityName !== null &&
                        profileDetail.entityName !== '' &&
                        profileDetail.entityName &&
                        profileDetail.profileTitle ? ' at ' : ''}
                        {profileDetail.entityName}
                      </span>
                    </IonCardTitle>
                  </IonRow>
                </div>
              </IonHeader>
              <IonRow className='d-flex justify-content-center text-center'>
                <IonList
                  lines="none"
                  // className="profile-details-content -- remove class"
                  className="pt-0"
                >
                  <div
                    className="ion-padding-start ion-padding-end cursor-pointer"
                    onClick={() => {
                      history.push('/connection/mynetwork/ALL');
                    }}
                  >
                    <IonCol>
                      {/* <IonIcon icon={peopleOutline} className='font-24 me-2 color-theme-dark'></IonIcon> */}
                      <div className='font-bold'>{profileDetailsCount.connections}</div>
                      {t('userproperties.text3')}
                    </IonCol>
                    {/* <IonCol size="2" className="ion-text-end">
                      {profileDetailsCount.connections}
                    </IonCol> */}
                  </div>
                </IonList>
                <IonList
                  lines="none"
                  className="pt-0"
                >
                  <div
                    className="ion-padding-start ion-padding-end cursor-pointer"
                    onClick={() => viewViewsModel()}
                  >
                    <IonCol>
                      {/* <IonIcon icon={eyeOutline} className='font-24 me-2 color-theme-dark'></IonIcon> */}
                      <div className='font-bold'>{profileDetailsCount.views}</div>
                      {t('feedproperties.text12')}
                    </IonCol>
                    {/* <IonCol size="2" className="ion-text-end">
                      {profileDetailsCount.views}
                    </IonCol> */}
                  </div>
                </IonList>
                {/* Asked By Chirag on 17-Sep-2022 Commented By Arpan */}
                {/* <IonList
                  lines="none"
                  className="full-width-row profile-details-content"
                >
                  <IonRow className="ion-padding-start ion-padding-end">
                    <IonCol size="10">
                      <IonIcon icon={documentTextOutline} className='font-24 me-2 color-theme-dark'></IonIcon>
                      Views on last post
                    </IonCol>
                    <IonCol size="2" className="ion-text-end">
                      {profileDetailsCount.viewOnLastPost}
                    </IonCol>
                  </IonRow>
                </IonList> */}
                {/* <IonList
                  lines="none"
                  className="full-width-row profile-details-content"
                >
                  <IonRow className="ion-padding-start ion-padding-end">
                    <IonCol size="10">
                      <IonIcon icon={newspaperOutline} className='font-24 me-2 color-theme-dark'></IonIcon>
                      Monthly Post
                    </IonCol>
                    <IonCol size="2" className="ion-text-end">
                      {profileDetailsCount.monthlyPost}
                    </IonCol>
                  </IonRow>
                </IonList> */}
              </IonRow>
            </>
          ) : (
            <SkeletonComonOverView />
          )}
        </>
      </IonCard>
      <IonModal
        isOpen={openViewModel}
        cssClass="viewModel"
        onDidDismiss={() => closeViewsModel()}
      >
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          <IonLabel className="MuiTypography-h6">{t('feedproperties.text12')}</IonLabel>
          <IonButton
            fill="clear"
            onClick={closeViewsModel}
            className="close link-btn-tx ion-no-padding ion-no-margin"
          >
            <IonIcon
              icon={close}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </IonButton>
        </IonRow>
        <IonContent>
          <div className="modal-body">
            <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom ">
              {ScrollViewData.length > 0 ? (
                <>
                  {ScrollViewData.length >= 0 &&
                    ScrollViewData.map((list) => (
                      // <IonCol sizeMd="3" sizeXs="6">
                      //   <>
                      //     <div
                      //       className="group-team-center follower-list-card cursor-pointer"
                      //       onClick={() => {
                      //         history.push('/profile/' + list.id);
                      //       }}
                      //     >
                      //       <IonAvatar
                      //         slot="start"
                      //         className="MuiCardHeader-avatar cursor-pointer mx-auto"
                      //       >
                      //         {list.img === null || list.img === '' ? (
                      //           <img src={userProfile} />
                      //         ) : (
                      //           <img onError={(ev) => { ev.target.src = userProfile; }} src={list.img} />
                      //         )}
                      //       </IonAvatar>
                      //       <IonRow className="profileName">
                      //         <IonCardTitle>
                      //           <p className="margin MuiTypography-body1 fixed-textline">
                      //             {list.name}
                      //           </p>
                      //           <span className="margin MuiTypography-caption group-model-text">
                      //             {list.designation}
                      //           </span>
                      //           {getMutualConnectionCount(list.id)}
                      //         </IonCardTitle>
                      //       </IonRow>
                      //     </div>
                      //   </>
                      // 
                      <IonCol sizeMd="3" sizeXs="6">
                      <CommonGridList id={list.id} defultImage={userProfile} img={list.img} name={list.name} subString={list.designation}
                          subString2={list.request} dots={false} redirectLink='profile' />
                          </IonCol>
                    ))}
                </>
              ) : (
                ''
              )}
              {
              loading
                ? <SkeletonComonViewAll column={8} sizeMd={3} sizeXs={6} name={true} title={true} distription={false} link={false} />
                : ''
                }
              <IonInfiniteScroll
                onIonInfinite={loadDataConnection}
                threshold="100px"
                disabled={isInfiniteDisabled}
              >
                <IonInfiniteScrollContent
                  loadingSpinner="circular"
                  loadingText={t('appproperties.text215')}
                ></IonInfiniteScrollContent>
              </IonInfiniteScroll>
            </IonRow>
          </div>
        </IonContent>
      </IonModal>
    </>
  );
};
export default ProfileDetails;
