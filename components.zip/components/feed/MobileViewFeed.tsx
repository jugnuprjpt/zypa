import {
  IonButton,
  IonCol,
  IonContent,
  IonIcon,
  IonModal,
  IonRow
} from '@ionic/react';
import React from 'react';
import { useDispatch } from 'react-redux';
import FeedCard from '../common/FeedCard';
import { arrowBack } from 'ionicons/icons';
const MobileViewFeed = (props) => {
  const dispatch = useDispatch();

  const commentBoxHide = () => {
    props.setCommentMobileViewModel(false);
    dispatch({
      type: 'comment_btn_feedsData',
      showCommentsbox: false,
      index: props.feedKey
    });
  };
  return (
    <>
      <IonModal
        isOpen={props.commentMobileViewModel}
        onDidDismiss={commentBoxHide}
        cssClass="postCommentModal"
        id ='feed-modal'
      >
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          <IonButton
            fill="clear"
            onClick={commentBoxHide}
            className="close link-btn-tx ion-no-padding ion-no-margin pt-0"
          >
            <IonIcon
              icon={arrowBack}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </IonButton>
        </IonRow>
        <IonContent>
          <IonRow className="plane-bg">
            <IonRow className="container">
              <div className="row full-width-row main-page-content-row">
                <IonCol
                  size-lg="12"
                  size-md="12"
                  size-xs="12"
                  className="right-col"
                >
                    <FeedCard
                      feeds={props.feeds}
                      feedKey={props.feedKey}
                      origin={props.origin}
                      originId={props.originId}
                      isMobile ={true}
                    />
                </IonCol>
              </div>
            </IonRow>
          </IonRow>
        </IonContent>
      </IonModal>
    </>
  );
};
export default MobileViewFeed;
