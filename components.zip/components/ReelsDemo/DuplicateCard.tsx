import React, { useRef, useState , useEffect} from "react";
// import VideoHeader from "./VideoHeader";
import VideoFooter from "./VideoFooter";
// import "./videoCard.css";
import ReactDOM from "react-dom";

function DuplicateCard({ url, likes, shares, channel, avatarSrc, song }) {

const handleClick = (e) => {
    e.preventDefault();
    e.target.muted = !e.target.muted;
  };

  const handleScroll = (e) => {
    let next = ReactDOM.findDOMNode(e.target).parentNode.nextSibling;
    if (next) {
      next.scrollIntoView();
      e.target.muted = true;
    }
  };

  const callback = (entries) => {
    entries.forEach((entry)=>{
        let ele = entry.target.childNodes[0];
        console.log(ele)
        ele.play().then(()=>{
            if (!ele.paused && !entry.isIntersecting) {
                ele.paused()
                
            }
        })

    })
}
  
  let observer = new IntersectionObserver(callback, {threshold: 1.0});
  useEffect(()=>{
    const elements = document.querySelectorAll(".videos")
    elements.forEach((element)=>{
        observer.observe(element)
    })
    return ()=>{
      observer.disconnect();
    }
  },[])

  return (
    <>
      <div className="videoCard">
        {/* <VideoHeader /> */}
        <video
          src={url}
          className="videoCard_player"
          onEnded={handleScroll}
          muted="muted"
          onClick={handleClick}
          controls
          autoPlay
         
        />
      </div>
    </>
  );
}

export default DuplicateCard;
