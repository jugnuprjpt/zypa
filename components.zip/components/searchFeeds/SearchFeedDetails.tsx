/* eslint-disable react/jsx-key */
import { IonRow, IonButton, IonCard, IonAvatar, IonCol, IonInfiniteScroll, IonInfiniteScrollContent, IonIcon, IonCardTitle, IonLabel } from '@ionic/react';
import React, { useEffect, useRef, useState } from 'react';
import CallFor from '../../util/CallFor';
import groupLogo from '../../assets/img/group-profile-placeholder.png';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { useHistory } from 'react-router';
import companyProfile from '../../assets/img/page-company-profile-placeholder.png';
import FeedDetails from '../common/FeedsDetails';
import { ellipsisVertical, eyeOutline, list } from 'ionicons/icons';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import ProductDetail from '../company/productDetail';
import SkeletonNotification from '../common/skeleton/SkeletonNotification';
import { Device } from '@capacitor/device';
import productImg from '../../assets/img/Product_default.png';
import { Swiper, SwiperSlide } from 'swiper/react';
import ButtonComponent from '../common/ButtonComponent';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import { useSelector } from 'react-redux';
import ToastCommon from '../common/ToastCommon';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import { useTranslation } from 'react-i18next';

const SearchFeedsDetails = (props: any) => {
  const { t } = useTranslation();
  const profileDetail = useSelector(getProfileDetails);
  const history = useHistory();
  const [deviceInfo, setDeviceInfo] = useState();
  const [showToast, setShowToast] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [allBtnClass, setAllBtnClass] = useState('ion-button-color');
  const [confirmModel, setConfirmModel] = useState(false);
  const scrollElement = useRef(null);
  const [postBtnClass, setPostBtnClass] = useState('category-btn-color');
  const [peopleBtnClass, setPeopleBtnClass] = useState('category-btn-color');
  const [companyBtnClass, setCompanyBtnClass] = useState('category-btn-color');
  const [groupsBtnClass, setGroupsBtnClass] = useState('category-btn-color');
  const [productsBtnClass, setProductBtnClass] = useState('category-btn-color');
  const [buyersBtnClass, setBuyersBtnClass] = useState('category-btn-color');
  const [pageBtnClass, setPageBtnClass] = useState('category-btn-color');
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [removeConfirmModel, setRemoveConfirmModel] = useState(false);
  const [categoryType, setCategoryType] = useState('ALL');
  const [count, setCount] = useState(0);
  const [noDataFound, setNoDataFound] = useState(true);
  const [productDetailShowModal, setProductDetailShowModal] = useState(false);
  const [productDetails, setProductDetails] = useState();
  const decodedSearchValue = decodeURIComponent(escape(window.atob(props.searchValue.replace('&quot;', '/'))));
  const [loading, setLoading] = useState(false);
  useEffect(async () => {
    setDeviceInfo(await Device.getInfo());
    getSearchDataCount();
    getSearchData(props.searchType, 0);
  }, []);
  const [searchFeedData, setSearchFeedData] = useState({
    feed: [],
    company: [],
    user: [],
    group: [],
    product: [],
    page: [],
    buyers: []
  });

  const [searchCount, setSearchCount] = useState({
    user: 0,
    company: 0,
    group: 0,
    feed: 0,
    product: 0,
    page: 0,
    buyers: 0
  });
  const getSearchDataCount = async () => {
    const response = await CallFor('api/v1.1/searches/keywords/' + decodedSearchValue + '/count',
      'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      console.log(json1Response);
      if (json1Response.data !== null) {
        setSearchCount(json1Response.data);
      }
    }
  };
  const getSearchData = async (category: string, page: number) => {
    setSearchFeedData({
      feed: [],
      company: [],
      user: [],
      group: [],
      product: [],
      page: [],
      buyers: []
    });
    if (category === 'ALL') {
      setAllBtnClass('ion-button-color');
      setPostBtnClass('category-btn-color');
      setPeopleBtnClass('category-btn-color');
      setCompanyBtnClass('category-btn-color');
      setGroupsBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
      setPageBtnClass('category-btn-color');
      setBuyersBtnClass('category-btn-color');
    } else if (category === 'FEED') {
      setAllBtnClass('category-btn-color');
      setPostBtnClass('ion-button-color');
      setPeopleBtnClass('category-btn-color');
      setCompanyBtnClass('category-btn-color');
      setGroupsBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
      setPageBtnClass('category-btn-color');
      setBuyersBtnClass('category-btn-color');
    } else if (category === 'USER') {
      setAllBtnClass('category-btn-color');
      setPeopleBtnClass('ion-button-color');
      setPostBtnClass('category-btn-color');
      setCompanyBtnClass('category-btn-color');
      setGroupsBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
      setPageBtnClass('category-btn-color');
      setBuyersBtnClass('category-btn-color');
    } else if (category === 'BUYER') {
      setAllBtnClass('category-btn-color');
      setPostBtnClass('category-btn-color');
      setBuyersBtnClass('ion-button-color');
      setCompanyBtnClass('category-btn-color');
      setPeopleBtnClass('category-btn-color');
      setGroupsBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
      setPageBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
    } else if (category === 'COMPANY') {
      setAllBtnClass('category-btn-color');
      setPostBtnClass('category-btn-color');
      setCompanyBtnClass('ion-button-color');
      setPeopleBtnClass('category-btn-color');
      setGroupsBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
      setBuyersBtnClass('category-btn-color');
      setPageBtnClass('category-btn-color');
    } else if (category === 'GROUP') {
      setGroupsBtnClass('ion-button-color');
      setAllBtnClass('category-btn-color');
      setPostBtnClass('category-btn-color');
      setCompanyBtnClass('category-btn-color');
      setBuyersBtnClass('category-btn-color');
      setPeopleBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
      setPageBtnClass('category-btn-color');
      scrollElement.current.scrollLeft = 1000;
    } else if (category === 'PRODUCT') {
      setGroupsBtnClass('category-btn-color');
      setAllBtnClass('category-btn-color');
      setPostBtnClass('category-btn-color');
      setCompanyBtnClass('category-btn-color');
      setPeopleBtnClass('category-btn-color');
      setBuyersBtnClass('category-btn-color');
      setProductBtnClass('ion-button-color');
      // setEventsBtnClass('category-btn-color');
      setPageBtnClass('category-btn-color');
      scrollElement.current.scrollLeft = 1000;
    } else if (category === 'PAGE') {
      setGroupsBtnClass('category-btn-color');
      setAllBtnClass('category-btn-color');
      setPostBtnClass('category-btn-color');
      setCompanyBtnClass('category-btn-color');
      setBuyersBtnClass('category-btn-color');
      setPeopleBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
      setPageBtnClass('ion-button-color');
      scrollElement.current.scrollLeft = 1000;
    }
    setCategoryType(category);
    setInfiniteDisabled(false);
    getApiCall(category, 0, false);
  };
  const [SuppliersData, setSupplierData] = useState([]);
  const getSearchSupplierData = async (page, pageCount, scrolling) => {
    const response = await CallFor('api/v1.1/searches/keywords/' + decodedSearchValue + '/types/SUPPLIER?page=' + page + '&size=' + pageCount,
      'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data !== null && json1Response.data.supplier) {
        if (scrolling) {
          setSupplierData(...SuppliersData, ...json1Response.data.supplier);
        } else {
          setSupplierData(json1Response.data.supplier);
        }
      } else {
        setNoDataFound(true);
      }
    }
  };
  const connectionBtnHandler = async (userId) => {
    const response = await CallFor(
      'api/v1.1/connect/' + userId + '/INITIATE',
      'POST',
      '{"status": "INITIATE" }',
      'Auth'
    );
    if (response.status === 200) {
      getApiCall(categoryType, 0, false);
      setShowToastMsg(t('toastmessages.toast13'));
      setShowToast(true);
    } else if (response.status === 400) {
      const json1Response = await response.json();
      if (json1Response.error.message === t('userproperties.text21')) {
        setShowToastMsg(t('userproperties.text21'));
        setShowToast(true);
      }
    }
  };
  const getApiCall = async (category, page, scrolling) => {
    // setLoading(true);
    let pageCount = 10;
    if (category === 'ALL') {
      pageCount = 5;
    }
    const allFeedDataResponse = await CallFor('api/v1.1/searches/keywords/' + decodedSearchValue + '/types/' + category + '?page=' + page + '&size=' + pageCount,
      'GET', null, 'Auth');
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      if (scrolling) {
        if (json1Response.data != null && (json1Response.data.user.length > 0 || json1Response.data.company.length > 0 ||
          json1Response.data.group.length > 0 || json1Response.data.feed.length > 0 || json1Response.data.buyers.length > 0 || json1Response.data.product.length > 0 || json1Response.data.page.length > 0)) {
          const data = {
            feed: [],
            company: [],
            user: [],
            group: [],
            product: [],
            page: [],
            buyers: []
          };
          if (json1Response.data.user.length !== 0) {
            data.user = [...searchFeedData.user, ...json1Response.data.user];
          } else {
            data.user = [...searchFeedData.user];
          }
          if (json1Response.data.company.length !== 0) {
            data.company = [...searchFeedData.company, ...json1Response.data.company];
          } else {
            data.company = [...searchFeedData.company];
          }
          if (json1Response.data.group.length !== 0) {
            data.group = [...searchFeedData.group, ...json1Response.data.group];
          } else {
            data.group = [...searchFeedData.group];
          }
          if (json1Response.data.feed.length !== 0) {
            data.feed = [...searchFeedData.feed, ...json1Response.data.feed];
          } else {
            data.feed = [...searchFeedData.feed];
          }
          if (json1Response.data.product.length !== 0) {
            data.product = [...searchFeedData.product, ...json1Response.data.product];
          } else {
            data.product = [...searchFeedData.product];
          }
          if (json1Response.data.page.length !== 0) {
            data.page = [...searchFeedData.page, ...json1Response.data.page];
          } else {
            data.page = [...searchFeedData.page];
          }
          if (json1Response.data.buyers.length !== 0) {
            data.buyers = [...searchFeedData.buyers, ...json1Response.data.buyers];
          } else {
            data.buyers = [...searchFeedData.buyers];
          }
          setSearchFeedData(data);
        } else {
          setInfiniteDisabled(true);
        }
      } else {
        if (json1Response.data !== null) {
          setSearchFeedData(json1Response.data);
          if (json1Response.data.user.length !== 0) {
            setNoDataFound(false);
          }
          if (json1Response.data.company.length !== 0) {
            setNoDataFound(false);
          }
          if (json1Response.data.group.length !== 0) {
            setNoDataFound(false);
          }
          if (json1Response.data.feed.length !== 0) {
            setNoDataFound(false);
          }
          if (json1Response.data.product.length !== 0) {
            setNoDataFound(false);
          } else {
            if (category === 'ALL' || category === 'PRODUCT') {
              getSearchSupplierData(0, 5, false);
            }
          }
          if (json1Response.data.page.length !== 0) {
            setNoDataFound(false);
          }
          if (json1Response.data.buyers.length !== 0) {
            setNoDataFound(false);
          }
        }
        setCount(1);
      }
    }
    // setLoading(false);
  };
  const btnClickHandler = (page, id) => {
    history.push('/' + page + '/' + id);
  };
  const linkRedireaction = (category: string, page: number) => {
    if (deviceInfo !== undefined && (deviceInfo.platform === 'ios' || deviceInfo.platform === 'android')) {
      getSearchData(category, 0);
    } else {
      history.push('/searchFeeds/' + props.searchValue + '/' + category);
    }
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getApiCall(categoryType, count, true);
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  };
  const productDetailsHandler = async (id) => {
    const allFeedDataResponse = await CallFor('api/v1.1/products/' + id,
      'GET', null, 'Auth');
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      setProductDetails(json1Response.data);
      setProductDetailShowModal(true);
    }
  };
  const [removeConnectionModalData, setRemoveConnectionModalData] = useState({});
  const withdrawMobile = (reference, name, userId) => {
    setConfirmModel(true);
    const removeConfirmMessage = <IonLabel>{t('appproperties.text9a')} <strong>{name}</strong>{t('appproperties.text9b')}</IonLabel>;
    setRemoveConnectionModalData({ userId: userId, reference: reference, name: removeConfirmMessage });
  };
  const actionBtnHandler = async (fromUserId, type, id) => {
    const response = await CallFor('api/v1.1/connect/action/' + fromUserId + '/' + type, 'POST', '{ "message":"' + type + '", "id":"' + id + '"}', 'Auth');
    if (response.status === 200) {
      getApiCall(categoryType, 0, false);
      // history.push('/profile/' + props.userId);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      const jsonRes = response.json();
      console.log(jsonRes);
    }
  };
  const actionBtnHandlerReceived = async (reference, type, userid) => {
    const response = await CallFor('api/v1.1/connect/action/' + userid + '/' + type.toUpperCase(), 'POST', '{ "message":"' + type + '", "id":"' + reference + '"}', 'Auth');
    if (response.status === 200) {
      getApiCall(categoryType, 0, false);
      // setAdminInvitation(adminInvite.filter((item) => item.requestId !== id));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      const jsonRes = response.json();
      console.log(jsonRes);
    }
  };
  const confirmMessage = (
    <IonLabel>
     {t('userproperties.text1')}
    </IonLabel>
  );
  const removeConnectBtnHandler = async(userId) => {
    const response = await CallFor(
      'api/v1.1/users/connections/' + userId + '/remove',
      'POST',
      '{ "message":"", "id":"' + userId + '"}',
      'Auth'
    );
    if (response.status === 200) {
      getApiCall(categoryType, 0, false);
      setShowToastMsg(t('userproperties.text23'));
      setShowToast(true);
    } else if (response.status === 404) {
      const json1Response = await response.json();
      setShowToastMsg(json1Response.error.message);
      setShowToast(true);
    }
  };
  return (
    <IonRow className="display-grid full-width-row ion-padding top">
      <IonRow className='gup-btn-action swiper-btn-content position-sticky bg-theme pt-lg-0 pt-2' ref={scrollElement}>
        {/* <IonButton
          className={allBtnClass + ' button-small'}
          shape="round"
          onClick={() => linkRedireaction('ALL', 0)}
        >
          All
        </IonButton> */}
        {searchCount.user !== undefined && searchCount.user !== 0
          ? <IonButton
            className={peopleBtnClass + ' button-small'}
            shape="round"
            onClick={() => linkRedireaction('USER', 0)}
          >
            <span className='searchcount'>{searchCount.user}</span>
            {t('appproperties.text30')}
          </IonButton>
          : ''}
        {searchCount.feed !== undefined && searchCount.feed !== 0
          ? <IonButton
            className={postBtnClass + ' button-small'}
            shape="round"
            onClick={() => linkRedireaction('FEED', 0)}
          >
            <span className='searchcount'>{searchCount.feed}</span>
            {t('appproperties.text31')}
          </IonButton>
          : ''}
        {searchCount.product !== undefined && searchCount.product !== 0
          ? <IonButton
            className={productsBtnClass + ' button-small'}
            shape="round"
            onClick={() => linkRedireaction('PRODUCT', 0)}
          >
            <span className='searchcount'>{searchCount.product}</span>
            {t('appproperties.text32')}
          </IonButton>
          : ''}
        {searchCount.buyers !== undefined && searchCount.buyers !== 0
          ? <IonButton
            className={buyersBtnClass + ' button-small'}
            shape="round"
            onClick={() => linkRedireaction('BUYER', 0)}
          >
            <span className='searchcount'>{searchCount.buyers}</span>
            {t('appproperties.text33')}
          </IonButton>
          : ''}
        {searchCount.company !== undefined && searchCount.company !== 0
          ? <IonButton
            className={companyBtnClass + ' button-small'}
            shape="round"
            onClick={() => linkRedireaction('COMPANY', 0)}
          >
            <span className='searchcount'>{searchCount.company}</span>
            {t('appproperties.text34')}
          </IonButton>
          : ''}
        {searchCount.group !== undefined && searchCount.group !== 0
          ? <IonButton
            className={groupsBtnClass + ' button-small'}
            shape="round"
            onClick={() => linkRedireaction('GROUP', 0)}
          >
            <span className='searchcount'>{searchCount.group}</span>
            {t('appproperties.text35')}
          </IonButton>
          : ''}
        {searchCount.page !== undefined && searchCount.page !== 0
          ? <IonButton
            className={pageBtnClass + ' button-small'}
            shape="round"
            onClick={() => linkRedireaction('PAGE', 0)}
          >
            <span className='searchcount'>{searchCount.page}</span>
            {t('appproperties.text18')}
          </IonButton>
          : ''}

      </IonRow>
      <IonRow className='pb-4'>
        {loading
          ? <SkeletonNotification />
          : noDataFound
            ? <>
              {(() => {
                if (categoryType === 'ALL') {
                  if (SuppliersData.length !== 0) {
                    return ('');
                  }
                  return (
                    <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('feedproperties.text18')}</p>
                  );
                } else {
                  return (
                    <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text10')}</p>
                  );
                }
              })()}</>
            : <>
              {searchFeedData.user != null && searchFeedData.user.length !== 0
                ? <>
                  <h2>{t('appproperties.text30')}</h2>
                  {searchFeedData.user.map((user, i) => (
                    <>
                      <IonCard className="MuiPaper-rounded full-width-row border-radius search-feed-item cursor-pointer shadow-none" onClick={() => btnClickHandler('profile', user.id)} key={i}>
                        <IonRow className="ps-2">
                          <IonCol className='d-flex ion-justify-content-between ion-align-items-center'>
                            <div className="myprofile-feeds ion-no-padding d-flex ion-justify-content-start">
                              <div>
                                <IonAvatar className="MuiAvatar ion-margin-end">
                                  {user.profileImg !== null
                                    ? <img onError={(ev) => { ev.target.src = userProfile; }} src={user.profileImg} />
                                    : <img src={userProfile} />}
                                </IonAvatar>
                              </div>
                              <IonRow className="display-grid">
                                {user.fullName}
                                <span className="margin MuiTypography-caption group-model-text fixed-textline1">
                                  {user.profileTitle}
                                </span>
                              </IonRow>
                            </div>
                            <IonButton className='ion-button-color ion-float-right dn-mobile' onClick={() => btnClickHandler('profile', user.id)}>
                              {t('appproperties.text37')}
                            </IonButton>
                            <IonIcon className='icon-mobile show-mobile' icon={eyeOutline} onClick={() => btnClickHandler('profile', user.id)}></IonIcon>
                          </IonCol>
                        </IonRow>
                      </IonCard>
                    </>
                  ))}
                  {categoryType === 'ALL' ? <div className='d-flex justify-content-end w-100 mt-1 font-14'><a onClick={() => linkRedireaction('USER', 0)}>{t('commonproperties.text3')}</a></div> : ''}
                </>
                : ''}
              {searchFeedData.feed != null && searchFeedData.feed.length !== 0
                ? <><h2>{t('appproperties.text31')}</h2><div className="search-feed-content">
                  <IonCol size='8' className='full-width-row'>
                    {Object.entries(searchFeedData.feed).map(([feedKey, feeds]) => (
                      <FeedDetails feeds={feeds} feedKey={feedKey} origin='USER' originId='0' />
                    ))}
                  </IonCol>
                </div></>
                : ''
              }
              {searchFeedData.buyers != null && searchFeedData.buyers.length !== 0
                ? <>
                  <h2>{t('appproperties.text33')}</h2>
                  {searchFeedData.buyers.map((buyer, i) => (
                    <>
                      <IonCard className="MuiPaper-rounded full-width-row border-radius search-feed-item cursor-pointer shadow-none" key={i}>
                        <IonRow className="ps-2">
                          <IonCol className='d-flex ion-justify-content-between ion-align-items-center' onClick={() => btnClickHandler('profile', buyer.id)}>
                            <div className="myprofile-feeds ion-no-padding d-flex ion-justify-content-start">
                              <div>
                                <IonAvatar className="MuiAvatar ion-margin-end">
                                  {buyer.img !== null
                                    ? <img onError={(ev) => { ev.target.src = userProfile; }} src={buyer.img} />
                                    : <img src={userProfile} />}
                                </IonAvatar>
                              </div>
                              <IonRow className="display-grid">
                                {buyer.name}
                                <span className="margin MuiTypography-caption group-model-text fixed-textline1">
                                  {buyer.profileTitle}
                                </span>
                              </IonRow>
                            </div>
                            {/* <IonButton className='ion-button-color ion-float-right dn-mobile' onClick={() => btnClickHandler('profile', buyer.id)}>
                  View
                </IonButton> */}
                          </IonCol>
                          <IonRow className="right pr-details-action d-flex align-items-center">
                            {profileDetail.id !== buyer.id &&
                              profileDetail.id !== undefined &&
                              buyer.id !== undefined
                              ? (
                                <>
                                  {buyer.connection === 'default'
                                    ? (
                                      <ButtonComponent
                                        btnClick={connectionBtnHandler}
                                        field1={buyer.id}
                                        className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 ion-margin-end"
                                        size='small'
                                        name={t('appproperties.text28')} parametersPass={1} />
                                    )
                                    : buyer.connection === 'withdraw'
                                      ? (
                                        <ButtonComponent
                                          btnClick={withdrawMobile}
                                          field1={buyer.reference}
                                          field2={buyer.name}
                                          field3={buyer.id}
                                          size="small"
                                          className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 ion-margin-end"
                                          name={t('appproperties.text40')}
                                          parametersPass={3}
                                        />
                                      )
                                      : buyer.connection === 'reject'
                                        ? (
                                          <>
                                            <ButtonComponent
                                              className="btn-sm-cn ion-button-color ion-padding-end pe-0 ion-margin-end me-2"
                                              btnClick={actionBtnHandlerReceived}
                                              field1={buyer.reference}
                                              field2="ACCEPT"
                                              field3={buyer.id}
                                              size='small'
                                              name={t('appproperties.text20')}
                                              parametersPass={3}
                                            />
                                            <ButtonComponent
                                              className="category-btn-color cursor-pointer btn-sm-cn pe-0 me-2"
                                              btnClick={actionBtnHandlerReceived}
                                              field1={buyer.reference}
                                              field2="REJECT"
                                              field3={buyer.id}
                                              size='small'
                                              name={t('appproperties.text19')}
                                              parametersPass={3}
                                            />
                                          </>
                                        )
                                        : buyer.connection === 'accept'
                                          ? (
                                                  <>
                                                  <ButtonComponent
                                                  btnClick={removeConnectBtnHandler}
                                                  className='btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 ion-margin-end'
                                                  size='small'
                                                  field1={buyer.id}
                                                  name={t('appproperties.text370')}
                                                  parametersPass={1}
                                              />
                                              </>
                                            )

                                        : ''}
                                </>
                              )
                              : (
                                ''
                              )}
                          </IonRow>
                        </IonRow>
                      </IonCard>
                      <div>
                      </div>
                    </>
                  ))}
                  {categoryType === 'ALL' ? <div className='d-flex justify-content-end w-100 mt-1 font-14'><a onClick={() => linkRedireaction('BUYER', 0)}>{t('commonproperties.text3')}</a></div> : ''}
                </>
                : ''}
              {searchFeedData.product != null && searchFeedData.product.length > 0
                ? <><h2>{t('appproperties.text32')}</h2>
                  <IonRow className="MuiPaper-rounded full-width-row border-radius search-feed-item cursor-pointer shadow-none">
                    {searchFeedData.product.map((product, i) => (
                      <IonCol sizeMd="4" sizeXs='6' className="d-flex" key={i}>
                        <IonCard
                          className="cursor-pointer w-100 m-lg-2 m-0"
                        >
                          <IonRow className="profileName text-center" onClick={() => productDetailsHandler(product.id)}>
                            {product?.productlogo === undefined || product?.productlogo === null
                              ? (
                                <img src={productImg} alt={t('appproperties.text277')} />
                              )
                              : <>
                                <img src={product?.productlogo} alt={t('appproperties.text277')} />
                                {/* {product?.logo !== null && product?.logo.length > 1
                                  ? (
                                    <Swiper
                                      id="main"
                                      navigation
                                      pagination={{
                                        clickable: true,
                                        renderBullet: function(index, className) {
                                          return '<span class="' + className + '"><img class="pagination-bullet"/></span>';
                                        }
                                      }}
                                      spaceBetween={0}
                                      slidesPerView={1}
                                    >
                                      {product.logo.map((photo, index) => (
                                        <SwiperSlide key={index} className='d-flex justify-content-center'>
                                          <img
                                            src={photo}
                                          />
                                        </SwiperSlide>
                                      ))
                                      }
                                    </Swiper>)
                                  : <img src={product.logo} />
                                } */}
                              </>
                            }
                            <div className='px-lg-3 pb-lg-3 px-2 pb-2 text-center'>
                              <IonCardTitle className='text-left' 
                              // onClick={() => productDetailsHandler(product.id)}
                              >
                                <p className="title fixed-textline2 text-center">
                                  {product.productname}</p>
                                <p className="brand">{product.brandName}</p>
                              </IonCardTitle>
                              {product.entityname
                                ? <div 
                                onClick={(e) => { e.stopPropagation(); history.push('/companyDetail/' + product.entityid); }}
                                >
                                  <p className="title">{product.entityname}</p>
                                </div>
                                : ''
                              }
                            </div>
                          </IonRow>
                        </IonCard>
                      </IonCol>
                    ))}
                  </IonRow>
                  {categoryType === 'ALL' ? <div className='d-flex justify-content-end w-100 mt-1 font-14'><a onClick={() => linkRedireaction('PRODUCT', 0)}>{t('commonproperties.text3')}</a></div> : ''}
                </>
                : <>
                  {(categoryType === 'ALL' || categoryType === 'PRODUCT') && SuppliersData.length > 0
                    ? <>
                      <h2>{t('appproperties.text32')}</h2>
                      {SuppliersData.map((SuppliersData, i) => (
                        <IonCard className="MuiPaper-rounded full-width-row border-radius search-feed-item cursor-pointer shadow-none" onClick={() => btnClickHandler('profile', SuppliersData.id)} key={i}>
                          <IonRow className="ps-2">
                            <IonCol className='d-flex ion-justify-content-between ion-align-items-center'>
                              <div className="myprofile-feeds ion-no-padding d-flex ion-justify-content-start">
                                <div>
                                  <IonAvatar className="MuiAvatar ion-margin-end">
                                    {SuppliersData.logo !== null
                                      ? <img onError={(ev) => { ev.target.src = userProfile; }} src={SuppliersData.logo} />
                                      : <img src={userProfile} />}
                                  </IonAvatar>
                                </div>
                                <IonRow className="display-grid">
                                  {SuppliersData.name}
                                  <span className="margin MuiTypography-caption group-model-text fixed-textline1">
                                    {SuppliersData.profileTitle}
                                  </span>
                                </IonRow>
                              </div>
                              <IonButton className='ion-button-color ion-float-right dn-mobile' onClick={() => btnClickHandler('profile', SuppliersData.id)}>
                                {t('appproperties.text37')}
                              </IonButton>
                              <IonIcon className='icon-mobile show-mobile' icon={eyeOutline} onClick={() => btnClickHandler('profile', SuppliersData.id)}></IonIcon>
                            </IonCol>
                          </IonRow>
                        </IonCard>
                      ))}
                    </>
                    : ''}
                </>}
              {searchFeedData.company != null && searchFeedData.company.length > 0
                ? <><h2>{t('appproperties.text34')}</h2>
                  {searchFeedData.company.map((company, i) => (
                    <IonCard className="MuiPaper-rounded full-width-row border-radius search-feed-item cursor-pointer shadow-none" onClick={() => btnClickHandler('companyDetail', company.id)} key={i}>
                      <IonRow className="ps-2">
                        <IonCol>
                          <div className="myprofile-feeds ion-no-padding">
                            <IonAvatar className="MuiAvatar ion-margin-end">
                              {company.entityLogo !== null
                                ? <img onError={(ev) => { ev.target.src = companyProfile; }} src={company.entityLogo} />
                                : <img src={companyProfile} />
                              }
                            </IonAvatar>
                            <IonRow className="display-grid">
                              {company.name}
                              <span className="margin MuiTypography-caption group-model-text">
                                {company.profileTitle}
                              </span>
                              <span className="margin MuiTypography-caption group-model-text">
                                {company.datetime}
                              </span>
                            </IonRow>
                          </div>
                          <IonButton className='ion-button-color ion-float-right dn-mobile' onClick={() => btnClickHandler('companyDetail', company.id)}>
                            {t('appproperties.text37')}
                          </IonButton>
                          <IonIcon className='icon-mobile show-mobile' icon={eyeOutline} onClick={() => btnClickHandler('companyDetail', company.id)}></IonIcon>

                        </IonCol>
                        <div>
                          <a href='#' onClick={() => { linkRedireaction('USER', 0); }}></a>
                        </div>
                      </IonRow>
                    </IonCard>
                  ))}
                  {categoryType === 'ALL' ? <div className='d-flex justify-content-end w-100 mt-1 font-14'><a onClick={() => linkRedireaction('COMPANY', 0)}>{t('commonproperties.text3')}</a></div> : ''}
                </>
                : ''}
              {searchFeedData.group != null && searchFeedData.group.length !== 0
                ? <><h2>{t('appproperties.text35')}</h2>
                  {searchFeedData.group.map((groups, i) => (
                    <IonCard className="MuiPaper-rounded full-width-row border-radius  search-feed-item cursor-pointer shadow-none" onClick={() => btnClickHandler('groups', groups.id)} key={i}>
                      <IonRow className="ps-2">
                        <IonCol>
                          <div className="myprofile-feeds ion-no-padding">
                            <IonRow>
                              <IonAvatar className="MuiAvatar ion-margin-end">
                                {groups.logo !== null
                                  ? <img onError={(ev) => { ev.target.src = groupLogo; }} src={groups.logo} />
                                  : <img src={groupLogo} />}
                              </IonAvatar>
                            </IonRow>
                            <IonRow className="display-grid">
                              {groups.name}
                              <span className="margin MuiTypography-caption group-model-text">
                                {groups.about}
                              </span>
                              <span className="margin MuiTypography-caption group-model-text">
                                {groups.datetime}
                              </span>
                            </IonRow>
                          </div>
                          <IonButton className='ion-button-color ion-float-right dn-mobile' onClick={() => btnClickHandler('groups', groups.id)}>
                            {t('appproperties.text37')}
                          </IonButton>
                          <IonIcon className='icon-mobile show-mobile' icon={eyeOutline} onClick={() => btnClickHandler('groups', groups.id)}></IonIcon>
                        </IonCol>
                      </IonRow>
                    </IonCard>
                  ))}
                  {categoryType === 'ALL' ? <div className='d-flex justify-content-end w-100 mt-1 font-14'><a onClick={() => linkRedireaction('GROUP', 0)}>{t('commonproperties.text3')}</a></div> : ''}
                </>
                : ''}
              {searchFeedData.page != null && searchFeedData.page.length !== 0
                ? <><h2>{t('appproperties.text18')}</h2>
                  {searchFeedData.page.map((pages, i) => (
                    <IonCard className="MuiPaper-rounded full-width-row border-radius  search-feed-item cursor-pointer shadow-none" onClick={() => btnClickHandler('pageDetails', pages.id)} key={i}>
                      <IonRow className="ps-2">
                        <IonCol>
                          <div className="myprofile-feeds ion-no-padding">
                            <IonRow >
                              <IonAvatar className="MuiAvatar ion-margin-end">
                                {pages.logo !== null
                                  ? <img onError={(ev) => { ev.target.src = groupLogo; }} src={pages.logo} />
                                  : <img src={groupLogo} />
                                }
                              </IonAvatar>
                            </IonRow>
                            <IonRow className="display-grid">
                              {pages.name}
                              <span className="margin MuiTypography-caption group-model-text">
                                {pages.about}
                              </span>
                              <span className="margin MuiTypography-caption group-model-text">
                                {pages.datetime}
                              </span>
                            </IonRow>
                          </div>
                          <IonButton className='ion-button-color ion-float-right dn-mobile' onClick={() => btnClickHandler('pageDetails', pages.id)}>
                            {t('appproperties.text37')}
                          </IonButton>
                          <IonIcon className='icon-mobile show-mobile' icon={eyeOutline} onClick={() => btnClickHandler('pageDetails', pages.id)}></IonIcon>
                        </IonCol>
                      </IonRow>
                    </IonCard>
                  ))}
                  {categoryType === 'ALL' ? <div className='d-flex justify-content-end w-100 mt-1 font-14'><a onClick={() => linkRedireaction('PAGE', 0)}>{t('commonproperties.text3')}</a></div> : ''}
                </>
                : ''}
            </>
        }
        <IonInfiniteScroll
          onIonInfinite={loadData}
          threshold="100px"
          disabled={isInfiniteDisabled}
        >
          <IonInfiniteScrollContent
            loadingSpinner="circular"
            loadingText={t('appproperties.text215')}
          ></IonInfiniteScrollContent>
        </IonInfiniteScroll>
      </IonRow>
      {productDetailShowModal
        ? (
          <ProductDetail
            setProductDetailShowModal={setProductDetailShowModal}
            productDetailShowModal={productDetailShowModal}
            seteditFromShow={false}
            editFromshow={false}
            userFormState={productDetails}
            companyId={0}
            adminflag={false}
          />
        )
        : (
          ''
        )}
      <ToastCommon
        setShowToast={setShowToast}
        setShowToastMsg={setShowToastMsg}
        showToast={showToast}
        showToastMsg={showToastMsg}
        duration={5000}
      />
      <ConfirmModelCommon
        header={t('appproperties.text22')}
        message={confirmMessage}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text21')}
        confirmModel={confirmModel}
        setConfirmModel={setConfirmModel}
        deleteBtnHandler={actionBtnHandler}
        iD={removeConnectionModalData.reference}
        fromId={removeConnectionModalData.userId}
        type='CANCEL'
      />
      {/* {removeConfirmModel
         ? <ConfirmModelCommon
      header='Remove Connection'
      message={removeConfirmMessage}
      btn1='cancel'
      btn2='Remove'
      confirmModel={removeConfirmModel}
      setConfirmModel={setRemoveConfirmModel}
      deleteBtnHandler={removeModalConnectionBtnHandler}/>
         : ''} */}
    </IonRow>
  );
};
export default SearchFeedsDetails;
