import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonHeader,
  IonIcon,
  IonItem,
  IonList,
  IonRow
} from '@ionic/react';
import { arrowForward } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';

const MyPages = () => {
  const { t } = useTranslation();
  const myPages = [
    {
      id: 1,
      name: 'Shubham Gupta',
      designation: 'Purchase Manager at Istpl',
      profileImg:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      verified: true
    },
    {
      id: 2,
      name: 'John Parde',
      designation: 'Purchase Manager at ISourcing',
      profileImg:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8JZb1dRwy8UxASU66Oit--WrtJr0beom2ww&usqp=CAU',
      verified: true
    }
  ];
  return (
    <IonCard className="profile-details left-cards MuiPaper-rounded custom-scroll-header">
      <IonHeader className="card-header-text ion-padding-start ion-padding-end ion-no-border">
        <IonCol size="9" className=" ion-no-padding ">
          <p className="ion-font-color">{t('pageproperties.text16')}</p>
        </IonCol>
        <IonCol size="3" className="ion-no-padding">
          <a className="ion-float-right ion-padding-top">{t('commonproperties.text3')}</a>
        </IonCol>
      </IonHeader>
      <IonRow>
        <IonList lines="none" className="full-width-row">
          {myPages.map((detail) => {
            return (
              <>
                <IonItem>
                  <IonCol size="10">
                    <div className="myprofile-feeds ion-no-padding">
                      <IonAvatar className="MuiAvatar ">
                        <img src={detail.profileImg} />
                      </IonAvatar>
                      <IonRow className="profileName">
                        <IonCardTitle className="ion-padding-start">
                          <p className="margin">{detail.name}</p>
                          <span className="margin MuiTypography-caption group-model-text">
                            {detail.designation}
                          </span>
                        </IonCardTitle>
                      </IonRow>
                    </div>
                  </IonCol>
                  <IonCol size="2">
                    <div>
                      <IonButton fill="clear">
                        <IonIcon
                          icon={arrowForward}
                          slot="start"
                          size="medium"
                          className="test"
                        />
                      </IonButton>
                    </div>
                  </IonCol>
                </IonItem>
              </>
            );
          })}
        </IonList>
      </IonRow>
    </IonCard>
  );
};
export default MyPages;
