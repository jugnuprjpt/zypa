import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonHeader,
  IonIcon,
  IonItem,
  IonList,
  IonRow
} from '@ionic/react';
import { eye, arrowRedo, checkmarkCircleOutline } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';

const Notification = () => {
  const { t } = useTranslation();
  const notification = [
    {
      id: 1,
      name: 'Vaibhav Porwal',
      designation: 'Purchase Manager at Istpl',
      profileImg:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      verified: true,
      view: '10 min ago',
      icon: eye
    },
    {
      id: 2,
      name: 'Udat Patel',
      designation: 'Purchase Manager at ISourcing',
      profileImg:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8JZb1dRwy8UxASU66Oit--WrtJr0beom2ww&usqp=CAU',
      verified: true,
      view: '10 min ago',
      icon: arrowRedo
    },
    {
      id: 3,
      name: 'Arpan Shah',
      designation: 'Purchase Manager at Tender247',
      profileImg:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-yQN6LylHMN9BzuMpgr2OGLttCXfX0E9dCQ&usqp=CAU',
      verified: false,
      view: '10 min ago',
      icon: eye
    },
    {
      id: 4,
      name: 'Chirag rathod ',
      designation: 'Purchase Manager at LTB',
      profileImg:
        'https://zyapaar-image-test.s3.ap-south-1.amazonaws.com/1634906976934_a.jpg',
      verified: true,
      view: '10 min ago',
      icon: checkmarkCircleOutline
    }
  ];
  return (
    <IonCard className="profile-details left-cards MuiPaper-rounded">
      <IonHeader className="card-header-text ion-padding-start light-gradient-bottom popdown-clr ion-padding-end ion-no-border">
        <IonCol size="9" className=" ion-no-padding ">
          <p>Notification</p>
        </IonCol>
        <IonCol size="3" className="ion-no-padding">
          <a className="ion-float-right ion-padding-top reaction-color-tab">
          {t('commonproperties.text3')}
          </a>
        </IonCol>
      </IonHeader>
      <IonRow>
        <IonList lines="none" className="full-width-row">
          {notification.map((detail) => {
            return (
              <>
                <IonItem>
                  <IonCol size="10">
                    <div className="myprofile-feeds ion-no-padding">
                      <IonAvatar className="MuiAvatar ">
                        <img src={detail.profileImg} />
                      </IonAvatar>
                      <IonRow className="profileName">
                        <IonCardTitle className="ion-padding-start">
                          <p className="margin">{detail.name}</p>
                          <span className="margin MuiTypography-caption group-model-text">
                            {detail.designation}
                          </span>
                          <p className="margin MuiTypography-caption group-model-text">
                            {detail.view}
                          </p>
                        </IonCardTitle>
                      </IonRow>
                    </div>
                  </IonCol>
                  <IonCol size="2">
                    <div>
                      <IonButton
                        fill="clear"
                        className="header-row-margin-left"
                      >
                        <IonIcon
                          icon={detail.icon}
                          slot="start"
                          size="medium"
                          className="test"
                        />
                      </IonButton>
                    </div>
                  </IonCol>
                </IonItem>
              </>
            );
          })}
        </IonList>
      </IonRow>
    </IonCard>
  );
};
export default Notification;
