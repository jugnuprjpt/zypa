import {
  IonAvatar,
  IonCard,
  IonCardTitle,
  IonCol,
  IonRow
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router';
import CallFor from '../../util/CallFor';

const RecentlyAdded = () => {
  const history = useHistory;
  const [recentlyAdded, setRecentlyAdded] = useState([
    {
      id: '908389745544548352',
      logo:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1oJbq8uoavHOngzYj_4Kdd0oPf2W0zKS8tA&usqp=CAU',
      designation: 'Coding',
      view: '2.6k member'
    },
    {
      id: '908389745544548352',
      logo:
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1oJbq8uoavHOngzYj_4Kdd0oPf2W0zKS8tA&usqp=CAU',
      view: '3.6k member',
      designation: 'coding hub'
    }
  ]);
  useEffect(() => {
    getCreateGroups();
  }, []);
  const getCreateGroups = async() => {
    const response = await CallFor('api/v1/userdetail', 'GET', null, 'AUTH');
    if (response.status === 201) {
      const json1Response = await response.json();
      setRecentlyAdded(json1Response.data);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  return (
          <IonCard className="profile-details left-cards ion-no-margin MuiPaper-rounded ion-padding-top ion-padding-end">
            <IonRow>
               {recentlyAdded.map((detail) => (
              // eslint-disable-next-line react/jsx-key
              <IonCol size-md="6" size-xs="12" className="ion-no-padding ion-padding-start ion-padding-bottom ">
                <div className="myprofile-feeds ion-no-padding ion-padding-top ion-padding-end input-box">
                  <IonAvatar slot="start" className="MuiCardHeader-avatar">
                    <img src= {detail.logo} />
                  </IonAvatar>
                  <IonRow className="profileName">
                    <IonCardTitle>
                      <p className="margin MuiTypography-body1">
                      {detail.designation}
                      </p>
                      <span className="margin MuiTypography-caption">
                      {detail.view}
                      </span>
                    </IonCardTitle>
                  </IonRow>
                </div>
              </IonCol>
               ))}
            </IonRow>
          </IonCard>
  );
};
export default RecentlyAdded;
