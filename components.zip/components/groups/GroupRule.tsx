import { IonCard } from '@ionic/react';
import React from 'react';
import { useTranslation } from 'react-i18next';

const GroupRule = (props: any) => {
  const { t } = useTranslation();
  return (
    <>
     <IonCard className="MuiPaper-rounded ion-margin-top ion-padding ion-margin-bottom ion-no-margin about-details-content">
      <h4 className="ion-margin-start textcolour"> {t('appproperties.text309')} </h4>
      {props.aboutGroupDetails.rule !== '' && props.aboutGroupDetails.rule !== undefined
        ? <p className=" ion-padding-end textcolour p_wrap">
                {props.aboutGroupDetails.rule}
              </p>
        : <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text26')}
              </p>
              }

      </IonCard>

    </>
  );
};
export default GroupRule;
