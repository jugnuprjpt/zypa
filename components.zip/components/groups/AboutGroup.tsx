import { IonCard } from '@ionic/react';
import React from 'react';
import { useTranslation } from 'react-i18next';

const AboutGroup = (props: any) => {
  const { t } = useTranslation();
  return (
    <>
     <IonCard className="MuiPaper-rounded ion-margin-top ion-padding ion-margin-bottom ion-no-margin about-details-content">
       <h4 className="ion-margin-start textcolour"> {t('commonproperties.text17')} </h4>
       {props.aboutGroupDetails.about !== '' && props.aboutGroupDetails.about !== undefined
         ? <p className='p_wrap'>
                {props.aboutGroupDetails.about}
        </p>
         : <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text25')}
        </p>
        }
      </IonCard>

    </>
  );
};
export default AboutGroup;
