import { IonAvatar, IonButton, IonCard, IonCol, IonHeader, IonIcon, IonItem, IonList, IonRow } from '@ionic/react';
import { addCircle } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';

const IntrestGroups = () => {
  const { t } = useTranslation();
  const IntrestGroups = [
    {
      key: '1',
      profileImg:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Creative Design Specialists'
    },
    {
      key: '2',
      profileImg:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Design News'
    },
    {
      key: '3',
      profileImg:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Design News'
    },
    {
      key: '4',
      profileImg:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Design News'
    },
    {
      key: '5',
      profileImg:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Design News'
    }
  ];
  return (
    <IonCard className="profile-details left-cards MuiPaper-rounded">
      <IonHeader className="card-header-text ion-padding-start ion-padding-end ion-no-border">
        <IonCol size="9" className="ion-no-padding">
          <p>{t('groupproperties.text28')}</p>
        </IonCol>
        <IonCol size='3' className='ion-no-padding'>
        <a className='ion-float-right ion-padding-top link-btn-tx'>{t('commonproperties.text3')}</a>
        </IonCol>
      </IonHeader>
      <IonRow>
        <IonList lines="none" className="full-width-row">
          {IntrestGroups.map((detail) => {
            return (
              <>
                <IonItem>
                  <IonCol size="10">
                    <div className="myprofile-feeds ion-no-padding">
                      <IonAvatar className="MuiAvatar ">
                        <img src={detail.profileImg} />
                      </IonAvatar>
                      <IonRow className="ion-padding-start">
                        {detail.name}
                      </IonRow>
                    </div>
                  </IonCol>
                  <IonCol size="3">
                    <div>
                      <IonButton fill="clear">
                        <IonIcon
                          icon={addCircle}
                          slot="start"
                          size="medium"
                          className="test"
                        />
                      </IonButton>
                    </div>
                  </IonCol>
                </IonItem>
              </>
            );
          })}
        </IonList>
      </IonRow>
    </IonCard>
  );
};
export default IntrestGroups;
