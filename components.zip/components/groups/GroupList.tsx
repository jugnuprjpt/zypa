/* eslint-disable react/jsx-key */
import {
  IonButton,
  IonCard,
  IonCol,
  IonContent,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonLabel,
  IonModal,
  IonRow,
  useIonViewWillEnter
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router';
import CallFor from '../../util/CallFor';
import groupLogo from '../../assets/img/group-profile-placeholder.png';
import { close } from 'ionicons/icons';
import SkeletonComonList from '../common/skeleton/SkeletonComonList';
import SkeletonComonViewAll from '../common/skeleton/SkeletonComonViewAll';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import CommonGridList from '../common/CommonGridList';
import { useTranslation } from 'react-i18next';

const GroupList = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [memberBtnClass, setMemberBtnClass] = useState('ion-button-color');
  const [adminGroupClass, setAdminBtnClass] = useState('category-btn-color');
  const [groupList, setGroupList] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [count, setCount] = useState(0);
  const [scrollData, setScrollData] = useState([]);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [getGroupType, setGroupType] = useState('');
  const [confirmModel, setConfirmModel] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [groupId, setGroupId] = useState('');
  const confirmMessage = <IonLabel>{t('groupproperties.text19')} <strong>{groupName}</strong>. {t('groupproperties.text20')}</IonLabel>;
  useEffect(() => {
    getGroupList('ADMIN');
  }, []);
  const getGroupList = async(groupType) => {
    setGroupType(groupType);
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/groups/list/' + groupType,
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setScrollData(json1Response.data.content);
        setGroupList(json1Response.data.content);
      }
      // setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      history.push('/404');
    } else if (response.status === 500) {
      history.push('/500');
    }
    if (groupType === 'MEMBER') {
      setMemberBtnClass('ion-button-color');
      setAdminBtnClass('category-btn-color');
    } else {
      setMemberBtnClass('category-btn-color');
      setAdminBtnClass('ion-button-color');
    }
    setLoading(false);
    setCount(1);
  };

  const getGroupListOnScroll = async() => {
    let groupType = 'ADMIN';
    if (memberBtnClass === 'ion-button-color') {
      groupType = 'MEMBER';
    }
    const response = await CallFor(
      'api/v1.1/groups/list/' + groupType,
      'POST',
      '{"page": ' + count + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        setScrollData([...scrollData, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const leaveGroupHandler = async() => {
    const response = await CallFor(
      'api/v1.1/groups/' + groupId + '/leave',
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setGroupList(groupList.filter((item) => item.id !== groupId));
      setScrollData(scrollData.filter((item) => item.id !== groupId));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  useIonViewWillEnter(async() => {
    getGroupListOnScroll();
  });
  function searchNext(ev: any) {
    setTimeout(() => {
      getGroupListOnScroll();
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  }
  const viewPaginaction = () => {
    setShowModal(true);
    getGroupListOnScroll();
  };
  const closemodel = () => {
    setCount(1);
    setShowModal(false);
    setScrollData(groupList);
    setInfiniteDisabled(false);
  };
  return (
    <>
      <IonCard className="profile-details ion-no-margin ion-margin-bottom my-company-list MuiPaper-rounded grouplist-card blank-minheight">
        <IonRow className="w-100 mb-justiy-itc mb-8">
          <IonButton
            className={adminGroupClass + ' btn-sm-cn '}
            shape="round"
            size="small"
            onClick={() => getGroupList('ADMIN', 0)}
          >
            {t('appproperties.text210')}
          </IonButton>
          <IonButton
            className={memberBtnClass + ' btn-sm-cn '}
            shape="round"
            size="small"
            onClick={() => getGroupList('MEMBER', 0)}
          >
            {t('appproperties.text211')}
          </IonButton>
          {groupList.length >= 10
            ? <IonButton
            fill="clear"
            size="small"
            className="ml-auto link-btn link-btn-tx dn-mobile"
            onClick={viewPaginaction}
          >
            {t('commonproperties.text3')}
          </IonButton>
            : ''}
        </IonRow>
          {groupList.length > 0
            ? (
              <IonRow className='mx-m5 member-listing-group member-listing'>
              {groupList.map((list, i) => (
                <CommonGridList key={i} id={list.id} defultImage={groupLogo} img={list.img} name={list.name} subString2={list.members + t('appproperties.text192')} dots={false} isAdmin={list.isAdmin}
                  isAdminText={t('appproperties.text338')} isHide={list.isHide} redirectLink='groups' btnLeave={() => { setConfirmModel(true); setGroupId(list.id); setGroupName(list.name); }} DefaulCover={false} coverImg={false} />
              ))}
                </IonRow>
              )
            : loading
              ? (
            <>
              <SkeletonComonList column={6} sizeMd={6} sizeXs={12} name={true} title={true} distription={true} link={false} />
            </>
                )
              : <>
             {getGroupType === 'ADMIN'
               ? <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text19')}</p>
               : <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">{t('nodatafound.text20')}</p>
              }
              </>
          }

        {groupList.length >= 10
          ? <div className='right-col-cn gup-btn-action view-all-mobile'>
            <div onClick={viewPaginaction} className="link-btn-tx">
            {t('commonproperties.text3')}
            </div>
          </div>
          : ''}

      </IonCard>
      <IonModal isOpen={showModal} cssClass="pageModel" onDidDismiss={() => closemodel()}>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">{t('commonproperties.text3')}</IonLabel>
            <div
              onClick={closemodel}
              className="close ion-no-padding cursor-pointer"
            >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <IonContent>
          <div className="modal-body grouplist">
          <div className="no-footer">
            <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom mobile-pd-8 member-listing">
            {!loading
              ? <>
              {scrollData.length >= 0 &&
                scrollData.map((list, i) => (
                  <CommonGridList key={i} id={list.id} defultImage={groupLogo} img={list.img} name={list.name} subString2={list.members + t('appproperties.text192')} dots={false} isAdmin={list.isAdmin}
                    isAdminText={t('appproperties.text338')} isHide={list.isHide} redirectLink='groups' btnLeave={() => { setConfirmModel(true); setGroupId(list.id); setGroupName(list.name); }} DefaulCover={false} coverImg={false} />
                ))}
                </>
              : <SkeletonComonViewAll column={8} sizeMd={3} sizeXs={12} name={true} title={true} distription={true} link={false} />
              }
            </IonRow>
          <IonInfiniteScroll
            onIonInfinite={searchNext}
            threshold="100px"
            disabled={isInfiniteDisabled}
          >
            <IonInfiniteScrollContent
              loadingSpinner="circular"
              loadingText={t('appproperties.text215')}
            ></IonInfiniteScrollContent>
          </IonInfiniteScroll>
        </div>
        </div>
        </IonContent>
      </IonModal>
      <ConfirmModelCommon header={t('appproperties.text424')} message={confirmMessage} btn1={t('appproperties.text11')} btn2={t('appproperties.text339')} confirmModel={confirmModel} setConfirmModel={setConfirmModel} deleteBtnHandler={leaveGroupHandler} groupId={groupId}/>
    </>
  );
};
export default GroupList;
