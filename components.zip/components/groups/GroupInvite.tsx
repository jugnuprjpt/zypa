/* eslint-disable multiline-ternary */
/* eslint-disable react/prop-types */
import {
  IonAvatar,
  IonButton,
  IonCardTitle,
  IonCol,
  IonHeader,
  IonIcon,
  IonInput,
  IonRow
} from '@ionic/react';
import { searchOutline, close } from 'ionicons/icons';
import React, { useState } from 'react';
import { useHistory, useParams } from 'react-router';
import CallFor from '../../util/CallFor';
import userLogo from '../../assets/img/user-profile-placeholder.png';
import Footer from '../Layout/Footer';
import ToastCommon from '../common/ToastCommon';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper';
import ConfirmModelCommon from '../common/ConfirmModelCommon';

import MutualConnectionRow from '../common/MutualConnectionRow';
import { Trans, useTranslation } from 'react-i18next';
// SwiperCore.use([Navigation]);
const GroupInvite = (props: any) => {
  const { t } = useTranslation();
  const { groupId, groupName } = useParams();
  const history = useHistory();
  const [btnShow, setBtnShow] = useState(false);
  const [isCheck, setIsCheck] = useState([]);
  const [errorMsg, setErrorMsg] = useState('');
  const [isCheckAll, setIsCheckAll] = useState(false);
  const [selectedInviteConnection, setSelectedInviteConnection] = useState([]);
  const [isSelectedCheck, setIsSelectedCheck] = useState([]);
  const [searchValue, setSearchValue] = useState();
  const [showToast, setShowToast] = useState(false);
  const [inviteConnection, setInviteConnection] = useState([]);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [confirmModel, setConfirmModel] = useState(false);
  const decodedGroupName = decodeURIComponent(escape(window.atob(groupName.replace('&quot;', '/')))); // Base64 decode the String

  const inviteGroup = async() => {
    if (isSelectedCheck.length > 0) {
      const response = await CallFor(
        'api/v1.1/group/request/invite/' + groupId,
        'POST',
        JSON.stringify(isSelectedCheck),
        'Auth'
      );
      if (response.status === 201) {
        // setShowToastMsg('Your invite has been sent');
        setShowToastMsg(t('toastmessages.toast8', { name: isSelectedCheck.length }));
        setShowToast(true);
        setTimeout(() => {
          history.push('/groups/' + groupId);
        }, 1000);
      } else if (response.status === 401) {
        localStorage.clear();
      }
    } else {
      setErrorMsg(t('groupproperties.text23'));
    }
  };

  const checkboxChangeHandler = (event: any) => {
    setErrorMsg('');
    const { id, checked } = event.target;
    if (!checked) {
      setIsCheck(isCheck.filter((item) => item !== id));
    } else {
      if (
        selectedInviteConnection.filter((item) => item.id === id).length === 0
      ) {
        setSelectedInviteConnection([
          ...selectedInviteConnection,
          ...inviteConnection.filter((item) => item.id === id)
        ]);
        setIsSelectedCheck([...isSelectedCheck, id]);
      }
      setInviteConnection(inviteConnection.filter((item) => item.id !== id));
      setIsCheck([...isCheck, id]);
    }
    const checkboxes = document.querySelectorAll(
      'input[type=checkbox]:checked'
    ).length;
    if (checkboxes === inviteConnection.length) {
      setIsCheck([]);
      setBtnShow(false);
      setInviteConnection([]);
      setSearchValue('');
      // setIsCheckAll(true);
    } else {
      setIsCheckAll(false);
    }
  };

  const selectAllBtnHandler = () => {
    setErrorMsg('');
    setIsCheckAll(!isCheckAll);
    setIsCheck(inviteConnection.map((li) => li.id));
    if (isCheckAll) {
      setIsCheck([]);
    } else {
      const dataIds = [];
      const data = [];
      inviteConnection.map((details) => {
        if (
          selectedInviteConnection.filter((item) => item.id === details.id)
            .length === 0
        ) {
          dataIds.push(details.id);
          data.push(details);
        }
      });
      setSelectedInviteConnection([...selectedInviteConnection, ...data]);
      setIsSelectedCheck([...isSelectedCheck, ...dataIds]);
      setIsCheck([]);
      setBtnShow(false);
      setInviteConnection([]);
      setSearchValue('');
    }
  };
  const callInviction = async(event) => {
    let setInviteValue;
    setSearchValue(event.target.value);
    if (event.target.value !== undefined) {
      if (event.target.value.trim().length >= 3) {
        const response = await CallFor(
          'api/v1.1/connections/users/' + event.target.value,
          'GET',
          null,
          'Auth'
        );
        if (response.status === 200) {
          const jsonResponse = await response.json();
          if (jsonResponse.data !== null) {
            // setInviteConnection(jsonResponse.data);
            setInviteValue = jsonResponse.data;
          }
        } else if (response.status === 401) {
          localStorage.clear();
          history.push('/login');
        }
        if (setInviteValue !== null && setInviteValue !== undefined) {
          if (setInviteValue.length > 0) {
            setBtnShow(true);
          } else {
            setBtnShow(false);
          }
          setInviteConnection(setInviteValue);
        }
      } else {
        setInviteConnection([]);
        setIsCheckAll(false);
        setIsCheck([]);
        setBtnShow(false);
      }
    } else {
      setInviteConnection([]);
      setIsCheckAll(false);
      setIsCheck([]);
      setBtnShow(false);
    }
  };
  const removeUser = (id) => {
    setSelectedInviteConnection(
      selectedInviteConnection.filter((item) => item.id !== id)
    );
    setIsSelectedCheck(isSelectedCheck.filter((item) => item !== id));
  };
  const removeAll = () => {
    setSelectedInviteConnection([]);
    setIsSelectedCheck([]);
    setConfirmModel(false);
  };
  return (
    <>
      <div className="plane-bg">
        <div className="container">
          <div className="invite-page-content p-0">
          <IonRow className='member-listing-fixed'>
          <IonHeader>
              <h2>
                {t('commonproperties.text15')}{' '}
                <span className="color-theme-dark">{decodedGroupName}</span>
              </h2>
            </IonHeader>
            <IonCol
                sizeMd="4"
                sizeXs="12"
                className="profile-details ion-no-margin full-width-row left-cards MuiPaper-rounded show-mobile"
              >
                {
                  selectedInviteConnection.length > 0 ? (
                    <div className="bg-white p-2 invite-connnections mt-lg-4 mt-2">
                      <p className='pe-2'>{selectedInviteConnection.length} {t('appproperties.text200')}</p>
                      <div className="award-slider-aw product-slider-cn select-profile pe-2 mt-1">
                        <IonRow className="d-flex">
                          {selectedInviteConnection.length > 2 ? (
                            <Swiper
                              id="ka-swiper2"
                              navigation={true}
                              modules={[Navigation, Pagination]}
                              className="mySwiper"
                              autoHeight={true}
                              breakpoints={{
                                320: {
                                  width: 330,
                                  slidesPerView: 2
                                },
                                640: {
                                  width: 500,
                                  slidesPerView: 2
                                },
                                768: {
                                  width: 768,
                                  slidesPerView: 3
                                }
                              }}
                            >
                              {selectedInviteConnection.map((detail, i) => (
                                // eslint-disable-next-line react/jsx-key
                                <SwiperSlide className="swiper-slide-btn ms-2" key={i}>
                                  <div className="myprofile-feeds position-relative mobile-contions">
                                    <div
                                      onClick={() => removeUser(detail.id)}
                                      className="close ion-no-padding profile-remove zindex9"
                                    >
                                      <IonIcon
                                        icon={close}
                                        className="ion-button-color pr-0 "
                                        slot="start"
                                        size="undefined"
                                      />
                                    </div>

                                    <IonAvatar
                                      slot="start"
                                      className="MuiCardHeader-avatar cursor-pointer"
                                      onClick={() => {
                                        history.push('/profile/' + detail.id);
                                      }}
                                    >
                                      {detail.profileImg === null ||
                                        detail.profileImg === '' ? (
                                        <img src={userLogo} />
                                          ) : (
                                        <img onError={(ev) => { ev.target.src = userLogo; }} src={detail.profileImg} />
                                          )}
                                    </IonAvatar>
                                    <IonRow
                                      className="profileName cursor-pointer"
                                      onClick={() => {
                                        history.push('/profile/' + detail.id);
                                      }}
                                    >
                                      <IonCardTitle className='text-center mt-2'>
                                        <p className="margin MuiTypography-body1 fixed-textline2">
                                          {detail.fullName}
                                        </p>
                                      </IonCardTitle>
                                    </IonRow>
                                  </div>
                                </SwiperSlide>
                              ))}
                            </Swiper>
                          ) : (
                            <>
                              {selectedInviteConnection.map((detail, i) => (
                                // eslint-disable-next-line react/jsx-key
                                <div className="myprofile-feeds position-relative mobile-contions ms-2" key={i}>
                                  <div
                                    onClick={() => removeUser(detail.id)}
                                    className="close ion-no-padding profile-remove zindex9"
                                  >
                                    <IonIcon
                                      icon={close}
                                      className="ion-button-color pr-0 "
                                      slot="start"
                                      size="undefined"
                                    />
                                  </div>

                                  <IonAvatar
                                    slot="start"
                                    className="MuiCardHeader-avatar cursor-pointer"
                                    onClick={() => {
                                      history.push('/profile/' + detail.id);
                                    }}
                                  >
                                    {detail.profileImg === null ||
                                      detail.profileImg === '' ? (
                                      <img src={userLogo} />
                                        ) : (
                                      <img onError={(ev) => { ev.target.src = userLogo; }} src={detail.profileImg} />
                                        )}
                                  </IonAvatar>
                                  <IonRow
                                    className="profileName cursor-pointer"
                                    onClick={() => {
                                      history.push('/profile/' + detail.id);
                                    }}
                                  >
                                    <IonCardTitle className='text-center'>
                                      <p className="margin MuiTypography-body1 fixed-textline2">
                                        {detail.fullName}
                                      </p>
                                      {/* <span className="margin MuiTypography-caption group-model-text">
                                        {detail.profileTitle}
                                      </span>
                                      <span className="margin MuiTypography-caption group-model-text">
                                        <MutualConnectionRow id={detail.id} name={detail.fullName} />
                                      </span> */}
                                    </IonCardTitle>
                                  </IonRow>
                                </div>
                              ))}
                            </>
                          )}
                        </IonRow>
                      </div>
                      <div className="d-flex justify-content-end mt-3">
                        <IonButton
                          className="invite-btn pr-0 btn-sm-cn  me-2"
                          onClick={inviteGroup}
                        >
                          {t('appproperties.text362')}
                        </IonButton>
                        <IonButton
                          className="category-btn-color pr-0 btn-sm-cn"
                          onClick={() => setConfirmModel(true)}
                        >
                          {t('appproperties.text202')}
                        </IonButton>
                      </div>
                    </div>
                  ) : (
                    ''
                  )
                  //   <div className='bg-white p-2 border-radius'>
                  // <h4 className='ion-text-center'>No Data Found</h4></div>
                }
              </IonCol>
              <div className="filter-col ps-2 pe-2 mt-2 w-100">
              <div className="search-control">
                <div className="input-box-old ion-no-padding mb-0">
                  <IonIcon icon={searchOutline} />
                  <IonInput
                    value={searchValue}
                    placeholder={t('appproperties.text198')}
                    id="inviteSearch"
                    name="inviteSearch"
                    className=" ion-padding-start pt-lg-0 pt-2 ps-lg-0 ps-3"
                    onIonChange={callInviction}
                    enterkeyhint="search"
                  ></IonInput>
                </div>
                <div className="select-btn">
                  {btnShow ? (
                    <>
                      {!isCheckAll ? (
                        <IonButton
                          className="ion-button-color m-0"
                          onClick={selectAllBtnHandler}
                        >
                          {t('appproperties.text199')}
                        </IonButton>
                      ) : (
                        <IonButton
                          className="ion-button-color m-0"
                          onClick={selectAllBtnHandler}
                        >
                          {t('appproperties.text413')}
                        </IonButton>
                      )}
                    </>
                  ) : (
                    ''
                  )}
                </div>
              </div>
              <IonRow className="full-width-row show-mobile">
                <span className="error ion-no-margin ">{errorMsg}</span>
              </IonRow>
              <div>
                {/* <IonButton className="ion-button-color ">CANCEL</IonButton> */}
                {/* <IonButton className="ion-button-color pr-0" type='submit' onClick={inviteGroup}>
                INVITE CONNECTIONS
              </IonButton> */}
              </div>
            </div>
            <IonRow className="full-width-row dn-mobile">
              <span className="error ion-no-margin ion-margin-bottom">
                {errorMsg}
              </span>
            </IonRow>
          </IonRow>

            <IonRow className="member-reverse">
              <IonCol
                sizeMd="8"
                sizeXs="12"
                className="profile-details ion-no-margin full-width-row left-cards MuiPaper-rounded p-0"
              >
                 <div className="bg-white p-2 mt-lg-4 mt-2">
                  {inviteConnection.length > 0 ? (
                    <IonRow>
                      {inviteConnection.map((detail, index) => (
                        // eslint-disable-next-line react/jsx-key
                        <IonCol sizeMd="6" sizeXs="12">
                          <div className="myprofile-feeds h-100">
                            <div>
                              <input
                                id={detail.id}
                                name={detail.firstName}
                                type="checkbox"
                                onChange={checkboxChangeHandler}
                                checked={isCheck.includes(detail.id)}
                              />
                            </div>
                            <div className="d-flex ion-align-items-center ion-justify-content-start">
                              <IonAvatar
                                slot="start"
                                className="MuiCardHeader-avatar cursor-pointer"
                                onClick={() => {
                                  history.push('/profile/' + detail.id);
                                }}
                              >
                                {detail.profileImg === null ||
                                  detail.profileImg === '' ? (
                                  <img src={userLogo} />
                                    ) : (
                                  <img onError={(ev) => { ev.target.src = userLogo; }} src={detail.profileImg} />
                                    )}
                              </IonAvatar>
                              <IonRow
                                className="profileName cursor-pointer"
                              >
                                <IonCardTitle onClick={() => {
                                  history.push('/profile/' + detail.id);
                                }}>
                                  <p className="margin MuiTypography-body1 fixed-textline2">
                                    {detail.fullName}
                                  </p>
                                </IonCardTitle>
                              </IonRow>
                            </div>
                          </div>
                        </IonCol>
                      ))}
                    </IonRow>
                  ) : (
                    <h4 className="ion-text-center">
                      {t('groupproperties.text23') + '!!'}
                    </h4>
                  )}
                </div>
              </IonCol>

              {/* End Mobile viwe */}
              

              {/* End Mobile viwe */}

              {/* desktop start */}
              <IonCol
                sizeMd="4"
                sizeXs="12"
                className="profile-details ion-no-margin full-width-row left-cards MuiPaper-rounded  mt-4 dn-mobile"
              >
                {
                  selectedInviteConnection.length > 0 ? (
                    <div className="bg-white p-2 border-radius invite-connnections overflow-auto">
                      <p className='ms-1 mb-1'>{selectedInviteConnection.length} {t('appproperties.text200')}</p>
                      <div className="select-profile pe-2">
                        <IonRow className="d-flex">
                          {selectedInviteConnection.map((detail) => (
                            // eslint-disable-next-line react/jsx-key
                            <IonCol sizeMd="12" sizeXs="4">
                              <div className="myprofile-feeds position-relative mobile-contions">
                                <div
                                  onClick={() => removeUser(detail.id)}
                                  className="close ion-no-padding profile-remove zindex9"
                                >
                                  <IonIcon
                                    icon={close}
                                    className="ion-button-color pr-0 "
                                    slot="start"
                                    size="undefined"
                                  />
                                </div>
                                <IonAvatar
                                  slot="start"
                                  className="MuiCardHeader-avatar cursor-pointer"
                                  onClick={() => {
                                    history.push('/profile/' + detail.id);
                                  }}
                                >
                                  {detail.profileImg === null ||
                                    detail.profileImg === '' ? (
                                    <img src={userLogo} />
                                      ) : (
                                    <img onError={(ev) => { ev.target.src = userLogo; }} src={detail.profileImg} />
                                      )}
                                </IonAvatar>
                                <IonRow
                                  className="profileName cursor-pointer"
                                  onClick={() => {
                                    history.push('/profile/' + detail.id);
                                  }}
                                >
                                  <IonCardTitle>
                                    <p className="margin MuiTypography-body1">
                                      {detail.fullName}
                                    </p>
                                    <span className="margin MuiTypography-caption group-model-text dn-mobile">
                                      {detail.profileTitle}
                                    </span>
                                    <span className="margin MuiTypography-caption group-model-text">
                                      <MutualConnectionRow id={detail.id} name={detail.fullName} key={detail.id}/>
                                    </span>
                                  </IonCardTitle>
                                </IonRow>
                              </div>
                            </IonCol>
                          ))}
                        </IonRow>
                      </div>
                      <div className="d-flex justify-content-end mt-3">
                        <IonButton
                          className="invite-btn pr-0 btn-sm-cn  me-2"
                          onClick={inviteGroup}
                        >
                          {t('appproperties.text201')}
                        </IonButton>
                        <IonButton
                          className="category-btn-color pr-0 btn-sm-cn"
                          onClick={() => setConfirmModel(true)}
                        >
                          {t('appproperties.text202')}
                        </IonButton>
                      </div>
                    </div>
                  ) : (
                    ''
                  )
                  //   <div className='bg-white p-2 border-radius'>
                  // <h4 className='ion-text-center'>No Data Found</h4></div>
                }
              </IonCol>
              {/* End desktop start */}
            </IonRow>
          </div>
        </div>
      </div>
      <Footer />
      <ToastCommon
        setShowToast={setShowToast}
        setShowToastMsg={setShowToastMsg}
        showToast={showToast}
        showToastMsg={showToastMsg}
        duration={5000}
      />
      <ConfirmModelCommon
        header={t('appproperties.text400')}
        message={t('appproperties.text204')}
        btn1={t('appproperties.text206')}
        btn2={t('appproperties.text205')}
        confirmModel={confirmModel}
        setConfirmModel={setConfirmModel}
        deleteBtnHandler={removeAll}
      />
    </>
  );
};
export default GroupInvite;
