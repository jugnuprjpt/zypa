/* eslint-disable multiline-ternary */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonFooter,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  IonTextarea,
  useIonPopover
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { close, ellipsisVertical, pencilOutline, trashBinOutline, warningOutline } from 'ionicons/icons';
import CallFor from '../../util/CallFor';
import { useHistory } from 'react-router';
import groupLogo from '../../assets/img/group-profile-placeholder.png';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import edit from '../../assets/img/edit.svg';
import Select from 'react-select';
import SkeletonComonViewDetais from '../common/skeleton/SkeletonComonViewDetail';
import PopoverCommon from '../common/PopoverCommon';
import ConfirmModelCommon from '../common/ConfirmModelCommon';
import groupbackGroundImg from '../../assets/img/banner-placeholder.png';
import ButtonComponent from '../common/ButtonComponent';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import { useTranslation, Trans } from 'react-i18next';
import NotAuthorizeModal from '../common/NotAuthorizeModal';

const customStyles = {
  control: (provided: any) => ({
    ...provided,
    height: 49,
    background: '#fff !important',
    border: 'none',
    '&:focus': {
      border: '1px solid #00529C'
    }
  }),
  multiValue: (styles, { data }) => {
    return {
      ...styles,
      padding: 4,
      backgroundColor: '#0073ae!important',
      borderRadius: '50px'
    };
  },
  multiValueLabel: (styles, { data }) => ({
    ...styles,
    color: '#fff'
  }),
  multiValueRemove: (styles, { data }) => ({
    ...styles,
    color: '#0073ae!important',
    borderRadius: '50px',
    margin: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    ':hover': {
      backgroundColor: '#fff'
    }
  }),
  indicatorSeparator: () => { }, // removes the "stick"
  dropdownIndicator: (defaultStyles: any) => ({
    ...defaultStyles,
    '& svg': { display: 'none' }
  })
};
const GroupDetail = (props: any) => {
  const { t } = useTranslation();
  const history = useHistory();
  const inviteBtnHandler = () => {
    const groupName = encodedString(props.groupDetail.name);
    history.push(
      '/groups/' + props.groupId + '/' + groupName.replace('/', '&quot;') + '/groupInvite'
    );
  };
  const encodedString = (str) => {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
      return String.fromCharCode(parseInt(p1, 16));
    }));
  };
  const [loginModal, setLoginModal] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [imageView, setImageView] = useState(false);
  const [groupFormState, setGroupFormState] = useState({});
  const [groupFile, setGroupFile] = useState('');
  const [industry, setIndustry] = useState([]);
  const [isValid, setIsValid] = useState(true);
  const [reportModal, setReportModel] = useState(false);
  const [reason, setReason] = useState('');
  const [characterCount, setCharacterCount] = useState(0);
  const profileDetail = useSelector(getProfileDetails);
  const [ruleCharacterCount, setRuleCharacterCount] = useState(0);
  const maxAboutCount = 500;
  const maxRuleCount = 500;
  const [updateDisabled, setUpdateDisabled] = useState(false);
  const [showModelProfilePicture, setshowModelProfilePicture] = useState(false);

  const maxCount = 500;
  useEffect(() => {
    props.getGroupDetails(props.groupId);
  }, []);
  const validationSchema = Yup.object().shape({
    name: Yup.string().trim().required(t('groupproperties.text8'))
      .test(
        'len',
        t('groupproperties.text9'),
        (val) => val && val.toString().length >= 1
      )
      .test(
        'len',
        t('groupproperties.text10'),
        (val) => val && val.toString().length <= 250
      ),
    industry: Yup.string().required(t('groupproperties.text7')),
    // discoverability: Yup.string().required('Group Discoverability is Required'),
    about: Yup.string().trim().nullable(true).optional().notRequired()
      .test(
        'len',
        t('groupproperties.text11'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined && !val.includes(' ')) {
            return val && val.toString().trim().length >= 10;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('groupproperties.text12'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length <= 500;
          } else {
            return true;
          }
        }
      ),
    rule: Yup.string().trim().nullable(true).optional().notRequired()
      .test(
        'len',
        t('groupproperties.text11'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined && !val.includes(' ')) {
            return val && val.toString().trim().length >= 10;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('groupproperties.text12'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length <= 500;
          } else {
            return true;
          }
        }
      ),
    location: Yup
      .string().nullable(true).notRequired().optional()
      .matches(/^[A-Za-z0-9@&-\s][A-Za-z0-9@&-\s]*$/, { message: t('groupproperties.text15'), excludeEmptyString: true }).test(
        'len',
        t('groupproperties.text16'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length <= 100;
          } else {
            return true;
          }
        }
      )
  });

  const uploadCompanylogoHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        setIsValid(false);
      } else {
        if (event.target.files[0].size > 3145728) {
          setError('upload', {
            type: 'required',
            message: t('commonproperties.text2')
          });
          setIsValid(false);
        } else {
          clearErrors('upload');
          resetField('upload');
          // setCreateDisabled(false);
          setIsValid(true);
        }
      }
      setGroupFile(file1);
      setImageView(true);
    }
  };
  const {
    register,
    handleSubmit,
    setValue,
    clearErrors,
    resetField,
    control,
    setError,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });
  const userformDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined) {
      if (event.target.value !== null && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setGroupFormState({
        ...groupFormState,
        [event.target.name]: event.target.value
      });
    }
  };
  const industryChangeHandler = (event) => {
    if (event !== null && event.value !== undefined) {
      setGroupFormState({ ...groupFormState, industry: event.value });
      if (event.value !== 0) {
        setTimeout(function() {
          clearErrors('industry');
        }, 1);
      }
    } else {
      setGroupFormState({ ...groupFormState, industry: null });
    }
  };
  const selectErrorMsg = () => {
    if (groupFormState.industry !== null) {
      if (groupFormState.industry.length === 0) {
        setError('industry', {
          type: 'manual',
          message: t('groupproperties.text7')
        });
      } else {
        clearErrors('industry');
      }
    } else {
      setError('industry', {
        type: 'manual',
        message: t('groupproperties.text7')
      });
    }
  };
  const groupSubmitHandler = async() => {
    if (imgValibactionHandler() && isValid) {
      setUpdateDisabled(true);
      const logo = document.getElementById('upload');
      const data = new FormData();
      if (logo.files[0] !== undefined) {
        data.append('logo', logo.files[0]);
        groupFormState.logo = null;
      } else {
        groupFormState.logo = groupFile;
        data.append('logo', null);
      }
      let groupNameData = '';
      let groupLocationData = '';
      let groupAboutData = '';
      let groupRuleData = '';
      if (groupFormState.name !== undefined && groupFormState.name !== null) {
        groupNameData = groupFormState.name.trim();
        groupFormState.name = groupNameData;
      }
      if (groupFormState.location !== undefined && groupFormState.location !== null) {
        groupLocationData = groupFormState.location.trim();
        groupFormState.location = groupLocationData;
      }
      if (groupFormState.about !== undefined && groupFormState.about !== null) {
        groupAboutData = groupFormState.about.trim();
        groupFormState.about = groupAboutData;
      }
      if (groupFormState.rule !== undefined && groupFormState.rule !== null) {
        groupRuleData = groupFormState.rule.trim();
        groupFormState.rule = groupRuleData;
      }
      // const discoverability = document.getElementsByName('discoverability');
      // groupFormState.discoverability = discoverability[0].value;

      data.append('group', JSON.stringify(groupFormState));
      const response = await CallFor(
        'api/v1.1/groups',
        'POST',
        data,
        'authWithoutContentType'
      );
      if (response.status === 201) {
        setUpdateDisabled(true);
        props.getGroupDetails(props.groupId);
        props.getGroupLists(props.groupId);
        setShowModal(false);
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else if (response.status === 400) {
        const dataress = await response.json();
        dataress.error.errors.map((details) => {
          setError(details.field, {
            type: 'server',
            message: details.message
          });
        });
      }
      setUpdateDisabled(false);
    } else {
      imgValibactionHandler();
    }
  };
  const imgValibactionHandler = () => {
    const logo = document.getElementById('upload');
    let isUserLogoValid = true;
    let isIndustryValid = true;
    if (groupFormState.industry !== null) {
      if (groupFormState.industry.length === 0) {
        setError('industry', {
          type: 'manual',
          message: t('groupproperties.text7')
        });
        isIndustryValid = false;
      } else {
        clearErrors('industry');
        isIndustryValid = true;
      }
    } else {
      setError('industry', {
        type: 'manual',
        message: t('groupproperties.text7')
      });
      isIndustryValid = false;
    }
    if (logo.files[0] !== undefined && logo.files[0] !== '') {
      if (logo.files[0].size > 3145728) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text2')
        });
        isUserLogoValid = false;
      }
      if (!logo.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        isUserLogoValid = false;
      }
    }
    if (isIndustryValid && isUserLogoValid) {
      setIsValid(true);
      return true;
    } else {
      setIsValid(false);
      return false;
    }
  };
  const getEditGroupDetails = async() => {
    const response = await CallFor(
      'api/v1.1/group/details/' + props.groupId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      setGroupFormState({
        id: json1Response.data.id,
        name: json1Response.data.name,
        industry: json1Response.data.industry,
        about: json1Response.data.about,
        rule: json1Response.data.rule,
        location: json1Response.data.location
        // discoverability: json1Response.data.discoverability,
        //  reviewPostByAdmin: json1Response.data.reviewPostByAdmin,
        // canMemberInvite: json1Response.data.canMemberInvite
      });
      setGroupFile(json1Response.data.logo);
      const fields = [
        'id',
        'name',
        'industry',
        'about',
        'rule',
        'location',
        'discoverability',
        'reviewPostByAdmin',
        'canMemberInvite'

      ];
      fields.forEach((field) => setValue(field, json1Response.data[field]));
      let inputs, index;
      inputs = document.getElementsByTagName('ion-textarea');
      for (index = 0; index < inputs.length; ++index) {
        const val = inputs[index].value;
        if (val !== null && val.length > 0) {
          inputs[index].classList.add('input-fill');
        }
      }
      setImageView(true);
    }
  };

  const getIndustry = async() => {
    const response = await CallFor('api/v1.1/industries', 'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      const states = await json1Response.data.map(
        (d: { subIndustryID: any; subIndustry: any }) => ({
          value: d.subIndustryID,
          label: d.subIndustry
        })
      );
      setIndustry(states);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const joinBtnHandler = async(id) => {
    const response = await CallFor(
      'api/v1.1/groups/request/join/' + id,
      'POST',
      null,
      'Auth'
    );
    if (response.status === 201) {
      props.getGroupDetails(props.groupId);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  const leaveBtnHandler = async() => {
    const response = await CallFor(
      'api/v1.1/groups/' + props.groupDetail.id + '/leave',
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      props.getGroupDetails(props.groupId);
      history.push('/groups');
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const openModelWithClearError = () => {
    getIndustry();
    setShowModal(true);
    clearErrors();
  };
  // const deleteImg = () => {
  //   setGroupFile();
  //   document.getElementById('upload').value = '';
  //   clearErrors('upload');
  // };
  const openReportModelclearstate = () => {
    setReportModel(true);
    setReason('');
    clearErrors();
    dismiss();
  };
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr">
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => { onHide(); openReportModelclearstate(); }}
      >
        <IonIcon icon={warningOutline} size="small" className="header-menu-img " />
        <p>{t('commonproperties.text19')}</p>
      </IonItem>
    </IonList>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });

  const reportChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined) {
      setReason(event.target.value);
    }
    if (event.target.value !== undefined) {
      description: event.target.value;
    }
    if (event.target.value !== undefined && event.target.value != null) {
      setCharacterCount(event.target.value.length);
    }
  };
  const visibleImg = () => {
    setImageView(false);
  };

  const imageEditHandle = () => {
    setImageView(false);
    // uploadCompanylogoHandleChange()
  };
  const deleteImageHandle = () => {
    //  document.getElementById('groupImg').src = `${groupLogo}`;
    setIsValid(true);
    setGroupFile(null);
    document.getElementById('upload').value = '';
    clearErrors('upload');
    setImageView(true);
  };
  const addImg = () => {
    setImageView(false);
  };
  const clickHereToReport = async() => {
    if (reason !== undefined && reason !== '') {
      if (reason.length <= 1000) {
        const reportsData = JSON.stringify({ originId: props.groupId, origin: 'GROUP', remarks: reason });
        const response = await CallFor(
          'api/v1.1/spam-report',
          'POST',
          reportsData,
          'Auth'
        );
        if (response.status === 201) {
          setReportModel(false);
          props.setReportHideState(true);
        }
      } else {
        setError('reason', {
          type: 'required',
          message: t('commonproperties.text21')
        });
      }
    } else {
      setError('reason', {
        type: 'required',
        message: t('commonproperties.text20')
      });
    }
  };
  const removeOverLay = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const addClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.add('imageHover');
  };
  const removeClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const aboutChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setGroupFormState({
        ...groupFormState,
        about: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };
  const ruleChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setGroupFormState({
        ...groupFormState,
        rule: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setRuleCharacterCount(event.target.value.length);
    }
  };
  const imgModalOpen = () => {
    setshowModelProfilePicture(true);
  };
  const [confirmModel, setConfirmModel] = useState(false);
  const confirmMessage = <IonLabel><Trans i18nKey="appproperties.text423" values={{ group_name: props.groupDetail.name }}
  components={{ bold: <strong className='text-dark' /> }} /></IonLabel>;

  return (
    <>
      <IonCard className="MuiPaper-rounded ion-no-margin ion-margin-top profile-card-content mtm-0">
        {!props.loading
          ? <>
            <div className="groupsize-group">
              <img src={groupbackGroundImg} className="groupsize-group img-mb" />
            </div>

            {/*  Profile Picture Zoom  */}
            <IonModal isOpen={showModelProfilePicture} cssClass="add-award-model awd-img-gallery" onDidDismiss={() => setshowModelProfilePicture(false)}>
              <IonContent>
                <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
                  <div onClick={() => setshowModelProfilePicture(false)} className="close ion-no-padding">
                    <IonIcon
                      icon={close}
                      className="ion-button-color pr-0"
                      slot="start"
                      size="undefined" />
                  </div>
                </IonRow>
                <IonRow className="mx-auto d-flex justify-content-center overview-heigth">
                  {props.groupDetail.logo === null || props.groupDetail.logo === ''
                    ? (
                      <img src={groupLogo} alt="Group Logo" />
                      )
                    : (
                      <img onError={(ev) => { ev.target.src = groupLogo; }} src={props.groupDetail.logo} alt="Group Logo" />
                      )}
                </IonRow>
              </IonContent>
            </IonModal>
            {/*  Profile Picture Zoom  */}

            <div className="profile-card-body">
              <div className="profile-avt-content">
                <div>
                  <IonAvatar
                  slot="start"
                  className=" ion-no-border profileAvtar ion-no-margin"
                  >
                  {props.groupDetail.logo === null || props.groupDetail.logo === ''
                    ? (
                    <img src={groupLogo} onClick={() => imgModalOpen()} alt="Group Logo" />
                      )
                    : (
                      <img onError={(ev) => { ev.target.src = groupLogo; }} src={props.groupDetail.logo} onClick={() => imgModalOpen()} alt="Group Logo" />
                      )}
                  </IonAvatar>
                </div>

                {/* <ProfilePicture /> */}

                {props.groupDetail.isAdmin === true && props.groupDetail.isHide !== true
                  ? <div
                    fill="clear"
                    className="header-row-margin-left edit cursor-pointer zindex9"
                    onClick={openModelWithClearError}
                  >
                    <IonIcon
                      icon={edit}
                      className="textcolor header-row-margin-left header-menu-account-img"
                      slot="start" onClick={visibleImg}
                    />
                  </div>
                  : ''}
              </div>
              <div className="profileName w-100">
                <IonCardTitle>
                  <h4 className="margin fixed-textline2">
                    {props.groupDetail.name}
                  </h4>
                  <span className='fixed-textline2'>{props.groupDetail.industryName}
                    {props.groupDetail.location ? ' | ' + props.groupDetail.location : ''}
                  </span>
                </IonCardTitle>
                <div className="profile-card-follow">
                  {props.groupDetail.members
                    ? (
                      <IonLabel className="follower-text sc-ion-label-md-h sc-ion-label-md-s md hydrated">
                        <span id='memberData'>{props.groupDetail.members}</span>{' '}
                        <IonLabel className="group-model-text group-text-center">
                        {t('groupproperties.text21')}
                        </IonLabel>
                      </IonLabel>
                      )
                    : (
                        ''
                      )}
                      {!props.reportHideState ? !props.groupDetail.isHide
                        ? <>
                  {(() => {
                    if (props.groupDetail.isAdmin === true) {
                      return (
                        <IonButton
                          className="ion-button-color pr-0"
                          size="small"
                          onClick={inviteBtnHandler}
                        >
                          + {t('appproperties.text362')}
                        </IonButton>
                      );
                    } else if (props.groupDetail.isMember === true) {
                      return (
                        <IonButton
                          className="ion-button-color"
                          size="small"
                          onClick={() => setConfirmModel(true)}
                        >
                          {t('appproperties.text339')}
                        </IonButton>
                      );
                    } else if (
                      props.groupDetail.isAdmin === false &&
                      props.groupDetail.isMember === false &&
                      props.groupDetail.isRequested === false
                    ) {
                      return (
                        // <IonButton
                        //   className="ion-button-color ion-padding-end pr-0"
                        //   size="small"
                        //   onClick={() => joinBtnHandler(props.groupDetail.id)}
                        // >
                        //   join
                        // </IonButton>
                        <ButtonComponent
                        btnClick={joinBtnHandler}
                        size="small"
                        className='ion-button-color ion-padding-end pr-0'
                        field1={props.groupDetail.id} name={t('appproperties.text393')} parametersPass={1} />
                      );
                    }
                  })()}</>
                        : '' : ''}
                  {!props.reportHideState ? !props.groupDetail.isHide ? props.groupDetail.isAdmin !== true
                    ? <div className="dot-btn">
                      <IonIcon
                        icon={ellipsisVertical}
                        slot="start"
                        className="test report cursor-pointer"
                        onClick={(e) => {
                          if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                            present({ event: e.nativeEvent });
                          } else {
                            // history.push('/addnewcompany');
                            setLoginModal(true);
                          }
                        }
                          }
                      />
                    </div>
                    : '' : '' : ''}
                </div>
              </div>
            </div>
          </>
          : <SkeletonComonViewDetais />}
      </IonCard>
      <IonModal isOpen={showModal} onDidPresent={getEditGroupDetails} className="createGroupModal grouppageModal"
        onDidDismiss={() => setShowModal(false)}>
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6  ">
            {t('groupproperties.text22')}
            </IonLabel>
            <div
              onClick={() => setShowModal(false)}
              className="close ion-no-padding cursor-pointer"
            >
              <IonIcon
                icon={close}
                className="ion-button-color "
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <div className="modal-body">
            <form
              className="h-100"
              data-testid="form-submit"
              autoComplete="off"
              noValidate
              onSubmit={handleSubmit(groupSubmitHandler, imgValibactionHandler)}
            >
              <div className="body-content">
                <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
                  <IonCol size-md="2" size-xs="12" className="ion-padding-start">
                    <IonRow className="ion-justify-content-center">
                      <input
                        type="file"
                        color="primary"
                        onChange={uploadCompanylogoHandleChange}
                        id="upload"
                        accept="image/png, image/jpg, image/jpeg"
                        className="upload"
                        disabled={imageView}
                      />
                      <label htmlFor="upload" className='cursor-pointer up-img hover-avtar' id='lblupload' onClick={removeOverLay} onMouseEnter={addClass} onMouseLeave={removeClass}>
                        <IonAvatar
                          id="companyAvatar"
                          slot="start"
                          className="MuiCardHeader-avatar avtar-img modal-avtar mx-auto"
                        >
                          {groupFile
                            ? (
                              <img
                                src={groupFile}
                                alt="Group Logo"
                                className="group-img groupPhoto" id='groupImg'
                              />
                              )
                            : (
                              <img src={groupLogo} className="group-img" alt="Group Logo" />
                              )}
                        </IonAvatar>
                        <span className='addImage' onClick={addImg}></span>
                        {groupFile
                          ? <><div className='avr-edit-del-icon'>
                            <span className="icon edit cursor-pointer">
                              <IonIcon icon={trashBinOutline} onClick={deleteImageHandle} />
                            </span>
                            <span className="icon edit cursor-pointer">
                              <IonIcon icon={pencilOutline} onClick={imageEditHandle} />
                            </span>
                          </div>
                          </>
                          : ''}
                      </label>
                      <div className='error ion-text-center w-100 position-relative'>
                        {errors.upload?.message}
                      </div>
                    </IonRow>
                  </IonCol>
                  <IonCol size-md="10" size-xs="12" className='mop-0 '>
                    <IonRow className='mom-5'>
                      <IonCol size-md="12" className="input-label-box">
                        <IonItem
                          className={
                            errors.name
                              ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                              : 'form-group input-label-box position-relative pt-0 mb-0'
                          }
                        >
                          <IonLabel position="floating">{' '}{t('groupproperties.text2')}<sup>*</sup>{' '}</IonLabel>
                          <IonInput type='text' autocomplete='off'
                            className='input-box'
                            placeholder=""
                            id="name"
                            {...register('name')}
                            onIonChange={userformDataChangeHandler}
                            value={groupFormState.name}
                          />
                          <span className={errors.name ? 'error input-error' : ''}>
                            {errors.name?.message}
                          </span>
                        </IonItem>
                      </IonCol>
                      <IonCol size-lg="6" size-md="12" size-xs="12" className='show-tooltip input-popover d-block mb-3 select-cross group-notification'>
                          <Controller
                            name='industry'
                            control={control}
                            render={({ field }) => (
                              <Select type='text' autocomplete='off'
                                {...field}
                                isClearable // enable isClearable to demonstrate extra error handling
                                isSearchable={true}
                                className={
                                  errors.industry
                                    ? 'error-border selectOption moreimp v-imp orm-group input-label-box border borderradius6 position-relative pt-0 mb-0 selectcorss-btn'
                                    : 'selectOption moreimp v-imp orm-group input-label-box position-relative border borderradius6 pt-0 mb-0 editgroup-select selectcorss-btn'
                                }
                                options={industry}
                                value={industry.filter(
                                  (obj) => obj.value === groupFormState.industry
                                )}
                                onChange={industryChangeHandler}
                                placeholder={t('groupproperties.text6') + '*'}
                                styles={customStyles}
                                onBlur={selectErrorMsg}
                              />
                            )}
                          />
                          <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text259')}/>
                          <p className={errors.industry ? 'error input-error left5' : ''}>
                            {errors.industry?.message}
                          </p>
                      </IonCol>
                      <IonCol size-lg="6" size-md="12" size-xs="12" className="input-label-box show-tooltip input-popover">
                        <IonItem
                          className={
                            errors.location
                              ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                              : 'form-group input-label-box position-relative pt-0 mb-0'
                          }
                        >
                          <IonLabel position="floating">{t('groupproperties.text3')}</IonLabel>
                          <IonInput type='text' autocomplete='off'
                            className='input-box input-custom-width'
                            placeholder=""
                            {...register('location')}
                            onIonChange={userformDataChangeHandler}
                            value={groupFormState.location}
                          />
                        <span className={errors.location ? 'error input-error' : ''}>
                          {errors.location?.message}
                        </span>
                        </IonItem>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text260')}/>
                      </IonCol>
                    </IonRow>
                  </IonCol>
                  <IonCol size-lg="6" size-md="12" size-xs="12" className="ion-no-padding">
                    <IonItem
                      className={
                        errors.about
                          ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                          : 'form-group input-label-box position-relative pt-0 mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('groupproperties.text4')}</IonLabel>
                      <IonTextarea
                        className='input-box mt-0'
                        {...register('about')}
                        value={groupFormState.about}
                        onIonChange={aboutChangeHandler}
                        rows={5}
                        maxlength={500}
                        id='about'
                      />
                      <span className={errors.about ? 'error input-error' : ''}>
                        {errors.about?.message || errors.about?.label.message}
                      </span>
                    </IonItem>
                    <p className='text-grey text-end font-14'>{groupFormState.about !== undefined && groupFormState.about !== null && groupFormState.about.length > 0
                      ? groupFormState.about.length
                      : characterCount}/{maxAboutCount}</p>
                  </IonCol>
                  <IonCol
                    size-md="6"
                    size-xs="12"
                    className="ion-no-padding text-area-padding show-tooltip input-popover groupdetailsRules d-flex flex-column"
                  >
                    <IonItem
                      className={
                        errors.rule
                          ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                          : 'form-group input-label-box position-relative pt-0 mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('groupproperties.text5')}</IonLabel>
                      <IonTextarea type='text' autocomplete='off'
                        className='input-box mt-0'
                        {...register('rule')}
                        value={groupFormState.rule}
                        onIonChange={ruleChangeHandler}
                        rows={5}
                        maxlength={500}
                        id='rule'
                      />
                      <span className={errors.rule ? 'error input-error' : ''}>
                        {errors.rule?.message || errors.rule?.label.message}
                      </span>
                    </IonItem>
                    <p className='text-grey text-end font-14'>
                      {groupFormState.rule !== undefined && groupFormState.rule !== null && groupFormState.rule.length > 0
                        ? groupFormState.rule.length
                        : ruleCharacterCount}/{maxRuleCount}
                      <PopoverCommon className='popover-zyapaar position-relative float-right' Description={t('appproperties.text261')}/>
                    </p>
                  </IonCol>
                </IonRow>
              </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
                <IonRow>
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto"
                    size="small"
                    type="submit"
                    disabled={updateDisabled}
                  >
                    {t('groupproperties.text22')}
                    {updateDisabled
                      ? <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                      : ''
                    }
                  </IonButton>
                </IonRow>
              </IonFooter>
            </form>
          </div>
        </IonContent>

      </IonModal>
      <IonModal
        isOpen={reportModal}
        className="createGroupModal recommed-modal"
        onDidDismiss={() => setReportModel(false)}
        id="report-modal"
      >

          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6 ion-padding-start ps-3">
            {t('commonproperties.text19')}
            </IonLabel>
            <div
              onClick={() => setReportModel(false)}
              className="close ion-no-padding"
            >
              <IonIcon
                icon={close}
                className="ion-button-color pe-2"
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <div className="modal-body">
            <div className="body-content">
              <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
                <IonCol size-md="12" size-xs="12" className="ion-no-padding p-lg-3 p-1 pt-2">
                  <IonItem
                    className={
                      errors.reason
                        ? 'error-border form-group input-label-box position-relative pt-0 mb-0 reportmsg'
                        : 'form-group input-label-box position-relative pt-0 mb-0 reportmsg'
                    }
                  >
                    <IonLabel position="floating">{t('commonproperties.text18')}</IonLabel>
                    <IonTextarea
                      type="text"
                      autocomplete="off"
                      placeholder=''
                      rows="13"
                      className='input-box mt-0'
                      value={reason}
                      maxlength={500}
                      onIonChange={reportChangeHandler}
                    />
                    <span className={errors.reason ? 'error input-error' : ''}>
                      {errors.reason?.message}
                    </span>
                  </IonItem>
                  <p className="text-grey text-end font-14 mt-3">
                    {characterCount}/{maxCount}
                  </p>
                </IonCol>
              </IonRow>
            </div>

              <IonRow className='pe-3'>
                {/* <IonButton
                  className="header-row-margin-left ion-button-color ml-auto pr-0"
                  size="small"
                  type="button"
                  onClick={clickHereToReport}
                >
                  Spam
                </IonButton> */}
                <ButtonComponent btnClick={clickHereToReport} size="small"
                className='header-row-margin-left ion-button-color ml-auto pr-0' name ={t('commonproperties.text19')} parametersPass={0} />
              </IonRow>

          </div>

      </IonModal>
      <ConfirmModelCommon header={t('appproperties.text424')} message={confirmMessage} btn1={t('appproperties.text11')} btn2={t('appproperties.text339')} confirmModel={confirmModel} setConfirmModel={setConfirmModel} deleteBtnHandler={leaveBtnHandler} />
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}
    </>
  );
};
export default GroupDetail;
