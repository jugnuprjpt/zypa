/* eslint-disable indent */
/* eslint-disable multiline-ternary */
/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardContent,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonIcon,
  IonItem,
  IonList,
  useIonPopover
} from '@ionic/react';
import { ellipsisVertical, trashBinOutline } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router';
import ButtonComponent from './ButtonComponent';
import MutualConnectionRow from './MutualConnectionRow';
const CommonGridList = (props: any) => {
  const { t } = useTranslation();
  const history = useHistory();
  const openThreeDot = (e) => {
    present({ event: e.nativeEvent });
    const data = {};
    data.id = props.id;
    data.name = props.name;
    props.setRemoveConnectionModalData(data);
  };
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <>
      {props.dots === true
        ? (
          <IonList className="my-account-pr">
            <IonItem
              lines="none"
              className="cursor-pointer"
              onClick={(e) => {
                e.stopPropagation();
                onHide();
                props.setRemoveConfirmModel(true);
              }}
            >
              <IonIcon size="small" icon={trashBinOutline} className="header-menu-img " />
              {props.dotsEventLable1 !== undefined &&
                props.dotsEventLable1 !== ''
                ? (
                  <p>{props.dotsEventLable1}</p>
                )
                : (
                  ''
                )}
            </IonItem>
          </IonList>
        )
        : (
          ''
        )}
    </>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });
  const onClick = () => {
    if(props.redirection){
      window.open("https://www.zyapaar.com/");
    }else if (props.userId !== undefined && props.userId !== undefined) {
      history.push('/' + props.redirectLink + '/' + props.userId + '/' + props.id);
    } else {
      history.push('/' + props.redirectLink + '/' + props.id);
    }
  };

  return (
    <>
      <div className="connectionListCommon">
        <IonCol>
          <IonCard className="m-0 ion-padding cursor-pointer">
            {props.DefaulCover === false && props.coverImg === false
              ? ''
              : <>
                {props.coverImg === undefined || props.coverImg === null || props.coverImg === '' ? (
                  <div
                    className='position-absolute w-100 coverBanner'
                    style={{ background: 'url(' + props.DefaulCover + ')', backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', height: '60px', top: '0px', left: '0', zIndex: '1' }}
                    onClick={onClick}
                  />
                ) : (
                  <div
                    className='position-absolute w-100 coverBanner'
                    style={{ background: 'url(' + props.coverImg + ')', backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', height: '60px', top: '0px', left: '0', zIndex: '1' }}
                    onClick={onClick}
                  />
                )}
              </>
            }
            <IonCardContent className="text-center">
              {props.dots === false
                ? (
                  ''
                )
                : (
                  props.isAdmin
                    ? <IonIcon
                      icon={ellipsisVertical}
                      slot="start"
                      className="font-18 text-grey actions cursor-pointer position-absolute"
                      onClick={(e) => { e.stopPropagation(); openThreeDot(e) }}
                    />
                    : ''
                )}
              <div
              // className='cursor-pointer'
              onClick={onClick}
              >
                <IonAvatar
                  slot="start"
                  className="mx-md-auto"
                >
                  {props.img === undefined ||
                    props.img === null ||
                    props.img === ''
                    ? (
                      <img src={props.defultImage} alt="Brand Logo" />
                    )
                    : (
                      <img onError={(ev) => { ev.target.src = props.defultImage; }} src={props.img} alt="Brand Logo" />
                    )}
                </IonAvatar>
              </div>
              <div className='intro'>

                <IonCardSubtitle className='text-normal'>
                  <IonCardTitle onClick={onClick}>
                    <span
                      className="fixed-textline cons-name pt-lg-3 MuiTypography-body1 cursor-pointer"
                    // onClick={onClick}
                    >
                      {props.name}
                    </span>
                  </IonCardTitle>
                  {props.subString !== undefined && props.subString !== ''
                    ? (
                      <p className="fixed-textline1 cons-designation color-darkgrey cursor-pointer"
                        onClick={(e) => { e.stopPropagation(); onClick() }}
                      >
                        {props.subString}
                      </p>
                    )
                    : (
                      ''
                    )}
                  <span className="margin MuiTypography-caption group-model-text">
                    <MutualConnectionRow id={props.id} name={props.name} key={props.id}/>
                  </span>
                  {props.subString2 !== undefined && props.subString2 !== ''
                    ? (
                      <p className="cons-mulconnection mt-1 cursor-pointer"
                        onClick={(e) => { e.stopPropagation(); onClick()}}
                      >
                        {props.subString2}</p>
                    )
                    : (
                      ''
                    )}
                  {props.btnText !== undefined && props.btnText !== ''
                    ? (
                      <ButtonComponent
                        btnClick={props.btnFnc}
                        className='ion-button-color mt-2 pe-0'
                        size='small'
                        name={props.btnText} parametersPass={0} />
                    )
                    : (
                      ''
                    )}
                  {props.gotoProfile !== undefined && props.gotoProfile !== ''
                    ? (
                      <span className='w-100 d-block cursor-pointer'
                        onClick={(e) => { e.stopPropagation(); onClick() }}
                      >
                        <IonButton
                          size="small"
                          className="link-btn m-0 header-row-margin-left ion-padding-left p-0"
                        // onClick={onClick}
                        >
                          {props.gotoProfile}
                        </IonButton>
                      </span>
                    )
                    : (
                      ''
                    )}
                  {props.isAdmin === false && props.isHide === false
                    ? (
                      <IonButton
                        fill="clear"
                        className="link-btn m-0 header-row-margin-left ion-padding-left p-0"
                        onClick={(e) => { e.stopPropagation(); props.btnLeave() }}
                      >
                        {props.isAdminText}
                      </IonButton>
                    )
                    : (
                      ''
                    )}
                  {props.showAdminTag === true && props.isAdmin === true
                    ? (
                      <IonButton
                        fill="clear"
                        className="link-btn m-0 header-row-margin-left ion-padding-left p-0"
                        onClick={(e) => { e.stopPropagation(); onClick() }}
                      >
                        {t('appproperties.text193')}
                      </IonButton>
                    )
                    : (
                      ''
                    )}
                </IonCardSubtitle>
              </div>
            </IonCardContent>
          </IonCard>
        </IonCol>
      </div>
    </>
  );
};
export default CommonGridList;
