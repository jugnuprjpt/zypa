import {
  IonAvatar,
  IonButton,
  IonCard,
  IonChip,
  IonCol,
  IonContent,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonLabel,
  IonModal,
  IonRow
} from '@ionic/react';
import {
  close,
  chatboxOutline,
  shareSocialOutline,
  arrowRedoOutline,
  chatboxEllipsesOutline,
  sendOutline
} from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import Emojis from '../feed/Emojis';
import CommentBox from './CommentBox';
import Like from '../../assets/img/emojis/like.svg';
import Celebrate from '../../assets/img/emojis/celebration.svg';
import ShakeHand from '../../assets/img/emojis/shakehands.svg';
import Interest from '../../assets/img/emojis/interest.svg';
import Supports from '../../assets/img/emojis/support.svg';
import Pdf from '../../assets/img/icons/pdf-icon.svg';
import { Share } from '@capacitor/share';

import { useDispatch, useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import CallFor from '../../util/CallFor';
import ImageGallery, { ReactImageGalleryItem } from 'react-image-gallery';
import SharePost from './SharePost';
import { useHistory } from 'react-router';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import Editor from './Editor';
import ProfileDetailRow from './ProfileDetailRow';
import FeedDiv from './FeedDiv';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Device } from '@capacitor/device';
import VideoPlayer from './VideoPlayer';
import MobileViewFeed from '../feed/MobileViewFeed';
import { useTranslation } from 'react-i18next';
import CatalougeSuggestion from './CatalougeSuggestion';
import BuyerInquiry from './BuyerInquiry';

const FeedCommon = (props: any) => {
  const [loginModal, setLoginModal] = useState(false);
  const { t } = useTranslation();
  const history = useHistory();
  const [reactionBtnData, setReactionBtnData] = useState({
    postId: '923136026965442560',
    count: 0,
    likeCount: 0,
    celebrateCount: 0,
    interestCount: 0,
    shakeHandCount: 0,
    supportCount: 0
  });
  const [reactionData, setReactionData] = useState([]);
  const [allBtnClass, setAllBtnClass] = useState('ion-button-color');
  const [likeBtnClass, setLikeBtnClass] = useState('category-btn-color');
  const [celebrateBtnClass, setCelebrateBtnClass] = useState('category-btn-color');
  const [interestBtnClass, setInterestBtnClass] = useState('category-btn-color');
  const [shakehandsBtnClass, setShakehandsBtnClass] = useState('category-btn-color');
  const [supportBtnClass, setSupportBtnClass] = useState('category-btn-color');
  const [showReactionModal, setShowReactionModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showImgModal, setshowImgModal] = useState(false);
  const [selectedImgIndex, setSelectedImgIndex] = useState(0);
  const [commentPageCount, setCommentPageCount] = useState(0);
  const [isLoaderShow, setIsLoaderShow] = useState(true);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const dispatch = useDispatch();
  const profileDetail = useSelector(getProfileDetails);
  const [imgDimention, setImgDimention] = useState();
  const photoGallery: readonly ReactImageGalleryItem[] | { original: any }[] =
    [];
  const videoGallary = [];
  let pdfFile = '';

  useEffect(async () => {
    let subscription = true;

    if (subscription) {
      if (document.getElementById('feed-modal')?.getAttribute('aria-modal')) {
        setCommentPageCount(1);
      }
    }

    return () => {
      subscription = false
    }
  }, []);
  
  const reactionDetails = async (postId, reactionCount) => {
    if (reactionCount !== 0) {
      setShowReactionModal(true);
      const allFeedDataResponse = await CallFor('api/v1/reaction/' + postId, 'get', null, 'Auth');
      if (allFeedDataResponse.status === 200) {
        const json1Response = await allFeedDataResponse.json();
        if (json1Response.data !== null) {
          setReactionBtnData(json1Response.data);
        }
      } else if (allFeedDataResponse.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
      getReactionData('ALL', 0, postId);
    }
  };
  const commentBoxBtnHandler = async (
    id: string,
    page: string | number,
    index: string | number | undefined
  ) => {
    let PageCount = commentPageCount;
    if (commentPageCount === 0 && props.isMobile) {
      PageCount = 1;
    }
    const data = '{"page": ' + PageCount + ' }';
    const response1 = await CallFor('api/v1/post/comments/' + id, 'POST', data, 'Auth');
    if (response1.status === 200) {
      const jsonResponse = await response1.json();
      if (jsonResponse.data.content.length > 0) {
        if (page === 0) {
          dispatch({
            type: 'add_comments_feedsData_firstTime',
            comments: jsonResponse.data.content,
            index: index
          });
        } else {
          jsonResponse.data.content.map((details) => {
            dispatch({
              type: 'add_comments_feedsData',
              comments: details,
              index: index
            });
          });
        }
        setCommentPageCount(commentPageCount + 1);
      } else {
        if (page === 0) {
          dispatch({
            type: 'add_comments_feedsData_firstTime',
            comments: jsonResponse.data.content,
            index: index
          });
        }
        setIsLoaderShow(false);
      }
    } else if (response1.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const [commentMobileViewModel, setCommentMobileViewModel] = useState(false);
  const showCommentboxHandler = (
    index: string | number | undefined,
    showCommentsbox: any
  ) => {
    if (window.innerWidth < 991) {
      if (!document.getElementById('feed-modal')?.getAttribute('aria-modal')) {
        setCommentMobileViewModel(true);
      }
    }
    if (showCommentsbox) {
      dispatch({
        type: 'comment_btn_feedsData',
        showCommentsbox: false,
        index: index
      });
    } else {
      dispatch({
        type: 'comment_btn_feedsData',
        showCommentsbox: true,
        index: index
      });
    }
  };
  const [scollingReactionType, setScollingReactionType] = useState();
  const [scollingPostId, setScollingPostId] = useState();
  const [isLoadding, setIsLoading] = useState(false);
  const getReactionData = async (reactionType, page, postId) => {
    setInfiniteDisabled(false);
    setIsLoading(true);
    setCount(1);
    if (reactionType === 'ALL') {
      setAllBtnClass('ion-button-color');
      setLikeBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'LIKE') {
      setAllBtnClass('category-btn-color');
      setLikeBtnClass('ion-button-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'CELEBRATE') {
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('ion-button-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'INTEREST') {
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('ion-button-color');
      setShakehandsBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'SHAKEHANDS') {
      setShakehandsBtnClass('ion-button-color');
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
    } else if (reactionType === 'SUPPORT') {
      setSupportBtnClass('ion-button-color');
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
    }
    const allFeedDataResponse = await CallFor('api/v1/reaction/list/' + postId + '/' + reactionType,
      'POST', JSON.stringify({ page: 0 }), 'Auth');
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      setReactionData(json1Response.data.content);
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setScollingReactionType(reactionType);
    setScollingPostId(postId);
    setIsLoading(false);
  };
  const [originData, setOriginData] = useState({ origin: props.origin, originId: props.originId });
  const sharePostHandler = (origin, originId) => {
    const data = {};
    if (origin === '1') {
      data.origin = 'USER';
      data.originId = originId;
    } else if (origin === '2') {
      data.origin = 'PAGE';
      data.originId = originId;
    } else if (origin === '3') {
      data.origin = 'GROUP';
      data.originId = originId;
    }
    if (data.origin !== undefined) {
      setOriginData(data);
    }
    setShowShareModal(true);
  };
  const imgModalOpen = (selectedImgIndex) => {
    setSelectedImgIndex(selectedImgIndex);
    setshowImgModal(true);
  };
  const mediaMap = (mediaUrl) => {
    if (mediaUrl !== undefined) {
      mediaUrl.map((media) => {
        if (media.split('.').pop() === 'mp4' || media.split('.').pop() === 'mov' || media.split('.').pop() === 'MP4' || media.split('.').pop() === 'MOV') {
          videoGallary.push(media);
        } else if (media.split('.').pop() === 'pdf') {
          console.log(media);
          pdfFile = media;
        } else {
          photoGallery.push({ original: media });
        }
      });
    };
  };
  const textMethod = (text) => {
    let stringvalue = '';
    if (text.length > 200) {
      let msg = text.slice(0, 201);
      for (let i = 201; i < text.length; i++) {
        if (text.charAt(i) !== ' ') {
          msg += text.charAt(i);
        } else {
          break;
        }
      }
      stringvalue = msg;
    } else {
      stringvalue = text.slice(0, text.length + 1);
    }

    return stringvalue;
  };
  const changeContent = (contentObj) => {
    if (contentObj.text.length > 1) {
      let finalString = contentObj.text;
      const subStringval = textMethod(finalString);
      let EmailAnchorlength = 0;
      const ValidateEmail = (mail) => {
        const emailsArray = mail.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
        if (emailsArray != null && emailsArray.length > 0) {
          let j = 0;
          const uniqueChars = [...new Set(emailsArray)];
          let count = 0;
          while (j < uniqueChars.length) {
            const re = new RegExp(uniqueChars[j], 'g');
            const temp = subStringval;
            count += (temp.match(re) || []).length;
            j++;
          }
          EmailAnchorlength = 7 * count;
          let i = 0;
          while (i < uniqueChars.length) {
            const re = new RegExp(uniqueChars[i], 'g');
            finalString = finalString.replace(re, `<a class="font-color" href="mailto:${uniqueChars[i]}">${uniqueChars[i]}</a>`);
            i++;
          }
        }
        return finalString;
      };

      ValidateEmail(finalString);
      let isSame = true;
      if (subStringval.trim().length === finalString.trim().length) {
        isSame = false;
      }
      const urlarr: any[] = [];
      const ValidateUrl = (text) => {
        const urlRegex = /(([a-z]+:\/\/)?(([a-z0-9\-]+\.)+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel|local|internal))(:[0-9]{1,5})?(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&amp;]*)?)?(#[a-zA-Z0-9!$&'()*+.=-_~:/?]*)?)(\s+|$)/gi;
        return text.replace(urlRegex, (url) => {
          urlarr.push(url);
          let urlval = url;
          if (urlval.includes('https://') || urlval.includes('http://')) {
          } else {
            urlval = `https://${url}`;
          }
          const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
          return `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'>${url}</a>`;
        });
      };
      finalString = ValidateUrl(finalString);
      const uniqueUrl = [...new Set(urlarr)];
      let j = 0;
      const arr = [];
      while (j < uniqueUrl.length) {
        const re = new RegExp(uniqueUrl[j], 'g');
        const temp = subStringval;
        arr.push(temp.match(re) || []);
        j++;
      }
      const uniarr = [];
      const uninum = [];
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].length > 0) {
          uninum.push(arr[i].length);
        }

        if (arr[i][0] !== undefined) {
          uniarr.push(arr[i][0]);
        }
      }

      let k = 0;
      let Urllength = 0;
      while (k < uniarr.length) {
        let urlval = uniarr[k];
        if (urlval.includes('https://') || urlval.includes('http://')) {
        } else {
          urlval = `https://${uniarr[k]}`;
        }
        const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
        const val = `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'></a>`;
        Urllength = Urllength + val.length * uninum[k];
        k++;
      }

      let AnchorLength = 0;
      let hashlength = 0;
      let hashData = '';

      if (contentObj.attributes.length > 0) {
        const data = [];
        contentObj.attributes.forEach((element) => {
          const res = contentObj.text.substring(element.start, element.start + element.length);
          if (element.mention === 'PROFILE') {
            if (data.includes(res)) {
              const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
              AnchorLength += val.length;
            } else {
              data.push(res);
              finalString = finalString.replaceAll(res, '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '">' + res + '</a>');
              const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
              AnchorLength += val.length;
            }
          }
        });
      }
      hashData = finalString.match(/#[a-z]+/gi);
      if (hashData !== null && hashData.length > 0) {
        const map = {};
        hashData.map((hashValue) => {
          if ((Object.keys(map).filter(item => item === hashValue)).length > 0) {
            const cnt = map.[hashValue];
            map.[hashValue] = 1;
          } else {
            map.[hashValue] = 1;
            finalString = finalString.replaceAll(hashValue, '<span style="text-decoration: none;" class = "font-color" href="#">' + hashValue + '</span>');
          }
          const val = '<span style="text-decoration: none;" class ="font-color" href="#">' + hashValue + '</span>';
          hashlength += val.length;
        });
      }
      finalString = finalString.replace(/(\r\n|\r|\n)/g, '<br>');
      const breakstring = finalString.slice(0, AnchorLength + subStringval.length);
      const countbreak = breakstring.match(/<br>/gi);
      let breakcount = 0;
      if (countbreak !== null && countbreak.length > 0) {
        breakcount = countbreak.length;
      }
      if (finalString.length > (200 + EmailAnchorlength + Urllength + AnchorLength + hashlength + breakcount * 3) && !showMore) {
        return (
          <>
            <span dangerouslySetInnerHTML={{ __html: finalString.slice(0, EmailAnchorlength + Urllength + AnchorLength + hashlength + subStringval.length + breakcount * 3 + 1) }} />

            {isSame
              ? <a
                onClick={() => setShowMore(true)} >
                {t('appproperties.text399')} </a>
              : ' '}
          </>
        );
      } else {
        return (
          <span dangerouslySetInnerHTML={{ __html: finalString }} />
        );
      }
    } else {
      return '';
    }
  };
  const getImgdata = () => {
    if (photoGallery.length > 0) {
      if (photoGallery.length >= 5) {
        return (<div className="post-img tow-col img5">
          <div className="col-1">
            <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            <img src={photoGallery[1].original} onClick={() => imgModalOpen(1)} />
          </div>
          <div className="col-2">
            <img src={photoGallery[2].original} onClick={() => imgModalOpen(2)} />
            <img src={photoGallery[3].original} onClick={() => imgModalOpen(3)} />
            <img src={photoGallery[4].original} onClick={() => imgModalOpen(4)} />
            {photoGallery.length > 5
              ? <span className="count" onClick={() => imgModalOpen(4)}> + {photoGallery.length - 5}</span>
              : ''
            }
          </div>
        </div>);
      } else if (photoGallery.length === 4) {
        return (<div className="post-img tow-col">
          <div className="col-1 img2">
            <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            <img src={photoGallery[1].original} onClick={() => imgModalOpen(1)} />
          </div>
          <div className="col-2 img2">
            <img src={photoGallery[2].original} onClick={() => imgModalOpen(2)} />
            <img src={photoGallery[3].original} onClick={() => imgModalOpen(3)} />
          </div>
        </div>);
      } else if (photoGallery.length === 3) {
        return (<div className="post-img">
          <div className="col-1 img3">
            <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            <img src={photoGallery[1].original} onClick={() => imgModalOpen(1)} />
            <img src={photoGallery[2].original} onClick={() => imgModalOpen(2)} />
          </div>
        </div>);
      } else if (photoGallery.length === 2) {
        return (<div className="post-img">
          <div className="col-1 img2">
            <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            <img src={photoGallery[1].original} onClick={() => imgModalOpen(1)} />
          </div>
        </div>);
      } else if (photoGallery.length === 1) {
        getMeta(photoGallery[0].original);
        if (imgDimention !== undefined && imgDimention >= 815) {
          return (<div className="post-img graterImg">
            <div className="col-1 img1">
              <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            </div>
          </div>);
        } else {
          return (<div className="post-img lessImg">
            <div className="col-1 img1">
              <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            </div>
          </div>);
        }
      }
    }
  };
  const getFileName = (val) => {
    const url = val.split('/').pop();
    const lastslashindex = url.indexOf('_');
    return decodeURI(url.substring(lastslashindex + 1));
  };
  const sendPostHandler = async (feedId) => {
    const deviceDetails = await Device.getInfo();
    if (deviceDetails.platform === 'ios' || deviceDetails.platform === 'android') {
      await Share.share({
        text: 'Zyapaar - View Feed ',
        url: 'https://zyapaar.com/viewfeed/' + feedId
      });
    } else {
      let url = 'https://web.whatsapp.com/send?';
      url += '&text=https://www.zyapaar.com/viewfeed/' + feedId;
      window.open(url);
    }
  };
  const [count, setCount] = useState(1);
  const loadData = (ev: any) => {
    setTimeout(() => {
      scrollData();
      ev.target.complete();
    }, 500);
  };
  const scrollData = async () => {
    const allFeedDataResponse = await CallFor('api/v1/reaction/list/' + scollingPostId + '/' + scollingReactionType,
      'POST', JSON.stringify({ page: count }), 'Auth');
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      // setReactionData(json1Response.data.content);
      if (json1Response.data.content.length > 0) {
        setReactionData([...reactionData, ...json1Response.data.content]);
        setCount(count + 1);
      } else {
        setInfiniteDisabled(true);
      }
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
    }
  };
  const closeReactionModel = () => {
    setShowReactionModal(false);
    setCount(1);
  };

  function getMeta(url) {
    const img = new Image();
    img.addEventListener('load', function () {
      return setImgDimention(this.naturalWidth);
    });
    img.src = url;
  }
  return (
    <>
      {!props?.feeds?.isReport
        ? <div className='mb-lg-3 mb-2'>
          {!props?.feeds?.isDeleted
            ? <><IonCard className="MuiPaper-rounded ion-no-margin ion-margin-bottom ion-margin-top feed-cards-posts">
              <ProfileDetailRow userProfile={props?.feeds?.userProfile} userName={props?.feeds?.userName}
                userDesignation={props?.feeds?.userDesignation} ageOfPost={props?.feeds.ageOfPost} userId={props.feeds.userId} feedId={props.feeds.id} feedType={props.feeds.type} feedIndex={props.feedKey} companyName={props.feeds.userCompany} />
              <IonRow className='feed-body'>
                <IonRow className='full-width-row ion-padding-horizontal'>
                  {JSON.parse(props.feeds.content).text.length > 1
                    ? <IonLabel className="full-width-row MuiTypography-body2 description">
                      {changeContent(JSON.parse(props.feeds.content))}
                    </IonLabel>
                    : ''}
                </IonRow>
                <IonRow className='full-width-row feed-img'>
                  {mediaMap(props.feeds.mediaUrl)}
                  {photoGallery.length > 0
                    ? (
                      getImgdata()
                    )
                    : (
                      ''
                    )}
                </IonRow>
                <IonRow className='full-width-row feed-img'>
                  {videoGallary.length > 0
                    ? Object.entries(videoGallary).map((details) => (
                      <>
                        <div className="post-img post-video">
                          <div className="col-1">
                            <VideoPlayer url={details[1]} />
                          </div>
                        </div>
                      </>))
                    : ''}</IonRow>
                {pdfFile.length > 0
                  ? <div className="pdf-file-cn">
                    <a href={pdfFile} target='_blank' rel="noreferrer"> <img src={Pdf} width='20' /> {getFileName(pdfFile)}</a>
                  </div>
                  : ''}
              </IonRow>
              <IonRow>

                {props.feeds.postOf !== null
                  ? <FeedDiv postOf={props.feeds.postOf} key={props.feeds.postOf} />
                  : ''}
              </IonRow>
              <IonRow className="card-header-text post-comment-view">
                <IonRow className="full-width-row com-first-row">
                  <IonCol size-md="6" size-xs="4" className="myprofile-feeds pa-0">
                    <IonChip
                      className="post-btn ion-no-padding ion-padding-start ion-padding-end mobile-thumb"
                      onClick={() => reactionDetails(props.feeds.id, props.feeds.reactionCount)}
                    >
                      <IonAvatar className="ion-no-padding reaction-btn">
                        {/* <img src ={Like} width='20'/> */}
                        {(() => {
                          if (props.feeds.reaction === '1') {
                            return (
                              <><img src={Like} width="20" /> <span>{t('feedproperties.text6')}</span></>
                            );
                          } else if (props.feeds.reaction === '2') {
                            return (
                              <><img src={Celebrate} width="20" /><span>{t('feedproperties.text7')}</span></>
                            );
                          } else if (props.feeds.reaction === '3') {
                            return (
                              <><img src={Interest} width="20" /><span>{t('feedproperties.text8')}</span></>
                            );
                          } else if (props.feeds.reaction === '4') {
                            return (
                              <><img src={ShakeHand} width="20" /><span>{t('feedproperties.text9')}</span></>
                            );
                          } else if (props.feeds.reaction === '5') {
                            return (
                              <><img src={Supports} width="20" /><span>{t('feedproperties.text10')}</span></>
                            );
                          } else {
                            return (
                              <><img src={Like} width="20" /> <span>{t('feedproperties.text6')},</span></>
                            );
                          }
                        })()}
                        {/* <img src ={Celebrate} width='20'/> */}
                        {/* <img src ={ShakeHand} width='20'/> */}
                      </IonAvatar>
                    </IonChip>
                    <p className="rectionCount"> {props.feeds.reactionCount}</p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="8" className="ion-align-self-center pa-0">
                    <p className="ion-float-right secondary-text MuiTypography-body2">
                      <span className='cursor-pointer'
                        onClick={function (event) {
                          if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                            if (props.feeds.showCommentsbox === undefined) {
                              commentBoxBtnHandler(props.feeds.id, commentPageCount, props.feedKey);
                            }
                            showCommentboxHandler(props.feedKey, props.feeds.showCommentsbox);
                          } else {
                            // history.push('/addnewcompany');
                            setLoginModal(true);
                          }
                        }}
                      >
                        {props.feeds.commentCount} {t('feedproperties.text11')}
                      </span>
                      {/* <span className="dot"></span> {props.feeds.viewCount} {t('feedproperties.text12')} */}
                    </p>
                  </IonCol>
                </IonRow>
                <IonRow className="action-buttons full-width-row ion-margin-start ion-margin-end">
                  <Emojis id={props.feeds.id} reactionId={props.feeds.reactionId} reaction={props.feeds.reaction}
                    postUserId={props.feeds.userId} feedIndex={props.feedKey} type='post' profileDetail={profileDetail} />
                  
                  <IonButton
                    fill="clear"
                    className="ion-text-capitalize ion-no-padding reaction-color-tab right-padding vertical-btn" onClick={() => {
                      if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                        sharePostHandler(props.feeds.origin, props.feeds.originId);
                      } else {
                        //history.push('/addnewcompany');
                        setLoginModal(true);
                      }
                    }}

                  >
                    <div className="vertical-btn">
                      <IonIcon
                        icon={shareSocialOutline}
                        className="reaction-padding "
                        size="large" />
                      <span>{t('appproperties.text233')}</span></div>
                  </IonButton>
                  <IonButton
                    fill="clear"
                    className="ion-text-capitalize ion-no-padding reaction-color-tab vertical-btn"
                    onClick={() => {
                      if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                        sendPostHandler(props.feeds.id);
                      } else {
                        // history.push('/addnewcompany');
                        setLoginModal(true);
                      }
                    }}
                  >
                    <div className="vertical-btn send-rotate">
                      <IonIcon
                        icon={sendOutline}
                        className="reaction-padding "
                        size="large" />
                      <span>{t('feedproperties.text15')}</span>
                    </div>
                  </IonButton>
                  <IonButton
                    fill="clear"
                    className="ion-text-capitalize ion-no-padding reaction-color-tab vertical-btn"
                    onClick={function (event) {
                      if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                        if (props.feeds.showCommentsbox === undefined) {
                          commentBoxBtnHandler(props.feeds.id, commentPageCount, props.feedKey);
                        }
                        showCommentboxHandler(props.feedKey, props.feeds.showCommentsbox);
                      } else {
                        // history.push('/addnewcompany');
                        setLoginModal(true);
                      }
                    }}
                  >
                    <div className="vertical-btn inqiure-button"><IonIcon
                      icon={chatboxEllipsesOutline}
                      className="reaction-padding"
                      size="large" />
                      <span className='ps-1'>Inquire</span></div>
                  </IonButton>
                </IonRow>
                {!commentMobileViewModel
                  ? <>
                    {props.feeds.showCommentsbox !== undefined &&
                      props.feeds.showCommentsbox === true
                      ? (
                        <><IonRow className="full-width-row ion-padding-bottom comment-box-content-box comment-filed-control dn-mobile">
                          <IonCol size-md="1" size-xs="2" className="ion-no-padding">
                            <div className="myprofile-feeds ps-lg-3 ps-0">
                              <IonAvatar
                                slot="start"
                                className="MuiCardHeader-avatar MuiAvatar-circular"
                              >
                                {profileDetail.profileImg !== null
                                  ? <img src={profileDetail.profileImg} />
                                  : <img src={userProfile} />}
                              </IonAvatar>
                            </div>
                          </IonCol>
                          <IonCol
                            size-md="11"
                            size-xs="10"
                            className="ion-no-padding ion-padding-end"
                          >
                            <Editor postId={props.feeds.id} postUserId={props.feeds.userId} feedIndex={props.feedKey} type='Comment' placeholder={t('appproperties.text228')} />
                          </IonCol>
                        </IonRow>
                          <>
                            {props.feeds.comments !== undefined
                              ? Object.entries(props.feeds.comments).map(([commentKey, commentObj]) => (
                                <>
                                  <CommentBox
                                    commentObj={commentObj}
                                    feedKey={props.feedKey}
                                    opId={props.feeds.id}
                                    postUserId={props.feeds.userId}
                                    commentInput={true} commentKey={commentKey} />
                                </>
                              ))
                              : ''}
                            {props.feeds.showCommentsbox !== undefined &&
                              props.feeds.showCommentsbox === true
                              ? (
                                <>
                                  {props.feeds.comments != null && props.feeds.comments.length >= 5 && isLoaderShow
                                    ? <IonRow className="full-width-row loadmore-btn-con">
                                      <IonButton
                                        fill="clear"
                                        className="text-normal loadmore"
                                        onClick={() => commentBoxBtnHandler(props.feeds.id, 1, props.feedKey)}
                                      >
                                        {t('appproperties.text368')}
                                      </IonButton>
                                    </IonRow>
                                    : ''}
                                </>
                              )
                              : (
                                ''
                              )}
                          </></>
                      )
                      : ('')}
                  </>
                  : ''}
              </IonRow>
            </IonCard>

              {!commentMobileViewModel
                ? <>{props.feeds.showCommentsbox !== undefined &&
                  props.feeds.showCommentsbox === true
                  ? (
                    <IonRow className="full-width-row ion-padding-bottom comment-box-content-box comment-filed-control d-lg-none d-block d-flex ion-align-items-center" id ='feedComment'>
                      <IonCol size-md="1" size-xs="2" className="ion-no-padding">
                        <div className="myprofile-feeds ps-0">
                          <IonAvatar
                            slot="start"
                            className="MuiCardHeader-avatar MuiAvatar-circular"
                          >
                            {profileDetail.profileImg !== null
                              ? <img src={profileDetail.profileImg} />
                              : <img src={userProfile} />}
                          </IonAvatar>
                        </div>
                      </IonCol>
                      <IonCol
                        size-md="11"
                        size-xs="10"
                        className="ion-no-padding ion-padding-end"
                      >
                        <Editor postId={props.feeds.id} postUserId={props.feeds.userId} feedIndex={props.feedKey} type='Comment' placeholder={t('appproperties.text228')} />
                      </IonCol>
                    </IonRow>
                  )
                  : ('')}</>
                : ''
              }
            </>
            : <IonCard className='ion-padding ion-no-margin ion-margin-bottom ion-margin-top'>
             {t('feedproperties.text16')}
            </IonCard>}
        </div>
        : <IonCard className='ion-padding ion-no-margin ion-margin-bottom ion-margin-top'>
          {t('feedproperties.text17')}

        </IonCard>}

        {/* Catelouge suggestion */}
        <CatalougeSuggestion/>
     
        {/* Buyer Inquiry */}
        <BuyerInquiry/>

      <IonModal isOpen={showReactionModal} cssClass='add-award-model' onDidDismiss={() => setShowReactionModal(false)}>
        <div className=''>
          <IonCol className="d-flex MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between custom-modal-heading">
            <IonLabel className="MuiTypography-h6">
              {t('feedproperties.text5')}
            </IonLabel>
            <div onClick={closeReactionModel} className="close ion-no-padding me-2 mt-2" >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 cursor-pointer"
                slot="start"
                size="undefined"
              />
            </div>
          </IonCol>
          <IonRow className='reaction-icon-list scroll-mobile-horztl px-2'>
            <IonButton
              className={allBtnClass}
              shape="round"
              size="small"
              onClick={() => getReactionData('ALL', 0, reactionBtnData.postId)}
            >
              {t('appproperties.text15')}
            </IonButton>
            {reactionBtnData.likeCount !== 0
              ? <IonButton
                className={likeBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('LIKE', 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Like} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.likeCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.celebrateCount !== 0
              ? <IonButton
                className={celebrateBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('CELEBRATE', 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Celebrate} width="20" />
                  <span className='ion-padding-start'>{reactionBtnData.celebrateCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.interestCount !== 0
              ? <IonButton
                className={interestBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('INTEREST', 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Interest} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.interestCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.shakeHandCount !== 0
              ? <IonButton
                className={shakehandsBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('SHAKEHANDS', 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={ShakeHand} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.shakeHandCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.supportCount !== 0
              ? <IonButton
                className={supportBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('SUPPORT', 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Supports} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.supportCount}</span>
                </div>
              </IonButton>
              : ''}
          </IonRow>
        </div>
        <IonContent>
          <IonRow className='pb-2 px-3 px-xl-4 ion-padding-top reaction-list-content w-100'>
            {!isLoadding &&
              reactionData.map((reaction) => (
                <>
                  <IonRow className='full-width-row ion-no-padding'>
                    {(() => {
                      if (reaction.reaction === '1') {
                        return (
                          <div className='reation-emoji'><img src={Like} width='20' /></div>
                        );
                      } else if (reaction.reaction === '2') {
                        return (
                          <div className='reation-emoji'><img src={Celebrate} width='20' /></div>
                        );
                      } else if (reaction.reaction === '3') {
                        return (
                          <div className='reation-emoji'><img src={Interest} width='20' /></div>
                        );
                      } else if (reaction.reaction === '4') {
                        return (
                          <div className='reation-emoji'><img src={ShakeHand} width='20' /></div>
                        );
                      } else if (reaction.reaction === '5') {
                        return (
                          <div className='reation-emoji'><img src={Supports} width='20' /></div>
                        );
                      }
                    })()}
                    <div className="myprofile-feeds ion-padding-start">
                      <IonAvatar className="MuiAvatar ion-margin-end">
                        {reaction.profileImage != null
                          ? <img src={reaction.profileImage} />
                          : <img src={userProfile} />
                        }
                      </IonAvatar>
                      <IonRow className="display-grid">
                        <span className='name'>{reaction.userName}</span>
                        <span className="margin MuiTypography-caption group-model-text nowrap-normal">
                          {reaction.designation}
                        </span>
                      </IonRow>
                    </div>
                  </IonRow>
                </>
              ))
            }
            <IonInfiniteScroll
              onIonInfinite={loadData}
              threshold="100px"
              disabled={isInfiniteDisabled}
            >
              <IonInfiniteScrollContent
                loadingSpinner="circular"
                loadingText={t('appproperties.text215')}
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </IonRow>
        </IonContent>
      </IonModal>
      {showShareModal
        ? (<SharePost showShareModal={showShareModal} setShowShareModal={setShowShareModal} feeds={props.feeds} origin={originData.origin} originId={originData.originId} />)
        : ('')}
      <IonModal isOpen={showImgModal} cssClass="add-award-model awd-img-gallery" onDidDismiss={() => setshowImgModal(false)} >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
            <div onClick={() => setshowImgModal(false)} className="close ion-no-padding" >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <IonRow className="overview-heigth ">
            <ImageGallery
              items={photoGallery}
              showPlayButton={false}
              autoPlay={false}
              startIndex={selectedImgIndex}
            />
          </IonRow>
        </IonContent>
      </IonModal>
      <MobileViewFeed commentMobileViewModel={commentMobileViewModel}
        setCommentMobileViewModel={setCommentMobileViewModel}
        feeds={props.feeds} feedKey={props.feedKey} origin={props.origin} originId={props.originId} />
    </>
  );
};
export default FeedCommon;
