import React from 'react';
import MetaTags from 'react-meta-tags';
const MetaTage = (props) => {
  return (
    <MetaTags>
            <meta charSet="UTF-8" />
            <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
           <title>{props.metaDetails.title}</title>
            <meta name="description" content={props.metaDetails.description} />
            <meta name="keywords" content={props.metaDetails.keywords} />
            <link rel="canonical" href={window.location.href}></link>
            <meta name="author" content="zyapaar"/>
            <meta name="copyright" content="Lets Talk Business Pvt. Ltd."/>
            <meta name="robots" content="index, follow"/>
            <meta property="fb:app_id" content="5445705852176938"/>
            <link rel="apple-touch-icon" sizes="180x180" href="/assets/img/apple-touch-icon.png" />
            <link rel="icon" type="image/png" sizes="32x32" href="/assets/img/favicon-32x32.png" />
            <link rel="icon" type="image/png" sizes="16x16" href="/assets/img/favicon-16x16.png" />
            <link rel="manifest" href="/assets/img/site.webmanifest"></link>
            <meta property="og:type" content='website'/>
            <meta property="og:title" content={props.metaDetails.title} />
            <meta property="og:url" content={props.metaDetails.ogurl} />
            <meta property="og:image" content="https://zyapaar-image-test.s3.ap-south-1.amazonaws.com/1652873326512_zyapaar.png" />
            <meta property="og:description" content={props.metaDetails.description}/>
            <meta property="og:description" content={props.metaDetails.description}/>
            <meta property="og:image:width" content="247" /> <meta property="og:image:height" content="250" />
            <meta name="twitter:card" content="summary_large_image" />
            <meta name="twitter:title" content="Zyapaar " />
            <meta name="twitter:site" content="@zyapaar" />
            <meta name="twitter:description" content={props.metaDetails.description} />
            <meta name="twitter:image" content="https://zyapaar-image-test.s3.ap-south-1.amazonaws.com/1652873326512_zyapaar.png" />
      </MetaTags>
  );
};

export default MetaTage;
