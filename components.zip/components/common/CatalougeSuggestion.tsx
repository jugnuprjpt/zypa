import { IonAvatar, IonButton, IonCard, IonIcon, IonRow } from '@ionic/react';
import React from 'react';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import cataloueImage from '../../assets/img/blog/blog-cover-3.jpg';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper';

const CatalougeSuggestion = () => {
  return (
    <>
      <div className="ion-padding-verticale catelogue-suggestion">
        <IonRow>
          <span className="textcolour head-title ms-2 ms-lg-0">Bussiness Catalogue</span>
        </IonRow>
        <IonRow className="connection-suggetion-item-box connection-member mt-2 ps-2">
          <Swiper
            id="ka-swiper2"
            navigation={true}
            modules={[Navigation, Pagination]}
            className="mySwiper"
            autoHeight={true}
            spaceBetween={0}
            breakpoints={{
              320: {
                slidesPerView: 1.05
              }
            }}
          >
            <SwiperSlide className="ion-padding-end" >
              <IonCard className="MuiPaper-rounded ion-margin-bottom ion-no-margin connectionSuggestion">
                <div className='catalogueImg' style={{ background: 'url(' + cataloueImage + ')', height: '110px' }}>
                  {/* <img src={cataloueImage} alt="Catalogue" /> */}
                </div>
                <div className="myprofile-feeds ion-padding-start  post-card w-100 feed-cards-posts m-0">
                  <div className='myprofile-feeds ion-no-padding cursor-pointer w-75'>
                    <IonAvatar
                      slot="start"
                      className="MuiCardHeader-avatar MuiAvatar-circular"
                    >
                    </IonAvatar>
                    <IonRow className="profileName overflow-nowrap">
                      <h2 className="margin MuiTypography-body1">
                        Shubham Dholaria
                      </h2>
                      <span className="margin MuiTypography-caption">
                        Wholesaler @Joint International Craft
                      </span>
                      <span className="margin MuiTypography-caption d-block text-left">
                        (Ahmedabad - Kalupur)
                      </span>
                    </IonRow>
                  </div>
                  <IonRow className="ion-float-right header-row-margin-left">
                    <IonButton
                      fill="clear"
                      className="m-0 header-row-margin-left ion-padding-left p-0">
                      <span>Connect</span>
                    </IonButton>
                  </IonRow>
                </div>
              </IonCard>
            </SwiperSlide>
            <SwiperSlide className="ion-padding-end" >
              <IonCard className="MuiPaper-rounded ion-margin-bottom ion-no-margin connectionSuggestion">
                <div className='catalogueImg' style={{ background: 'url(' + cataloueImage + ')', height: '110px' }}>
                  {/* <img src={cataloueImage} alt="Catalogue" /> */}
                </div>
                <div className="myprofile-feeds ion-padding-start  post-card w-100 feed-cards-posts m-0">
                  <div className='myprofile-feeds ion-no-padding cursor-pointer w-75'>
                    <IonAvatar
                      slot="start"
                      className="MuiCardHeader-avatar MuiAvatar-circular"
                    >
                    </IonAvatar>
                    <IonRow className="profileName overflow-nowrap">
                      <h2 className="margin MuiTypography-body1">
                        Shubham Dholaria
                      </h2>
                      <span className="margin MuiTypography-caption">
                        Wholesaler @Joint International Craft
                      </span>
                      <span className="margin MuiTypography-caption d-block">
                        (Ahmedabad - Kalupur)
                      </span>
                    </IonRow>
                  </div>
                  <IonRow className="ion-float-right header-row-margin-left">
                    <IonButton
                      fill="clear"
                      className="m-0 header-row-margin-left ion-padding-left p-0">
                      <span>Connect</span>
                    </IonButton>
                  </IonRow>
                </div>
              </IonCard>
            </SwiperSlide>
            <SwiperSlide className="ion-padding-end" >
              <IonCard className="MuiPaper-rounded ion-margin-bottom ion-no-margin connectionSuggestion">
                <div className='catalogueImg' style={{ background: 'url(' + cataloueImage + ')', height: '110px' }}>
                  {/* <img src={cataloueImage} alt="Catalogue" /> */}
                </div>
                <div className="myprofile-feeds ion-padding-start  post-card w-100 feed-cards-posts m-0">
                  <div className='myprofile-feeds ion-no-padding cursor-pointer w-75'>
                    <IonAvatar
                      slot="start"
                      className="MuiCardHeader-avatar MuiAvatar-circular"
                    >
                    </IonAvatar>
                    <IonRow className="profileName overflow-nowrap">
                      <h2 className="margin MuiTypography-body1">
                        Shubham Dholaria
                      </h2>
                      <span className="margin MuiTypography-caption">
                        Wholesaler @Joint International Craft
                      </span>
                      <span className="margin MuiTypography-caption d-block">
                        (Ahmedabad - Kalupur)
                      </span>
                    </IonRow>
                  </div>
                  <IonRow className="ion-float-right header-row-margin-left">
                    <IonButton
                      fill="clear"
                      className="m-0 header-row-margin-left ion-padding-left p-0">
                      <span>Connect</span>
                    </IonButton>
                  </IonRow>
                </div>
              </IonCard>
            </SwiperSlide>
          </Swiper>
        </IonRow>
      </div>
    </>
  );
};
export default CatalougeSuggestion;
