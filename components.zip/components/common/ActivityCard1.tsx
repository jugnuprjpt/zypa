import {
  IonCard,
  IonHeader,
  IonRow,
  IonList,
  IonLabel,
  IonItem,
  IonAvatar,
  IonButton,
  IonIcon,
  IonSkeletonText
} from '@ionic/react';
import React from 'react';
import { useHistory } from 'react-router';

const ActivityCard1 = (props: any) => {
  const history = useHistory();
  const detaillink = (link, name, id) => {
    if (props.sublink === 1) {
      history.push(link + name + '/' + id);
    } else if (props.sublink === 2) {
      history.push(link + id + '/1');
    } else if (props.sublink === 4) {
      history.push(link + id);
      window.location.reload(false)
    } else {
      history.push(link + id);
    }
  };
  return (
  <IonCard className={`sdb-box profile-details left-cards no-shadow ${props.className}`} >
    <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between">
        <p className="ion-align-self-start">{props.header}</p>
        {props.headerLinkLable !== ''
          ? <span className="ion-align-self-end "><a href={props.headerLink} className="link-btn-tx">{props.headerLinkLable}</a></span>
          : '' }
      </IonHeader>
    <IonRow>
      <IonList lines="none" className="full-width-row">
        {props.loading
          ? (<><IonRow className="ion-padding-start ion-bottom-padding-smallcom">
          <IonRow>
            <div className="myprofile-feeds ion-no-padding">
              <IonAvatar className="MuiAvatar ion-margin-end">
                <IonSkeletonText animated />
              </IonAvatar>
              <IonRow className='display-grid'>
                <span className="margin MuiTypography-caption group-model-text">
                  <IonSkeletonText animated className='skeleton-width' />
                  {props.subHeader
                    ? <IonSkeletonText animated className='skeleton-width-half' />
                    : ''}
                </span>
              </IonRow>
            </div>
          </IonRow>
          <IonRow className='header-row-margin-left right-padding'>
            {!props.icon
              ? <IonButton fill="clear">
                <IonIcon
                  icon={props.icon}
                  slot="start"
                  size="medium"
                  className="test" />
              </IonButton>
              : <IonSkeletonText animated className='skeleton-width-btn'/>}
          </IonRow>
        </IonRow><IonRow className="ion-padding-start ion-bottom-padding-smallcom">
            <IonRow>
              <div className="myprofile-feeds ion-no-padding">
                <IonAvatar className="MuiAvatar ion-margin-end">
                  <IonSkeletonText animated />
                </IonAvatar>
                <IonRow className='display-grid'>
                  <span className="margin MuiTypography-caption group-model-text">
                    <IonSkeletonText animated className='skeleton-width' />
                    {props.subHeader
                      ? <IonSkeletonText animated className='skeleton-width-half' />
                      : ''}
                  </span>
                </IonRow>
              </div>
            </IonRow>
            <IonRow className='header-row-margin-left right-padding'>
              {!props.icon
                ? <IonButton fill="clear">
                  <IonIcon
                    icon={props.icon}
                    slot="start"
                    size="medium"
                    className="test" />
                </IonButton>
                : <IonSkeletonText animated className='skeleton-width-btn'/>}
            </IonRow>
          </IonRow>
          <IonRow className="ion-padding-start ion-bottom-padding-smallcom">
            <IonRow >
                <div className="myprofile-feeds ion-no-padding">
                  <IonAvatar className="MuiAvatar ion-margin-end">
                    <IonSkeletonText animated />
                  </IonAvatar>
                  <IonRow className='display-grid'>
                    <span className="margin MuiTypography-caption group-model-text">
                    <IonSkeletonText animated className='skeleton-width'/>
                    {props.subHeader
                      ? <IonSkeletonText animated className='skeleton-width-half' />
                      : ''}
                    </span>
                  </IonRow>
                </div>
              </IonRow>
              <IonRow className='header-row-margin-left right-padding'>
                {!props.icon
                  ? <IonButton fill="clear">
                    <IonIcon
                      icon={props.icon}
                      slot="start"
                      size="medium"
                      className="test"
                    />
                  </IonButton>
                  : <IonSkeletonText animated className='skeleton-width-btn'/> }
              </IonRow>
          </IonRow>
          </>)
          : props.mapData.length > 0
            ? props.mapData.map((detail) => {
              return (
                <>
                  <IonRow onClick={() => detaillink(props.fieldLink, detail.name, detail.id)} >
                    <IonRow className='cursor-pointer item' >
                        <div className="myprofile-feeds ion-no-padding cursor-pointer">
                          { detail.entityLogo
                            ? (<IonAvatar className="MuiAvatar ion-margin-end">
                            <img onError={(ev) => { ev.target.src = props.image; }} src={detail.entityLogo} />
                          </IonAvatar>)
                            : (props.image !== undefined
                                ? <IonAvatar className="MuiAvatar ion-margin-end">
                            <img src={props.image} alt=""/>
                          </IonAvatar>
                                : '')
                          }
                           <IonRow className='display-grid'>
                            {detail.name}
                            <span className="margin MuiTypography-caption group-model-text">
                              {detail.designation}
                            </span>
                          </IonRow>
                        </div>
                      </IonRow>
                      <IonRow className='header-row-margin-left'>
                      {detail.connection
                        ? <span className=" top-padding">
                        {detail.connection}
                      </span>
                        : ''}
                          <IonButton fill="clear" onClick={() => props.btn(detail.id)}>
                            <IonIcon
                              icon={props.icon}
                              slot="start"
                              size="medium"
                              className="test"
                            />
                          </IonButton>
                      </IonRow>
                  </IonRow>
                </>
              );
            })
            : <p className='ion-padding'>{props.noDataFound}</p>
        }

        {props.footerLinkLable
          ? <IonItem>
          <IonRow >
            <IonLabel>
              <a>{props.footerLinkLable}</a>
            </IonLabel>
          </IonRow>
        </IonItem>
          : '' }
      </IonList>
    </IonRow>
  </IonCard>
  );
};
export default ActivityCard1;
