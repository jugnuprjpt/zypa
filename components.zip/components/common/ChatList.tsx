import { IonAvatar, IonCard, IonCardContent, IonCardSubtitle, IonCardTitle, IonCol } from '@ionic/react'
import React from 'react'

const ChatList = (props: any) => {
    return (
        <div
            className="connectionListCommon"
        >
            <IonCol>
                <IonCard className="m-0 ion-padding cursor-pointer">
                    <IonCardContent className="text-center">
                        <IonAvatar
                            slot="start"
                            className="mx-md-auto"
                        >
                            {props.img === undefined ||
                                props.img === null ||
                                props.img === ''
                                ? (
                                    <img src={props.defultImage} alt="Brand Logo" />
                                )
                                : (
                                    <img onError={(ev) => { ev.target.src = props.defultImage; }} src={props.img} alt="Brand Logo" />
                                )}
                        </IonAvatar>

                        <div className='intro'>
                            <IonCardSubtitle
                                className='text-normal'
                            >
                                <IonCardTitle>
                                    <span
                                        className="fixed-textline cons-name pt-lg-3 MuiTypography-body1 cursor-pointer"
                                    >
                                        {props.name}
                                    </span>
                                </IonCardTitle>
                            </IonCardSubtitle>
                        </div>
                    </IonCardContent>
                </IonCard>
            </IonCol>
        </div>
    )
}

export default ChatList