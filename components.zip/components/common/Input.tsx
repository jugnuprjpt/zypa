import { IonCol, IonInput } from '@ionic/react';
import React from 'react';

const Input = (props: any) => {
  const { containerStyle, refCallback, ...remainingProps } = props;
  return (
    <IonCol size="12">
      <IonInput type='text' autocomplete='off' maxlength={6}
        className={containerStyle}
        {...remainingProps}
        ref={refCallback}
      />
    </IonCol>
  );
};
export default Input;
