import { IonCard, IonHeader, IonRow, IonList, IonAvatar, IonSkeletonText, IonButton, IonIcon, IonItem, IonLabel } from '@ionic/react';
import React from 'react';
import { useHistory } from 'react-router';

const CommonCard = (props) => {
  const history = useHistory();
  const detaillink = (name, id) => {
    props.btnHandler(id);
    props.btnHandler2(props.param1);
    props.setId(id);
    props.setClassMobile(true);
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
    history.push(props.fieldLink + id);
  };
  return (
<IonCard className={`sdb-box profile-details left-cards no-shadow ${props.className}`} >
    <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between">
    {props.header ? <p className="ion-align-self-start">{props.header}</p> : ''}
        {props.headerLinkLable !== ''
          ? <span className="ion-align-self-end "><a href={props.headerLink} className="link-btn-tx">{props.headerLinkLable}</a></span>
          : '' }
      </IonHeader>
    <IonRow>
      <IonList lines="none" className="full-width-row py-0 mt-1">
        {props.loading
          ? (<><IonRow className="ion-padding-start ion-bottom-padding-smallcom">
          <IonRow>
            <div className="myprofile-feeds ion-no-padding">
              <IonAvatar className="MuiAvatar ion-margin-end">
                <IonSkeletonText animated />
              </IonAvatar>
              <IonRow className='display-grid'>
                <span className="margin MuiTypography-caption group-model-text">
                  <IonSkeletonText animated className='skeleton-width' />
                  {props.subHeader
                    ? <IonSkeletonText animated className='skeleton-width-half' />
                    : ''}
                </span>
              </IonRow>
            </div>
          </IonRow>
          <IonRow className='header-row-margin-left right-padding'>
            {!props.icon
              ? <IonButton fill="clear">
                <IonIcon
                  icon={props.icon}
                  slot="start"
                  size="medium"
                  className="test" />
              </IonButton>
              : <IonSkeletonText animated className='skeleton-width-btn'/>}
          </IonRow>
        </IonRow><IonRow className="ion-padding-start ion-bottom-padding-smallcom">
            <IonRow>
              <div className="myprofile-feeds ion-no-padding">
                <IonAvatar className="MuiAvatar ion-margin-end">
                  <IonSkeletonText animated />
                </IonAvatar>
                <IonRow className='display-grid'>
                  <span className="margin MuiTypography-caption group-model-text">
                    <IonSkeletonText animated className='skeleton-width' />
                    {props.subHeader
                      ? <IonSkeletonText animated className='skeleton-width-half' />
                      : ''}
                  </span>
                </IonRow>
              </div>
            </IonRow>
            <IonRow className='header-row-margin-left right-padding'>
              {!props.icon
                ? <IonButton fill="clear">
                  <IonIcon
                    icon={props.icon}
                    slot="start"
                    size="medium"
                    className="test" />
                </IonButton>
                : <IonSkeletonText animated className='skeleton-width-btn'/>}
            </IonRow>
          </IonRow>
          <IonRow className="ion-padding-start ion-bottom-padding-smallcom">
            <IonRow >
                <div className="myprofile-feeds ion-no-padding">
                  <IonAvatar className="MuiAvatar ion-margin-end">
                    <IonSkeletonText animated />
                  </IonAvatar>
                  <IonRow className='display-grid'>
                    <span className="margin MuiTypography-caption group-model-text">
                    <IonSkeletonText animated className='skeleton-width'/>
                    {props.subHeader
                      ? <IonSkeletonText animated className='skeleton-width-half' />
                      : ''}
                    </span>
                  </IonRow>
                </div>
              </IonRow>
              <IonRow className='header-row-margin-left right-padding'>
                {!props.icon
                  ? <IonButton fill="clear">
                    <IonIcon
                      icon={props.icon}
                      slot="start"
                      size="medium"
                      className="test"
                    />
                  </IonButton>
                  : <IonSkeletonText animated className='skeleton-width-btn'/> }
              </IonRow>
          </IonRow>
          </>)
          : props.mapData.length > 0
            ? props.mapData.map((detail, i) => {
              return (
                <>
                  <IonRow className={props.paramId === detail.id ? 'activeListPage' : ''} onClick={() => detaillink(detail.name, detail.id)} key={i}>
                    {props.hashTag === true ? <IonRow className='display-grid hashTagAtivityCard ion-padding-start'>#{detail.key}</IonRow> : '' }
                    <IonRow className='cursor-pointer item' >
                        <div className="myprofile-feeds ion-no-padding cursor-pointer">
                          { detail.img
                            ? (<IonAvatar className="MuiAvatar ion-margin-end">
                            <img onError={(ev) => { ev.target.src = props.image; }} src={detail.img} />
                          </IonAvatar>)
                            : (props.image !== undefined
                                ? <IonAvatar className="MuiAvatar ion-margin-end">
                            <img src={props.image} alt=""/>
                          </IonAvatar>
                                : '')
                          }
                           <IonRow className='display-grid'>
                            {detail.name}
                            <span className="margin MuiTypography-caption group-model-text">
                              {detail.designation}
                            </span>
                          </IonRow>
                        </div>
                      </IonRow>
                      <IonRow className='header-row-margin-left'>
                      {detail.connection
                        ? <span className=" top-padding">
                        {detail.connection}
                      </span>
                        : ''}
                          <IonButton fill="clear" onClick={() => props.btn(detail.id)}>
                            <IonIcon
                              icon={props.icon}
                              slot="start"
                              size="medium"
                              className="test"
                            />
                          </IonButton>
                      </IonRow>
                  </IonRow>
                </>
              );
            })
            : <p className='ion-padding font-15'>{props.noDataFound}</p>
        }

        {props.footerLinkLable
          ? <IonItem>
          <IonRow >
            <IonLabel>
              <a>{props.footerLinkLable}</a>
            </IonLabel>
          </IonRow>
        </IonItem>
          : '' }
      </IonList>
    </IonRow>
  </IonCard>
  );
};
export default CommonCard;
