import { IonIcon, IonList, useIonPopover } from '@ionic/react';
import { close, informationCircle } from 'ionicons/icons';
import React from 'react';

const ToolTipComon = (props: any) => {
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList onClick={() => onHide()} className="my-account-pr tooltip-zyapaar">
      <div lines="none" className="cursor-pointer tooltip-zyapaar-inner" >
        <IonIcon icon={close} size="small" className="header-menu-img " />
        <p>{props.headLine}</p>
      </div>
    </IonList>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });
  return (
    <div className="dot-btn tooltip-zyapaar">
      <IonIcon
        icon={informationCircle}
        slot="start"
        className="report cursor-pointer"
        onClick={(e) => present({ event: e.nativeEvent })}
      />
    </div>
  );
};
export default ToolTipComon;
