import { IonCol, IonIcon, IonLabel, IonRow } from '@ionic/react';
import { duplicateOutline } from 'ionicons/icons';
import React from 'react';
import { useHistory } from 'react-router-dom';
import language from '../../assets/img/language.svg';

const HeaderMenu = () => {
  const history = useHistory();

  const clickHandler = () => {
    history.push('/language');
  };

  return (
    <>
      <IonRow className='top-header-menu position-relative'>
        <IonCol className='d-flex justify-content-between font-14 font-bold color-darkgrey bg-white pt-3 position-fixed zindex99 px-2'>
          <IonLabel className='color-theme-dark active-topmenu '>Feed</IonLabel>
          <IonLabel className='position-relative'>Leads<span className="count notify">15</span></IonLabel>
          <IonLabel className='position-relative'>Requirement<span className="count notify">5</span></IonLabel>
          <IonLabel className='d-flex'><IonIcon icon={duplicateOutline} className='font-18 me-1 color-theme-dark'/>Product</IonLabel>
          {/* <IonLabel onClick={clickHandler}><img src={language} alt="language" width='23' className='me-3' /></IonLabel> */}
        </IonCol>
      </IonRow>
    </>
  );
};
export default HeaderMenu;
