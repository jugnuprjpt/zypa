import { IonRow, IonSkeletonText } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import cataloueImage from '../../assets/img/blog/blog-cover-3.jpg';
import cataloueImage1 from '../../assets/img/blog/blog-cover-4.jpg';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper';
import callFor from '../../util/CallFor';
import { alertOutline } from 'ionicons/icons';

const BannerSection = () => {
  const [loading, setLoading] = useState(false);
  const [showBannerList, setShowBannerList] = useState([]);

  useEffect(() => {
    GetBannerList();
  }, []);

  const GetBannerList = async () => {
    const response = await callFor('api/v1.1/banner/list', 'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      console.log(json1Response);
      setShowBannerList(json1Response.data);
    }
  };

  return (
    <>
      <div className="ion-padding-verticale">
        <IonRow className="mt-2">
          {loading
            ? <>
              <IonSkeletonText animated style={{ height: '100px' }} />
            </>
            : <>
              <Swiper
                id="ka-swiper2"
                navigation={true}
                modules={[Navigation, Pagination]}
                className="mySwiper"
                autoHeight={true}
              >
                {showBannerList.map((details, i) => (
                  <>
                    <SwiperSlide key={i}>
                      <div>
                        <img src={details.url} alt="Catalogue" />
                      </div>
                    </SwiperSlide>
                  </>
                ))}
              </Swiper>
            </>
          }
        </IonRow>
      </div>
    </>
  );
};
export default BannerSection;
