/* eslint-disable array-callback-return */
/* eslint-disable no-unused-vars */
import React, { useEffect, useRef, useState } from 'react';
import ReactQuill from 'react-quill';
import CallFor from '../../util/CallFor';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import 'quill-mention';
import 'quill/dist/quill.snow.css';
import 'quill-mention/dist/quill.mention.min.css';
import { useDispatch } from 'react-redux';
import { IonButton } from '@ionic/react';
import { useTranslation } from 'react-i18next';

const modules = {
  toolbar: false,
  mention: {
    showDenotationChar: false,
    allowedChars: /^[A-Za-z\sÅÄÖåäö]*$/,
    mentionDenotationChars: ['@', '#'],
    isolateCharacter: true,
    source: async function(searchTerm: any, renderList: (arg0: any) => void) {
      if (searchTerm !== '') {
        const matchedPeople = await suggestPeople(searchTerm);
        renderList(matchedPeople);
      }
    },
    renderItem: (item) => {
      return `<div class="userList">
          <IonRow class="userListItem">
          <IonAvatar class="MuiAvatar ion-margin-end">
          <img src=${item.profileImg !== null ? item.profileImg : userProfile
        } class="MuiAvatar-circular"/> </IonAvatar>
      <span>${item.value}</span></IonRow> </div>`;
    },
    onSelect: function(item: any, insertItem: any) {
      insertItem(item);
      const mentionData = document.querySelectorAll('.mention > span');
      mentionData.forEach(element => {
        element.contentEditable = 'true';
      });
    }
  }
};
const suggestPeople = async(searchTerm: string) => {
  const response = await CallFor(
    'api/v1.1/connections/users/' + searchTerm,
    'GET',
    null,
    'Auth'
  );
  if (response.status === 200) {
    const jsonResponse = await response.json();
    const options = await jsonResponse.data.map((d: any) => ({
      id: d.id,
      value: d.fullName,
      profileImg: d.profileImg
    }));
    return options;
  } else if (response.status === 401) {
    localStorage.clear();
  }
};
const EditedCommentBox = (props: any) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const commentTag = useRef(null);
  const changeContent = (contentObj) => {
    let finalString = contentObj.text;
    if (contentObj.attributes.length > 0) {
      contentObj.attributes.forEach((element) => {
        const res = contentObj.text.substring(
          element.start,
          element.start + element.length
        );
        if (element.mention === 'PROFILE') {
          finalString = finalString.replace(
            res,
            '<a href="/profile/' + element.id + '"> ' + res + '</a>'
          );
        }
      });
    }
    finalString = finalString.replace(/(\r\n|\r|\n)/g, '<br>');
    return finalString;
  };

  const getcommentData = (contentObj) => {
    const test = [];
    if (contentObj.attributes.length > 0) {
      contentObj.attributes.forEach((element, index) => {
        if (element.start === 0) {
          const firstValue = contentObj.text.substring(
            element.start,
            element.start + element.length
          );
          test.push({
            insert: {
              mention: {
                index: '0',
                denotationChar: '',
                id: element.id,
                value: firstValue
              }
            }
          });
          if (contentObj.text.length > element.start + element.length) {
            if (index + 1 < contentObj.attributes.length) {
              const afterMentionValue = contentObj.text.substring(
                element.start + element.length,
                contentObj.attributes[1].start
              );
              test.push({
                insert: afterMentionValue
              });
            } else {
              const afterMentionValue = contentObj.text.substring(
                element.start + element.length,
                contentObj.text.length
              );
              test.push({
                insert: afterMentionValue
              });
            }
          }
        } else {
          if (index === 0) {
            const beforeMentionValue = contentObj.text.substring(
              0,
              element.start
            );
            test.push({
              insert: beforeMentionValue
            });
            const mentionValue = contentObj.text.substring(
              element.start,
              element.start + element.length
            );
            test.push({
              insert: {
                mention: {
                  index: '0',
                  denotationChar: '',
                  id: element.id,
                  value: mentionValue
                }
              }
            });
            if (contentObj.text.length > element.start + element.length) {
              if (index + 1 < contentObj.attributes.length) {
                const afterMentionValue = contentObj.text.substring(
                  element.start + element.length,
                  contentObj.attributes[index + 1].start
                );
                test.push({
                  insert: afterMentionValue
                });
              } else {
                const afterMentionValue = contentObj.text.substring(
                  element.start + element.length,
                  contentObj.text.length
                );
                test.push({
                  insert: afterMentionValue
                });
              }
            }
          } else {
            const mentionValue = contentObj.text.substring(
              element.start,
              element.start + element.length
            );
            test.push({
              insert: {
                mention: {
                  index: '0',
                  denotationChar: '',
                  id: element.id,
                  value: mentionValue
                }
              }
            });
            if (contentObj.text.length > element.start + element.length) {
              if (index + 1 < contentObj.attributes.length) {
                const afterMentionValue = contentObj.text.substring(
                  element.start + element.length,
                  contentObj.attributes[index + 1].start
                );
                test.push({
                  insert: afterMentionValue
                });
              } else {
                const afterMentionValue = contentObj.text.substring(
                  element.start + element.length,
                  contentObj.text.length
                );
                test.push({
                  insert: afterMentionValue
                });
              }
            }
          }
        }
      });
    } else {
      test.push({
        insert: contentObj.text
      });
    }
    return test;
  };
  useEffect(() => {
    let subscription = true;
    if (subscription) {
      getcommentData(JSON.parse(props.commentText));
      commentTag.current
        .getEditor()
        .setContents(getcommentData(JSON.parse(props.commentText)));
    }

    return () => {
      subscription = false;
    };
  }, []);
  const onHandleSubmit = async() => {
    const d = commentTag.current.editor.getContents();
    const tagValues = [];
    let postData = '';
    const attributes = [];
    d.ops.map((object) => {
      if (typeof object.insert === 'object') {
        tagValues.push(object.insert.mention.value);
        postData += object.insert.mention.value;
        const data1 = {
          mention: 'PROFILE',
          start: postData.lastIndexOf(object.insert.mention.value),
          length: object.insert.mention.value.length,
          id: object.insert.mention.id
        };
        attributes.push(data1);
      } else {
        if (object.insert !== undefined) {
          postData += object.insert;
        }
      }
    });
    const postComment = { text: postData, attributes: attributes };
    if (postData.length > 1) {
      let commentId = null;
      if (props.commentId !== undefined) {
        commentId = '"' + props.commentId + '"';
      }
      const data =
        '{"content": ' +
        JSON.stringify(postComment) +
        ', "id":' +
        commentId +
        '}';
      const response1 = await CallFor(
        'api/v1/post/comments',
        'PUT',
        data,
        'Auth'
      );
      if (response1.status === 200) {
        document.getElementById('feedComment').classList.remove('d-none');
        if (document.getElementById('feedReplyComment') !== undefined && document.getElementById('feedReplyComment') !== null) {
          document.getElementById('feedReplyComment').classList.remove('d-none');
        }
        if (props.type === 'Comment') {
          dispatch({
            type: 'edit_comment_content',
            content: JSON.stringify(postComment),
            index: props.feedIndex,
            commentIndex: props.commentIdex
          });
          dispatch({
            type: 'edit_comment_hide',
            isEdited: false,
            index: props.feedIndex,
            commentIndex: props.commentIdex
          });
        } else {
          dispatch({
            type: 'edit_Reply_content',
            content: JSON.stringify(postComment),
            index: props.feedIndex,
            commentIndex: props.comment,
            replyIndex: props.commentIdex
          });
          dispatch({
            type: 'edit_reply_hide',
            isEdited: false,
            index: props.feedIndex,
            commentIndex: props.comment,
            replyIndex: props.commentIdex
          });
        }
      } else if (response1.status === 500) {
        const jsonResponse = await response1.json();
        console.log(jsonResponse.error);
      }
    }
  };
  const [editBtn, seteditBtn] = useState(false);

  const closeEdit = () => {
    document.getElementById('feedComment').classList.remove('d-none');
    console.log(document.getElementById('feedReplyComment'));
    if (document.getElementById('feedReplyComment') !== undefined && document.getElementById('feedReplyComment') !== null) {
      document.getElementById('feedReplyComment').classList.remove('d-none');
    }
    if (props.type === 'Comment') {
      dispatch({
        type: 'edit_comment_hide',
        isEdited: false,
        index: props.feedIndex,
        commentIndex: props.commentIdex
      });
    } else {
      dispatch({
        type: 'edit_reply_hide',
        isEdited: false,
        index: props.feedIndex,
        commentIndex: props.comment,
        replyIndex: props.commentIdex
      });
    }
  };
  const addContentEditable = () => {
    const mentionData = document.querySelectorAll('.mention > span');
    mentionData.forEach(element => {
      element.contentEditable = 'true';
    });
  };
  return (
    <>
      <div className="quill-control custom-quill-bg">
        <div className="editCmt">
          <ReactQuill
            ref={commentTag}
            modules={modules}
            placeholder={props.placeholder}
            onChange={addContentEditable}
          />
          <div className="action">
            <IonButton
              size="small"
              className="pr-0 pl-2 category-btn-color btn-sm-cn"
              onClick={closeEdit}
            >
             {t('appproperties.text11')}
            </IonButton>
            <IonButton
              size="small"
              className="ion-button-color pr-0 pl-2 btn-sm-cn"
              onClick={onHandleSubmit}
            >
             {t('appproperties.text64')}
            </IonButton>
          </div>
        </div>
      </div>
    </>
  );
};
export default EditedCommentBox;
