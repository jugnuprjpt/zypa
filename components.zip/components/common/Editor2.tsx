import React, { useCallback } from 'react';
import ReactQuill from 'react-quill';

import 'quill-mention';
import 'quill/dist/quill.snow.css';
import 'quill-mention/dist/quill.mention.min.css';
import CallFor from '../../util/CallFor';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { useTranslation } from 'react-i18next';

const Editor2 = (props: any) => {
  const { t } = useTranslation();
  const modules = {
    toolbar: false,
    mention: {
      showDenotationChar: false,
      allowedChars: /^[A-Za-z\sÅÄÖåäö]*$/,
      mentionDenotationChars: ['@', '#'],
      isolateCharacter: true,
      source: useCallback(async (searchTerm: string, renderList: (arg0: { id: number; value: string; }[], arg1: any) => void, mentionChar: string) => {
        if (mentionChar === '@') {
          if (searchTerm !== '') {
            const matchedPeople = await suggestPeople(searchTerm);
            renderList(matchedPeople, mentionChar);
          }
        } else {
          if (searchTerm !== '') {
            const matchedPeople = await suggestHashTage(searchTerm);
            renderList(matchedPeople, mentionChar);
          }
        }
      }, []),
      renderItem: useCallback((item: { profileImg: null; value: any; }, mentionChar: string) => {
        if (mentionChar === '@') {
          return `<div class="userList">
            <IonRow class="userListItem">
            <IonAvatar class="MuiAvatar ion-margin-end">
                <img src=${item.profileImg !== null ? item.profileImg : userProfile} class="MuiAvatar-circular"/> </IonAvatar>
        <span>${item.value}</span></IonRow> </div>`;
        }
        return item.value;
      }, []),
      onSelect: useCallback((item: any, insertItem: any) => {
        insertItem(item);
        addContentEditable();
      }, [])
    }
  };
  const suggestPeople = async (searchTerm: string) => {
    const response = await CallFor(
      'api/v1.1/connections/users/' + searchTerm,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const jsonResponse = await response.json();
      const options = await jsonResponse.data.map(
        (d: any) => ({
          id: d.id,
          value: d.fullName,
          profileImg: d.profileImg
        })
      );
      return options;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    // return allPeople.filter(person => person.value.includes(searchTerm));
  };
  const suggestHashTage = async (searchTerm: string) => {
    const response = await CallFor(
      'api/v1/searches/hashtag/' + searchTerm,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const jsonResponse = await response.json();
      const options = await jsonResponse.data.map(
        (d: any) => ({
          id: d.tag,
          value: d.tag
        })
      );
      return options;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const addContentEditable = () => {
    const mentionData = document.querySelectorAll('.mention > span');
    mentionData.forEach(element => {
      element.contentEditable = 'true';
    });
  };
  return (
    <div className='quill-textarea'>
      <ReactQuill
        ref={props.postref}
        modules={modules}
        // value={postContent}
        onChange={addContentEditable}
        placeholder={t('appproperties.text86')}
      >
        {/* <div className="full-width-row post-q-editor post-modal-editor" /> */}
      </ReactQuill>
    </div>
  );
};
export default Editor2;
