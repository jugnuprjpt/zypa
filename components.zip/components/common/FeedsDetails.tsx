import { IonCard, IonRow, IonLabel, IonCol, IonChip, IonAvatar, IonHeader, IonContent, IonIcon, IonModal } from '@ionic/react';
import React, { useState } from 'react';
import Like from '../../assets/img/emojis/like.svg';
import Celebrate from '../../assets/img/emojis/celebration.svg';
import ShakeHand from '../../assets/img/emojis/shakehands.svg';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { useHistory } from 'react-router';
import ImageGallery, { ReactImageGalleryItem } from 'react-image-gallery';
import Pdf from '../../assets/img/icons/pdf-icon.svg';
import {
  close
} from 'ionicons/icons';
import VideoPlayer from './VideoPlayer';
import { useTranslation } from 'react-i18next';
const FeedDetails = (props) => {
  const { t } = useTranslation();
  const history = useHistory();
  const photoGallery: readonly ReactImageGalleryItem[] | { original: any }[] =
    [];
  const videoGallary = [];
  let pdfFile = '';
  const [showImgModal, setshowImgModal] = useState(false);

  const textMethod = (text) => {
    let stringvalue = '';
    if (text.length > 200) {
      let msg = text.slice(0, 201);
      for (let i = 201; i < text.length; i++) {
        if (text.charAt(i) !== ' ') {
          msg += text.charAt(i);
        } else {
          break;
        }
      }
      stringvalue = msg;
    } else {
      stringvalue = text.slice(0, text.length + 1);
    }

    return stringvalue;
  };

  const [selectedImgIndex, setSelectedImgIndex] = useState(0);
  const [showMore, setShowMore] = useState(false);
  const changeContent = (contentObj) => {
    if (contentObj.text.length > 1) {
      let finalString = contentObj.text;
      const subStringval = textMethod(finalString);
      let EmailAnchorlength = 0;
      const ValidateEmail = (mail) => {
        const emailsArray = mail.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
        if (emailsArray != null && emailsArray.length > 0) {
          let j = 0;
          const uniqueChars = [...new Set(emailsArray)];
          let count = 0;
          while (j < uniqueChars.length) {
            const re = new RegExp(uniqueChars[j], 'g');
            const temp = subStringval;
            count += (temp.match(re) || []).length;
            j++;
          }
          EmailAnchorlength = 7 * count;
          let i = 0;
          while (i < uniqueChars.length) {
            const re = new RegExp(uniqueChars[i], 'g');
            finalString = finalString.replace(re, `<a class="font-color" href="mailto:${uniqueChars[i]}">${uniqueChars[i]}</a>`);
            i++;
          }
        }
        return finalString;
      };

      ValidateEmail(finalString);
      let isSame = true;
      if (subStringval.trim().length === finalString.trim().length) {
        isSame = false;
      }
      const urlarr: any[] = [];
      const ValidateUrl = (text) => {
        const urlRegex = /(([a-z]+:\/\/)?(([a-z0-9\-]+\.)+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel|local|internal))(:[0-9]{1,5})?(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&amp;]*)?)?(#[a-zA-Z0-9!$&'()*+.=-_~:/?]*)?)(\s+|$)/gi;
        return text.replace(urlRegex, (url) => {
          urlarr.push(url);
          let urlval = url;
          if (urlval.includes('https://') || urlval.includes('http://')) {
          } else {
            urlval = `https://${url}`;
          }
          const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
          return `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'>${url}</a>`;
        });
      };
      finalString = ValidateUrl(finalString);
      const uniqueUrl = [...new Set(urlarr)];
      let j = 0;
      const arr = [];
      while (j < uniqueUrl.length) {
        const re = new RegExp(uniqueUrl[j], 'g');
        const temp = subStringval;
        arr.push(temp.match(re) || []);
        j++;
      }
      const uniarr = [];
      const uninum = [];
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].length > 0) {
          uninum.push(arr[i].length);
        }

        if (arr[i][0] !== undefined) {
          uniarr.push(arr[i][0]);
        }
      }

      let k = 0;
      let Urllength = 0;
      while (k < uniarr.length) {
        let urlval = uniarr[k];
        if (urlval.includes('https://') || urlval.includes('http://')) {
        } else {
          urlval = `https://${uniarr[k]}`;
        }
        const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
        const val = `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'></a>`;
        Urllength = Urllength + val.length * uninum[k];
        k++;
      }

      let AnchorLength = 0;
      let hashlength = 0;
      let hashData = '';

      if (contentObj.attributes.length > 0) {
        const data = [];
        contentObj.attributes.forEach((element) => {
          const res = contentObj.text.substring(element.start, element.start + element.length);
          if (element.mention === 'PROFILE') {
            if (data.includes(res)) {
              const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
              AnchorLength += val.length;
            } else {
              data.push(res);
              finalString = finalString.replaceAll(res, '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '">' + res + '</a>');
              const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
              AnchorLength += val.length;
            }
          }
        });
      }
      hashData = finalString.match(/#[a-z]+/gi);
      if (hashData !== null && hashData.length > 0) {
        const map = {};
        hashData.map((hashValue) => {
          if((Object.keys(map).filter(item => item === hashValue)).length > 0){
            const cnt = map.[hashValue];
            map.[hashValue] = 1;
          }else {
            map.[hashValue] = 1;
            finalString = finalString.replaceAll(hashValue, '<span style="text-decoration: none;" class = "font-color" href="#">' + hashValue + '</span>');
          }
          const val = '<span style="text-decoration: none;" class ="font-color" href="#">' + hashValue + '</span>';
          hashlength += val.length;
        });
      }
      finalString = finalString.replace(/(\r\n|\r|\n)/g, '<br>');
      const breakstring = finalString.slice(0, AnchorLength + subStringval.length);
      const countbreak = breakstring.match(/<br>/gi);
      let breakcount = 0;
      if (countbreak !== null && countbreak.length > 0) {
        breakcount = countbreak.length;
      }
      if (finalString.length > (200 + EmailAnchorlength + Urllength + AnchorLength + hashlength + breakcount * 3) && !showMore) {
        return (
          <>
            <span className='textBrerak' dangerouslySetInnerHTML={{ __html: finalString.slice(0, EmailAnchorlength + Urllength + AnchorLength + hashlength + subStringval.length + breakcount * 3 + 1) }} />

            {isSame
              ? <a
                onClick={() => setShowMore(true)} >
                {t('appproperties.text399')} </a>
              : ' '}
          </>
        );
      } else {
        return (
          <span className='textBrerak' dangerouslySetInnerHTML={{ __html: finalString }} />
        );
      }
    } else {
      return '';
    }
  };
  const cardClick = () => {
    history.push('/viewfeed/' + props.feeds.id);
  };
  const mediaMap = (mediaUrl) => {
    const meditaData = mediaUrl.split(',');
    for (const data in meditaData) {
      if (meditaData[data] !== undefined && meditaData[data] !== '') {
        if (meditaData[data].split('.').pop() === 'mp4' || meditaData[data].split('.').pop() === 'MP4' || meditaData[data].split('.').pop() === 'mov' || meditaData[data].split('.').pop() === 'MOV') {
          videoGallary.push(meditaData[data]);
        } else if (meditaData[data].split('.').pop() === 'pdf') {
          pdfFile = meditaData[data];
        } else {
          photoGallery.push({ original: meditaData[data] });
        }
      };
    }
  };
  const getImgdata = () => {
    if (photoGallery.length > 0) {
      if (photoGallery.length >= 5) {
        return (<div className="post-img tow-col img5">
        <div className="col-1">
          <img src={photoGallery[0].original} onClick ={() => imgModalOpen(0)}/>
          <img src={photoGallery[1].original} onClick ={() => imgModalOpen(1)}/>
        </div>
        <div className="col-2">
            <img src={photoGallery[2].original} onClick ={() => imgModalOpen(2)}/>
            <img src={photoGallery[3].original} onClick ={() => imgModalOpen(3)}/>
            <img src={photoGallery[4].original} onClick ={() => imgModalOpen(4)}/>
            {photoGallery.length > 5
              ? <span className="count" onClick ={() => imgModalOpen(4)}> + {photoGallery.length - 5 }</span>
              : ''
            }
        </div>
    </div>);
      } else if (photoGallery.length === 4) {
        return (<div className="post-img tow-col">
        <div className="col-1 img2">
          <img src={photoGallery[0].original} onClick ={() => imgModalOpen(0)}/>
            <img src={photoGallery[1].original} onClick ={() => imgModalOpen(1)}/>
        </div>
        <div className="col-2 img2">
            <img src={photoGallery[2].original} onClick ={() => imgModalOpen(2)}/>
            <img src={photoGallery[3].original} onClick ={() => imgModalOpen(3)}/>
        </div>
    </div>);
      } else if (photoGallery.length === 3) {
        return (<div className="post-img">
        <div className="col-1 img3">
          <img src={photoGallery[0].original} onClick ={() => imgModalOpen(0)}/>
          <img src={photoGallery[1].original} onClick ={() => imgModalOpen(1)}/>
          <img src={photoGallery[2].original} onClick ={() => imgModalOpen(2)}/>
        </div>
    </div>);
      } else if (photoGallery.length === 2) {
        return (<div className="post-img">
        <div className="col-1 img2">
          <img src={photoGallery[0].original} onClick ={() => imgModalOpen(0)}/>
          <img src={photoGallery[1].original} onClick ={() => imgModalOpen(1)}/>
        </div>
    </div>);
      } else if (photoGallery.length === 1) {
        return (<div className="post-img">
        <div className="col-1 img1">
          <img src={photoGallery[0].original} onClick ={() => imgModalOpen(0)}/>
        </div>
    </div>);
      }
    }
  };
  const imgModalOpen = (selectedImgIndex) => {
    setSelectedImgIndex(selectedImgIndex);
    setshowImgModal(true);
  };
  const getFileName = (val) => {
    const url = val.split('/').pop();
    const lastslashindex = url.indexOf('_');
    return decodeURI(url.substring(lastslashindex + 1));
  };
  return (
        <><IonCard className="MuiPaper-rounded ion-no-margin ion-margin-bottom 
         full-width-row shadow-none mb-2" onClick={() => cardClick(props.feeds.id)}>
      <IonRow>
        <IonHeader className="card-header">
          <div className="myprofile-feeds ion-padding-start ion-padding-top post-card">
            <IonAvatar
              slot="start"
              className="MuiCardHeader-avatar MuiAvatar-circular"
            >
              {props.feeds.userProfile !== null
                ? <img onError={(ev) => { ev.target.src = userProfile; }} src={props.feeds.userProfile} />
                : <img src={userProfile} />}
            </IonAvatar>
            <IonRow className="profileName">
              <h2 className="margin MuiTypography-body1">
                {props.feeds.userName}
              </h2>
              <span className="margin MuiTypography-caption nowrap-normal">
                {props.feeds.userDesignation}
              </span>
            </IonRow>
            <IonRow className="ion-float-right header-row-margin-left">
              <p className="ion-float-right ion-no-margin home-font-color MuiTypography-caption text-flex">
                {props.feeds.ageOfPost}
              </p>
            </IonRow>
          </div>
        </IonHeader>
      </IonRow>
      <IonRow className='feed-body'>
        <IonRow className='full-width-row ion-padding-horizontal'>
          <IonLabel className="full-width-row MuiTypography-body2 description">
            {changeContent(JSON.parse(props.feeds.content))}
          </IonLabel>
        </IonRow>
        <IonRow className='full-width-row feed-img'>
          {mediaMap(props.feeds.mediaUrl)}
          {photoGallery.length > 0
            ? (
                getImgdata()
              )
            : (
                ''
              )}
        </IonRow>
        <IonRow className='full-width-row feed-img'>
          {videoGallary.length > 0
            ? Object.entries(videoGallary).map((details) => (
              <>
                <div className="post-img post-video">
                  <div className="col-1">
                  <VideoPlayer url ={details[1]} />
                  </div>
                </div>
              </>))
            : ''}</IonRow>
        {pdfFile.length > 0
          ? <div className="pdf-file-cn">
            <a href={pdfFile} target='_blank' rel="noreferrer"> <img src={Pdf} width='20' /> {getFileName(pdfFile)}</a>
          </div>
          : ''}
      </IonRow>
      <IonRow className="card-header-text post-comment-view mt-3">
        <IonRow className="full-width-row">
          <IonCol size-md="6" size-xs="4" className="myprofile-feeds ps-0">
            <IonChip
              className="post-btn ion-no-padding ion-padding-start ion-padding-end">
              <IonAvatar className="ion-no-padding reaction-btn">
                <img src={Like} width='20' />
                <img src={Celebrate} width='20' />
                <img src={ShakeHand} width='20' />
              </IonAvatar>
            </IonChip>
            <p className="rectionCount"> {props.feeds.reactionCount}</p>
          </IonCol>
          <IonCol size-md="6" size-xs="8" className="ion-align-self-center">
            <p className="ion-float-right ion-padding-end secondary-text MuiTypography-body2">
              {props.feeds.commentCount} {t('feedproperties.text11')} 
              {/* <span className="dot"></span> 0{t('appproperties.text226')} */}
            </p>
          </IonCol>
        </IonRow>
      </IonRow>
    </IonCard>
    <IonModal isOpen={showImgModal} cssClass="add-award-model awd-img-gallery" onDidDismiss={() => setshowImgModal(false)}>
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
            <div onClick={() => setshowImgModal(false)} className="close ion-no-padding">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined" />
            </div>
          </IonRow>
          <IonRow className="overview-heigth ">
            <ImageGallery
              items={photoGallery}
              showPlayButton={false}
              autoPlay={false}
              startIndex={selectedImgIndex} />
          </IonRow>
        </IonContent>
      </IonModal></>
  );
};
export default FeedDetails;
