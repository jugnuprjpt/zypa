import { IonModal, IonRow } from '@ionic/react';
import React from 'react';
import { Link } from 'react-router-dom';
import approvedprofile from '../../assets/img/approved-profile.svg';

const NotAuthorizeModal = (props) => {
  return (
    <IonModal
      isOpen={props.authModal}
      cssClass="team-list-modal addCompany-modal"
      onDidDismiss={() => props.setAuthModal(false)}
      id='Apporove-modal'
    >
      <div>
        <div className="modal-body px-4 pt-3 text-center Apporve-modal">
          <div className=" no-footer">
            <IonRow className="connect-re-view-all">
              {/* <p className='mb-3'>{t('appproperties.text369')}</p> */}
              <p className='font-16'>This feature is available to Verified Users only.</p>
            <img src={approvedprofile} className="Apporveimage" />
              <p className='font-14'>To Start Enjoying Zyapaar, verify your business!</p>
              <Link
                to="/addnewcompany"
                className="link-btn-tx ion-no-padding ion-no-margin font-regular complete-button m-auto mt-3 borderRadius6 p-2 px-3"
              >
                Complete Profile
              </Link>
            </IonRow>
          </div>
        </div>
      </div>
    </IonModal>
  );
};
export default NotAuthorizeModal;
