import { IonAvatar, IonButton, IonCard, IonHeader, IonIcon, IonRow } from '@ionic/react';
import React from 'react';
import BuyrsIcon from '../../assets/img//buyres-icon.png';

const BuyerInquiry = () => {
  return (
    <>
      <div className="ion-padding-verticale buyers-inquiry mb-2">
        <IonHeader className="card-header bg-white">
          <IonRow className="connection-suggetion-item-box connection-member">
            <IonCard className="MuiPaper-rounded ion-margin-bottom ion-no-margin connectionSuggestion w-100">
              <div className="myprofile-feeds ion-padding-start  post-card w-100 feed-cards-posts mt-0 mb-0 pb-0  d-flex justify-content-between">
                <div className='myprofile-feeds ion-no-padding cursor-pointer w-75'>
                  <IonAvatar
                    slot="start"
                    className="MuiCardHeader-avatar MuiAvatar-circular"
                  >
                  </IonAvatar>
                  <IonRow className="profileName overflow-nowrap">
                    <h2 className="margin MuiTypography-body1">
                      Shubham Dholaria
                    </h2>
                    <span className="margin MuiTypography-caption">
                      Wholesaler @Joint International Craft
                    </span>
                  </IonRow>
                </div>
                <div className="ion-float-right ion-no-margin home-font-color MuiTypography-caption text-flex mt-lg-2 pt-lg-1 ion-align-items-start">
                  <span>18 Min</span>
                </div>
              </div>
            </IonCard>

            <IonCard className='pt-0 mt-0 mb-1'>
              <span className='font-14 m-0 p-0 textcolor font-bold'>Showing Interest for</span>
              <div className='d-flex mt-2'>
                <div className='buyers-icon'>
                  <img src={BuyrsIcon} alt="Buyers Icon" />
                </div>
                <div className='ps-3 w-85'>
                  <span className='color-theme-dark font-14 font-regular fixed-textline2'>Smart watch available in cheap rate Smart watch available in cheap rate</span>
                  <p className='font-13 font-regular fixed-textline1'>Maruti Digital Wathes</p>
                </div>
              </div>
            </IonCard>
          </IonRow>
        </IonHeader>
      </div>
    </>
  );
};
export default BuyerInquiry;
