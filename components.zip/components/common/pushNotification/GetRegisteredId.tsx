import { PushNotifications, Token } from '@capacitor/push-notifications';
import CallFor from '../../../util/CallFor';

const GetRegisteredId = (diviceInfo, type) => {
  if (diviceInfo.platform === 'ios' || diviceInfo.platform === 'android') {
  // Register with Apple / Google to receive push via APNS/FCM
    PushNotifications.requestPermissions().then(result => {
      if (result.receive === 'granted') {
      // Register with Apple / Google to receive push via APNS/FCM
        PushNotifications.register();
      } else {
      // Show some error
      }
    });

    // On success, we should be able to receive notifications
    PushNotifications.addListener('registration',
      async(token: Token) => {
        const deviceData = {};
        deviceData.fcm = token.value;
        deviceData.type = diviceInfo.platform;
        deviceData.deviceDetails = JSON.stringify(diviceInfo);
        const response = await CallFor('api/v1/add/userfcm', 'POST', JSON.stringify(deviceData), type);
        if (response.status === 200) {
          console.log('Data inserted in app');
        } else {
          console.log('Error Msg in fcm');
        }
      }
    );
    // Some issue with our setup and push will not work
    // PushNotifications.addListener('registrationError',
    //   (error: any) => {
    //     alert('Error on registration: ' + JSON.stringify(error));
    //   }
    // );
  }
};
export default GetRegisteredId;
