import { PushNotifications, ActionPerformed } from '@capacitor/push-notifications';
import { useHistory } from 'react-router';

const HandlePushNotification = () => {
  const history = useHistory();
  console.log('Initializing HomePage');

  // Some issue with our setup and push will not work
  PushNotifications.addListener('registrationError',
    (error: any) => {
      alert('Error on registration: ' + JSON.stringify(error));
    }
  );

  // // Show us the notification payload if the app is open on our device
  // PushNotifications.addListener('pushNotificationReceived',
  //   (notification: PushNotificationSchema) => {
  //     setnotifications(notifications => [...notifications, { title: notification.title, body: notification.body, type: 'foreground' }]);
  //   }
  // );

  // Method called when tapping on a notification
  PushNotifications.addListener('pushNotificationActionPerformed',
    (notification: ActionPerformed) => {
      const activityDetails = JSON.parse(notification.notification.data.body);
      if (activityDetails.activity !== undefined) {
        if (activityDetails.activity === '2' || activityDetails.activity === '3' || activityDetails.activity === '4' ||
          activityDetails.activity === '5' || activityDetails.activity === '6' || activityDetails.activity === '7' ||
          activityDetails.activity === '8') {
          history.push('/viewfeed/' + activityDetails.id);
        } else if (activityDetails.activity === '9') {
          history.push('/companyDetail/' + activityDetails.id);
        } else if (activityDetails.activity === '10') {
          history.push('/groups/' + activityDetails.id);
        } else if (activityDetails.activity === '11') {
          history.push('/pageDetails/' + activityDetails.id);
        } else if (activityDetails.activity === '12') {
          history.push('/network/');
        } else {
          history.push('/profile/' + activityDetails.id);
        }
      }
    }
  );
};
export default HandlePushNotification;
