/* eslint-disable multiline-ternary */
/* eslint-disable react/jsx-key */
/* eslint-disable react/prop-types */
import {
  IonCard,
  IonCol,
  IonContent,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonLabel,
  IonModal,
  IonRow
} from '@ionic/react';
import React, { useState } from 'react';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import callFor from '../../util/CallFor';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { close } from 'ionicons/icons';
import { useHistory } from 'react-router';
import SkeletonComonViewAll from './skeleton/SkeletonComonViewAll';
import ToastCommon from './ToastCommon';
import CommonGridList from './CommonGridList';
import { useTranslation } from 'react-i18next';
import { Navigation, Pagination } from 'swiper';
import userCoverDefaulImg from '../../assets/img/banner-placeholder.png';

const ConnectionSuggestion = (props) => {
  const { t } = useTranslation();
  const [showModel, setShowModal] = useState(false);
  const [scrollData, setScrollData] = useState([]);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [count, setCount] = useState(1);
  const history = useHistory();
  const [showToast, setShowToast] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [modelLoading, setModelLoading] = useState(true);
  const connectionBtnHandler = async (id) => {
    const response = await callFor(
      'api/v1.1/connect/' + id + '/INITIATE',
      'POST',
      '{"status": "INITIATE" }',
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast13'));
      setShowToast(true);

      if (showModel) {
        props.getconnectionList();
        setScrollData(scrollData.filter((item) => item.id !== id));
      } else {
        props.getconnectionList();
      }
    } else if (response.status === 400) {
      const json1Response = await response.json();
      if (json1Response.error.message === t('userproperties.text21')) {
        setShowToastMsg(t('userproperties.text21'));
        setShowToast(true);
      };
    }
  };
  const viewConnectionHandler = () => {
    setShowModal(true);
    setInfiniteDisabled(false);
    setTimeout(() => {
      getconnectionList(1);
    }, 500);
  };
  const getconnectionList = async (page) => {
    const response = await callFor(
      'api/v1.2/suggestions/users',
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        if (page === 1) {
          setScrollData([
            ...props.connectionData,
            ...json1Response.data.content
          ]);
        } else {
          setScrollData([...scrollData, ...json1Response.data.content]);
        }
      } else {
        if (page === 1) {
          setScrollData(props.connectionData);
        }
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
      // setScrollData(json1Response.data.content);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setModelLoading(false);
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getconnectionList(count);
      ev.target.complete();
    }, 500);
  };
  const closeModel = () => {
    setShowModal(false);
    setCount(1);
    setModelLoading(true);
  };
  return (
    <>
      {props.connectionData.length > 0
        ? (
          <>
            <div className="ion-padding-verticale">
              <IonRow>
                <span className="textcolour head-title ms-2 ms-lg-0">{props.header}</span>
              </IonRow>
              {props.connectionData.length > 2
                ? <>
                  <IonRow className="connection-suggetion-item-box connection-member mt-3 ps-2">
                    <Swiper
                      id="ka-swiper2"
                      navigation={true}
                      modules={[Navigation, Pagination]}
                      className="mySwiper"
                      autoHeight={true}
                      breakpoints={{
                        320: {
                          width: 190,
                          slidesPerView: 1,
                          navigation: false
                        },
                        768: {
                          width: 768,
                          slidesPerView: 4
                        }
                      }}
                    >
                      {props.connectionData.map((detail, i) => (
                        <SwiperSlide className="ion-padding-end" key={i}>
                          <IonCard className="MuiPaper-rounded ion-margin-bottom ion-no-margin connectionSuggestion">
                            <CommonGridList id={detail.id} defultImage={userProfile} img={detail.img} name={detail.name} subString={detail.designation} coverImg={detail.cover} DefaulCover={userCoverDefaulImg}
                              subString2={detail.request} btnText={t('appproperties.text28')} btnFnc={() => connectionBtnHandler(detail.id)} dots={false} redirectLink='profile' />
                          </IonCard>
                        </SwiperSlide>
                      ))}
                      <SwiperSlide className="ion-padding-end">
                        <IonCard
                          className="MuiPaper-rounded ion-padding ion-no-margin viewAll-swipe-slider"
                          onClick={viewConnectionHandler}
                        >
                          {t('commonproperties.text3')}
                        </IonCard>
                      </SwiperSlide>
                    </Swiper>
                  </IonRow>
                </>
                : <>
                  <IonRow className="connection-suggetion-item-box4 connection-member mt-3">
                    {props.connectionData.map((detail, i) => (
                      <IonCol sizeMd='3' sizeXs='6' className="list-member" key={i}>
                        <CommonGridList id={detail.id} defultImage={userProfile} img={detail.img} name={detail.name} subString={detail.designation} coverImg={detail.cover} DefaulCover={userCoverDefaulImg}
                          subString2={detail.request} btnText={t('appproperties.text28')} btnFnc={() => connectionBtnHandler(detail.id)} dots={false} redirectLink='profile' />
                      </IonCol>
                    ))}
                  </IonRow>
                </>
              }
            </div>
          </>
        )
        : props.loading
          ? (<SkeletonComonViewAll column={4} sizeMd={3} sizeXs={6} name={true} title={true} distription={true} link={false} />
          )
          : ''}
      <IonModal isOpen={showModel} className="team-list-modal" onDidDismiss={closeModel} backdropDismiss={false}>
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
          <IonLabel className="MuiTypography-h6">{t('commonproperties.text3')}</IonLabel>
          <div
            onClick={closeModel}
            className="close ion-no-padding cursor-pointer"
          >
            <IonIcon
              icon={close}
              className="ion-button-color pr-0 "
              slot="start"
              size="undefined"
            />
          </div>
        </IonRow>
        <IonContent>
          <div className="modal-body">
            <div className="no-footer">
              <IonRow className={modelLoading ? 'ion-padding-start ion-padding-end ion-padding-bottom connectionSuggestionModal' : 'ion-padding-start ion-padding-end ion-padding-bottom member-listing connectionSuggestionModal'}>
                {modelLoading ? <SkeletonComonViewAll column={4} sizeMd={3} sizeXs={12} name={true} title={true} distription={true} link={false} /> : <>
                  {scrollData.map((detail, i) => (
                    // eslint-disable-next-line react/jsx-key
                    // <SkeletonComonViewAll column={4} sizeMd={3} sizeXs={12} name={true} title={true} distription={true} link={false} />
                    <CommonGridList key={i} id={detail.id} defultImage={userProfile} img={detail.img} name={detail.name} subString={detail.designation} coverImg={detail.cover} DefaulCover={userCoverDefaulImg}
                      subString2={detail.request} btnText={t('appproperties.text28')} btnFnc={() => connectionBtnHandler(detail.id)} dots={false} redirectLink='profile' />
                  ))}
                </>}
              </IonRow>
              <IonInfiniteScroll
                threshold="100px"
                onIonInfinite={loadData}
                disabled={isInfiniteDisabled}
              >
                <IonInfiniteScrollContent loadingText={t('appproperties.text215')}></IonInfiniteScrollContent>
              </IonInfiniteScroll>
            </div>
          </div>
        </IonContent>
      </IonModal>
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
    </>
  );
};
export default ConnectionSuggestion;
