/* eslint-disable no-undef */
import { IonAvatar, IonButton, IonCardTitle, IonCol, IonContent, IonIcon, IonInfiniteScroll, IonInfiniteScrollContent, IonLabel, IonModal, IonRow } from '@ionic/react';
import { infiniteOutline, close } from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router';
import callFor from '../../util/CallFor';
import SkeletonComonViewAll from './skeleton/SkeletonComonViewAll';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import { Trans, useTranslation } from 'react-i18next';

const MutualConnectionRow = (props) => {
  const { t } = useTranslation();
  const profileDetail = useSelector(getProfileDetails);
  const history = useHistory();
  const [mutualConnectionCount, setMutualConnectionCount] = useState();
  useEffect(() => {
    getMutualConnectionCount();
  }, []);
  const getMutualConnectionCount = async () => {
    const response = await callFor(
      'api/v1.1/mutual/count/' + props.id,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      setMutualConnectionCount(json1Response.data);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const [viewMutualConnectionmodal, setMutualConnectionModal] = useState(false);
  const [viewMutualConnectionList, setMutualConnectionList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pageCount, setPageCount] = useState(0);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const viewMutualConnection = async (page, isScroll) => {
    setMutualConnectionModal(true);
    setLoading(true);
    const response = await callFor(
      'api/v1.1/mutual/list/' + props.id,
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        if (isScroll) {
          setMutualConnectionList([...viewMutualConnectionList, ...json1Response.data.content]);
        } else {
          setMutualConnectionList(json1Response.data.content);
        }
      } else {
        setInfiniteDisabled(true);
      }
      setPageCount(page + 1);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const loadDataConnection = (ev) => {
    setTimeout(() => {
      viewMutualConnection(pageCount, true);
      ev.target.complete();
    }, 500);
  };
  return (
    <>
      {profileDetail.id !== props.id
        ? <>

          {mutualConnectionCount !== undefined && mutualConnectionCount !== 0
            ? (
              <p className="fixed-textline1 cons-designation text-grey font-12 cursor-pointer mutualConenction align-items-center npmline-h-error"
                onClick={(e) => { e.stopPropagation(); viewMutualConnection(0, false); }}>
                {/* <IonIcon
                  icon={infiniteOutline}
                  slot="start"
                  size='small'
                  className='me-1'
                /> */}
                <span className='font-medium text-nowrap'>{mutualConnectionCount}</span> {t('appproperties.text7')}
              </p>)
            : ''
          }</>
        : ''}
      <IonModal
        isOpen={viewMutualConnectionmodal}
        cssClass="mutualConnectionModal"
        onDidDismiss={() => setMutualConnectionModal(false)}
      >
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-justify-content-between mt-2 mt-lg-0">
          <IonCol sizeMd='11' sizeXs='11'>
            {/* <IonLabel className="MuiTypography-h6 mutualConnectionTitle ms-3">{mutualConnectionCount} Mutual Zyapaaris with {props.name}</IonLabel> */}
            <IonLabel className="MuiTypography-h6 mutualConnectionTitle ms-2">
              <Trans 
                i18nKey="appproperties.text433" 
                values={{ number: mutualConnectionCount, user_name: props.name}}
                components={{bold: <strong className='text-dark mx-1' />}} />
            </IonLabel>  
          </IonCol>

          <IonCol sizeMd='1' sizeXs='1' className='d-lg-flex justify-content-center'>
            <IonButton
              fill="clear"
              onClick={(e) => { e.stopPropagation(); setMutualConnectionModal(false)}}
              className="close link-btn-tx ion-no-padding ion-no-margin"
            >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined" />
            </IonButton>
          </IonCol>
        </IonRow>
        <IonContent>
          <div className="modal-body">
            <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom ">
              {viewMutualConnectionList.length > 0
                ? (
                  <>
                    {viewMutualConnectionList.length >= 0 &&
                      viewMutualConnectionList.map((list) => (
                        // eslint-disable-next-line react/jsx-key
                        <IonCol sizeMd="3" sizeXs="6">
                          <>
                            <div
                              className="group-team-center follower-list-card cursor-pointer"
                              onClick={(e) => { e.stopPropagation();
                                history.push('/profile/' + list.id);
                              }}
                            >
                              <IonAvatar
                                slot="start"
                                className="MuiCardHeader-avatar cursor-pointer mx-auto"
                              >
                                {list.img === null || list.img === ''
                                  ? (
                                    <img src={userProfile} />
                                  )
                                  : (
                                    <img onError={(ev) => { ev.target.src = userProfile; }} src={list.img} />
                                  )}
                              </IonAvatar>
                              <IonRow className="profileName">
                                <IonCardTitle>
                                  <p className="margin MuiTypography-body1 fixed-textline">
                                    {list.name}
                                  </p>
                                  <span className="margin MuiTypography-caption group-model-text">
                                    {list.designation}
                                  </span>
                                </IonCardTitle>
                              </IonRow>
                            </div>
                          </>
                        </IonCol>
                      ))}
                  </>
                )
                : (
                  ''
                )}
              {loading
                ? <SkeletonComonViewAll column={8} sizeMd={3} sizeXs={6} name={true} title={true} distription={false} link={false} />
                : ''}
              <IonInfiniteScroll
                onIonInfinite={loadDataConnection}
                threshold="100px"
                disabled={isInfiniteDisabled}
              >
                <IonInfiniteScrollContent
                  loadingSpinner="circular"
                  loadingText={t('appproperties.text215')}
                ></IonInfiniteScrollContent>
              </IonInfiniteScroll>
            </IonRow>
          </div>
        </IonContent>
      </IonModal></>
  );
};
export default MutualConnectionRow;
