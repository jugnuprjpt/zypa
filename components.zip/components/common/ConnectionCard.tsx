import { IonCard, IonHeader, IonRow, IonList, IonBadge } from '@ionic/react';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router';
import SkeletonConnectionList from './skeleton/SkeletonConnectionList';

const ConnectionCard = (props) => {
  const { t } = useTranslation();
  const history = useHistory();
  const detaillink = (name, id) => {
    props.setClassMobile(true);
    history.push('/connection/' + name + '/' + id);
    props.setParamNetworkId(id);
    props.setParamNetworkName(name);
    props.getTeamMemberList(id);
  };

  return (
    <IonCard
        className={'sdb-box profile-details left-cards no-shadow sidebar-pages connectionlist remove-connections-border'}
      >
        <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between">
          <p className="ion-align-self-start">{t('appproperties.text8')}</p>
        </IonHeader>
        <div className='h-300 overflow-y connection-sapce'>
          <IonRow>
            <IonList lines="none" className="full-width-row mb-2">
              {props.industryloading
                ? <SkeletonConnectionList column='5'/>
                : props.connectionIndustry.length > 0
                  ? props.connectionIndustry.map((detail, i) => {
                    return (
                        <IonRow
                          key={i}
                          onClick={() => detaillink(detail.name, detail.id)}
                          className='border-0'
                        >
                          <IonRow className="connection-padding cursor-pointer item justify-content-between p-0 ">
                            <div className="myprofile-feeds ion-no-padding d-flex justify-content-between w-100 overflow-hidden activeConnection">
                            {detail.name === props.paramNetworkName
                              ? <>
                                  <IonRow className="d-flex align-items-center justify-content-between IsactiveConnection w-100 px-3 py-2">  
                                    <div className='w-85'>
                                      {detail.name}
                                    </div>
                                    <IonBadge className='custom-bage p-0 md hydrated'>
                                      {detail.count}
                                    </IonBadge>
                                  </IonRow>
                                  </>
                              : <>
                                  <IonRow className="display-grid px-3 py-2">
                                    {detail.name}
                                  </IonRow>
                                  <IonBadge className='custom-bage pe-3 py-2'>
                                    {detail.count}
                                  </IonBadge>
                                  </>}
                             </div>
                          </IonRow>
                        </IonRow>
                    );
                  })
                  : <p className='ion-padding-start position-absolute pt-1 text-center w-100 ps-0'>{t('nodatafound.text13')}</p>}
            </IonList>
          </IonRow>
        </div>
      </IonCard>
  );
};
export default ConnectionCard;
