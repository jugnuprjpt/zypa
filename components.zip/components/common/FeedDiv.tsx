import { IonCard, IonRow, IonLabel, IonContent, IonIcon, IonModal } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import callFor from '../../util/CallFor';
import { useHistory } from 'react-router';
import ProfileDetailRow from './ProfileDetailRow';
import ImageGallery, { ReactImageGalleryItem } from 'react-image-gallery';
import Pdf from '../../assets/img/icons/pdf-icon.svg';
import VideoPlayer from './VideoPlayer';
import { close } from 'ionicons/icons';
import { useTranslation } from 'react-i18next';

const FeedDiv = (props) => {
  const { t } = useTranslation();
  const history = useHistory();
  const [feedDivData, setFeedDivData] = useState({});
  const [showMore, setShowMore] = useState<boolean>(false);
  const [imgDimention, setImgDimention] = useState();
  const [selectedImgIndex, setSelectedImgIndex] = useState(0);
  const [showImgModal, setshowImgModal] = useState(false);
  const photoGallery: readonly ReactImageGalleryItem[] | { original: any }[] =
    [];
  const videoGallary = [];
  let pdfFile = '';

  useEffect(() => {
    getFeedDatafun(props.postOf);
  }, []);

  const getFeedDatafun = async(id) => {
    const response = await callFor('api/v1/feed/' + id, 'POST', null, 'Auth');
    if (response.status === 200) {
      const jsonResponse = await response.json();
      if (jsonResponse.data !== '' && jsonResponse.data !== null) {
        setFeedDivData(jsonResponse.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const mediaMap = (mediaUrl) => {
    if (mediaUrl !== undefined) {
      mediaUrl.map((media) => {
        if (media.split('.').pop() === 'mp4' || media.split('.').pop() === 'MP4' || media.split('.').pop() === 'mov' || media.split('.').pop() === 'MOV') {
          videoGallary.push(media);
        } else if (media.split('.').pop() === 'pdf') {
          pdfFile = media;
        } else {
          photoGallery.push({ original: media });
        }
      });
    };
  };
  const textMethod = (text: string) => {
    let stringvalue = '';
    if (text.length > 200) {
      let msg = text.slice(0, 201);
      for (let i = 201; i < text.length; i++) {
        if (text.charAt(i) !== ' ') {
          msg += text.charAt(i);
        } else {
          break;
        }
      }
      stringvalue = msg;
    } else {
      stringvalue = text.slice(0, text.length + 1);
    }

    return stringvalue;
  };
  let isSame = true;
  const changeContent = (contentObj: { text: string; attributes: any[]; }) => {
    if (contentObj.text.length > 1) {
      let finalString = contentObj.text;
      const subStringval = textMethod(finalString);

      let EmailAnchorlength = 0;
      const ValidateEmail = (mail) => {
        const emailsArray = mail.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
        if (emailsArray != null && emailsArray.length > 0) {
          let j = 0;
          const uniqueChars = [...new Set(emailsArray)];
          let count = 0;
          while (j < uniqueChars.length) {
            const re = new RegExp(uniqueChars[j], 'g');
            const temp = subStringval;
            count += (temp.match(re) || []).length;
            j++;
          }
          EmailAnchorlength = 7 * count;
          let i = 0;
          while (i < uniqueChars.length) {
            const re = new RegExp(uniqueChars[i], 'g');
            finalString = finalString.replace(re, `<a>${uniqueChars[i]}</a>`);
            i++;
          }
        }
        return finalString;
      };

      ValidateEmail(finalString);
      if (subStringval.trim().length === finalString.trim().length) {
        isSame = false;
      }
      const urlarr: any[] = [];
      const ValidateUrl = (text) => {
        const urlRegex = /(([a-z]+:\/\/)?(([a-z0-9\-]+\.)+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel|local|internal))(:[0-9]{1,5})?(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&amp;]*)?)?(#[a-zA-Z0-9!$&'()*+.=-_~:/?]*)?)(\s+|$)/gi;
        return text.replace(urlRegex, (url) => {
          urlarr.push(url);
          let urlval = url;
          if (urlval.includes('https://') || urlval.includes('http://')) {
          } else {
            urlval = `https://${url}`;
          }
          const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
          return `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'>${url}</a>`;
        });
      };
      finalString = ValidateUrl(finalString);
      const uniqueUrl = [...new Set(urlarr)];
      let j = 0;
      const arr = [];
      while (j < uniqueUrl.length) {
        const re = new RegExp(uniqueUrl[j], 'g');
        const temp = subStringval;
        arr.push(temp.match(re) || []);
        j++;
      }
      const uniarr = [];
      const uninum = [];
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].length > 0) {
          uninum.push(arr[i].length);
        }

        if (arr[i][0] !== undefined) {
          uniarr.push(arr[i][0]);
        }
      }

      let k = 0;
      let Urllength = 0;
      while (k < uniarr.length) {
        let urlval = uniarr[k];
        if (urlval.includes('https://') || urlval.includes('http://')) {
        } else {
          urlval = `https://${uniarr[k]}`;
        }
        const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
        const val = `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'></a>`;
        Urllength = Urllength + val.length * uninum[k];
        k++;
      }

      let AnchorLength = 0;
      let hashlength = 0;
      let hashData = '';

      if (contentObj.attributes.length > 0) {
        contentObj.attributes.forEach((element) => {
          const res = contentObj.text.substring(element.start, element.start + element.length);
          if (element.mention === 'PROFILE') {
            finalString = finalString.replace(res, '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '">' + res + '</a>');
            if (subStringval.includes(res)) {
              const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
              AnchorLength += val.length;
            }
          }
        });
      }
      hashData = finalString.match(/#[a-z]+/gi);
      if (hashData !== null && hashData.length > 0) {
        const map = {};
        hashData.map((hashValue) => {
          if((Object.keys(map).filter(item => item === hashValue)).length > 0){
            const cnt = map.[hashValue];
            map.[hashValue] = 1;
          }else {
            map.[hashValue] = 1;
            finalString = finalString.replaceAll(hashValue, '<span style="text-decoration: none;" class = "font-color" href="#">' + hashValue + '</span>');
          }
          const val = '<span style="text-decoration: none;" class ="font-color" href="#">' + hashValue + '</span>';
          hashlength += val.length;
        });
      }
      finalString = finalString.replace(/(\r\n|\r|\n)/g, '<br>');

      const breakstring = finalString.slice(0, AnchorLength + subStringval.length);
      const countbreak = breakstring.match(/<br>/gi);
      let breakcount = 0;
      if (countbreak !== null && countbreak.length > 0) {
        breakcount = countbreak.length;
      }

      if (finalString.length > (200 + EmailAnchorlength + Urllength + AnchorLength + hashlength + breakcount * 3) && !showMore) {
        return (
          <>
          <span dangerouslySetInnerHTML={{ __html: finalString.slice(0, EmailAnchorlength + Urllength + AnchorLength + hashlength + subStringval.length + breakcount * 3 + 1) }} />
          </>
        );
      } else {
        return (
          <span dangerouslySetInnerHTML={{ __html: finalString }}/>
        );
      }
    } else {
      return '';
    }
  };

  const getImgdata = () => {
    if (photoGallery.length > 0) {
      if (photoGallery.length >= 5) {
        return (<div className="post-img tow-col img5">
          <div className="col-1">
            <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            <img src={photoGallery[1].original} onClick={() => imgModalOpen(1)} />
          </div>
          <div className="col-2">
            <img src={photoGallery[2].original} onClick={() => imgModalOpen(2)} />
            <img src={photoGallery[3].original} onClick={() => imgModalOpen(3)} />
            <img src={photoGallery[4].original} onClick={() => imgModalOpen(4)} />
            {photoGallery.length > 5
              ? <span className="count" onClick={() => imgModalOpen(4)}> + {photoGallery.length - 5}</span>
              : ''
            }
          </div>
        </div>);
      } else if (photoGallery.length === 4) {
        return (<div className="post-img tow-col">
          <div className="col-1 img2">
            <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            <img src={photoGallery[1].original} onClick={() => imgModalOpen(1)} />
          </div>
          <div className="col-2 img2">
            <img src={photoGallery[2].original} onClick={() => imgModalOpen(2)} />
            <img src={photoGallery[3].original} onClick={() => imgModalOpen(3)} />
          </div>
        </div>);
      } else if (photoGallery.length === 3) {
        return (<div className="post-img">
          <div className="col-1 img3">
            <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            <img src={photoGallery[1].original} onClick={() => imgModalOpen(1)} />
            <img src={photoGallery[2].original} onClick={() => imgModalOpen(2)} />
          </div>
        </div>);
      } else if (photoGallery.length === 2) {
        return (<div className="post-img">
          <div className="col-1 img2">
            <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            <img src={photoGallery[1].original} onClick={() => imgModalOpen(1)} />
          </div>
        </div>);
      } else if (photoGallery.length === 1) {
        getMeta(photoGallery[0].original);
        if (imgDimention !== undefined && imgDimention >= 815) {
          return (<div className="post-img graterImg">
            <div className="col-1 img1">
              <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            </div>
          </div>);
        } else {
          return (<div className="post-img lessImg">
            <div className="col-1 img1">
              <img src={photoGallery[0].original} onClick={() => imgModalOpen(0)} />
            </div>
          </div>);
        }
      }
    }
  };
  function getMeta(url) {
    const img = new Image();
    img.addEventListener('load', function() {
      return setImgDimention(this.naturalWidth);
    });
    img.src = url;
  }

  const imgModalOpen = (selectedImgIndex) => {
    setSelectedImgIndex(selectedImgIndex);
    setshowImgModal(true);
  };
  const getFileName = (val) => {
    const url = val.split('/').pop();
    const lastslashindex = url.indexOf('_');
    return decodeURI(url.substring(lastslashindex + 1));
  };
  return (
    <><IonRow className='full-width-row'>
      {feedDivData.userId !== undefined

        ? <IonCard className="MuiPaper-rounded feed-cards-posts full-width-row post-share-card no-shadow">
          <ProfileDetailRow userProfile={feedDivData.userProfile} userName={feedDivData.userName}
            userDesignation={feedDivData.userDesignation} userId={feedDivData.userId} />
          <IonRow className='feed-body'>
            <IonRow className='full-width-row ion-padding-horizontal'>
              <IonLabel className="full-width-row MuiTypography-body2 description cursor-pointer">
                <span onClick={() => history.push('/viewfeed/' + props.postOf)}>{changeContent(JSON.parse(feedDivData.content))}</span>
                <span onClick={() => history}>
                  {isSame ? !showMore && JSON.parse(feedDivData.content).text !== undefined && JSON.parse(feedDivData.content).text.length > 200 ? <a onClick={() => setShowMore(true)}>{t('appproperties.text399')} </a> : '' : ' '}
                </span>
              </IonLabel>
            </IonRow>
            <IonRow className='full-width-row feed-img'>
              {mediaMap(feedDivData.mediaUrl)}
              {photoGallery.length > 0
                ? (
                    getImgdata()
                  )
                : (
                    ''
                  )}
            </IonRow>
            <IonRow className='full-width-row feed-img'>
              {videoGallary.length > 0
                ? Object.entries(videoGallary).map((details) => (
                  <>
                    <div className="post-img post-video">
                      <div className="col-1">
                        <VideoPlayer url={details[1]} />
                      </div>
                    </div>
                  </>))
                : ''}</IonRow>
            {pdfFile.length > 0
              ? <div className="pdf-file-cn">
                <a href={pdfFile} target='_blank' rel="noreferrer"> <img src={Pdf} width='20' /> {getFileName(pdfFile)}</a>
              </div>
              : ''}
          </IonRow>
        </IonCard>
        : ''}
    </IonRow><IonModal isOpen={showImgModal} cssClass="add-award-model awd-img-gallery" onDidDismiss={() => setshowImgModal(false)}>
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
            <div onClick={() => setshowImgModal(false)} className="close ion-no-padding">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined" />
            </div>
          </IonRow>
          <IonRow className="overview-heigth ">
            <ImageGallery
              items={photoGallery}
              showPlayButton={false}
              autoPlay={true}
              startIndex={selectedImgIndex} />
          </IonRow>
        </IonContent>
      </IonModal></>
  );
};
export default FeedDiv;
