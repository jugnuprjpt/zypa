const SwiperCard = () => {
return {
    
}
};
export default SwiperCard;
