/* eslint-disable react/prop-types */
import { IonCol, IonLabel, IonRow, IonToggle } from '@ionic/react';
import React from 'react';

const SettingNotification = (props) => {
  return (
    <IonCol
      sizeMd="4"
      sizeXs="12"
      className="ion-no-padding ion-padding-start ion-padding-bottom pb-2"
    >
      <div className="ion-no-padding box-group ion-padding-end ion-padding-bottom py-lg-2 border-remove-xs">
        <div className="group-flex ion-padding-start pb-2">
          <b className="ion-no-padding">{props.heading}</b>
        </div>
        <IonRow>
          <IonCol>
            <IonCol className="ion-padding-start ps-2" >
              <IonToggle
                className="header-row-margin-left p-1"
                name={props.namePush}
                checked={props.valuePush}
                onIonChange={props.settingFromChangeHandler}
              ></IonToggle>
              <IonLabel className="MuiFormControlLabel-root texttop cursor-none pt-2 pt-lg-0">
                {props.toggleA}
              </IonLabel>
            </IonCol>
            <IonCol className="svg  ms-5">
              <IonToggle
                className="header-row-margin-left p-1"
                name={props.nameEmail}
                checked={props.valueEmail}
                onIonChange={props.settingFromChangeHandler}
              ></IonToggle>
              <IonLabel className="MuiFormControlLabel-root texttop cursor-none pt-2 pt-lg-0">
                {props.toggleB}
              </IonLabel>
            </IonCol>
          </IonCol>
        </IonRow>
      </div>
    </IonCol>
  );
};
export default SettingNotification;
