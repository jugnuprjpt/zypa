import { IonIcon, IonItem, IonList, IonModal, IonRow, useIonPopover } from '@ionic/react';
import { cameraOutline, ellipsisVertical, imageOutline } from 'ionicons/icons';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import edit from '../../assets/img/icons/pencil-line-blue.svg';
import FullCoverImage from '../../assets/img/blog/blog-cover-3.jpg';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper';

const CoverImage = (props) => {
  const { t } = useTranslation();
  const [showModal, setShowModal] = useState(false);

  // const PopoverList: React.FC<{
  //   onHide: () => void;
  // }> = ({ onHide }) => (

  // );
  // const [present, dismiss] = useIonPopover(PopoverList, {
  //   onHide: () => dismiss()
  // });
  return (
    <>
      <div className="coverimg position-relative">
        <div className="ion-no-margin">
          {
            props.croppedImage !== null && props.croppedImage !== ''
              ? <img src={props.croppedImage} />
              : props.image !== null && props.image !== ''
                ? <img src={props.image} />
                : props.croppedImage !== null && props.image !== null
                  ? <img src={props.croppedImage} />
                  : props.image === null
                    ? <img src={props.defultLogo} />
                    : ''
          }

          {!props.reportHideState && props.isHide !== true && props.isAdmin
            ? <div className="edit-coverimg position-absolute d-flex ion-align-items-center ion-justify-content-center cursor-pointer profile-picture">
              <div className='d-flex editimg ion-align-items-center justfy-mobile-center'>
              <IonIcon
                icon={cameraOutline}
                slot="start"
                className="test report cursor-pointer"
                onClick={() => setShowModal(true)}
              // onClick={(e) => {
              //   present({ event: e.nativeEvent });
              // }
              // }
              />
            </div>
            </div>
            : ''
          }

          {/* <Swiper
            id="ka-swiper2"
            className="mySwiper CoverImageswiper"
            autoHeight={true}
            spaceBetween={5}
            navigation={true}
            pagination={{
              clickable: true
            }}
            modules={[Navigation, Pagination]}
          >
            <SwiperSlide className="ion-padding-end pe-0" ><img src={FullCoverImage} alt="Cover Image" /></SwiperSlide>
            <SwiperSlide className="ion-padding-end pe-0" ><img src={FullCoverImage} alt="Cover Image" /></SwiperSlide>
          </Swiper> */}

          {/* <div className='edit-coverimg position-absolute d-flex ion-align-items-center ion-justify-content-center cursor-pointer' onClick={() => setShowModal(true)}>
            <span className='addImage'></span>
            <IonIcon
              icon={edit}
              className="textcolor header-row-margin-left header-menu-account-img"
              slot="start" />
          </div> */}
        </div>
      </div>

      <IonModal isOpen={showModal} cssClass="modelpadding post-modal" onDidDismiss={() => setShowModal(false)} id="confirm-modal">
        <div className='modal-body p-3'>
          <h5 className='m-0 text-dark'>Add Photos</h5>
          <div>
            <IonList className="ps-0 ms-0">
              <IonItem
                lines="none"
                className="cursor-pointer p-0"
                onClick={() => { setShowModal(false); props.openEditModal(); }}
              >
                <IonIcon icon={imageOutline} className="me-2" />
                <p>Workplace</p>
              </IonItem>
              <IonItem
                lines="none"
                className="cursor-pointer p-0"
                onClick={() => { setShowModal(false); props.openEditModal(); }}
              >
                <IonIcon icon={imageOutline} className="me-2" />
                <p>Visiting Card</p>
              </IonItem>
              <IonItem
                lines="none"
                className="cursor-pointer p-0"
                onClick={() => { setShowModal(false); props.openEditModal(); }}
              >
                <IonIcon icon={imageOutline} className="me-2" />
                <p>Other</p>
              </IonItem>
            </IonList>
          </div>
        </div>
      </IonModal>
    </>
  );
};
export default CoverImage;
