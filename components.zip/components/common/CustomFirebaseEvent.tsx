import { FirebaseAnalytics } from '@capacitor-community/firebase-analytics';
const CustomeFirebaseEvent = (eventName, deviceInfo) => {
  if (deviceInfo !== undefined) {
    let events = '';
    if (deviceInfo.platform === 'ios') {
      events = 'ios_' + eventName;
    } else if (deviceInfo.platform === 'android') {
      events = 'android_' + eventName;
    }
    if (events !== '') {
      FirebaseAnalytics.logEvent({
        name: events,
        params: {
          fcmId: 'test',
          eventName: events
        }
      })
        .then(() => console.log('Event successfully tracked'))
        .catch(err => console.log('Error tracking event:', err));
    }
  }
};
export default CustomeFirebaseEvent;
