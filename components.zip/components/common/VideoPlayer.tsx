import React, { useEffect, useRef } from 'react';

const VideoPlayer = (props) => {
  const videoRef = useRef(null);
  useEffect(() => {
    const options = {
      rootMargin: '0px',
      threshold: [1.00, 1.00]
    };

    const handlePlay = (entries, observer) => {
      entries.forEach((entry) => {
        if (videoRef !== undefined && videoRef !== null && videoRef.current !== undefined && videoRef.current !== null) {
          if (entry.isIntersecting) {
            const playPromise = videoRef.current.play();
            if (playPromise !== undefined) {
              playPromise.then(() => {
                videoRef.current.play();
              }).catch((error) => {
                console.log(error);
              });
            }
          } else {
            videoRef.current.pause();
          }
        }
      });
    };
    const observer = new IntersectionObserver(handlePlay, options);

    observer.observe(videoRef.current);
  });
  return (
    <div className="videoadjustment">
      <video
        controls
        controlsList="nodownload"
        playsInline
        muted
        ref={videoRef}
        src={props.url}
      ></video>
    </div>
  );
};
export default VideoPlayer;
