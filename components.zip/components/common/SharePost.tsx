import {
  IonModal,
  IonContent,
  IonRow,
  IonCol,
  IonLabel,
  IonButton,
  IonIcon,
  IonAvatar,
  IonCardTitle,
  IonRadioGroup,
  IonRadio,
  IonCard,
  IonHeader,
  IonFooter,
  IonItem
} from '@ionic/react';
import React, { useEffect, useRef, useState } from 'react';
import { close } from 'ionicons/icons';
import { useDispatch, useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import callFor from '../../util/CallFor';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import Editor2 from './Editor2';
import Pdf from '../../assets/img/icons/pdf-icon.svg';
import { ReactImageGalleryItem } from 'react-image-gallery';
import { useHistory } from 'react-router';
import ToastCommon from './ToastCommon';
import VideoPlayer from './VideoPlayer';
import { useTranslation } from 'react-i18next';

const SharePost = (props: any) => {
  const { t } = useTranslation();
  const history = useHistory();
  const dispatch = useDispatch();
  const postref = useRef(null);
  const profileDetail = useSelector(getProfileDetails);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  // const [formState, setFormState] = useState({ });
  const [feedDetails, setFeedDetails] = useState(props.feeds);
  // const [privacyError, setPrivacyError] = useState('');
  const [loading, setloading] = useState(false);
  const [btnSubmit, setBtnSubmit] = useState(false);
  const photoGallery: readonly ReactImageGalleryItem[] | { original: any }[] = [];
  const videoGallary = [];
  let pdfFile = '';
  useEffect(() => {
    if (props.feeds.postOf !== null) {
      getFeedDatafun();
    }
  }, []);

  const getFeedDatafun = async() => {
    const response = await callFor('api/v1/feed/' + props.feeds.postOf, 'POST', null, 'Auth');
    if (response.status === 200) {
      const jsonResponse = await response.json();
      if (jsonResponse.data !== '' && jsonResponse.data !== null) {
        setFeedDetails(jsonResponse.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 500) {
      const jsonResponse = await response.json();
      setShowToastMsg(jsonResponse.error);
      setShowToast(true);
      // history.push('/home');
    }
  };
  // const checkValidation = () => {
  //   let isPrivacyValid = false;
  //   if (formState.privacy !== undefined && formState.privacy !== null) {
  //     isPrivacyValid = true;
  //   } else {
  //     setPrivacyError('Privacy is required');
  //   }
  //   if (isPrivacyValid) {
  //     return true;
  //   }
  //   return false;
  // };
  const postHandler = async() => {
    // if (checkValidation()) {
    setloading(true);
    setBtnSubmit(true);
    const d = postref.current.editor.getContents();
    let postData = '';
    let hashData = '';
    const attributes: { type: string; start: number; length: any; id: any; }[] = [];
    // eslint-disable-next-line array-callback-return
    d.ops.map((object: { insert: string; }) => {
      if (typeof object.insert === 'object') {
        postData += object.insert.mention.value;
        if (object.insert.mention.value.charAt(0) !== '#') {
          const data1 = {
            mention: 'PROFILE',
            start: postData.lastIndexOf(object.insert.mention.value),
            length: object.insert.mention.value.length,
            id: object.insert.mention.id
          };
          attributes.push(data1);
        } else {
          hashData += object.insert.mention.value;
        }
      } else {
        if (object.insert.match(/#[a-z]+/gi) != null) {
          hashData += object.insert.match(/#[a-z]+/gi);
        }
        postData += object.insert;
      }
    });
    let postType = '';
    if (feedDetails.type === '1') {
      postType = 'Buy';
    } else if (feedDetails.type === '2') {
      postType = 'Sell';
    } else {
      postType = 'General';
    }
    const postComment = { text: postData, attributes: attributes };
    const post = '{"content":' + JSON.stringify(postComment) + ',"origin":"' + props.origin + '","originId":"' + props.originId + '","hashTag":"' + hashData.replaceAll(',', '') + '","type":"' + postType.toUpperCase() + '","privacy":"ANYONE","postOf":"' + feedDetails.id + '"}';
    const data = new FormData();
    data.append('post', post);
    const response = await callFor('api/v1/post', 'POST', data, 'authWithoutContentType');
    if (response.status === 201) {
      const json1Response = await response.json();
      closeHandler();
      let type = '0';
      if (postType === 'Buy') {
        type = '1';
      } else if (postType === 'Sell') {
        type = '2';
      } else {
        type = '3';
      }
      dispatch({
        type: 'add_feedsData_newPost',
        Feeds: {
          id: json1Response.data.id,
          userId: profileDetail.id,
          postOf: feedDetails.id,
          content: JSON.stringify(postComment),
          hashTag: hashData.replaceAll(',', ''),
          mediaUrl: json1Response.data.mediaUrl,
          products: null,
          type: type,
          privacy: '1',
          status: '1',
          ageOfPost:  t('appproperties.text232'),
          commentCount: 0,
          reactionCount: 0,
          userProfile: profileDetail.profileImg,
          userName: profileDetail.name,
          userDesignation: profileDetail.profileTitle,
          sendTo: [],
          aboutUser: null,
          reactionId: null,
          reaction: null,
          viewCount: 0
        }
      });
    } else {
      setloading(false);
      setBtnSubmit(false);
    }
    // }
  };
  const closeHandler = () => {
    // setFormState({ });
    props.setShowShareModal(false);
    // setPrivacyError('');
    setBtnSubmit(false);
    setloading(false);
  };
  const [showMore, setShowMore] = useState(false);
  const textMethod = (text) => {
    let stringvalue = '';
    if (text.length > 200) {
      let msg = text.slice(0, 201);
      for (let i = 201; i < text.length; i++) {
        if (text.charAt(i) !== ' ') {
          msg += text.charAt(i);
        } else {
          break;
        }
      }
      stringvalue = msg;
    } else {
      stringvalue = text.slice(0, text.length + 1);
    }

    return stringvalue;
  };
  const changeContent = (contentObj) => {
    if (contentObj.text.length > 1) {
      let finalString = contentObj.text;
      const subStringval = textMethod(finalString);
      let EmailAnchorlength = 0;
      const ValidateEmail = (mail) => {
        const emailsArray = mail.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
        if (emailsArray != null && emailsArray.length > 0) {
          let j = 0;
          const uniqueChars = [...new Set(emailsArray)];
          let count = 0;
          while (j < uniqueChars.length) {
            const re = new RegExp(uniqueChars[j], 'g');
            const temp = subStringval;
            count += (temp.match(re) || []).length;
            j++;
          }
          EmailAnchorlength = 7 * count;
          let i = 0;
          while (i < uniqueChars.length) {
            const re = new RegExp(uniqueChars[i], 'g');
            finalString = finalString.replace(re, `<a class="font-color" href="mailto:${uniqueChars[i]}">${uniqueChars[i]}</a>`);
            i++;
          }
        }
        return finalString;
      };

      ValidateEmail(finalString);
      let isSame = true;
      if (subStringval.trim().length === finalString.trim().length) {
        isSame = false;
      }
      const urlarr: any[] = [];
      const ValidateUrl = (text) => {
        const urlRegex = /(([a-z]+:\/\/)?(([a-z0-9\-]+\.)+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel|local|internal))(:[0-9]{1,5})?(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&amp;]*)?)?(#[a-zA-Z0-9!$&'()*+.=-_~:/?]*)?)(\s+|$)/gi;
        return text.replace(urlRegex, (url) => {
          urlarr.push(url);
          let urlval = url;
          if (urlval.includes('https://') || urlval.includes('http://')) {
          } else {
            urlval = `https://${url}`;
          }
          const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
          return `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'>${url}</a>`;
        });
      };
      finalString = ValidateUrl(finalString);
      const uniqueUrl = [...new Set(urlarr)];
      let j = 0;
      const arr = [];
      while (j < uniqueUrl.length) {
        const re = new RegExp(uniqueUrl[j], 'g');
        const temp = subStringval;
        arr.push(temp.match(re) || []);
        j++;
      }
      const uniarr = [];
      const uninum = [];
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].length > 0) {
          uninum.push(arr[i].length);
        }

        if (arr[i][0] !== undefined) {
          uniarr.push(arr[i][0]);
        }
      }

      let k = 0;
      let Urllength = 0;
      while (k < uniarr.length) {
        let urlval = uniarr[k];
        if (urlval.includes('https://') || urlval.includes('http://')) {
        } else {
          urlval = `https://${uniarr[k]}`;
        }
        const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
        const val = `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'></a>`;
        Urllength = Urllength + val.length * uninum[k];
        k++;
      }

      let AnchorLength = 0;
      let hashlength = 0;
      let hashData = '';

      if (contentObj.attributes.length > 0) {
        const data = [];
        contentObj.attributes.forEach((element) => {
          const res = contentObj.text.substring(element.start, element.start + element.length);
          if (element.mention === 'PROFILE') {
            if (data.includes(res)) {
              const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
              AnchorLength += val.length;
            } else {
              data.push(res);
              finalString = finalString.replaceAll(res, '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '">' + res + '</a>');
              const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
              AnchorLength += val.length;
            }
          }
        });
      }
      hashData = finalString.match(/#[a-z]+/gi);
      if (hashData !== null && hashData.length > 0) {
        const map = {};
        hashData.map((hashValue) => {
          if((Object.keys(map).filter(item => item === hashValue)).length > 0){
            const cnt = map.[hashValue];
            map.[hashValue] = 1;
          }else {
            map.[hashValue] = 1;
            finalString = finalString.replaceAll(hashValue, '<span style="text-decoration: none;" class = "font-color" href="#">' + hashValue + '</span>');
          }
          const val = '<span style="text-decoration: none;" class ="font-color" href="#">' + hashValue + '</span>';
          hashlength += val.length;
        });
      }
      finalString = finalString.replace(/(\r\n|\r|\n)/g, '<br>');
      const breakstring = finalString.slice(0, AnchorLength + subStringval.length);
      const countbreak = breakstring.match(/<br>/gi);
      let breakcount = 0;
      if (countbreak !== null && countbreak.length > 0) {
        breakcount = countbreak.length;
      }
      if (finalString.length > (200 + EmailAnchorlength + Urllength + AnchorLength + hashlength + breakcount * 3) && !showMore) {
        return (
          <>
            <span dangerouslySetInnerHTML={{ __html: finalString.slice(0, EmailAnchorlength + Urllength + AnchorLength + hashlength + subStringval.length + breakcount * 3 + 1) }} />

            {isSame
              ? <a
                onClick={() => setShowMore(true)} >
                {t('appproperties.text399')} </a>
              : ' '}
          </>
        );
      } else {
        return (
          <span dangerouslySetInnerHTML={{ __html: finalString }} />
        );
      }
    } else {
      return '';
    }
  };
  // const changeHandler = (event) => {
  //   if (event.target.value !== undefined) {
  //     setFormState({ ...formState, [event.target.name]: event.target.value });
  //     if (event.target.name === 'privacy') {
  //       setPrivacyError('');
  //     }
  //   }
  // };
  const mediaMap = (mediaUrl) => {
    if (mediaUrl !== undefined) {
      mediaUrl.map((media) => {
        if (media.split('.').pop() === 'mp4' || media.split('.').pop() === 'MP4' || media.split('.').pop() === 'mov' || media.split('.').pop() === 'MOV') {
          videoGallary.push(media);
        } else if (media.split('.').pop() === 'pdf') {
          pdfFile = media;
        } else {
          photoGallery.push({ original: media });
        }
      });
    };
  };
  const getImgdata = () => {
    if (photoGallery.length > 0) {
      if (photoGallery.length >= 5) {
        return (<div className="post-img tow-col img5">
        <div className="col-1">
          <img src={photoGallery[0].original} />
          <img src={photoGallery[1].original} />
        </div>
        <div className="col-2">
            <img src={photoGallery[2].original} />
            <img src={photoGallery[3].original} />
            <img src={photoGallery[4].original} />
            {photoGallery.length > 5
              ? <span className="count" > + {photoGallery.length - 5 }</span>
              : ''
            }
        </div>
    </div>);
      } else if (photoGallery.length === 4) {
        return (<div className="post-img tow-col">
        <div className="col-1 img2">
          <img src={photoGallery[0].original} />
            <img src={photoGallery[1].original} />
        </div>
        <div className="col-2 img2">
            <img src={photoGallery[2].original}/>
            <img src={photoGallery[3].original}/>
        </div>
    </div>);
      } else if (photoGallery.length === 3) {
        return (<div className="post-img">
        <div className="col-1 img3">
          <img src={photoGallery[0].original} />
          <img src={photoGallery[1].original} />
          <img src={photoGallery[2].original} />
        </div>
    </div>);
      } else if (photoGallery.length === 2) {
        return (<div className="post-img">
        <div className="col-1 img2">
          <img src={photoGallery[0].original} />
          <img src={photoGallery[1].original} />
        </div>
    </div>);
      } else if (photoGallery.length === 1) {
        return (<div className="post-img">
        <div className="col-1 img1">
          <img src={photoGallery[0].original} />
        </div>
    </div>);
      }
    }
  };
  const getFileName = (val) => {
    const url = val.split('/').pop();
    const lastslashindex = url.indexOf('_');
    return decodeURI(url.substring(lastslashindex + 1));
  };
  return (
    <><IonModal isOpen={props.showShareModal} cssClass="sharePostModel modelpadding post-modal" onDidDismiss={() => {
      closeHandler();
    } }>
      <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
        <IonLabel className="MuiTypography-h6">{t('feedproperties.text14')}</IonLabel>
        <div
          onClick={closeHandler}
          className="close ion-no-padding"
        >
          <IonIcon
            icon={close}
            className="ion-button-color pr-0 "
            slot="start"
            size="undefined" />
        </div>
      </IonRow>
      <IonContent className='middel-content'>
        <IonRow>
          <div className='myprofile-feeds ion-padding-start pt-0'>
            <IonAvatar
              slot="start"
              className="MuiCardHeader-avatar MuiAvatar-circular"
            >
              {profileDetail.profileImg !== null
                ? <img onError={(ev) => { ev.target.src = userProfile; }} src={profileDetail.profileImg} />
                : <img src={userProfile} />}
            </IonAvatar>
            <IonRow className="profileName ">
              <IonCardTitle>
                <p className="margin MuiTypography-body1">
                  {profileDetail.name}
                </p>
              </IonCardTitle>
            </IonRow>
          </div>
        </IonRow>
        {/* <IonRow className="ion-padding-top">
          <IonCol className='profileName nowrap-normal' size-md="5" size-xs="12">
            <IonLabel className="ion-padding-start">
              Privacy
            </IonLabel>
            <IonRadioGroup value={formState.privacy}
              onIonChange={changeHandler} name='privacy'>
              <IonRow className="ion-padding-start">
                <IonItem lines="none">
                  <IonRadio mode="md" item-left value="ANYONE"></IonRadio>
                  <IonLabel className="MuiFormControlLabel-root">
                    Anyone
                  </IonLabel>
                </IonItem>
                <IonItem lines="none">
                  <IonRadio mode="md" value="CONNECTION_ONLY"></IonRadio>
                  <IonLabel className="MuiFormControlLabel-root">
                    Connection Only
                  </IonLabel>
                </IonItem>
              </IonRow>
            </IonRadioGroup>
            <p className='error ion-padding-start position-relative'>
              {privacyError}
            </p>
          </IonCol>
        </IonRow> */}
        <Editor2 postref={postref} />
        <IonRow className="ion-padding">
          <IonCard className="MuiPaper-rounded ion-no-margin full-width-row no-shadow">
            <IonRow>
              <IonHeader className="card-header">
                <div className="myprofile-feeds ion-padding-start ion-padding-top">
                  <IonAvatar
                    slot="start"
                    className="MuiCardHeader-avatar MuiAvatar-circular"
                  >
                    {feedDetails.userProfile !== null
                      ? <img onError={(ev) => { ev.target.src = userProfile; }} src={feedDetails.userProfile} />
                      : <img src={userProfile} />}
                  </IonAvatar>
                  <IonRow className="profileName">
                    <IonCardTitle>
                      <p className="margin MuiTypography-body1">
                        {feedDetails.userName}
                      </p>
                      <span className="margin MuiTypography-caption">
                        {feedDetails.userDesignation}
                      </span>
                    </IonCardTitle>
                  </IonRow>
                </div>
              </IonHeader>
            </IonRow>
            <IonRow>
              <IonRow className='full-width-row'>
                <IonButton
                  className="ion-button-color ion-no-margin ion-padding-start cat-btn"
                  shape="round"
                  size="small"
                >
                  {feedDetails.type === '1'
                    ? (t('appproperties.text90'))
                    : feedDetails.type === '2'
                      ? (t('appproperties.text91'))
                      : (t('postproperties.text5'))}
                </IonButton>
              </IonRow>
              <IonRow className='full-width-row ion-margin-bottom'>
                <IonLabel className="MuiTypography-body1 ion-padding-start">
                  {changeContent(JSON.parse(feedDetails.content))}
                </IonLabel>
              </IonRow>

              <IonRow className='full-width-row feed-img'>
                {mediaMap(feedDetails.mediaUrl)}
                {photoGallery.length > 0
                  ? (
                      getImgdata()
                    )
                  : (
                      ''
                    )}
              </IonRow>
              <IonRow className='full-width-row feed-img'>
                {videoGallary.length > 0
                  ? Object.entries(videoGallary).map((details) => (
                    <>
                      <div className="post-img post-video">
                        <div className="col-1">
                        <VideoPlayer url ={details[1]} />
                        </div>
                      </div>
                    </>))
                  : ''}</IonRow>
              {pdfFile.length > 0
                ? <div className="pdf-file-cn">
                  <a href={pdfFile} target='_blank' rel="noreferrer"> <img src={Pdf} width='20' /> {getFileName(pdfFile)}</a>
                </div>
                : ''}
            </IonRow>
          </IonCard>
        </IonRow>
      </IonContent>
      <IonFooter className="ion-no-border MuiButton-label">
        <IonRow className="header-row-margin-left">
          <IonButton
            className="ion-float-right ion-button ion-button-color"
            onClick={postHandler}
            size='default' disabled={btnSubmit}
          >
          {t('feedproperties.text14')}
            {loading
              ? <span className="loader" id="loader-2">
                <span></span>
                <span></span>
                <span></span>
              </span>
              : ''}
          </IonButton>
        </IonRow>
      </IonFooter>
    </IonModal><ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} /></>
  );
};
export default SharePost;
