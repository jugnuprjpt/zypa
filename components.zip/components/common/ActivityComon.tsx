/* eslint-disable multiline-ternary */
/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonChip,
  IonCol,
  IonContent,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  useIonPopover
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import Like from '../../assets/img/emojis/like.svg';
import Celebrate from '../../assets/img/emojis/celebration.svg';
import ShakeHand from '../../assets/img/emojis/shakehands.svg';
import Interest from '../../assets/img/emojis/interest.svg';
import Supports from '../../assets/img/emojis/support.svg';
import FeedDiv from './FeedDiv';
import ImageGallery, { ReactImageGalleryItem } from 'react-image-gallery';
import Pdf from '../../assets/img/icons/pdf-icon.svg';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { close, warning } from 'ionicons/icons';
import { useHistory } from 'react-router-dom';
import CallFor from '../../util/CallFor';
import ProfileDetailRow from './ProfileDetailRow';
import ToastCommon from './ToastCommon';
import VideoPlayer from './VideoPlayer';
import { useTranslation } from 'react-i18next';

const ActivityComman = (props: any) => {
  const { t } = useTranslation();
  const history = useHistory();
  const photoGallery: readonly ReactImageGalleryItem[] | { original: any }[] =
    [];
  const [selectedImgIndex, setSelectedImgIndex] = useState(0);
  const [showImgModal, setshowImgModal] = useState(false);
  const [showReactionModal, setShowReactionModal] = useState(false);
  const [allBtnClass, setAllBtnClass] = useState('ion-button-color');
  const [likeBtnClass, setLikeBtnClass] = useState('category-btn-color');
  const [celebrateBtnClass, setCelebrateBtnClass] = useState('category-btn-color');
  const [interestBtnClass, setInterestBtnClass] = useState('category-btn-color');
  const [shakehandsBtnClass, setShakehandsBtnClass] = useState('category-btn-color');
  const [supportBtnClass, setSupportBtnClass] = useState('category-btn-color');
  const [reactionData, setReactionData] = useState([]);
  const [showMore, setShowMore] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [scollingReactionType, setScollingReactionType] = useState();
  const [scollingPostId, setScollingPostId] = useState();
  const [isLoadding, setIsLoading] = useState(false);
  const [datastring, setDataString] = useState([]);

  const [reactionBtnData, setReactionBtnData] = useState({
    postId: '',
    count: 0,
    likeCount: 0,
    celebrateCount: 0,
    interestCount: 0,
    shakeHandCount: 0,
    supportCount: 0
  });
  const videoGallary = [];
  let pdfFile = '';

  const textMethod = (text: string) => {
    let stringvalue = '';
    if (text.length > 200) {
      let msg = text.slice(0, 201);
      for (let i = 201; i < text.length; i++) {
        if (text.charAt(i) !== ' ') {
          msg += text.charAt(i);
        } else {
          break;
        }
      }
      stringvalue = msg;
    } else {
      stringvalue = text.slice(0, text.length + 1);
    }

    return stringvalue;
  };

  let isSame = true;
  const changeContent = (contentObj) => {
    const arrVal: any[] = [];
    if (contentObj.text.length > 1) {
      let finalString = contentObj.text;
      const subStringval = textMethod(finalString);

      let EmailAnchorlength = 0;
      const ValidateEmail = (mail) => {
        const emailsArray = mail.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
        if (emailsArray != null && emailsArray.length > 0) {
          let j = 0;
          const uniqueChars = [...new Set(emailsArray)];
          let count = 0;
          while (j < uniqueChars.length) {
            const re = new RegExp(uniqueChars[j], 'g');
            const temp = subStringval;
            count += (temp.match(re) || []).length;
            j++;
          }
          EmailAnchorlength = 7 * count;
          let i = 0;
          while (i < uniqueChars.length) {
            const re = new RegExp(uniqueChars[i], 'g');
            finalString = finalString.replace(re, `<a class="font-color" href="mailto:${uniqueChars[i]}">${uniqueChars[i]}</a>`);
            i++;
          }
        }
        return finalString;
      };

      ValidateEmail(finalString);
      if (subStringval.trim().length === finalString.trim().length) {
        isSame = false;
      }
      const urlarr: any[] = [];
      const ValidateUrl = (text) => {
        const urlRegex = /(([a-z]+:\/\/)?(([a-z0-9\-]+\.)+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel|local|internal))(:[0-9]{1,5})?(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&amp;]*)?)?(#[a-zA-Z0-9!$&'()*+.=-_~:/?]*)?)(\s+|$)/gi;
        return text.replace(urlRegex, (url) => {
          urlarr.push(url);
          let urlval = url;
          if (urlval.includes('https://') || urlval.includes('http://')) {
          } else {
            urlval = `https://${url}`;
          }
          const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
          return `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'>${url}</a>`;
        });
      };
      finalString = ValidateUrl(finalString);
      const uniqueUrl = [...new Set(urlarr)];
      let j = 0;
      const arr = [];
      while (j < uniqueUrl.length) {
        const re = new RegExp(uniqueUrl[j], 'g');
        const temp = subStringval;
        arr.push(temp.match(re) || []);
        j++;
      }
      const uniarr = [];
      const uninum = [];
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].length > 0) {
          uninum.push(arr[i].length);
        }

        if (arr[i][0] !== undefined) {
          uniarr.push(arr[i][0]);
        }
      }

      let k = 0;
      let Urllength = 0;
      while (k < uniarr.length) {
        let urlval = uniarr[k];
        if (urlval.includes('https://') || urlval.includes('http://')) {
        } else {
          urlval = `https://${uniarr[k]}`;
        }
        const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
        const val = `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'></a>`;
        Urllength = Urllength + val.length * uninum[k];
        k++;
      }

      let AnchorLength = 0;
      let hashlength = 0;
      let hashData = '';

      if (contentObj.attributes.length > 0) {
        contentObj.attributes.forEach((element) => {
          const res = contentObj.text.substring(element.start, element.start + element.length);
          if (element.mention === 'PROFILE') {
            finalString = finalString.replace(res, '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '">' + res + '</a>');
            if (subStringval.includes(res)) {
              const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
              AnchorLength += val.length;
            }
          }
        });
      }
      hashData = finalString.match(/#[a-z]+/gi);
      if (hashData !== null && hashData.length > 0) {
        const map = {};
        hashData.map((hashValue) => {
          if ((Object.keys(map).filter(item => item === hashValue)).length > 0) {
            const cnt = map.[hashValue];
            map.[hashValue] = 1;
          } else {
            map.[hashValue] = 1;
            finalString = finalString.replaceAll(hashValue, '<span style="text-decoration: none;" class = "font-color" href="#">' + hashValue + '</span>');
          }
          const val = '<span style="text-decoration: none;" class ="font-color" href="#">' + hashValue + '</span>';
          hashlength += val.length;
        });
      }
      finalString = finalString.replace(/(\r\n|\r|\n)/g, '<br>');
      const breakstring = finalString.slice(0, AnchorLength + subStringval.length);
      const countbreak = breakstring.match(/<br>/gi);
      let breakcount = 0;
      if (countbreak !== null && countbreak.length > 0) {
        breakcount = countbreak.length;
      }
      arrVal.push(finalString);
      arrVal.push(200 + EmailAnchorlength + Urllength + AnchorLength + hashlength + breakcount * 3);
      arrVal.push(EmailAnchorlength + Urllength + AnchorLength + hashlength + subStringval.length + breakcount * 3 + 1);
      return arrVal;
      // if (finalString.length > (200 + EmailAnchorlength + Urllength + AnchorLength + hashlength + breakcount * 3) && !showMore) {
      //   return (
      //     <>
      //       <span dangerouslySetInnerHTML={{ __html: finalString.slice(0, EmailAnchorlength + Urllength + AnchorLength + hashlength + subStringval.length + breakcount * 3 + 1) }} />

      //       {isSame
      //         ? <a
      //           onClick={() => setShowMore(true)} >
      //           ...see more </a>
      //         : ' '}
      //     </>
      //   );
      // } else {
      //   return (
      //     <span dangerouslySetInnerHTML={{ __html: finalString }} />
      //   );
      // }
    } else {
      return arrVal;
    }
  };

  const imgModalOpen = (selectedImgIndex) => {
    setSelectedImgIndex(selectedImgIndex);
    setshowImgModal(true);
  };
  const mediaMap = (mediaUrl) => {
    if (mediaUrl !== undefined) {
      mediaUrl.map((media) => {
        if (media.split('.').pop() === 'mp4' || media.split('.').pop() === 'mov' || media.split('.').pop() === 'MP4' || media.split('.').pop() === 'MOV') {
          videoGallary.push(media);
        } else if (media.split('.').pop() === 'pdf') {
          pdfFile = media;
        } else {
          photoGallery.push({ original: media });
        }
      });
    }
  };
  const getImgdata = () => {
    if (photoGallery.length > 0) {
      if (photoGallery.length >= 5) {
        return (
          <div className="post-img tow-col img5">
            <div className="col-1">
              <img
                src={photoGallery[0].original}
                onClick={() => imgModalOpen(0)}
              />
              <img
                src={photoGallery[1].original}
                onClick={() => imgModalOpen(1)}
              />
            </div>
            <div className="col-2">
              <img
                src={photoGallery[2].original}
                onClick={() => imgModalOpen(2)}
              />
              <img
                src={photoGallery[3].original}
                onClick={() => imgModalOpen(3)}
              />
              <img
                src={photoGallery[4].original}
                onClick={() => imgModalOpen(4)}
              />
              {photoGallery.length > 5 ? (
                <span className="count" onClick={() => imgModalOpen(4)}>
                  {' '}
                  + {photoGallery.length - 5}
                </span>
              ) : (
                ''
              )}
            </div>
          </div>
        );
      } else if (photoGallery.length === 4) {
        return (
          <div className="post-img tow-col">
            <div className="col-1 img2">
              <img
                src={photoGallery[0].original}
                onClick={() => imgModalOpen(0)}
              />
              <img
                src={photoGallery[1].original}
                onClick={() => imgModalOpen(1)}
              />
            </div>
            <div className="col-2 img2">
              <img
                src={photoGallery[2].original}
                onClick={() => imgModalOpen(2)}
              />
              <img
                src={photoGallery[3].original}
                onClick={() => imgModalOpen(3)}
              />
            </div>
          </div>
        );
      } else if (photoGallery.length === 3) {
        return (
          <div className="post-img">
            <div className="col-1 img3">
              <img
                src={photoGallery[0].original}
                onClick={() => imgModalOpen(0)}
              />
              <img
                src={photoGallery[1].original}
                onClick={() => imgModalOpen(1)}
              />
              <img
                src={photoGallery[2].original}
                onClick={() => imgModalOpen(2)}
              />
            </div>
          </div>
        );
      } else if (photoGallery.length === 2) {
        return (
          <div className="post-img">
            <div className="col-1 img2">
              <img
                src={photoGallery[0].original}
                onClick={() => imgModalOpen(0)}
              />
              <img
                src={photoGallery[1].original}
                onClick={() => imgModalOpen(1)}
              />
            </div>
          </div>
        );
      } else if (photoGallery.length === 1) {
        return (
          <div className="post-img">
            <div className="col-1 img1">
              <img
                src={photoGallery[0].original}
                onClick={() => imgModalOpen(0)}
              />
            </div>
          </div>
        );
      }
    }
  };
  const getFileName = (val) => {
    const url = val.split('/').pop();
    const lastslashindex = url.indexOf('_');
    return decodeURI(url.substring(lastslashindex + 1));
  };
  const [showToastMsg, setShowToastMsg] = useState('');
  const [erroMsg, setErrorMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [reportModal, setReportModel] = useState(false);
  const [reason, setReason] = useState('');
  const openReportModelclearstate = async () => {
    setReportModel(true);
    setReason('');
    setErrorMsg('');
    setShowToastMsg('');
    setShowToast(false);
    
  };
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr">
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => {onHide(); openReportModelclearstate()}}
      >
        <IonIcon icon={warning} size="small" className="header-menu-img " />
        <p className="ion-padding-start">{t('appproperties.text313')}</p>
      </IonItem>
    </IonList>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });
  const reportChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined) {
      setReason(event.target.value);
    }
  };
  const clickHereToReport = async () => {
    if (reason !== undefined && reason !== '') {
      if (reason.length <= 1000) {
        const reportsData =
          '{"originId": "' +
          props.activity.feedId +
          '","origin": "USER","remarks":"' +
          reason +
          '" }';
        const response = await CallFor(
          'api/v1.1/spam-report',
          'POST',
          reportsData,
          'Auth'
        );
        if (response.status === 200) {
          setReportModel(false);
          setShowToastMsg(
            t('toastmessages.toast24')
          );
          setShowToast(true);
          setTimeout(() => {
            setReportModel(false);
          }, 1000);
        }
      } else {
        setErrorMsg(t('commonproperties.text21'));
      }
    } else {
      setErrorMsg(t('commonproperties.text20'));
    }
  };
  const getReactionData = async (reactionType, page, postId) => {
    setInfiniteDisabled(false);
    setIsLoading(true);
    setCount(1);
    if (reactionType === 'ALL') {
      setAllBtnClass('ion-button-color');
      setLikeBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'LIKE') {
      setAllBtnClass('category-btn-color');
      setLikeBtnClass('ion-button-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'CELEBRATE') {
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('ion-button-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'INTEREST') {
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('ion-button-color');
      setShakehandsBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'SHAKEHANDS') {
      setShakehandsBtnClass('ion-button-color');
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
    } else if (reactionType === 'SUPPORT') {
      setSupportBtnClass('ion-button-color');
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
    }
    const allFeedDataResponse = await CallFor('api/v1/reaction/list/' + postId + '/' + reactionType,
      'POST', JSON.stringify({ page: 0 }), 'Auth');
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      setReactionData(json1Response.data.content);
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setScollingReactionType(reactionType);
    setScollingPostId(postId);
    setIsLoading(false);
  };
  const reactionDetails = async (postId, reactionCount) => {
    if (reactionCount !== 0) {
      setShowReactionModal(true);
      const allFeedDataResponse = await CallFor('api/v1/reaction/' + postId, 'get', null, 'Auth');
      if (allFeedDataResponse.status === 200) {
        const json1Response = await allFeedDataResponse.json();
        if (json1Response.data !== null) {
          setReactionBtnData(json1Response.data);
        }
      } else if (allFeedDataResponse.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
      getReactionData('ALL', 0, postId);
    }
  };
  // const toggle = () => {
  //   setShowMore(true);
  //   setText('');
  // };
  const [count, setCount] = useState(1);
  const loadData = (ev: any) => {
    setTimeout(() => {
      scrollData();
      ev.target.complete();
    }, 500);
  };
  const scrollData = async () => {
    const allFeedDataResponse = await CallFor('api/v1/reaction/list/' + scollingPostId + '/' + scollingReactionType,
      'POST', JSON.stringify({ page: count }), 'Auth');
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      // setReactionData(json1Response.data.content);
      if (json1Response.data.content.length > 0) {
        setReactionData([...reactionData, ...json1Response.data.content]);
        setCount(count + 1);
      } else {
        setInfiniteDisabled(true);
      }
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const closeReactionModel = () => {
    setShowReactionModal(false);
    setCount(1);
  };

  useEffect(() => {
    let subscription = true;
    if (subscription) {

      const finalstringdata = changeContent(JSON.parse(props.activity.content));
      setDataString(finalstringdata);
    }

    return () => {
      subscription = false
    }
  }, []);
  
  return (
    <>
      <div className='feed-activity-card'>
        <IonCard className="MuiPaper-rounded ion-no-margin ion-margin-bottom ion-margin-top feed-cards-posts ">
          {props.activity.activityType ? (
            <IonRow className="card-header-text ion-padding-top ion-padding-start ion-padding-end ion-no-border post-person-name">
              <p className='hashTagAtivityCard cursor-pointer' onClick={() => {
                history.push('/profile/' + props.userId);
              }}>{props.userName} &nbsp;</p>
              {(() => {
                if (props.activity.activityType === '1') {
                  return (
                    <>
                      <span>{t('appproperties.text306')}</span>
                    </>
                  );
                } else if (props.activity.activityType === '2') {
                  return (
                    <>
                      {(() => {
                        if (props.activity.userReaction === '1') {
                          return (
                            <span>{t('appproperties.text307')}</span>
                          );
                        } else if (props.activity.userReaction === '2') {
                          return (
                            <span>{t('appproperties.text308')} </span>
                          );
                        } else if (props.activity.userReaction === '3') {
                          return (
                            <span> {t('appproperties.text308')} </span>
                          );
                        } else if (props.activity.userReaction === '4') {
                          return (
                            <span>{t('appproperties.text308')}</span>
                          );
                        } else if (props.activity.userReaction === '5') {
                          return (
                            <span> {t('appproperties.text308')} </span>
                          );
                        }
                      })()}
                    </>
                  );
                } else if (props.activity.activityType === '3') {
                  return (
                    <>
                      <span>{t('appproperties.text310')}</span>
                    </>
                  );
                } else if (props.activity.activityType === '4') {
                  return (
                    <>
                      <span> {t('appproperties.text310')} </span>
                    </>
                  );
                } else if (props.activity.activityType === '5') {
                  return (
                    <>
                      <span> {t('appproperties.text312')} </span>
                    </>
                  );
                } else if (props.activity.activityType === '6') {
                  return (
                    <>
                      <span> {t('appproperties.text311')} </span>
                    </>
                  );
                }
              })()}
            </IonRow>
          ) : (
            ''
          )}
          <ProfileDetailRow userProfile={props.activity.userProfile} userName={props.activity.userName}
            userDesignation={props.activity.userDesignation} ageOfPost={props.activity.ageOfPost} userId={props.activity.userId} feedId={props.activity.feedId} isFeed={true} feedType={props.activity.type} feedIndex={props.feedKey} isactive={true} companyName={props.activity.userCompany} />
          <IonRow className="feed-body">
            <IonRow
              className="full-width-row ion-padding-horizontal"
            >
              <IonLabel className="full-width-row MuiTypography-body2 description cursor-pointer">
                <span >{

                  datastring.length > 0 &&
                    (datastring[0].length > (datastring[1]) && !showMore)
                    ? <>
                      <span onClick={() => history.push('/viewfeed/' + props.activity.feedId)} dangerouslySetInnerHTML={{ __html: datastring[0].slice(0, datastring[2]) }} />
                      {isSame ? (datastring.length > 0) && !showMore && datastring[0].length > (datastring[1]) ? <a onClick={() => setShowMore(true)} >{t('appproperties.text399')} </a> : ' ' : ' '}

                    </> : <span onClick={() => history.push('/viewfeed/' + props.activity.feedId)} dangerouslySetInnerHTML={{ __html: datastring[0] }} />

                }</span>
              </IonLabel>

            </IonRow>
            <IonRow className="full-width-row feed-img">
              {mediaMap(props.activity.mediaUrl)}
              {photoGallery.length > 0 ? getImgdata() : ''}
            </IonRow>
            <IonRow className="full-width-row feed-img">
              {videoGallary.length > 0
                ? Object.entries(videoGallary).map((details) => (
                  <>
                    <div className="post-img post-video">
                      <div className="col-1">
                        <VideoPlayer url={details[1]} />
                      </div>
                    </div>
                  </>
                ))
                : ''}
            </IonRow>
            {pdfFile.length > 0 ? (
              <div className="pdf-file-cn">
                <a href={pdfFile} target="_blank" rel="noreferrer">
                  {' '}
                  <img src={Pdf} width="20" /> {getFileName(pdfFile)}
                </a>
              </div>
            ) : (
              ''
            )}
            <IonRow className='full-width-row'>
              {props.activity.postOf !== null ? (
                <FeedDiv postOf={props.activity.postOf} />
              ) : (
                ''
              )}
            </IonRow>
          </IonRow>

          <IonRow className="card-header-text post-comment-view ion-padding-bottom ion-padding-top">
            <IonRow className="full-width-row com-first-row">
              <IonCol size-md="6" size-xs="4" className="myprofile-feeds pa-0">
                <IonChip className="post-btn ion-no-padding ion-padding-start ion-padding-end" onClick={() => reactionDetails(props.activity.feedId, props.activity.reactionCount)}>
                  <IonAvatar className="ion-no-padding reaction-btn">
                    {(() => {
                      if (props.activity.reaction === '1') {
                        return (
                          <img src={Like} width='20' />
                        );
                      } else if (props.activity.reaction === '2') {
                        return (
                          <img src={Celebrate} width='20' />
                        );
                      } else if (props.activity.reaction === '3') {
                        return (
                          <img src={Interest} width='20' />
                        );
                      } else if (props.activity.reaction === '4') {
                        return (
                          <img src={ShakeHand} width='20' />
                        );
                      } else if (props.activity.reaction === '5') {
                        return (
                          <img src={Supports} width='20' />
                        );
                      } else {
                        return (
                          <img src={Like} width='20' />
                        );
                      }
                    })()}
                  </IonAvatar>
                </IonChip>
                <p className="rectionCount"> {props.activity.reactionCount}</p>
              </IonCol>
              <IonCol size-md="6" size-xs="8" className="ion-align-self-center pa-0">
                <p className="ion-float-right secondary-text MuiTypography-body2">
                  {props.activity.commentCount} {t('feedproperties.text11')}
                </p>
              </IonCol>
            </IonRow>
          </IonRow>
        </IonCard>
      </div>
      <IonModal
        isOpen={showImgModal}
        cssClass="add-award-model awd-img-gallery"
        onDidDismiss={() => setshowImgModal(false)}
      >
        <IonContent>
          <IonRow className="full-width-row ">
            <IonButton
              fill="clear"
              className="ion-activatable header-row-margin-left"
              onClick={() => setshowImgModal(false)}
            >
              <IonIcon
                icon={close}
                className="ion-button-color"
                slot="start"
                size="undefined"
              />
            </IonButton>
          </IonRow>
          <IonRow className="overview-heigth ">
            <ImageGallery
              items={photoGallery}
              showPlayButton={false}
              autoPlay={false}
              startIndex={selectedImgIndex}
            />
          </IonRow>
        </IonContent>
      </IonModal>

      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />

      <IonModal isOpen={showReactionModal} cssClass='add-award-model' onDidDismiss={() => setShowReactionModal(false)}>
        <div className='px-3 px-xl-4'>
          <IonCol className="d-flex MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">
              {t('feedproperties.text5')}
            </IonLabel>
            <div onClick={closeReactionModel} className="close ion-no-padding" >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 cursor-pointer"
                slot="start"
                size="undefined"
              />
            </div>
          </IonCol>
          <IonRow className='reaction-icon-list scroll-mobile-horztl'>
            <IonButton
              className={allBtnClass}
              shape="round"
              size="small"
              onClick={() => getReactionData('ALL', 0, reactionBtnData.postId)}
            >
              {t('appproperties.text15')}
            </IonButton>
            {reactionBtnData.likeCount !== 0
              ? <IonButton
                className={likeBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData(t('feedproperties.text6'), 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Like} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.likeCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.celebrateCount !== 0
              ? <IonButton
                className={celebrateBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('CELEBRATE', 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Celebrate} width="20" />
                  <span className='ion-padding-start'>{reactionBtnData.celebrateCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.interestCount !== 0
              ? <IonButton
                className={interestBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('INTEREST', 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Interest} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.interestCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.shakeHandCount !== 0
              ? <IonButton
                className={shakehandsBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('SHAKEHANDS', 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={ShakeHand} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.shakeHandCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.supportCount !== 0
              ? <IonButton
                className={supportBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('SUPPORT', 0, reactionBtnData.postId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Supports} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.supportCount}</span>
                </div>
              </IonButton>
              : ''}
          </IonRow>
        </div>
        <IonContent>
          <IonRow className='pb-2 px-3 px-xl-4 ion-padding-top reaction-list-content w-100'>
            {!isLoadding &&
              reactionData.map((reaction) => (
                <>
                  <IonRow className='full-width-row ion-no-padding'>
                    {(() => {
                      if (reaction.reaction === '1') {
                        return (
                          <div className='reation-emoji'><img src={Like} width='20' /></div>
                        );
                      } else if (reaction.reaction === '2') {
                        return (
                          <div className='reation-emoji'><img src={Celebrate} width='20' /></div>
                        );
                      } else if (reaction.reaction === '3') {
                        return (
                          <div className='reation-emoji'><img src={Interest} width='20' /></div>
                        );
                      } else if (reaction.reaction === '4') {
                        return (
                          <div className='reation-emoji'><img src={ShakeHand} width='20' /></div>
                        );
                      } else if (reaction.reaction === '5') {
                        return (
                          <div className='reation-emoji'><img src={Supports} width='20' /></div>
                        );
                      }
                    })()}
                    <div className="myprofile-feeds ps-3">
                      <IonAvatar className="MuiAvatar ion-margin-end">
                        {reaction.profileImage != null
                          ? <img onError={(ev) => { ev.target.src = userProfile; }} src={reaction.profileImage} />
                          : <img src={userProfile} />
                        }
                      </IonAvatar>
                      <IonRow className="display-grid">
                        <span className='name'>{reaction.userName}</span>
                        <span className="margin MuiTypography-caption group-model-text nowrap-normal">
                          {reaction.designation}
                        </span>
                      </IonRow>
                    </div>
                  </IonRow>
                </>
              ))
            }
            <IonInfiniteScroll
              onIonInfinite={loadData}
              threshold="100px"
              disabled={isInfiniteDisabled}
            >
              <IonInfiniteScrollContent
                loadingSpinner="circular"
                loadingText={t('appproperties.text215')}
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </IonRow>
        </IonContent>
      </IonModal>
    </>
  );
};
export default ActivityComman;