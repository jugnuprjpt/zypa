/* eslint-disable react/prop-types */
import { IonCard, IonRow } from '@ionic/react';
import React from 'react';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper';
import CommonGridList from './CommonGridList';
import companyProfile from '../../assets/img/banner-placeholder.png';

const KnowledgePartner = (props) => {
  return (
    <div className="ion-padding-verticale">
        <IonRow>
        <span className="textcolour head-title ms-2 ms-lg-0">{props.header}</span>
        </IonRow >
        {
          props.KnowledgePartnerData.length > 4
            ? <>
            <IonRow className="connection-suggetion-item-box connection-member mt-3 ps-2 knowledge-partner">
              <Swiper
                  id="ka-swiper2"
                  navigation={true}
                  modules={[Navigation, Pagination]}
                  className="mySwiper"
                  autoHeight={true}
                  breakpoints={{
                    320: {
                      width: 190,
                      slidesPerView: 1,
                      navigation: false
                    },
                    768: {
                      width: 768,
                      slidesPerView: 4
                    }
                  }}
              >
                {
                  props.KnowledgePartnerData.map((detail, i) => (
                    <>
                    {
                      detail.status === 'ACTIVE' &&
                    <SwiperSlide className="ion-padding-end" key={i}>
                      <IonCard className="MuiPaper-rounded ion-margin-bottom ion-no-margin connectionSuggestion">
                      <CommonGridList
                        defultImage={companyProfile}
                        img={detail.logoUrl}
                        name={detail.companyName + '-' + detail.industryName}
                        redirection={true}
                      />
                      </IonCard>
                    </SwiperSlide>
                    }
                    </>
                  ))
                }

              </Swiper>
            </IonRow>
          </>
            : ''
      }
    </div>

  );
};

export default KnowledgePartner;
