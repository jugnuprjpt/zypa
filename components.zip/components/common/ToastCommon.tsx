import { IonToast } from '@ionic/react';
import { informationCircle } from 'ionicons/icons';
import React from 'react';

const ToastCommon = (props : any) => {
  return (
    <IonToast
    isOpen={props.showToast}
    onDidDismiss={() => props.setShowToast(false)}
    message={props.showToastMsg}
    icon={informationCircle}
    position="bottom"
    duration={props.duration}
    cssClass='successTost'
    buttons={[
      {
        text: 'close',
        role: 'cancel'
      }
    ]}
  />
  );
};
export default ToastCommon;
