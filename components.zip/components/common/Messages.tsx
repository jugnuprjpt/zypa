/* eslint-disable prettier/prettier */
import React from 'react';
import moment from 'moment';
import { IonItem, IonLabel, IonList, IonRow } from '@ionic/react';

const Message = (props: any) => {
    return (
        <>
            {
                props.data.senderId === props.currentUserId ? (
                    <IonItem className='msgSender'>
                        <div>
                            <IonRow className='msgText'>
                                <IonLabel className="align-right">{props.data.content}</IonLabel>
                            </IonRow>
                            <IonRow className='msgTime text-right'>
                                <IonLabel
                                    className="align-right"
                                >{new Date(props.data?.createdOn)?.toLocaleTimeString(
                                    'en-US',
                                    {
                                        hour: 'numeric',
                                        minute: 'numeric',
                                        hour12: true,
                                    }
                                )}</IonLabel>
                            </IonRow>
                        </div>
                    </IonItem>
                ) : (
                    <IonItem className='msgReceiver'>
                        <div>
                            <IonRow className='msgText'>
                                <IonLabel className="align-left">{props.data.content}</IonLabel>
                            </IonRow>
                            <IonRow className='msgTime text-left'>
                                <IonLabel
                                    className="align-left"
                                >{new Date(props.data?.createdOn)?.toLocaleTimeString(
                                    'en-US',
                                    {
                                        hour: 'numeric',
                                        minute: 'numeric',
                                        hour12: true,
                                    }
                                )}</IonLabel>
                            </IonRow>
                        </div>
                    </IonItem>
                )
            }
        </>
    );
};
const DisplayDate = (props: any) => {
    return (
        <div className='msgDate'>
            <div className="align-center">
                {props.date}
            </div>
        </div>
    );
};

const Messages = (props: any) => {
    function groupedDays(messages: any) {
        return messages.reduce((acc: any, el: any, i: any) => {
            const diffDays = moment(new Date()).diff(moment(el.createdOn), 'days')
var messageDate;
            if(diffDays > 7){

                messageDate = moment(el.createdOn).format('DD-MM-YYYY');
            }
            else{

                messageDate  = moment(el.createdOn).format('dddd');
            }
            if (acc[messageDate]) {
                return { ...acc, [messageDate]: acc[messageDate].concat([el]) };
            }
            return { ...acc, [messageDate]: [el] };
        }, {});
    }

    function generateItems(messages: any) {
        const days = groupedDays(messages);
        const sortedDays = Object.keys(days).sort(
            (x, y) => moment(y, 'DD-MM-YYYY').unix() - moment(x, 'DD-MM-YYYY').unix()
        );
        const items: any = sortedDays.reduce((acc: any, date: any) => {
            const sortedMessages: any = days[date].sort(
                (x: any, y: any) => new Date(y?.createdOn) - new Date(x?.createdOn)
            );
            return acc.concat([...sortedMessages, { type: 'day', date, id: date }]);
        }, []);
        return items;
    }

    return (
        <IonList lines="none">
            {props.messages.length > 0 &&
                generateItems(props.messages)
                    ?.slice(0)
                    ?.reverse()
                    ?.map((msg: any, i: any) => {
                        if (msg?.type) {
                            return <DisplayDate key={i} date={msg?.date} className='ActiveDate' />;
                        }
                        return <Message key={i} data={msg} currentUserId={props.userId} />;
                    })}
        </IonList>
    );
};

export default Messages;
