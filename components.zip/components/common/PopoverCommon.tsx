import React from 'react';
import { IonIcon, IonList, useIonPopover } from '@ionic/react';
import { informationCircle } from 'ionicons/icons';

const PopoverCommon = (props : any) => {
  const PopoverList: React.FC<{
        onHide: () => void;
    }> = ({ onHide }) => (

        <IonList className='common-popover'>
            {props.Description}
        </IonList>
    );

  const [present, dismiss] = useIonPopover(PopoverList, { onHide: () => dismiss() });

  return (
        <div className="popover-zyapaar">
            <IonIcon
                icon={informationCircle}
                slot="start"
                size='small'
                className="report cursor-pointer"
                onClick={(e) => present({ event: e.nativeEvent })}
            />
        </div>
  );
};
export default PopoverCommon;
