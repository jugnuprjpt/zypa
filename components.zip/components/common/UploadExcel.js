import React, { useCallback } from 'react';
// import XLSX from 'xlsx';
import XLSX from 'xlsx';

const UploadExcel = () => {
  // const [fileName, setFileName] = useState(null);

  // const handlefile = async(e) => {
  //   // const file = e.target.files[0];
  //   // const data = await file.arrayBuffer();
  //   const data = e.target.result;
  //   console.log(data);
  //   const workbook = XLSX.read(data);
  //   alert('sjcdbb');
  //   const worksheet = workbook.Sheets[workbook.SheetNames[0]];
  //   const jsonData = XLSX.utils.sheet_to_json(worksheet);

  //   console.log(jsonData);
  // };
  const handleFileChange = useCallback((e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = function(e) {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      console.log(workbook);
      const firstSheet = workbook.SheetNames[0];
      console.log(firstSheet);
      // setIsReading(false);
      const elements = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet]);
      console.log('Excel read OK!');
      console.log('Found ' + elements.length + ' elements');
      console.log('JSON size', JSON.stringify(elements).length, 'bytes');
    };
    // setIsReading(true);
    reader.readAsArrayBuffer(file);
  }, []);

  return (
    <div>l
       <input type="file" onChange={handleFileChange}/>

    </div>
  );
};

export default UploadExcel;
