import { IonRow, IonHeader, IonAvatar, IonIcon, IonItem, IonList, useIonPopover } from '@ionic/react';
import { ellipsisVertical, trashBinOutline, warningOutline } from 'ionicons/icons';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import CallFor from '../../util/CallFor';
import ConfirmModelCommon from './ConfirmModelCommon';
import NotAuthorizeModal from './NotAuthorizeModal';
import ReportSpamCommon from './ReportSpamCommon';
import ToastCommon from './ToastCommon';

const ProfileDetailRow = (props) => {
  const { t } = useTranslation();
  const [loginModal, setLoginModal] = useState(false);
  const label = [
    {
      id: 1,
      name: t('appproperties.text43')
    },
    {
      id: 2,
      name: t('appproperties.text44')
    },
    {
      id: 3,
      name: t('appproperties.text45')
    },
    {
      id: 4,
      name: t('appproperties.text46')
    },
    {
      id: 5,
      name: t('appproperties.text47')
    },
    {
      id: 6,
      name: t('dropdownfields.text13')
    }];
  const profileDetail = useSelector(getProfileDetails);
  const history = useHistory();
  const dispatch = useDispatch();
  const [showToastMsg, setShowToastMsg] = useState('');
  // const [erroMsg, setErrorMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [confirmModel, setConfirmModel] = useState(false);
  const clickHandler = () => {
    if (props.userId !== undefined) {
      history.push('/profile/' + props.userId);
    }
  };
  const [reportModal, setReportModel] = useState(false);
  // const [reason, setReason] = useState('');
  const openReportModelclearstate = async () => {
    setReportModel(true);
    // setReason('');
    // setErrorMsg('');
    setShowToastMsg('');
    setShowToast(false);
    dismiss();
  };
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <>
      {props.isactive !== true
        ? <IonList className="my-account-pr">
          {profileDetail.id === props.userId
            ? <IonItem
              lines="none"
              className="cursor-pointer"
              onClick={() => { onHide(); setConfirmModel(true); }}
            >
              <IonIcon icon={trashBinOutline} size="small" className="header-menu-img " />
              <p>{t('commonproperties.text35')}</p>
            </IonItem>
            : ''}
          {profileDetail.id !== props.userId
            ? <IonItem
              lines="none"
              className="cursor-pointer"
              onClick={() => { onHide(); openReportModelclearstate() }}
            >
              <IonIcon icon={warningOutline} size="small" className="header-menu-img " />
              <p>{t('commonproperties.text19')}</p>
            </IonItem>
            : ''}
        </IonList>
        : <IonList className="my-account-pr">
          <IonItem
            lines="none"
            className="cursor-pointer"
            onClick={() => { onHide(); openReportModelclearstate() }}
          >
            <IonIcon icon={warningOutline} size="small" className="header-menu-img " />
            <p>{t('commonproperties.text19')}</p>
          </IonItem>
        </IonList>}
    </>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });
  const deleteBtnHandler = async (feedId, index) => {
    setConfirmModel(true);
    dismiss();
    const response = await CallFor(
      'api/v1/post/' + feedId,
      'DELETE',
      null,
      'Auth'
    );
    if (response.status === 201) {
      dispatch({
        type: 'delete_feedsData',
        isDeleted: true,
        index: props.feedIndex
      });
    } else if (response.status === 400) {
      const json1Response = await response.json();
      console.log(json1Response.error.message);
    }
  };
  return (
    <IonRow>
      <IonHeader className="card-header">
        <div className="myprofile-feeds ion-padding-start ion-padding-top post-card w-100">
          <div className='myprofile-feeds ion-no-padding cursor-pointer w-75' onClick={clickHandler}>
            <IonAvatar
              slot="start"
              className="MuiCardHeader-avatar MuiAvatar-circular"
            >
              {props.userProfile !== null
                ? <img onError={(ev) => { ev.target.src = userProfile; }} src={props.userProfile} />
                : <img src={userProfile} />
              }
            </IonAvatar>
            <IonRow className="profileName overflow-nowrap">
              <h2 className="margin MuiTypography-body1">
                {props.userName}
              </h2>
              <span className="margin MuiTypography-caption">
                {props.userDesignation} {props.companyName ? 'at' + ' ' + props.companyName : ''}
              </span>

            </IonRow>
          </div>
          {props.ageOfPost !== undefined
            ? <IonRow className="ion-float-right header-row-margin-left">
              {props.feedType !== undefined
                ? <>
                  <span
                    className="ion-button-color ion-no-margin cat-btn pr-3 feed-type-btn topcss"
                  >
                    {props.feedType === '1'
                      ? t('appproperties.text90')
                      : props.feedType === '2'
                        ? t('appproperties.text91')
                        : props.feedType === '3'
                          ? t('postproperties.text5')
                          : ''}
                  </span>
                </>
                : ''}
              <div className="ion-float-right ion-no-margin home-font-color MuiTypography-caption text-flex mt-lg-2 pt-lg-1 ion-align-items-start">
                <span>{props.ageOfPost}</span>
                {props.isactive === true
                  // && profileDetail.id === props.userId
                  ? ''
                  : <div className="dot-btn">
                    <IonIcon
                      icon={ellipsisVertical}
                      slot="start"
                      className="color-theme font-20 text-grey report cursor-pointer"
                      onClick={(e) => {
                        if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                          present({ event: e.nativeEvent });
                        } else {
                          // history.push('/addnewcompany');
                          setLoginModal(true);
                        }
                      }
                      }
                    />
                  </div>}

              </div>
              {/* <IonButton fill="clear" className="ion-no-margin">
                  <IonIcon
                    icon={ellipsisVertical}
                    className="test ion-no-margin" />
                </IonButton> */}
            </IonRow>
            : ''}
        </div>
      </IonHeader>
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />

      {/* <IonModal
        isOpen={reportModal}
        className="createGroupModal"
        backdropDismiss="false"
      >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6 ">
            Report Spam
            </IonLabel>
            <Link
              onClick={() => setReportModel(false)}
              className="close ion-no-padding"
            >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0"
                slot="start"
                size="undefined"
              />
            </Link>
          </IonRow>
          <div className="modal-body">
            <div className="body-content">
              <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
                <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                  <div className="input-label-box">
                    <IonTextarea
                      type="text"
                      autocomplete="off"
                      placeholder='Write a message'
                      rows="15"
                      className={
                        erroMsg
                          ? 'error-border input-box'
                          : 'input-box mt-0'
                      }
                      value={reason}
                      onIonChange={reportChangeHandler}
                    />
                  </div>
                  <span className={erroMsg ? 'error' : ''}>
                    {erroMsg}
                  </span>
                </IonCol>
              </IonRow>
            </div>
            <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
              <IonRow>
                <IonButton
                  className="header-row-margin-left ion-button-color ml-auto pr-0"
                  size="small"
                  type="button"
                  onClick={clickHereToReport}
                >
                  Spam
                </IonButton>
              </IonRow>
            </IonFooter>
          </div>
        </IonContent>
      </IonModal> */}
      <ReportSpamCommon reportModal={reportModal} setReportModel={setReportModel} reportId={props.feedId} origin='FEED' mapData={label} message={t('toastmessages.toast21')} fIndex={props.feedIndex} />
      <ConfirmModelCommon header={t('appproperties.text427')} message={t('appproperties.text403')} btn1={t('appproperties.text206')} btn2={t('commonproperties.text35')} confirmModel={confirmModel} setConfirmModel={setConfirmModel} deleteBtnHandler={deleteBtnHandler} iD={props.feedId} indexId={props.feedIndex} />
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}
    </IonRow>
  );
};
export default ProfileDetailRow;
