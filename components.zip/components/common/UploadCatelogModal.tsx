/* eslint-disable @typescript-eslint/semi */
import { IonButton, IonIcon, IonModal } from '@ionic/react'
import { closeOutline, cloudUploadOutline, downloadOutline } from 'ionicons/icons';
import React, { useRef } from 'react'
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router';
const download='https://zyapaar-image-test2.s3.ap-south-1.amazonaws.com/Bulk_product_catalogue_Template.xlsx';

const UploadCatelogModal = (props: any) => {
  const { t } = useTranslation();
  const linkRef = useRef();

  async function downloadImage(e) {
    e.preventDefault()
    const src = linkRef.current.href
    linkRef.current.download = 'randomImage'
    linkRef.current.click()
  }

  const closeHandler = () => {
    props.setOpenmodal(false);
    localStorage.removeItem('upload')
  };
  return (
    <IonModal
        isOpen={props.openModal}
        cssClass="addCompany-modal fileup-height"
        backdropDismiss={false}
      >
        <div
          onClick={closeHandler}
          className="close ion-no-padding cursor-pointer p-2 text-end"
        >
          <IonIcon
            icon={closeOutline}
            className="ion-button-color text-dark font-28"
            slot="start"
            size="undefined"
          />
        </div>
        <input
          type="file"
          accept=".xls, .xlsx, .csv"
          color="dark"
          onChange={props?.fileHandler}
          className="ion-text-capitalize ion-no-padding ion-padding-end upload"
          multiple
          id="fileUpload"
        ></input>
        <label
          htmlFor="fileUpload"
          className="ion-text-capitalize cursor-pointer border pb-2 borderRadius12 w-75 mx-auto"
          color="dark"
        >
          <h2 className='color-theme-dark d-flex align-items-center justify-content-center  mt-2 mb-0'>
            <IonIcon icon={cloudUploadOutline} className='me-3 font-28' />{t('appproperties.text55')}
          </h2>
        </label>

        <h4 className='justify-content-center m-0 mt-1'>
        <div className='font-15 text-center'>{t('appproperties.text56')}</div>
          <a ref={linkRef} href={download} download="download" className='d-flex justify-content-center mb-4'>
            <IonButton onClick={downloadImage}  className='d-flex align-items-center'>
              <IonIcon 
                icon={downloadOutline}
                className="ion-button-color text-white font-26"
                slot="start"
              />
              {t('appproperties.text57')}
            </IonButton>
          </a>
          
        </h4>
      </IonModal>
  )
}

export default UploadCatelogModal