import { IonButton, IonCol, IonContent, IonFooter, IonIcon, IonItem, IonLabel, IonModal, IonRadio, IonRadioGroup, IonRow } from '@ionic/react';
import { close } from 'ionicons/icons';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import callFor from '../../util/CallFor';
import ButtonComponent from './ButtonComponent';
import ToastCommon from './ToastCommon';

const ReportSpamCommon = (props: any) => {
  const { t } = useTranslation();
  const history = useHistory();
  const [showToast, setShowToast] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [show, setshow] = useState(true);
  const [remarks, setRemarks] = useState('');
  const [selected, setSelected] = useState('');
  const dispatch = useDispatch();
  const conformBtn = (remarksName) => {
    setRemarks(remarksName);
    setshow(false);
  };
  const closeModel = () => {
    props.setReportModel(false);
    setshow(true);
    setSelected('');
  };

  const reportBtnHandler = async () => {
    const reportsData =
      '{"originId": "' + props.reportId + '","origin":"' + props.origin + '" ,"remarks":"' + remarks + '" }';
    const response = await callFor(
      'api/v1.1/spam-report',
      'POST',
      reportsData,
      'Auth'
    );
    if (response.status === 201) {
      if (props.origin === 'COMMENT') {
        if (props.replyIndex === undefined) {
          dispatch({
            type: 'report_comment',
            isReport: true,
            index: props.index,
            commentIndex: props.commentIndex

          });
        } else {
          dispatch({
            type: 'report_reply',
            isReport: true,
            index: props.index,
            commentIndex: props.commentIndex,
            replyIndex: props.replyIndex
          });
        }
      }
      if (props.origin === 'FEED') {
        dispatch({
          type: 'report_feedsData',
          isReport: true,
          index: props.fIndex
        });
      };
      if (props.origin === 'USER' || props.origin === 'COMPANY') {
        props.setReportHideState(true);
      }

      setshow(true);
      setSelected('');
      setShowToastMsg(props.message);
      setShowToast(true);
      props.setReportModel(false);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  return (
    <><IonModal
      isOpen={props.reportModal}
      className="addCompany-modal report-modal"
      onDidDismiss={() => closeModel()}
      id="report-modal"
    >
      <div className='report-spam-type custom-popheight'>
        <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
          <IonLabel className="MuiTypography-h6 ">
            {t('commonproperties.text19')}
          </IonLabel>
          <IonButton fill="clear" onClick={() => closeModel()} className="close link-btn-tx ion-no-padding ion-no-margin">
            <IonIcon
              icon={close}
              className="ion-button-color pr-0"
              slot="start"
              size="undefined" />
          </IonButton>
        </IonRow>
        <div>
          {show
            ? <div className="body-content">
              <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
                <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                  {props.mapData.map((detail, i) => (<>

                    <IonRadioGroup className='Home-modal-content-post-type-radio' value={selected} onIonChange={e => setSelected(e.detail.value)} key={i}>
                      <IonItem className='report-space' slot="start" value={detail.name} onClick={() => conformBtn(detail.name)}>
                        <IonRadio />
                        <IonLabel>{detail.name}</IonLabel>
                      </IonItem>
                    </IonRadioGroup>
                    {/* <p onClick={() => conformBtn(detail.name)} className='cursor-pointer'> {detail.id} {detail.name} </p> */}
                  </>
                  )
                  )}
                </IonCol>
              </IonRow>
            </div>
            : <><div className="body-content">
              <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
                <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                  <IonLabel className='msg-text' > {t('appproperties.text395')}<b> {remarks}</b> ? </IonLabel>
                </IonCol>
              </IonRow>
            </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom bottom0 position-absolute">
                <IonRow>
                  <IonButton
                    className="btn-secondry mr-2"
                    size="small"
                    onClick={() => setshow(true)}
                  >
                    {t('appproperties.text159')}
                  </IonButton>
                  {/* <IonButton
                        className="ion-button-color "
                        size="small"
                        onClick={() => reportBtnHandler()}
                      >
                      
                      </IonButton> */}
                  <ButtonComponent
                    btnClick={reportBtnHandler}
                    className='ion-button-color'
                    size='small'
                    name={t('commonproperties.text19')} parametersPass={0} />
                </IonRow>
              </IonFooter>
            </>
          }
        </div>
      </div>
    </IonModal>
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
    </>
  );
};
export default ReportSpamCommon;
