import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonRow
} from '@ionic/react';
import React from 'react';

const AddSummaryCard = (props: { mapData: any[] }) => {
  return (
    <IonCard className="profile-details left-cards ion-no-margin MuiPaper-rounded ion-padding-bottom ion-padding-end">
      <IonRow>
        {props.mapData.map(
          (detail: {
            activityLogo: string | undefined;
            profileName:
              | boolean
              | React.ReactChild
              | React.ReactFragment
              | React.ReactPortal
              | null
              | undefined;
            description:
              | boolean
              | React.ReactChild
              | React.ReactFragment
              | React.ReactPortal
              | null
              | undefined;
            buttontag:
              | boolean
              | React.ReactChild
              | React.ReactFragment
              | React.ReactPortal
              | null
              | undefined;
          }) => (
            // eslint-disable-next-line react/jsx-key
            <IonCol
              sizeMd="6"
              sizeXs="12"
              className="ion-no-padding ion-padding-start ion-padding-top"
            >
              <div className="myprofile-feeds ion-no-padding input-box ion-padding-end ion-padding-bottom">
                <IonAvatar slot="start" className="MuiCardHeader-avatar">
                  <img src={detail.activityLogo} />
                </IonAvatar>
                <IonRow className="profileName">
                  <IonCardTitle>
                    <p className="margin MuiTypography-body1">
                      {detail.profileName}
                    </p>
                    <span className="margin MuiTypography-caption group-model-text">
                      {detail.description}
                    </span>
                  </IonCardTitle>
                </IonRow>
                {detail.buttontag
                  ? (
                  <IonButton
                    className="ion-button-color header-row-margin-left ion-padding-left"
                    size="small"
                  >
                    {detail.buttontag}
                  </IonButton>
                    )
                  : (
                      ''
                    )}
              </div>
            </IonCol>
          )
        )}
      </IonRow>
    </IonCard>
  );
};
export default AddSummaryCard;
