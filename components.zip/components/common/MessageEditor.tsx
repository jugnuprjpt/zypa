import React from 'react';
import ReactQuill from 'react-quill';

import 'quill-mention';
import 'quill/dist/quill.snow.css';
import 'quill-mention/dist/quill.mention.min.css';
import CallFor from '../../util/CallFor';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import { useTranslation } from 'react-i18next';

const MessageEditor = (props: any) => {
  const { t } = useTranslation();
  const modules = {
    toolbar: false,
    mention: {
      showDenotationChar: false,
      allowedChars: /^[A-Za-z\sÅÄÖåäö]*$/,
      mentionDenotationChars: ['@', '#'],
      isolateCharacter: true,
      source: async function(searchTerm: string, renderList: (arg0: { id: number; value: string; }[], arg1: any) => void, mentionChar: string) {
        if (mentionChar === '@') {
          if (searchTerm !== '') {
            const matchedPeople = await suggestPeople(searchTerm);
            renderList(matchedPeople, mentionChar);
          }
        }
      },
      renderItem: (item: { profileImg: null; value: any; }, mentionChar: string) => {
        if (mentionChar === '@') {
          return `<div class="userList">
            <IonRow class="userListItem">
            <IonAvatar class="MuiAvatar ion-margin-end">
                <img src=${item.profileImg !== null ? item.profileImg : userProfile} class="MuiAvatar-circular"/> </IonAvatar>
        <span>${item.value}</span></IonRow> </div>`;
        }
        return item.value;
      },
      onSelect: function(item: any, insertItem: any) {
        insertItem(item);
        addContentEditable();
      }
    }
  };
  const suggestPeople = async(searchTerm: string) => {
    const response = await CallFor(
      'api/v1.1/connections/users/' + searchTerm,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const jsonResponse = await response.json();
      const options = await jsonResponse.data.map(
        (d: any) => ({
          id: d.id,
          value: d.fullName,
          profileImg: d.profileImg
        })
      );
      return options;
    } else if (response.status === 401) {
      localStorage.clear();
    }
  };
  const addContentEditable = () => {
    const mentionData = document.querySelectorAll('.mention > span');
    mentionData.forEach(element => {
      element.contentEditable = 'true';
    });
  };
  return (
    <><div>
      <ReactQuill
        ref ={props.messageRef}
        modules={modules}
        onChange={addContentEditable}
        onBlur={props.messageChangeHandler}
        placeholder={t('userproperties.text10')}
      >
        <div className='full-width-row post-q-editor post-modal-editor'>
        </div>
      </ReactQuill>
    </div></>
  );
};
export default MessageEditor;
