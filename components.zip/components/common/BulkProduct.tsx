import React, { useEffect, useRef, useState } from 'react'
import {
  IonButton,
  IonCard,
  IonCol,
  IonContent,
  IonFooter,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonRow,
  IonTextarea
} from '@ionic/react';
import product from '../../assets/img/Product_default.png';
import { add, closeOutline, copyOutline, trashBinOutline } from 'ionicons/icons';
import CallFor from '../../util/CallFor';
import { useHistory } from 'react-router';
import { useTranslation } from 'react-i18next';
const BulkProduct = (props: any) => {
  const { t } = useTranslation();
  const history = useHistory();
  const [withOutImageModal, setWithOutImageModal] = useState(false);
  const buttonPhotoRef = useRef();
  const [currentActiveRow, setCurrentActiveRow] = useState(0);
  const [moreImageModal, setMoreImageModal] = useState(false);
  const [createDisabled, setCreateDisabled] = useState(false);
  const [ConfirmModal, setConfirmModel] = useState(false);
  const [deleteRowModal, setDeleteRowModal] = useState(false);
  const [removeImage, setRemoveImage] = useState(false);
  const [deleteRowIndex, setDeleteRowIndex] = useState(0);
  const [copyModal, setCopyModal] = useState(false);
  const [copyIndex, setCopyIndex] = useState();
  const [deleteIndex, setDeleteIndex] = useState();
  const [checkedEvents, setCheckedEvents] = useState({});
  const [isError, setIsError] = useState(false);
  const [updateDisabled, setUpdateDisabled] = useState(false);
  const maxCount = 1000;
  const [isFocus, setIsFocus] = useState(false);
  const [isCopy, setIsCopy] = useState(false);
  const [isCopyLoading, setIscopyLoading] = useState(false);
  useEffect(() => {
    let unsubscribe = false;
    if (!unsubscribe) {
      const curr = props.imageList[currentActiveRow]
      let errorCount = 0;
      curr?.map(image => {
        if (image.hasError) {
          errorCount++
        }
      })
      let currentProduct = props.productList[currentActiveRow]
      if (errorCount > 0) {
        if (currentProduct !== undefined) {
          props?.setProductList([...props?.productList?.slice(0, currentActiveRow),
          { ...currentProduct, hasError: true },
          ...props.productList?.slice(currentActiveRow + 1)]);
        }
      }
      else {
        if (currentProduct !== undefined) {
          props?.setProductList([...props?.productList?.slice(0, currentActiveRow),
          { ...currentProduct, hasError: false },
          ...props.productList?.slice(currentActiveRow + 1)]);
        }
      }
    }
    return () => {
      unsubscribe = true;
    }
  }, [props.imageList]);
  useEffect(() => {
    let subscription = true
    if (subscription) {
      setIsError(false)
      props.productList?.map(product => {
        if (product.hasError) {
          setIsError(true)
        }
      })
    }
    return () => {
      subscription = false
    }
  }, [props.productList])
  const numberRegex = /^[0-9.\b]+$/;
  const validationFun = (name: string, value: string) => {
    let msg = '';
    if (name === 'name') {
      if (value !== undefined) {
        if (String(value).trim() === '') {
          msg = (t('productproperties.text8'));
        } else if (String(value).trim().length < 2) {
          msg = (t('productproperties.text9'));
        } else if (String(value).trim().length > 150) {
          msg = (t('productproperties.text10'));
        } else {
          msg = '';
        }
      } else {
        msg = (t('productproperties.text8'));
      }
    } else if (name === 'price') {
      if (value !== undefined) {
        if (!numberRegex.test(value)) {
          msg = t('productproperties.text12');
        }
        if (String(value).trim() === '') {
          msg = t('productproperties.text11');
        }
      } else {
        msg = t('productproperties.text11');
      }
    } else if (name === 'brandName') {
      if (String(value).trim() !== '' && value !== undefined) {
        if (String(value).trim().length < 2) {
          msg = (t('productproperties.text9'));
        } else if (String(value).trim().length > 150) {
          msg = (t('productproperties.text10'));
        } else {
          msg = '';
        }
      }
    } else if (name === 'minimumQty') {
      if (value !== undefined) {
        if (String(value).trim() === '') {
          msg = t('productproperties.text18')
        } else if (Number(value) === 0) {
          msg = (t('productproperties.text20'))
        } else {
          msg = '';
        }
      } else {
        msg = t('productproperties.text18')
      }
    } else if (name === 'paymentTerms') {
      if (value !== undefined) {
        if (String(value).trim() === '') {
          msg = t('productproperties.text21')
        } else if (value !== undefined && String(value).trim().length < 2) {
          msg = (t('productproperties.text9'));
        } else if (value !== undefined && String(value).trim().length > 150) {
          msg = (t('productproperties.text10'));
        } else {
          msg = '';
        }
      } else {
        msg = t('productproperties.text21')
      }
    } else if (name === 'description') {
      if (value !== undefined) {
        if (String(value).trim() === '') {
          msg = t('productproperties.text26')
        } else if (String(value).trim().length < 10) {
          msg = t('commonproperties.text28');
        } else if (String(value).trim().length > 1000) {
          msg = t('productproperties.text28');
        } else {
          msg = '';
        }
      } else {
        msg = t('productproperties.text26')
      }
    }
    return msg;
  }
  const uploadMoreImages = (event: { target: { files: string | any[]; }; }) => {
    if (event.target.files.length > 0) {
      const imageDatas = props.imageList;
      const images = [];
      images.push(...imageDatas[currentActiveRow]);
      const imgLength = images.length + event.target.files.length;
      if (imgLength <= 5) {
        for (let i = 0; i < event.target.files.length; i++) {
          if (!event.target.files[i].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
            images.push({ file: event.target.files[i], hasError: true, errorMsg: t('appproperties.text397') });
          } else if (event.target.files[i].size > 716800) {
            images.push({ file: event.target.files[i], hasError: true, errorMsg: t('productproperties.text31') });
          }
          else {
            images.push({ file: event.target.files[i], hasError: false, errorMsg: '' });
          }
          setMoreImageModal(true);
          props.setImagesList([...props.imageList.slice(0, currentActiveRow),
            images,
          ...props.imageList.slice(currentActiveRow + 1),]);
        }
      } else {
        props.setShowToastMsg('Can\'t upload product more than 5');
        props.setShowToast(true);
        setMoreImageModal(false);
      }
    }
  };
  const checkValidation = () => {
    const productData = props.productList;
    let isvalid = true;
    props.productList.map((value: any, i: number) => {
      productData[i]['name_error'] = validationFun('name', value.name);
      productData[i]['description_error'] = validationFun('description', value.description);
      productData[i]['price_error'] = validationFun('price', value.price);
      productData[i]['brandName_error'] = validationFun('brandName', value.brandName);
      productData[i]['minimumQty_error'] = validationFun('minimumQty', value.minimumQty);
      productData[i]['paymentTerms_error'] = validationFun('paymentTerms', value.paymentTerms);
      if (productData[i]['name_error'] !== '') {
        isvalid = false;
      } else if (productData[i]['description_error'] !== '') {
        isvalid = false;
      } else if (productData[i]['price_error'] !== '') {
        isvalid = false;
      } else if (productData[i]['brandName_error'] !== '') {
        isvalid = false;
      } else if (productData[i]['minimumQty_error'] !== '') {
        isvalid = false;
      } else if (productData[i]['paymentTerms_error'] !== '') {
        isvalid = false;
      } else if (isError) {
        isvalid = false;
      }
      props.setProductList([...props.productList.slice(0, i),
      productData[i],
      ...props.productList.slice(i + 1),]);
    })
    // setIsRecentlyDeleteProduct(false);
    return isvalid;
  }
  const getPhotoUrl = (img: Blob | MediaSource | undefined) => {
    if (img !== undefined) {
      return URL.createObjectURL(img.file);
    } else {
      return '';
    }
  };
  const seeMoreimg = (index: React.SetStateAction<undefined>) => {
    setCurrentActiveRow(index);
    setMoreImageModal(true);
  };
  function userformDataChangeHandler(event, index) {
    if (event.target.value !== undefined) {
      let productData = Object.assign({}, props.productList[index]);
      productData[event.target.name] = event.target.value;
      const msg = validationFun(event.target.name, event.target.value);
      let validationfiled = [event.target.name] + '_error';
      productData[validationfiled] = msg;
      props.setProductList([...props.productList.slice(0, index),
        productData,
      ...props.productList.slice(index + 1)]);
    }
  };
  const submitdata = () => {
    if (checkValidation()) {
      let isEmpty = 0;
      props.productList.map((value: any, index: any) => {
        const images: string | any[] | Blob = [];
        props.imageList[index].map((val: any, ind: any) => {
          images.push(val);
        });
        if (images.length === 0) {
          isEmpty++;
        }
      });
      if (isEmpty > 0) {
        setWithOutImageModal(true);
      } else {
        submitHandler();
      }
    }
  }
  const submitHandler = async () => {
    if (checkValidation()) {
      const images: string | any | Blob = [];
      const jsonData: { name: any; price: any; brandName: any; minimumQty: any; paymentTerms: any; description: any; index: any; imageCount: any; entitiesId: any; }[] = [];
      const data = new FormData();
      props.productList.map((value: { name: any; price: any; brandName: any; minimumQty: any; paymentTerms: any; description: any; entitiesId: any; }, index: string | number) => {
        jsonData.push({ name: (String(value.name).trim()), price: (Number(String(value.price).trim())), brandName: String(value.brandName).trim(), minimumQty: String(value.minimumQty).trim(), paymentTerms: String(value.paymentTerms).trim(), description: String(value.description).trim(), index: index, imageCount: props.imageList[index].length, entitiesId: value.entitiesId });
        props.imageList[index].map((val: any, ind: any) => {
          images.push(val.file);
          data.append("productImage", val.file);
        });
      });
      if (images.length === 0) {
        data.append("productImage", images);
      }
      var jsonDatapas = { "products": jsonData };
      data.append('dto', JSON.stringify(jsonDatapas));
      setUpdateDisabled(true)
      const response = await CallFor(
        'api/v1.1/product',
        'POST',
        data,
        'authWithoutContentType'
      );
      if (response.status === 200) {
        props.setShowModal(false);
        props.setShowToastMsg(t('toastmessages.toast40'));
        props.setShowToast(true);
        props.setImagesList([]);
        props.setProductList([])
        if (props.productList !== undefined) {
          props.productLists();
        }
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else if (response.status === 400) {
        const datares = await response.json();
        if (datares.length > 0) {
          datares.map(data => props.setShowToastMsg(data.message));
        } else {
          props.setShowToastMsg(datares.error.message);
        }
        props.setShowToast(true);
        setCreateDisabled(false);
      } else {
        setCreateDisabled(false);
      }
    };
    setWithOutImageModal(false);
    setUpdateDisabled(false);
    props.setPageCount(0);
  };
  const deleteRow = () => {
    let filteredProduct = props.productList.filter((value: any, i: any) => i !== deleteRowIndex)
    props.setProductList(filteredProduct);
    props.setImagesList(props.imageList.filter((value: any, i: any) => i !== deleteRowIndex));
    if ((props.productList.length - 1) === 0) {
      props.setShowModal(false);
      setDeleteRowModal(true);
    } else {
      setDeleteRowModal(false);
    }
    setDeleteRowIndex(0);
  };
  const openmodal = (index) => {
    setDeleteRowModal(true);
    setDeleteRowIndex(index);
  }
  const deleteImage = () => {
    const images = props.imageList[currentActiveRow];
    props.setImagesList([...props.imageList.slice(0, currentActiveRow),
    images.filter((value: any, i: any) => i !== deleteIndex),
    ...props.imageList.slice(currentActiveRow + 1),]);
    setRemoveImage(false);
  }
  const deleteProduct = (index) => {
    setDeleteIndex(index);
    props.setProductList([]);
    props.setImagesList([]);
    setCurrentActiveRow(0);
    props.setShowModal(false);
  }
  const openCopyModal = (index) => {
    if (!isCopy) {
      setCopyModal(true);
      setCopyIndex(index);
    }
  }
  const copyRow = () => {
    if (checkedEvents !== undefined && !isCopy) {
      setIsCopy(true);
      setIscopyLoading(true);
      if (checkedEvents.allDetails) {
        let products = [];
        for (var i = 0; i < props.productList.length; i++) {
          let tempProduct = props.productList[i];
          if (i > copyIndex) {
            if (props.productList[copyIndex].price !== '') {
              tempProduct.price = props.productList[copyIndex].price
              tempProduct.price_error = props.productList[copyIndex].price_error
            }
            else {
              if (props.productList[i].price !== "")
                tempProduct.price = props.productList[i].price
              tempProduct.price_error = props.productList[i].price_error
            }
            if (props.productList[copyIndex].brandName !== '') {
              tempProduct.brandName = props.productList[copyIndex].brandName
              tempProduct.brandName_error = props.productList[copyIndex].brandName_error
            } else {
              if (props.productList[i].brandName !== "")
                tempProduct.brandName = props.productList[i].brandName
              tempProduct.brandName_error = props.productList[i].brandName_error
            }
            if (props.productList[copyIndex].description !== '') {
              tempProduct.description = props.productList[copyIndex].description
              tempProduct.description_error = props.productList[copyIndex].description_error
            }
            else {
              if (props.productList[i].description !== "")
                tempProduct.description = props.productList[i].description
              tempProduct.description_error = props.productList[i].description_error
            }
            if (props.productList[copyIndex].minimumQty !== '') {
              tempProduct.minimumQty = props.productList[copyIndex].minimumQty
              tempProduct.minimumQty_error = props.productList[copyIndex].minimumQty_error
            }
            else {
              if (props.productList[i].minimumQty !== "")
                tempProduct.minimumQty = props.productList[i].minimumQty
              tempProduct.minimumQty_error = props.productList[i].minimumQty_error
            }
            if (props.productList[copyIndex].paymentTerms !== '') {
              tempProduct.paymentTerms = props.productList[copyIndex].paymentTerms
              tempProduct.paymentTerms_error = props.productList[copyIndex].paymentTerms_error
            }
            else {
              if (props.productList[i].paymentTerms !== "")
                tempProduct.paymentTerms = props.productList[i].paymentTerms
              tempProduct.paymentTerms_error = props.productList[i].paymentTerms_error
            }
            if (props.productList[copyIndex].name !== '') {
              tempProduct.name = props.productList[copyIndex].name
              tempProduct.name_error = props.productList[copyIndex].name_error
            } else {
              if (props.productList[i].name !== "")
                tempProduct.name = props.productList[i].name
              tempProduct.name_error = props.productList[i].name_error
            }
            products.push(tempProduct)
          }
          else {
            products.push(props.productList[i]);
          }
        }
        props.setProductList(products);
        props.setImagesList([...props.imageList, []])
        products = []
      } else {
        let products = [];
        for (var i = 0; i < props.productList.length; i++) {
          let productData = Object.assign({}, props.productList[i]);
          if (checkedEvents.price) {
            if (i > copyIndex && props.productList[copyIndex].price !== '') {
              productData.price = props.productList[copyIndex].price;
              productData.price_error = props.productList[copyIndex].price_error;
            } else {
              productData.price = props.productList[i].price;
            }
          }
          if (checkedEvents.brandName) {
            if (i > copyIndex && props.productList[copyIndex].brandName !== '') {
              productData.brandName = props.productList[copyIndex].brandName;
              productData.brandName_error = props.productList[copyIndex].brandName_error;
            } else {
              productData.brandName = props.productList[i].brandName;
            }
          }
          if (checkedEvents.description) {
            if (i > copyIndex && props.productList[copyIndex].description !== '') {
              productData.description = props.productList[copyIndex].description;
              productData.description_error = props.productList[copyIndex].description_error;
            } else {
              productData.description = props.productList[i].description;
            }
          }
          if (checkedEvents.minimumQuantity) {
            if (i > copyIndex && props.productList[copyIndex].minimumQty !== '') {
              productData.minimumQty = props.productList[copyIndex].minimumQty;
              productData.minimumQty_error = props.productList[copyIndex].minimumQty_error;
            } else {
              productData.minimumQty = props.productList[i].minimumQty;
            }
          }
          if (checkedEvents.paymentTerms) {
            if (i > copyIndex && props.productList[copyIndex].paymentTerms !== '') {
              productData.paymentTerms = props.productList[copyIndex].paymentTerms;
              productData.paymentTerms_error = props.productList[copyIndex].paymentTerms_error;
            } else {
              productData.paymentTerms = props.productList[i].paymentTerms;
            }
          }
          if (checkedEvents.productName) {
            if (i > copyIndex && props.productList[copyIndex].name !== '') {
              productData.name = props.productList[copyIndex].name;
              productData.name_error = props.productList[copyIndex].name_error;
            } else {
              productData.name = props.productList[i].name;
            }
          }
          products.push(productData);
        }
        props.setProductList(products);
      }
    }
    setCopyModal(false);
    setIscopyLoading(false);
  }
  const addMoreProduct = () => {
    if (props.productList.length < 30) {
      props.setProductList([...props.productList, { name: '', price: '', brandName: '', minimumQty: '', paymentTerms: '', description: '', image: '', index: props.productList.length + 1, imageCount: 0, entitiesId: props.companyId }])
      props.setImagesList([...props.imageList, []])
    }
    setIsCopy(false);
  }
  const handleChange = (event) => {
    if (event.target.name === 'allDetail') {
      if (event.target.checked) {
        return setCheckedEvents({
          ...checkedEvents, allDetails: true, productName: true, brandName: true, minimumQuantity: true, paymentTerms: true, price: true, description: true
        })
      } else {
        return setCheckedEvents({
          ...checkedEvents, allDetails: false, productName: false, brandName: false, minimumQuantity: false, paymentTerms: false, price: false, description: false
        })
      }
    }
    setCheckedEvents({ ...checkedEvents, [event.target.name]: event.target.checked, allDetails: false });
  }
  const deleteImageModal = (index) => {
    setRemoveImage(true);
    setDeleteIndex(index);
  }
  const bulkProductCloseHandler = () => {
    props.setIsSingle(false);
    props.setShowModal(false);
    props.setProductList([]);
    props.setImagesList([]);
  }
  const copyStateChage = () => {
    setIsCopy(false);
  };
  return (
    <>
      <IonCard className='shadow-none'>
        <div>
          <IonModal
            isOpen={props.showModal}
            cssClass="AddNewCatalogue"
            backdropDismiss={false}
          >
            <div className='d-flex justify-content-between ps-4 custom-modal-heading'>
              <h3>
                {props.addProductPage ? <>{t('productproperties.text1')}</> : <>{t('appproperties.text53')}</>}
              </h3>
              <div
                onClick={bulkProductCloseHandler}
                className="close cursor-pointer font-26 ion-no-padding pe-3 py-2"
              >
                <IonIcon
                  icon={closeOutline}
                  className="ion-button-color text-dark"
                  slot="start"
                  size="undefined"
                />
              </div>
            </div>
            <IonContent>
              <div className="modal-body m-3 iosinput-textbox">
                <form
                  data-testid="form-submit"
                  autoComplete="off"
                  className="h-100"
                  noValidate
                // onSubmit={handleSubmit}
                >
                  <table className='table'>
                    <thead>
                      <tr>
                        <th align='center'>{t('appproperties.text58')}</th>
                        <th align='center'>{t('productproperties.text2')}</th>
                        <th align='center'>{t('productproperties.text3')}</th>
                        <th align='center'>{t('productproperties.text5')}</th>
                        <th align='center'>{t('productproperties.text6')}</th>
                        <th align='center'>{t('productproperties.text7')}</th>
                        <th align='center'>{t('commonproperties.text39')}</th>
                        <th align='center'>{t('appproperties.text61')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {props.productList?.map((productData, index: number) => {
                        return <tr className='position-relative' key={index}>
                          <td><div>Product {index + 1} / {props?.productList?.length}</div></td>
                          <td className='d-flex justify-content-between pb-1 pt-0'>
                            <div className="catalogue-img float-left float-lg-none text-center cursor-pointer d-sm-block d-flex align-items-center" onClick={() => seeMoreimg(index)}>
                              {props?.imageList[index][0] !== undefined ?
                                <img
                                  src={getPhotoUrl(props?.imageList[index][0])}
                                  alt={t('appproperties.text299')}
                                />
                                : <img src={product} alt={t('appproperties.text299')} />
                              }
                              <div className='ms-2'>
                                <p className='cursor-pointer addmoreimg ms-lg-0'>{t('appproperties.text59')}</p>
                                {productData?.hasError && <p className='error ion-padding-start mt-0 mb-0 post-error ps-0 line-h-error erro-small-font'>{t('appproperties.text263')} </p>}
                              </div>
                            </div>
                            <div>
                              {!(props.productList.length === 1) &&
                                <IonButton
                                  className="header-row-margin-left category-btn-color ml-auto me-2 pe-lg-0 mt-md-2"
                                  size="small"
                                  title={t('appproperties.text65')}
                                  onMouseDown={() => openCopyModal(index)}
                                >
                                  <IonIcon icon={copyOutline} />
                                </IonButton>
                              }
                              <IonButton
                                className="header-row-margin-left category-btn-color ml-auto pe-lg-0 mt-md-2"
                                size="small"
                                title={t('commonproperties.text35')}
                                // reference
                                onMouseDown={() => { openmodal(index); }}
                              >
                                <IonIcon icon={trashBinOutline} />
                              </IonButton>
                            </div>
                          </td>
                          <td>
                            <IonItem
                              className={
                                productData.name_error !== undefined && productData.name_error !== ''
                                  ? 'error-border form-group input-label-box position-relative pt-0 mb-0'
                                  : 'form-group input-label-box position-relative mb-0 pt-0'
                              }
                            >
                              <IonLabel position="floating">{t('productproperties.text2')}<sup>*</sup></IonLabel>
                              <IonInput
                                autocomplete="off"
                                type="text"
                                className="input-box input-custom-width"
                                data-testid="name"
                                // onChange={(e) => userformDataChangeHandler(e, index)}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => {copyStateChage(); setIsFocus(false)}}
                                onIonChange={(e) => isFocus && userformDataChangeHandler(e, index)}
                                placeholder=""
                                id="name"
                                name="name"
                                value={productData.name}
                              />
                            </IonItem>
                            <p className={productData.name_error !== undefined && productData.name_error !== '' ? 'error' : ''}>
                              {productData.name_error}
                            </p>
                          </td>
                          <td>
                            <IonItem
                              className={
                                productData.price_error !== undefined && productData.price_error !== ''
                                  ? 'error-border form-group input-label-box position-relative mb-0'
                                  : 'form-group input-label-box position-relative mb-0 pt-0'
                              }
                            >
                              <IonLabel position="floating">
                                {' '}
                                {t('productproperties.text3')}<sup>*</sup>{' '}
                              </IonLabel>
                              <IonInput
                                autocomplete="off"
                                type="text"
                                inputmode='numeric'
                                // onkeydown="javascript: return ['Backspace','Delete','ArrowLeft','ArrowRight','Period','Tab'].includes(event.code) ? true : !isNaN(Number(event.key)) && event.code!=='Space'"
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => {copyStateChage(); setIsFocus(false)}}
                                onIonChange={(e) => isFocus && userformDataChangeHandler(e, index)}
                                data-testid="price"
                                placeholder=""
                                className="input-box input-custom-width"
                                placeholder=""
                                id="price"
                                name="price"
                                value={productData.price}
                              // value={addProductData.price}
                              />
                            </IonItem>
                            <p className={productData.price_error !== undefined && productData.price_error !== '' ? 'error' : ''}>
                              {productData.price_error}
                            </p>
                          </td>
                          <td>
                            <IonItem
                              className={
                                productData.brandName_error !== undefined && productData.brandName_error !== ''
                                  ? 'error-border form-group input-label-box position-relative mb-0'
                                  : 'form-group input-label-box position-relative mb-0 pt-0'
                              }
                            >
                              <IonLabel position="floating">{t('productproperties.text5')}</IonLabel>
                              <IonInput
                                autocomplete="off"
                                type="text"
                                className="input-box input-custom-width"
                                data-testid="brandName"
                                placeholder=""
                                // onChange={(e) => userformDataChangeHandler(e, index)}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => {copyStateChage(); setIsFocus(false)}}
                                onIonChange={(e) => isFocus && userformDataChangeHandler(e, index)}
                                id="brandName"
                                name="brandName"
                                value={productData.brandName}
                              />
                            </IonItem>
                            <p className={productData.brandName_error !== undefined && productData.brandName_error !== '' ? 'error' : ''}>
                              {productData.brandName_error}
                            </p>
                          </td>
                          <td>
                            <IonItem
                              className={
                                productData.minimumQty_error !== undefined && productData.minimumQty_error !== ''
                                  ? 'error-border form-group input-label-box position-relative mb-0'
                                  : 'form-group input-label-box position-relative mb-0 pt-0'
                              }
                            >
                              <IonLabel position="floating">
                                {t('productproperties.text6')}<sup>*</sup>{' '}
                              </IonLabel>
                              <IonInput
                                autocomplete="off"
                                type="text"
                                data-testid="minimumQty"
                                className="input-box input-custom-width"
                                placeholder=""
                                // onChange={(e) => userformDataChangeHandler(e, index)}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => {copyStateChage(); setIsFocus(false)}}
                                onIonChange={(e) => isFocus && userformDataChangeHandler(e, index)}
                                id="minimumQty"
                                name="minimumQty"
                                value={productData.minimumQty}
                              />
                            </IonItem>
                            <p className={productData.minimumQty_error !== undefined && productData.minimumQty_error !== '' ? 'error' : ''}>
                              {productData.minimumQty_error}
                            </p>
                          </td>
                          <td>
                            <IonItem
                              className={
                                productData.paymentTerms_error !== undefined && productData.paymentTerms_error !== ''
                                  ? 'error-border form-group input-label-box position-relative mb-0'
                                  : 'form-group input-label-box position-relative mb-0 pt-0'
                              }
                            >
                              <IonLabel position="floating">
                                {t('productproperties.text7')}<sup>*</sup>{' '}
                              </IonLabel>
                              <IonInput
                                autocomplete="off"
                                type="text"
                                className="input-box input-custom-width"
                                data-testid="paymentTerms"
                                placeholder=""
                                // onChange={(e) => userformDataChangeHandler(e, index)}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => {copyStateChage(); setIsFocus(false)}}
                                onIonChange={(e) => isFocus && userformDataChangeHandler(e, index)}
                                id="paymentTerms"
                                name="paymentTerms"
                                value={productData.paymentTerms}
                              />
                            </IonItem>
                            <p className={productData.paymentTerms_error !== undefined && productData.paymentTerms_error !== '' ? 'error' : ''}>
                              {productData.paymentTerms_error}
                            </p>
                          </td>
                          <td className='description position-relative'>
                            <IonItem
                              className={
                                productData.description_error !== undefined && productData.description_error !== ''
                                  ? 'error-border form-group input-label-box position-relative full-width-row mb-0 pt-0'
                                  : 'form-group input-label-box position-relative full-width-row mb-0 pt-0'
                              }
                            >
                              <IonLabel position="floating">
                                {t('commonproperties.text39')}<sup>*</sup>
                              </IonLabel>
                              <IonTextarea
                                className="input-box full-width-row"
                                // onChange={(e) => userformDataChangeHandler(e, index)}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => {copyStateChage(); setIsFocus(false)}}
                                onIonChange={(e) => isFocus && userformDataChangeHandler(e, index)}
                                value={productData.description}
                                rows={1}
                                // maxlength={490}
                                id="description"
                                name="description"
                              />
                            </IonItem>
                            <p className={productData.description_error !== undefined && productData.description_error !== '' ? 'error' : ''}>
                              {productData.description_error}
                            </p>
                            <p className='text-grey pe-2 position-absolute right0 bottom0 text-end font-12'>
                              {productData.description !== undefined && productData.description !== null && productData.description.length > 0
                                ? productData.description.length
                                : 0}/{maxCount}
                            </p>
                          </td>
                        </tr>
                      })}
                    </tbody>
                  </table>
                </form>
              </div>
            </IonContent>
            <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
              <IonRow>
                <IonButton
                  className="ion-button-color"
                  size="small"
                  type="submit"
                  onClick={() => addMoreProduct()}
                  disabled={props.productList.length >= 30 ? true : false}
                >
                  {t('appproperties.text68')}
                </IonButton>
                <IonButton
                  className="header-row-margin-left ion-button-color ml-auto category-btn-color"
                  size="small"
                  type="submit"
                  onClick={() => setConfirmModel(true)}
                >
                  {t('commonproperties.text35')}
                </IonButton>
                <IonButton
                  className="ion-button-color pe-0"
                  size="small"
                  type="submit"
                  onClick={submitdata}
                  disabled={createDisabled || updateDisabled}
                >
                  {t('appproperties.text64')}
                  {updateDisabled &&
                    <span className="loader" id="loader-2">
                      <span></span>
                      <span></span>
                      <span></span>
                    </span>
                  }
                </IonButton>
              </IonRow>
            </IonFooter>
          </IonModal>
        </div>
      </IonCard>
      {moreImageModal && <IonModal
        isOpen={moreImageModal}
        onDidDismiss={() => setMoreImageModal(false)}
        cssClass="AddImages"
        backdropDismiss={false}
      >
        <IonRow className="MuiDialogTitle-root ion-padding pt-0 full-width-row modal-heading ion-align-items-center ion-justify-content-between bg-grey custom-modal-heading p-0 mb-10">
          <IonLabel className="MuiTypography-h6">{t('appproperties.text67')}</IonLabel>
          <div
            onClick={() => setMoreImageModal(false)}
            className="close ion-no-padding cursor-pointer mt-2 me-2"
          >
            <IonIcon
              icon={closeOutline}
              className="ion-button-color text-dark"
              slot="start"
              size="undefined"
            />
          </div>
        </IonRow>
        <div className='modal-body ion-padding pt-0'>
          <div className='d-md-flex ion-align-items-center moreimg h-75'>
            {currentActiveRow !== undefined && props.imageList[currentActiveRow] !== undefined && props.imageList[currentActiveRow].map((value: any, index: any) => {
              return (
                <div className='moreimages position-relative' style={{ borderColor: value.hasError ? "red" : "" }} key={index}>
                  <div>
                    <img src={getPhotoUrl(value)} alt={t('appproperties.text299')} />
                    <span className="icon edit cursor-pointer">
                      <IonIcon icon={closeOutline} onClick={() => deleteImageModal(index)} />
                    </span>
                  </div>
                  <div key={index} className='error error-catelogue'>{value.hasError && value.errorMsg}</div>
                </div>
              );
            })}
            <div className='fileUpload d-flex flex-column flex-column-reverse position-relative'>
              <input
                ref={buttonPhotoRef}
                type="file"
                accept="image/png, image/gif, image/jpg, image/jpeg"
                color="dark"
                onChange={uploadMoreImages}
                className="ion-text-capitalize ion-no-padding ion-padding-end upload"
                multiple
                id="image1"
              />
              <p><IonIcon className='font-22 d-flex d-lg-none me-2' icon={add} /> {t('appproperties.text68')}</p>
              <label
                htmlFor="image1"
                className="cursor-pointer iconAdd d-flex align-items-center justify-content-center"
                color="dark"
              >
                <IonIcon className='font-22 mt-n4 d-none d-lg-block' icon={add} />
              </label>
            </div>
          </div>
        </div>
      </IonModal>}
      {ConfirmModal && <IonModal
        isOpen={ConfirmModal}
        onDidDismiss={() => setConfirmModel(false)}
        cssClass="AddNewCatalogue Mesaage-popup"
        backdropDismiss={false}
      >
        <div
          className="pe-3 d-flex font-26 ion-no-padding justify-content-end  py-2 custom-modal-heading"
        >
          <IonIcon
            icon={closeOutline}
            onClick={() => setConfirmModel(false)}
            className="close ion-button-color text-dark position-relative"
            slot="start"
            size="undefined"
          />
        </div>
        <IonRow className=''>
          <IonCol sizeMd="12" sizeXs="12" className='text-center mt-3'>
            {t('appproperties.text258')}
          </IonCol>
          <IonCol sizeMd="12" sizeXs="12" className='text-right mt-1 me-2'>
            <IonButton onClick={deleteProduct} className='button-padding'>{t('appproperties.text241')}</IonButton>
            <IonButton onClick={() => setConfirmModel(false)} className='button-padding'>{t('appproperties.text242')}</IonButton>
          </IonCol>
        </IonRow>
      </IonModal>}
      {deleteRowModal && <IonModal
        isOpen={deleteRowModal}
        onDidDismiss={() => setDeleteRowModal(false)}
        cssClass="AddNewCatalogue Mesaage-popup"
        backdropDismiss={false}
      >
        <div
          className="d-flex font-26 ion-no-padding justify-content-end  py-2 custom-modal-heading"
        >
          <IonIcon
            onClick={() => setDeleteRowModal(false)}
            icon={closeOutline}
            className="ion-button-color text-dark close position-relative"
            slot="start"
            size="undefined"
          />
        </div>
        <IonRow className=''>
          <IonCol sizeMd="12" sizeXs="12" className='text-center mt-2'>
            {t('appproperties.text240')}
          </IonCol>
          <IonCol sizeMd="12" sizeXs="12" className='text-right mt-1 me-2'>
            <IonButton onClick={deleteRow} className='button-padding'>{t('appproperties.text241')}</IonButton>
            <IonButton onClick={() => setDeleteRowModal(false)} className='button-padding'>{t('appproperties.text242')}</IonButton>
          </IonCol>
        </IonRow>
      </IonModal>}
      {withOutImageModal && <IonModal
        isOpen={withOutImageModal}
        onDidDismiss={() => setWithOutImageModal(false)}
        cssClass="AddNewCatalogue Mesaage-popup"
        backdropDismiss={false}
      >
        <div
          onClick={() => setWithOutImageModal(false)}
          className="close cursor-pointer d-flex font-26 ion-no-padding justify-content-end pe-3 py-2 custom-modal-heading"
        >
          <IonIcon
            icon={closeOutline}
            className="ion-button-color text-dark close position-relative"
            slot="start"
            size="undefined"
          />
        </div>
        <IonRow className=''>
          <IonCol sizeMd="12" sizeXs="12" className='text-center mt-2'>
            {t('appproperties.text387')}
          </IonCol>
          <IonCol sizeMd="12" sizeXs="12" className='text-right mt-1 me-2'>
            <IonButton onClick={submitHandler} disabled={updateDisabled} className='button-padding'>
              {t('appproperties.text241')}
              {updateDisabled &&
                <span className="loader" id="loader-2">
                  <span></span>
                  <span></span>
                  <span></span>
                </span>
              }
            </IonButton>
            <IonButton onClick={() => setWithOutImageModal(false)} className='button-padding'>{t('appproperties.text242')}</IonButton>
          </IonCol>
        </IonRow>
      </IonModal>}
      {removeImage && <IonModal
        isOpen={removeImage}
        onDidDismiss={() => setRemoveImage(false)}
        cssClass="AddNewCatalogue Mesaage-popup"
        backdropDismiss={false}
      >
        <div
          onClick={() => setRemoveImage(false)}
          className="close cursor-pointer d-flex font-26 ion-no-padding justify-content-end pe-3 py-2 custom-modal-heading"
        >
          <IonIcon
            icon={closeOutline}
            className="ion-button-color text-dark position-relative"
            slot="start"
            size="undefined"
          />
        </div>
        <IonRow className=''>
          <IonCol sizeMd="12" sizeXs="12" className='text-center pt-3'>
            {t('appproperties.text374')}
          </IonCol>
          <IonCol sizeMd="12" sizeXs="12" className='text-right mt-2 pe-3'>
            <IonButton onClick={deleteImage} className='button-padding'>{t('appproperties.text241')}</IonButton>
            <IonButton onClick={() => setRemoveImage(false)} className='button-padding'>{t('appproperties.text242')}</IonButton>
          </IonCol>
        </IonRow>
      </IonModal>}
      {copyModal && <IonModal
        isOpen={copyModal}
        onDidDismiss={() => { setCopyModal(false); setCheckedEvents({}) }}
        cssClass="AddNewCatalogue modalbox-input report-modal"
        backdropDismiss={false}
        id='report-modal'
      >
        <div className='d-flex justify-content-between custom-modal-heading'>
          <h4 className='text-center'>{t('appproperties.text62')}</h4>
          {!isCopyLoading &&
            <div
              onClick={() => {
                setCopyModal(false); setCheckedEvents({});
              }}
              className="close cursor-pointer font-26 ion-no-padding pt-2 me-2"
            >
              <IonIcon
                icon={closeOutline}
                className="ion-button-color text-dark"
                slot="start"
                size="undefined"
              />
            </div>
          }
        </div>
        <IonItem>
          <input
            type="checkbox"
            id="copy_all_details"
            value="All Detail"
            name="allDetail"
            onChange={handleChange}
            disabled={isCopyLoading}
            checked={(Object.keys(checkedEvents)?.filter(event => checkedEvents[event]))?.length >= 7 ? true : false}
          />
          <IonLabel>{t('appproperties.text63')}</IonLabel>
        </IonItem>
        <IonItem>
          <input disabled={isCopyLoading} type="checkbox" id="copy_product_name" value={2} name="productName" onChange={handleChange} checked={checkedEvents?.productName} />
          <IonLabel>{t('productproperties.text2')}</IonLabel>
        </IonItem>
        <IonItem>
          <input disabled={isCopyLoading} type="checkbox" id="copy_price" value={3} name="price" onChange={handleChange} checked={checkedEvents?.price} />
          <IonLabel>{t('productproperties.text3')}</IonLabel>
        </IonItem>
        <IonItem>
          <input disabled={isCopyLoading} type="checkbox" id="copy_brand" value={5} name="brandName" onChange={handleChange} checked={checkedEvents?.brandName} />
          <IonLabel>{t('productproperties.text5')}</IonLabel>
        </IonItem>
        <IonItem>
          <input disabled={isCopyLoading} type="checkbox" id="copy_min_qty" value={4} name="minimumQuantity" onChange={handleChange} checked={checkedEvents?.minimumQuantity} />
          <IonLabel>{t('productproperties.text6')}</IonLabel>
        </IonItem>
        <IonItem>
          <input disabled={isCopyLoading} type="checkbox" id="copy_pytm_trm" value={6} name="paymentTerms" onChange={handleChange} checked={checkedEvents?.paymentTerms} />
          <IonLabel>{t('productproperties.text7')}</IonLabel>
        </IonItem>
        <IonItem>
          <input disabled={isCopyLoading} type="checkbox" id="copy_desc" value={7} name="description" onChange={handleChange} checked={checkedEvents?.description} />
          <IonLabel>{t('commonproperties.text39')}</IonLabel>
        </IonItem>
        {isCopyLoading && props.productList.length && <span className='position-absolute ps-3 catelog-image-error'>Please wait for few seconds</span>}
        <IonRow className='pb-2'>
          <IonButton
            className="header-row-margin-left ion-button-color mt-3"
            size="small"
            type="submit"
            onClick={copyRow}
            disabled={isCopyLoading}
          >
            {t('appproperties.text64')}
            {isCopyLoading &&
              <span className="loader" id="loader-2">
                <span></span>
                <span></span>
                <span></span>
              </span>
            }
          </IonButton>
        </IonRow>
      </IonModal>}
    </>
  )
}
export default BulkProduct;