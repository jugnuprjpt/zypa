/* eslint-disable multiline-ternary */
/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonCard,
  IonContent,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonList,
  IonRow
} from '@ionic/react';
import {
  chevronForward,
  arrowBack
} from 'ionicons/icons';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router';
import SkeletonComonInvitaion from './skeleton/SkeletonComonInvitaion';

const InterestedScrollCommon = (props: any) => {
  const { t } = useTranslation();
  const [classMobile, setclassMobile] = useState(false);

  const addMobileCss = () => {
    setclassMobile(true);
    document
      .getElementsByTagName('html')[0]
      .classList.add('mobileOverlayHandel');
  };
  const removeMobileCss = () => {
    setclassMobile(false);
    document
      .getElementsByTagName('html')[0]
      .classList.remove('mobileOverlayHandel');
  };
  const history = useHistory();
  const detaillink = (link, name, id) => {
    if (props.sublink === 1) {
      history.push(link + name + '/' + id);
    } else if (props.sublink === 2) {
      history.push(link + id + '/1');
    } else if (props.sublink === 4) {
      history.push(link + '/' + name + '/' + id);
    } else {
      history.push(link + id);
    }
  };
  return (
    <IonCard
      className={
        classMobile
          ? 'showpage sdb-box profile-details left-cards no-shadow MuiPaper-rounded ion-margin-top ion-margin-bottom '
          : 'sdb-box profile-details left-cards no-shadow  MuiPaper-rounded ion-margin-top ion-margin-bottom '
      }
    >
      <IonHeader className="card-header-text ion-padding-start ion-padding-end card-header-text dn-mobile">
        <IonRow className="ion-no-padding ion-align-items-center ion-justify-content-between w-100">
          <p>{props.header}</p>
        </IonRow>
      </IonHeader>
      <IonHeader
        className="card-header-text ion-padding-start ion-padding-end card-header-text show-mobile head-angle"
        onClick={addMobileCss}
      >
        <IonRow className="ion-no-padding mb-0  ion-align-items-center ion-justify-content-between w-100">
          <p>{props.header}</p>
          <IonIcon className="icon-mobile" icon={chevronForward}></IonIcon>
        </IonRow>
      </IonHeader>
      <IonRow
        className={
          classMobile
            ? 'showpage sdb-box profile-details left-cards no-shadow  MuiPaper-rounded ion-margin-top ion-margin-bottom'
            : 'sdb-box profile-details left-cards no-shadow  MuiPaper-rounded ion-margin-top ion-margin-bottom'
        }
        className="mobile-overlay-screen with-sb-box with-sox-head-btn"
      >
        <div className="mobile-back-screen show-mobile head-angle back-with-heading ">
          <IonIcon
            className="icon-mobile"
            icon={arrowBack}
            onClick={removeMobileCss}
          ></IonIcon>
          <h3>{props.header}</h3>
        </div>
        {props.requestloadingComon ? (
          <SkeletonComonInvitaion />
        ) : props.mapData.length > 0 ? (
          <IonList
            lines="none"
            className="full-width-row GroupInvitation-list "
          >
            {props.mapData.length > 4 ? (
              <IonContent className="custom-scroll custom-content-scroll">
                {props.mapData.map((detail) => (
                  <IonRow className="ion-padding-start ion-padding-end ion-align-items-center  ion-bottom-padding-smallcom GroupInvitation-list-item" onClick={() => detaillink(props.fieldLink, detail.name, detail.id)}>
                    <IonRow className="GroupInvitation-left-col">
                      <div className="myprofile-feeds ion-no-padding cursor-pointer">
                        <IonAvatar className="MuiAvatar ion-margin-end">
                          {detail.img !== undefined &&
                          detail.img !== null
                            ? (
                            <img onError={(ev) => { ev.target.src = props.image; }} src={detail.img} />
                              )
                            : (
                            <img src={props.image} />
                              )}
                        </IonAvatar>
                        <IonRow className="display-grid">
                              <span>{detail.name}</span>
                              <span className="margin MuiTypography-caption group-model-text">
                                {detail.designation}
                              </span>
                        </IonRow>
                      </div>
                    </IonRow>
                  </IonRow>
                ))}
                <IonInfiniteScroll
                  onIonInfinite={props.loadDataComon}
                  disabled={props.isInfiniteDisabledComon}
                >
                  <IonInfiniteScrollContent
                    loadingSpinner="circular"
                    loadingText={t('appproperties.text215')}
                  ></IonInfiniteScrollContent>
                </IonInfiniteScroll>
              </IonContent>
            ) : (
              props.mapData.map((detail) => (
                <IonRow className="ion-padding-start ion-padding-end ion-align-items-center  ion-bottom-padding-smallcom GroupInvitation-list-item" onClick={() => detaillink(props.fieldLink, detail.name, detail.id)}>
                  <IonRow className="GroupInvitation-left-col">
                    <div className="myprofile-feeds ion-no-padding cursor-pointer">
                      <IonAvatar className="MuiAvatar ion-margin-end">
                        {detail.img !== undefined &&
                        detail.img !== null
                          ? (
                          <img onError={(ev) => { ev.target.src = props.image; }} src={detail.img} />
                            )
                          : (
                          <img src={props.image} />
                            )}
                      </IonAvatar>
                      <IonRow className="display-grid">
                            <span>{detail.name}</span>
                            <span className="margin MuiTypography-caption group-model-text">
                              {detail.designation}
                            </span>
                      </IonRow>
                    </div>
                  </IonRow>
                </IonRow>
              ))
            )}
          </IonList>
        ) : (
          <>
              <p className="ion-padding">
              {props.noDataFound}
              </p>
          </>
        )}
      </IonRow>
    </IonCard>
  );
};
export default InterestedScrollCommon;
