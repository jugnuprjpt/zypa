import {
  IonAvatar,
  IonCardTitle,
  IonCol,
  IonHeader,
  IonList,
  IonRow,
  IonSkeletonText
} from '@ionic/react';
import React from 'react';
const SkeletonComonOverView = () => {
  return (
      <><IonHeader className="card-header">
        <div className='myprofile-feeds light-gradient-to-bottom cursor-pointer'>
          <IonAvatar slot="start" className="MuiCardHeader-avatar cursor-pointer ">
            <IonSkeletonText animated />
          </IonAvatar>
          <IonRow className='profileName'>
            <IonCardTitle>
              <p className='margin MuiTypography-body1'><IonSkeletonText animated className='skeleton-width-btn' /> </p>
              <span className='margin MuiTypography-caption'><IonSkeletonText animated className="skeleton-width-half" /></span>
            </IonCardTitle>
          </IonRow>
        </div>
      </IonHeader><IonRow>
          <IonList lines="none" className='full-width-row profile-details-content'>
            <IonRow className='ion-padding-start ion-padding-end'>
              <IonCol size='10'>
                <IonSkeletonText animated />
              </IonCol>
              <IonCol size='2' className='ion-text-end'>
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonCol>
            </IonRow>
          </IonList>
          <IonList lines="none" className='full-width-row profile-details-content'>
            <IonRow className='ion-padding-start ion-padding-end'>
              <IonCol size='10'>
                <IonSkeletonText animated />
              </IonCol>
              <IonCol size='2' className='ion-text-end'>
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonCol>
            </IonRow>
          </IonList>
          <IonList lines="none" className='full-width-row profile-details-content'>
            <IonRow className='ion-padding-start ion-padding-end'>
              <IonCol size='10'>
                <IonSkeletonText animated />
              </IonCol>
              <IonCol size='2' className='ion-text-end'>
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonCol>
            </IonRow>
          </IonList>
          <IonList lines="none" className='full-width-row profile-details-content'>
            <IonRow className='ion-padding-start ion-padding-end'>
              <IonCol size='10'>
                <IonSkeletonText animated />
              </IonCol>
              <IonCol size='2' className='ion-text-end'>
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonCol>
            </IonRow>
          </IonList>
        </IonRow></>
  );
};
export default SkeletonComonOverView;
