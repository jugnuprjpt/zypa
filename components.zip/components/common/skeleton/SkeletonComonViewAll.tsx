/* eslint-disable react/jsx-key */
import { IonCol, IonCard, IonAvatar, IonSkeletonText, IonCardContent, IonCardSubtitle, IonCardTitle } from '@ionic/react';
import React from 'react';

const SkeletonComonViewAll = (props: any) => {
  return (
    <>
    <div className="connectionListCommon member-listing skeleton">
      {Array.apply(null, {length: props.column}).map((e, i) => (
        <IonCol sizeMd={props.sizeMd} sizeXs={props.sizeXs} key={i}>
            <IonCard className='m-0 ion-padding'>
                <IonCardContent className='text-center'>
                    <IonAvatar
                      slot="start"
                      className="MuiCardHeader-avatar cursor-pointer mx-lg-auto"
                      >
                      <IonSkeletonText animated />
                    </IonAvatar>
                    <IonCardSubtitle>
                    {props.name === true
                      ? <div>
                          <IonSkeletonText animated className='mt-3 mx-auto h-14' />
                        </div>
                      : ''
                      }
                      {props.title === true
                        ? 
                        <IonSkeletonText animated className='my-2 mx-auto' />
                        : ''
                      }
                      {props.designation === true
                        ? 
                        <IonSkeletonText animated className='my-2 mx-auto h-14' />
                        : ''
                      }
                      {props.mutual === true
                        ? 
                        <IonSkeletonText animated className='my-2 mx-auto w-75 h-14' />
                        : ''
                      }
                      {props.distription === true
                        ? 
                        <IonSkeletonText animated className='my-2 mx-auto w-75' />
                        : ''
                      }
                      {props.request === true
                        ? <IonSkeletonText animated className='mt-4 mx-auto w-50' style={{'height':'30px'}} />
                        : ''
                      }
                      {props.link === true
                        ? <IonSkeletonText animated className='mt-4 mx-auto w-50' style={{'height':'30px'}} />
                        : ''
                      }
                    </IonCardSubtitle>
                </IonCardContent>
            </IonCard>
        </IonCol>
      ))}
    </div>
    </>
  );
};
export default SkeletonComonViewAll;
