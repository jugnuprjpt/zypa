/* eslint-disable react/jsx-key */
import {
  IonRow,
  IonList,
  IonAvatar,
  IonSkeletonText
} from '@ionic/react';
import React from 'react';

const SkeletonActivityComon = (props: any) => {
  return (
    <>
      <div className="skeleton">
        <div className="company-list-details">
          {/* llop column */}
          {Array.apply(null, { length: 4 }).map((e, i) => (
            <IonList lines="none" className="full-width-row" key={i}>
              <IonRow>
                <IonRow className="cursor-pointer item">
                  <div className="myprofile-feeds ion-no-padding cursor-pointer">
                    <IonAvatar className="MuiAvatar ion-margin-end">
                      <IonSkeletonText animated />
                    </IonAvatar>

                    <IonRow className="display-grid">
                    <IonSkeletonText animated className='skeleton-width' />
                      <span className="margin MuiTypography-caption group-model-text">
                      <IonSkeletonText animated className="skeleton-width-half" />
                      </span>
                    </IonRow>
                  </div>
                </IonRow>
              </IonRow>
            </IonList>
          ))}
        </div>
      </div>
    </>
  );
};
export default SkeletonActivityComon;
