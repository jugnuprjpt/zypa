/* eslint-disable react/jsx-key */
import {
  IonRow,
  IonSkeletonText,
  IonCardTitle,
  IonCol
} from '@ionic/react';
import React from 'react';

const SkeletonAward = (props: any) => {
  return (
    <>
      <div className="skeleton">
        <IonRow>
          {/* llop column */}
          {Array.apply(null, { length: props.column }).map((e, i) => (
            <IonCol key={i}>
              <div>
                <IonSkeletonText
                  className="groupsize-group"
                  animated
                />
                <IonCardTitle>
                  <p className="title">
                    <IonSkeletonText animated className="skeleton-width-half" />
                  </p>
                  <p className="description">
                    <IonSkeletonText animated className="skeleton-width-btn" />
                  </p>
                  {props.description === true
                    ? <><p className="description">
                      <IonSkeletonText animated className="skeleton-width-btn" />
                    </p><p className="description">
                        <IonSkeletonText animated className="skeleton-width-btn" />
                      </p><p className="description">
                        <IonSkeletonText animated className="skeleton-width-btn" />
                      </p></>
                    : ''}
                </IonCardTitle>
              </div>
            </IonCol>
          ))}
        </IonRow>
      </div>
    </>
  );
};
export default SkeletonAward;
