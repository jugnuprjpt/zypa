/* eslint-disable react/jsx-key */
import { IonAvatar, IonButton, IonCard, IonCol, IonHeader, IonIcon, IonList, IonRow } from '@ionic/react';
import { chevronForward, arrowBack, closeCircleOutline, checkmarkCircleOutline } from 'ionicons/icons';
import { type } from 'os';
import React from 'react';

const SkeletonComonInvitation = (props: any) => {
  return (
   <div></div>
  );
};

export default SkeletonComonInvitation;
