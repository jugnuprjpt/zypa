/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonCard,
  IonCol,
  IonHeader,
  IonRow,
  IonSkeletonText
} from '@ionic/react';
import React from 'react';

const SkeletonFeedComon = (props: any) => {
  return (
      <>
      {Array.apply(null, { length: props.column }).map((e, i) => (
          <IonCard className="MuiPaper-rounded ion-no-margin ion-margin-bottom ion-margin-top feed-cards-posts" key={i}>
          <IonHeader className="card-header">
          <div className="myprofile-feeds ion-padding-start ion-padding-top post-card full-width-row">
               <div className='myprofile-feeds ion-no-padding'>
              <IonAvatar
                slot="start"
                className="MuiCardHeader-avatar cursor-pointer"
              >
                <IonSkeletonText animated />
              </IonAvatar>
              <IonRow className="display-grid cursor-pointer">
                <div className="margin MuiTypography-caption">
                  <IonSkeletonText animated className="skeleton-width-btn" />
                </div>
                <div className="margin MuiTypography-caption">
                  <IonSkeletonText animated className="skeleton-width-btn" />
                </div>
              </IonRow>
              </div>
              <IonRow className="ion-float-right header-row-margin-left">
              <div className="margin MuiTypography-caption">
                  <IonSkeletonText animated className="skeleton-width-btn" />
                </div>
                </IonRow>
            </div>
            </IonHeader>
            <IonRow className='feed-body ion-padding-horizontal w-100'>
                  <IonSkeletonText animated />
                  <IonSkeletonText animated />
                   <IonSkeletonText animated className="skeleton-width-half" />
            </IonRow>

            <IonRow className="card-header-text post-comment-view">
        <IonRow className="full-width-row ion-padding-bottom ion-padding-end">
          <IonCol size-md="4" size-xs="4" className="myprofile-feeds pa-0">
               <IonRow className="full-width-row com-first-row">
                 <IonCol size-md="4" size-xs="4" className="myprofile-feeds pa-0">
                  <IonSkeletonText animated className="skeleton-width-btn" />
                </IonCol>
                <IonCol size-md="4" size-xs="4" className="myprofile-feeds pa-0">
                  <IonSkeletonText animated className="skeleton-width-btn" />
                  </IonCol>
                  <IonCol size-md="4" size-xs="4" className="myprofile-feeds pa-0">
                  <IonSkeletonText animated className="skeleton-width-btn" />
                  </IonCol>
                </IonRow>
          </IonCol>
          <IonCol size-md="8" size-xs="9" className="ion-text-end pa-0 pr-0">
              <IonSkeletonText animated className="skeleton-width-btn ml-auto" />
          </IonCol>
        </IonRow>
        </IonRow>
      </IonCard>
      ))}
      </>
  );
};
export default SkeletonFeedComon;
