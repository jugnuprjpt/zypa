import { IonCard, IonAvatar, IonSkeletonText, IonCardTitle, IonLabel, IonHeader, IonIcon, IonRow } from '@ionic/react';
import React from 'react';
const SkeletonComonProfile = () => {
  return (
<IonCard className="MuiPaper-rounded ion-no-margin ion-margin-top ion-margin-bottom profile-user-details">
        <IonHeader className="profile-header ion-no-border">
          <div className="myprofile-feeds ion-padding-top light-gradient-bottom ion-padding-start ion-padding-bottom profile-center">
          <IonAvatar
                slot="start"
                className="MuiCardHeader-avatar cursor-pointer ion-no-border profileAvtar ion-no-margin"
                >
                <IonSkeletonText animated />
              </IonAvatar>
            <IonRow className="profileName">
              <IonCardTitle>
                <p className="margin pcolor person-name-pd">
                <IonSkeletonText animated />
                </p>
                <span className="margin MuiTypography-caption pcolor">
                <IonSkeletonText animated className="skeleton-width-half" />
                </span>
                    <span className="margin MuiTypography-caption pcolor">
                    <IonSkeletonText animated className="skeleton-width-half" />
                    </span>
              </IonCardTitle>
            </IonRow>
              <div className="edit-icon">
                <IonSkeletonText animated className="skeleton-width-btn" />
              </div>
          </div>
        </IonHeader>
        <IonRow> </IonRow>
        <div className="profile-user-details-bottom">
          <IonHeader className="ion-no-border">
            <IonRow className="tow-colum-content">
              <IonRow className="left">
                  <>
                    <IonLabel
                      className="ion-text-capitalize cursor-pointer"
                    >
                     <IonSkeletonText animated className="skeleton-width-btn" />
                    </IonLabel>
                    <IonLabel
                      className="ion-text-capitalize cursor-pointer"
                    >
                      <IonSkeletonText animated className="skeleton-width-btn" />
                    </IonLabel>
                    <IonLabel
                      className="ion-text-capitalize cursor-pointer"
                    >
                      <IonSkeletonText animated className="skeleton-width-btn" />
                    </IonLabel>
                  </>
              </IonRow>
              <IonRow className="right pr-details-action">
                <div className="dot-btn">
                  <IonSkeletonText animated className="skeleton-width-btn" />
                </div>
              </IonRow>
            </IonRow>
          </IonHeader>
          <div className="ion-no-border">
            <div>
              <IonRow className="user-pr-contact-content">
                          <IonLabel className="MuiTypography-body1 ion-text-cemter textcolour ion-padding-end">
                            <IonIcon className="test icon-svg" />
                            <IonSkeletonText animated className="skeleton-width-half" />
                          </IonLabel>
                      <IonLabel className="MuiTypography-body1 ion-text-cemter textcolour ion-padding-end">
                        <IonIcon className="test icon-svg " />
                        <IonSkeletonText animated className="skeleton-width-half" />
                      </IonLabel>
              </IonRow>
            </div>
          </div>
        </div>
      </IonCard>
  );
};
export default SkeletonComonProfile;
