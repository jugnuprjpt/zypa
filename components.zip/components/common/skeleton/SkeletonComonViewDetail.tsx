import { IonCard, IonAvatar, IonSkeletonText, IonCardTitle, IonLabel, IonButton } from '@ionic/react';
import React from 'react';
const SkeletonComonViewDetais = () => {
  return (
<IonCard className="MuiPaper-rounded ion-no-margin ion-margin-top profile-card-content mtm-0">
        <div className="groupsize-group">
        </div>
        <div className="profile-card-body">
          <div className="profile-avt-content">
            <div>
              <IonAvatar
                slot="start"
                className="MuiCardHeader-avatar cursor-pointer ion-no-border profileAvtar ion-no-margin"
                >
                <IonSkeletonText animated />
              </IonAvatar>
            </div>
          </div>
          <div className="profileName">
            <IonCardTitle>
              <h4 className="margin ">
              <IonSkeletonText animated />
              </h4>
              <span><IonSkeletonText animated className="skeleton-width-half" /></span>
            </IonCardTitle>
            <div className="profile-card-follow">
              <IonLabel className="follower-text">
                <span><IonSkeletonText animated className="skeleton-width-btn" /></span>{' '}
              </IonLabel>
                    <IonLabel
                      className="ion-button-color pr-0"
                    >
                    <IonSkeletonText animated className="skeleton-width-btn" />

                    </IonLabel>
            </div>
          </div>
        </div>
      </IonCard>
  );
};
export default SkeletonComonViewDetais;
