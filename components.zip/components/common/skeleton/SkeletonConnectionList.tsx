/* eslint-disable react/jsx-key */
import { IonRow, IonSkeletonText } from '@ionic/react';
import React from 'react';

const SkeletonConnectionList = (props : any) => {
  return (
    <>
    {Array.apply(null, { length: props.column }).map((e, i) => (
      <IonRow key={i}>
        <IonRow className="item">
          <div className="myprofile-feeds ion-no-padding">
            <IonRow className="display-grid">  <IonSkeletonText animated className='skeleton-width' /></IonRow>
          </div>
        </IonRow>
      </IonRow>
    ))}

    </>
  );
};
export default SkeletonConnectionList;
