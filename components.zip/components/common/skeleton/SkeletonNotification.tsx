/* eslint-disable react/jsx-key */
import {
  IonRow,
  IonSkeletonText,
  IonAvatar,
  IonCard
} from '@ionic/react';
import React from 'react';

const SkeletonNotification = () => {
  return (
    <>
      <IonRow className="ion-margin-top full-width-row">

          {Array.apply(null, { length: 10 }).map((e, i) => (
            <>
              <IonCard className="MuiPaper-rounded full-width-row ion-no-margin border-radius notification-list">
              <IonRow className='full-width-row notify-content'>
                <div className="myprofile-feeds ion-no-padding full-width-row">
                    <IonAvatar className="MuiAvatar ion-margin-end">
                    <IonSkeletonText animated />
                    </IonAvatar>
                  <IonRow className="display-grid full-width-row cursor-pointer">
                    <b><IonSkeletonText animated className="skeleton-width-half" /> </b>
                    <span className="margin MuiTypography-caption group-model-text full-width-row notify-inner-content ion-align-items-baseline">
                     <span className='description'>                  <IonSkeletonText animated className='skeleton-width'/>

                      </span>
                      <span className="margin ion-padding-start MuiTypography-caption group-model-text ion-float-right">
                      <IonSkeletonText animated className="skeleton-width-btn ion-float-end" />

                      </span>
                    </span>
                  </IonRow>
                </div>
              </IonRow>
          </IonCard>
            </>
          ))}
        </IonRow>
    </>
  );
};
export default SkeletonNotification;
