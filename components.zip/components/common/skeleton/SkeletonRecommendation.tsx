/* eslint-disable react/jsx-key */
import { IonRow, IonSkeletonText, IonCol, IonAvatar, IonButton } from '@ionic/react';
import React from 'react';

const SkeletonRecommendation = (props: any) => {
  return (
    <>
      <div className="skeleton">
        <IonRow>
          {Array.apply(null, { length: props.column }).map((e, i) => (
            <><IonRow className='border-bottom full-width-row sdb-box profile-details recommend-list-item recom-page-item-content'>
              <IonCol size="12" className='d-flex'>
                <IonAvatar className="MuiAvatar ion-margin-end ">
                  <IonSkeletonText animated />
                </IonAvatar>
                <IonRow className="display-grid">
                  <b><IonSkeletonText animated className='skeleton-width' /></b>
                  <span className="margin MuiTypography-caption group-model-text">
                    <IonSkeletonText animated className="skeleton-width-btn" />
                  </span>
                  <p>
                    <IonSkeletonText animated className="skeleton-width-btn" />
                  </p>
                </IonRow>
              </IonCol>
              {props.button
                ? <IonRow className="header-row-margin-left col-rm-right">
                <IonButton
                  className="btn-sm-cn link-btn-tx dn-mobile"
                  fill="clear"
                  size="small"

                >
                  <IonSkeletonText animated className="skeleton-width-btn" />
                </IonButton>
                <IonButton
                  className="btn-sm-cn link-btn-tx dn-mobile"
                  fill="clear"
                  size="small"

                >
                  <IonSkeletonText animated className="skeleton-width-btn" />
                </IonButton>
              </IonRow>
                : ''}
            </IonRow></>
          ))}
        </IonRow>
      </div>
    </>
  );
};
export default SkeletonRecommendation;
