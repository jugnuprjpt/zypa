/* eslint-disable react/jsx-key */
import { IonAvatar, IonButton, IonCol, IonList, IonRow, IonSkeletonText } from '@ionic/react';
import React from 'react';

const SkeletonComonInvitaion = () => {
  return (
    <>
      <IonList
        lines="none"
        className="full-width-row GroupInvitation-list"
      >
        {Array.apply(null, { length: '3' }).map((e, i) => (
          <IonRow key={i} className="ion-padding-start ion-padding-end ion-align-items-center ion-bottom-padding-smallcom GroupInvitation-list-item ion-justify-content-between">
            <IonCol className='GroupInvitation-left-col'>
              <div className="myprofile-feeds ion-no-padding cursor-pointer">
                <IonAvatar className="MuiAvatar ion-margin-end">
                  <IonSkeletonText animated />
                </IonAvatar>
                <IonRow className='display-grid'>
                  <span className="margin MuiTypography-caption group-model-text">
                    <IonSkeletonText animated className='skeleton-width-half mb-2' />
                    <IonSkeletonText animated className='skeleton-width' />
                  </span>
                </IonRow>
              </div>
            </IonCol>

            <IonCol className="d-flex justify-content-end">
              <IonButton
                fill="clear"
                className="ion-no-padding close-ic-btn"
                size="small"
              >
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonButton>
              <IonButton
                fill="clear"
                className="ion-no-padding close-ic-btn"
                size="small"
              >
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonButton>
            </IonCol>
          </IonRow>
        ))}
      </IonList>
    </>
  );
};

export default SkeletonComonInvitaion;
