/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonLabel,
  IonRow,
  IonList,
  IonSkeletonText,
  IonCol
} from '@ionic/react';
import React from 'react';
const SkeletonConnectionRequest = () => {
  return (
    <>
      {Array.apply(null, { length: 3 }).map((e, i) => (
        <IonList lines="none" className="full-width-row GroupInvitation-list">
          <IonRow className="ion-padding-start ion-bottom-padding-smallcom GroupInvitation-list-item d-flex ion-align-items-center ion-justify-content-between">
            <IonCol className='w-60'>
              <div className="myprofile-feeds ion-no-padding cursor-pointer">
                <IonAvatar className="MuiAvatar ion-margin-end">
                  <IonSkeletonText animated />
                </IonAvatar>
                <IonRow className="margin MuiTypography-caption group-model-text">
                <IonSkeletonText animated className='skeleton-width' />
                  <span className="margin MuiTypography-caption group-model-text">
                    <IonSkeletonText animated className="skeleton-width-half" />
                  </span>
                </IonRow>
              </div>
            </IonCol>
            <IonCol className="header-row-margin-left ion-align-items-center justify-content-end w-25 d-flex">
              <IonLabel className="dn-mobile hashTagAtivityCard cursor-pointer ion-padding-end btn-sm-cn">
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonLabel>
              <IonLabel className="show-mobile icon-close">
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonLabel>
              <IonLabel className="btn-sm-cn ion-padding-end dn-mobile">
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonLabel>
              <IonLabel className="show-mobile icon-close">
                <IonSkeletonText animated className="skeleton-width-btn" />
              </IonLabel>
            </IonCol>
          </IonRow>
        </IonList>
      ))}
    </>
  );
};
export default SkeletonConnectionRequest;
