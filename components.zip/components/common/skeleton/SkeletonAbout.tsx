/* eslint-disable react/jsx-key */
import {
  IonRow,
  IonSkeletonText
} from '@ionic/react';
import React from 'react';

const SkeletonAbout = () => {
  return (
        <>
            <IonRow className='mt-3'>
                <IonSkeletonText animated className="skeleton-width-half mb-2" />
                <IonSkeletonText animated className="w-100" />
            </IonRow>
            <IonRow>
                <IonSkeletonText animated className="skeleton-width-half mb-2" />
                <IonSkeletonText animated className="w-100" />
            </IonRow>
            <IonRow>
                <IonSkeletonText animated className="skeleton-width-half" />
                <IonSkeletonText animated className="skeleton-width-half" />
            </IonRow>
        </>
  );
};
export default SkeletonAbout;
