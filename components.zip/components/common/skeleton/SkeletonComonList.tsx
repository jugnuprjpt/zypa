/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonCard,
  IonCol,
  IonRow,
  IonSkeletonText
} from '@ionic/react';
import React from 'react';

const SkeletonComonList = (props: any) => {
  return (
    <>
      <div className="skeleton">
        <IonRow>
          {Array.apply(null, { length: props.column }).map((e, i) => (
            <IonCol sizeMd={props.sizeMd} sizeXs={props.sizeXs} key={i}>
              <IonRow className="mx-m5">
                <IonCard className="ion-no-margin no-shadow ">
                  <div className="myprofile-feeds ion-padding">
                    <IonAvatar
                      slot="start"
                      className="MuiCardHeader-avatar cursor-pointer ms-0 me-0 me-lg-3 mb-3 mb-lg-0"
                    >
                      <IonSkeletonText animated />
                    </IonAvatar>
                    <IonRow className="cursor-pointer d-lg-block d-flex">
                      {props.name === true
                        ? <div className='w-75 mx-auto ms-lg-0'>
                          <IonSkeletonText animated />
                        </div>
                        : ''}
                      {props.title === true
                        ? <div className="margin MuiTypography-caption mx-auto ms-lg-0">
                          <IonSkeletonText animated className="skeleton-width-half" />
                        </div>
                        : ''}
                      {props.distription === true
                        ? <div className="margin MuiTypography-caption mx-auto ms-lg-0">
                          <IonSkeletonText animated className="skeleton-width-btn" />
                        </div>
                        : ''}
                      {props.link === true
                        ? <div className="margin MuiTypography-caption mx-auto ms-lg-0">
                          <IonSkeletonText animated className="skeleton-width-btn" />
                        </div>
                        : ''}
                    </IonRow>
                  </div>
                </IonCard>
              </IonRow>
            </IonCol>
          ))}
        </IonRow>
      </div>
    </>
  );
};
export default SkeletonComonList;
