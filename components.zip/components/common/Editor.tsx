/* eslint-disable no-unused-vars */
import React, { useCallback, useRef, useState } from 'react';
import ReactQuill from 'react-quill';

import CallFor from '../../util/CallFor';
import { IonRow, IonAvatar, IonButton, IonIcon } from '@ionic/react';
import userProfile from '../../assets/img/user-profile-placeholder.png';

import 'quill-mention';
import 'quill/dist/quill.snow.css';
import 'quill-mention/dist/quill.mention.min.css';
import { paperPlaneOutline, send } from 'ionicons/icons';
import { useDispatch, useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import { getFeedData } from '../../Redux/reducers/feeds';
import ToastCommon from './ToastCommon';
import { useTranslation } from 'react-i18next';

const Editor = (props: any) => {
  const { t } = useTranslation();
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const profileDetail = useSelector(getProfileDetails);
  const dispatch = useDispatch();
  const getFeedDatas = useSelector(getFeedData);
  const [comments, setComments] = useState('');
  const [commentBtn, setCommentBtn] = useState(false);
  const commentTag = useRef(null);
  const modules = {
    toolbar: false,
    mention: {
      showDenotationChar: false,
      allowedChars: /^[A-Za-z\sÅÄÖåäö]*$/,
      mentionDenotationChars: ['@', '#'],
      isolateCharacter: true,
      source: useCallback(async (searchTerm: any, renderList: (arg0: any) => void, mentionChar: string) => {
        if (mentionChar === '@') {
          if (searchTerm !== '') {
            const matchedPeople = await suggestPeople(searchTerm);
            renderList(matchedPeople, mentionChar);
          }
        } else {
          if (searchTerm !== '') {
            const matchedPeople = await suggestHashTage(searchTerm);
            renderList(matchedPeople, mentionChar);
          }
        }
      }, []),
      renderItem: useCallback((item: { profileImg: null; value: any; }, mentionChar: string) => {
        if (mentionChar === '@') {
          return `<div class="userList">
            <IonRow class="userListItem">
            <IonAvatar class="MuiAvatar ion-margin-end">
            <img src=${item.profileImg !== null ? item.profileImg : userProfile} class="MuiAvatar-circular"/> </IonAvatar>
        <span>${item.value}</span></IonRow> </div>`;
        }
        return item.value;
      }, []),
      onSelect: useCallback((item: any, insertItem: any) => {
        insertItem(item);
        const mentionData = document.querySelectorAll('.mention > span');
        mentionData.forEach(element => {
          element.contentEditable = 'true';
        });
      }, [])
    }
  };
  const suggestHashTage = async (searchTerm: string) => {
    const response = await CallFor(
      'api/v1/searches/hashtag/' + searchTerm,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const jsonResponse = await response.json();
      const options = await jsonResponse.data.map(
        (d: any) => ({
          id: d.tag,
          value: d.tag
        })
      );
      return options;
    } else if (response.status === 401) {
      localStorage.clear();
    }
  };
  const suggestPeople = async (searchTerm: string) => {
    const response = await CallFor(
      'api/v1.1/connections/users/' + searchTerm,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const jsonResponse = await response.json();
      const options = await jsonResponse.data.map(
        (d: any) => ({
          id: d.id,
          value: d.fullName,
          profileImg: d.profileImg
        })
      );
      return options;
    } else if (response.status === 401) {
      localStorage.clear();
      // history.push('/login');
    }
    // return allPeople.filter(person => person.value.includes(searchTerm));
  };
  const onHandleSubmit = async () => {
    setCommentBtn(true);
    const d = commentTag.current.editor.getContents();
    const tagValues = [];
    let postData = '';
    const attributes: { mention: string; start: number; length: any; id: any; }[] = [];
    // eslint-disable-next-line array-callback-return
    d.ops.map((object: { insert: { mention: { value: string | any[]; id: any; }; trim: () => string; } | undefined; }) => {
      if (typeof object.insert === 'object') {
        tagValues.push(object.insert.mention.value);
        postData += object.insert.mention.value;
        const data1 = {
          mention: 'PROFILE',
          start: postData.lastIndexOf(object.insert.mention.value),
          length: object.insert.mention.value.length,
          id: object.insert.mention.id
        };
        attributes.push(data1);
      } else {
        if (object.insert !== undefined) {
          if (d.ops.length === 1) {
            postData += object.insert.trim();
          } else {
            postData += object.insert;
          }
        }
      }
    });
    const postComment = { text: postData, attributes: attributes };
    if (postData.length > 0) {
      let commentId = null;
      if (props.commentId !== undefined) {
        commentId = '"' + props.commentId + '"';
      }
      const data = '{"content": ' +
        JSON.stringify(postComment) +
        ', "replyOf":' + commentId + ', "postUserId":' + props.postUserId + '}';
      const response1 = await CallFor('api/v1/post/' + props.postId + '/comments', 'POST', data, 'Auth');
      if (response1.status === 201) {
        setComments(' ');
        const jsonResponse = await response1.json();
        if (props.type === 'Comment') {
          dispatch({
            type: 'insert_comments_feedsData',
            comments: {
              id: jsonResponse.data.id,
              postId: props.postId,
              userId: profileDetail.id,
              content: JSON.stringify(postComment),
              replyOf: null,
              reactionCount: 0,
              userDesignation: profileDetail.profileTitle,
              userName: profileDetail.name,
              userProfile: profileDetail.profileImg,
              ageOfComment: t('appproperties.text232'),
              reactionId: null,
              reaction: null
            },
            index: props.feedIndex
          });
          dispatch({
            type: 'add_comments_feedsData_count',
            commentCount: getFeedDatas[props.feedIndex].commentCount + 1,
            index: props.feedIndex
          });
        } else {
          dispatch({
            type: 'add_new_reply_feedsData',
            reply: {
              id: jsonResponse.data.id,
              postId: props.postId,
              userId: profileDetail.id,
              content: JSON.stringify(postComment),
              replyOf: null,
              reactionCount: 0,
              userDesignation: profileDetail.profileTitle,
              userName: profileDetail.name,
              userProfile: profileDetail.profileImg,
              ageOfComment: t('appproperties.text232'),
              reactionId: null,
              reaction: null
            },
            index: props.feedIndex,
            commentIndex: props.commentIdex
          });
          let replyCount = 0;
          if (getFeedDatas[props.feedIndex].comments[props.commentIdex].replyCount != null) {
            replyCount = getFeedDatas[props.feedIndex].comments[props.commentIdex].replyCount;
          }
          dispatch({
            type: 'add_reply_feedsData_count',
            replyCount: replyCount + 1,
            index: props.feedIndex,
            commentIndex: props.commentIdex
          });
          dispatch({
            type: 'add_comments_feedsData_count',
            commentCount: getFeedDatas[props.feedIndex].commentCount + 1,
            index: props.feedIndex
          });
        }
      } else if (response1.status === 500) {
        const jsonResponse = await response1.json();
        setShowToastMsg(jsonResponse.error);
        setShowToast(true);
      }
    }
    setCommentBtn(false);
  };
  const handleChange = (event: { target: { value: React.SetStateAction<string>; } | undefined; }) => {
    if (event.target !== undefined) {
      const mentionData = document.querySelectorAll('.mention > span');
      mentionData.forEach(element => {
        element.contentEditable = 'true';
      });
      setComments(event.target.value);
    }
  };
  return (
    <>
      <div className='quill-control custom-quill-bg'>
        <div>
          <ReactQuill
            ref={commentTag}
            modules={modules}
            value={comments}
            onChange={handleChange}
            placeholder={props.placeholder}
          />
        </div>
        <div className='ql-post-btn'>
          <IonButton
            fill="clear"
            color="dark"
            ion-padding-end="50"
            onClick={onHandleSubmit}
            className="ion-text-capitalize ion-no-padding"
            item-right
            disabled={commentBtn}
          >
            <span className='me-1'>
              <IonIcon icon={paperPlaneOutline} className="test font-24 post-btn-rotate" ariaLabel='post' />
            </span>
          </IonButton>
        </div></div>
      <ToastCommon setShowToast={setShowToast} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
    </>
  );
};
export default Editor;
