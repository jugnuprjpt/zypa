import { IonInput } from '@ionic/react';
import React from 'react';

const InputBoxComon = (props: any) => {
  const { refCallback, ...remainingProps } = props;
  return (
    <IonInput
      className={props.errors ? ' input-box error-border' : 'input-box '}
      {...remainingProps}
      ref={refCallback}
    />
  );
};
export default InputBoxComon;
