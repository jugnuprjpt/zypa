import { IonButton } from '@ionic/react';
import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import NotAuthorizeModal from './NotAuthorizeModal';
const ButtonComponent = (props) => {
  const profileDetail = useSelector(getProfileDetails);
  const [loginModal, setLoginModal] = useState(false);
  const onClickBtn = async (e) => {
    e.stopPropagation();
    if (await profileDetail.entityId !== undefined) {
      if (await profileDetail.entityId !== null) {
        if (props.parametersPass === 0) {
          props.btnClick();
        } else if (props.parametersPass === 1) {
          props.btnClick(props.field1);
        } else if (props.parametersPass === 2) {
          props.btnClick(props.field1, props.field2);
        } else if (props.parametersPass === 3) {
          props.btnClick(props.field1, props.field2, props.field3);
        } else if (props.parametersPass === 4) {
          props.btnClick(props.field1, props.field2, props.field3, props.field4);
        } else if (props.parametersPass === 5) {
          props.btnClick(props.field1, props.field2, props.field3, props.field4, props.field5);
        }
      } else {
        setLoginModal(true);
        // history.push('/addnewcompany');
      }
    }
  };
  return (
    <>
      <IonButton
        className={props.className}
        onClick={onClickBtn}
        size={props.size !== undefined ? props.size : 'medium'}
      >
        {props.name}
      </IonButton>
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}

    </>
  );
};
export default ButtonComponent;
