/* eslint-disable multiline-ternary */
/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonChip,
  IonCol,
  IonContent,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  useIonPopover
} from '@ionic/react';
import React, { useState } from 'react';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import Emojis from '../feed/Emojis';
import { close, ellipsisVertical, trashBinOutline, warningOutline } from 'ionicons/icons';
import CallFor from '../../util/CallFor';
import { useDispatch, useSelector } from 'react-redux';
import ReplyBox from './ReplyBox';
import Editor from './Editor';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import Like from '../../assets/img/emojis/like.svg';
import Celebrate from '../../assets/img/emojis/celebration.svg';
import ShakeHand from '../../assets/img/emojis/shakehands.svg';
import Interest from '../../assets/img/emojis/interest.svg';
import Supports from '../../assets/img/emojis/support.svg';
import ReportSpamCommon from './ReportSpamCommon';
import EditedCommentBox from './EditedCommentBox';
import edit from '../../assets/img/edit.svg';
import { getFeedData } from '../../Redux/reducers/feeds';
import ConfirmModelCommon from './ConfirmModelCommon';
import MobileReplyFeed from '../feed/MobileReplyFeed';
import { useHistory } from 'react-router';
import { useTranslation } from 'react-i18next';
import NotAuthorizeModal from './NotAuthorizeModal';

const CommentBox = (props: any) => {
  const { t } = useTranslation();
  const [loginModal, setLoginModal] = useState(false);
  const label = [
    {
      id: 1,
      name: t('appproperties.text366')
    },
    {
      id: 2,
      name: t('appproperties.text367')
    },
    {
      id: 3,
      name: t('dropdownfields.text13')
    }];
  const profileDetail = useSelector(getProfileDetails);
  const history = useHistory();
  const [reactionBtnData, setReactionBtnData] = useState({
    postId: '923136026965442560',
    count: 0,
    likeCount: 0,
    celebrateCount: 0,
    interestCount: 0,
    shakeHandCount: 0,
    supportCount: 0
  });
  const [showReactionModal, setShowReactionModal] = useState(false);
  const [showRepliesModal, setShowRepliesModal] = useState(false);
  const [allBtnClass, setAllBtnClass] = useState('ion-button-color');
  const [likeBtnClass, setLikeBtnClass] = useState('category-btn-color');
  const [celebrateBtnClass, setCelebrateBtnClass] = useState('category-btn-color');
  const [interestBtnClass, setInterestBtnClass] = useState('category-btn-color');
  const [shakehandsBtnClass, setShakehandsBtnClass] = useState('category-btn-color');
  const [supportBtnClass, setSupportBtnClass] = useState('category-btn-color');
  const [reactionData, setReactionData] = useState([]);
  const [replyPageCount, setReplyPageCount] = useState(0);
  const [isLoaderShow, setIsLoaderShow] = useState(true);
  const [repliesList, setRepliesList] = useState([]);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [isReactionInfiniteDisabled, setReactionInfiniteDisabled] = useState(false);
  const [scollingReactionType, setScollingReactionType] = useState();
  const [scollingPostId, setScollingPostId] = useState();
  const [isLoadding, setIsLoading] = useState(false);
  const [count, setCount] = useState(0);
  const dispatch = useDispatch();
  const [confirmModel, setConfirmModel] = useState(false);
  const getFeedDatas = useSelector(getFeedData);
  const replyBoxBtnHandler = async (
    id: string,
    page: string | number,
    index: string | number | undefined,
    commentIndex: string | number | undefined
  ) => {
    const data = '{"page": ' + page + ' }';
    const response1 = await CallFor('api/v1/post/' + props.opId + '/comments/' + id, 'POST', data, 'Auth');
    if (response1.status === 200) {
      const response = await response1.json();
      if (response.data.content.length > 0) {
        if (page === 0) {
          dispatch({
            type: 'add_reply_feedsData',
            reply: response.data.content,
            index: index,
            commentIndex: commentIndex
          });
        } else {
          response.data.content.map((details) => {
            dispatch({
              type: 'add_new_reply_feedsData',
              reply: details,
              index: index,
              commentIndex: commentIndex
            });
          });
        }
        setReplyPageCount(page + 1);
      } else {
        if (page === 0) {
          dispatch({
            type: 'add_reply_feedsData',
            reply: response.data.content,
            index: index,
            commentIndex: commentIndex
          });
        }
        setIsLoaderShow(false);
      }
    }
  };
  const textMethod = (text) => {
    let stringvalue = '';
    if (text.length > 200) {
      let msg = text.slice(0, 201);
      for (let i = 201; i < text.length; i++) {
        if (text.charAt(i) !== ' ') {
          msg += text.charAt(i);
        } else {
          break;
        }
      }
      stringvalue = msg;
    } else {
      stringvalue = text.slice(0, text.length + 1);
    }

    return stringvalue;
  };
  const [showMore, setShowMore] = useState(false);
  const changeContent = (contentObj) => {
    if (contentObj.text.length > 0) {
      let finalString = contentObj.text;
      const subStringval = textMethod(finalString);
      let EmailAnchorlength = 0;
      const ValidateEmail = (mail) => {
        const emailsArray = mail.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
        if (emailsArray != null && emailsArray.length > 0) {
          let j = 0;
          const uniqueChars = [...new Set(emailsArray)];
          let count = 0;
          while (j < uniqueChars.length) {
            const re = new RegExp(uniqueChars[j], 'g');
            const temp = subStringval;
            count += (temp.match(re) || []).length;
            j++;
          }
          EmailAnchorlength = 7 * count;
          let i = 0;
          while (i < uniqueChars.length) {
            const re = new RegExp(uniqueChars[i], 'g');
            finalString = finalString.replace(re, `<a class="font-color" href="mailto:${uniqueChars[i]}">${uniqueChars[i]}</a>`);
            i++;
          }
        }
        return finalString;
      };

      ValidateEmail(finalString);
      let isSame = true;
      if (subStringval.trim().length === finalString.trim().length) {
        isSame = false;
      }
      const urlarr: any[] = [];
      const ValidateUrl = (text) => {
        const urlRegex = /(([a-z]+:\/\/)?(([a-z0-9\-]+\.)+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel|local|internal))(:[0-9]{1,5})?(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&amp;]*)?)?(#[a-zA-Z0-9!$&'()*+.=-_~:/?]*)?)(\s+|$)/gi;
        return text.replace(urlRegex, (url) => {
          urlarr.push(url);
          let urlval = url;
          if (urlval.includes('https://') || urlval.includes('http://')) {
          } else {
            urlval = `https://${url}`;
          }
          const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
          return `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'>${url}</a>`;
        });
      };
      finalString = ValidateUrl(finalString);
      const uniqueUrl = [...new Set(urlarr)];
      let j = 0;
      const arr = [];
      while (j < uniqueUrl.length) {
        const re = new RegExp(uniqueUrl[j], 'g');
        const temp = subStringval;
        arr.push(temp.match(re) || []);
        j++;
      }
      const uniarr = [];
      const uninum = [];
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].length > 0) {
          uninum.push(arr[i].length);
        }

        if (arr[i][0] !== undefined) {
          uniarr.push(arr[i][0]);
        }
      }

      let k = 0;
      let Urllength = 0;
      while (k < uniarr.length) {
        let urlval = uniarr[k];
        if (urlval.includes('https://') || urlval.includes('http://')) {
        } else {
          urlval = `https://${uniarr[k]}`;
        }
        const urlval1 = urlval.replace(/(^[\s\u200b]*|[\s\u200b]*$)/g, '');
        const val = `<a style="text-decoration: none;" class = "font-color" href="${urlval1}" target='_blank'></a>`;
        Urllength = Urllength + val.length * uninum[k];
        k++;
      }

      let AnchorLength = 0;
      let hashlength = 0;
      let hashData = '';

      if (contentObj.attributes.length > 0) {
        const data = [];
        contentObj.attributes.forEach((element) => {
          const res = contentObj.text.substring(element.start, element.start + element.length);
          if (!res.startsWith('#')) {
            if (element.mention === 'PROFILE') {
              if (data.includes(res)) {
                const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
                AnchorLength += val.length;
              } else {
                data.push(res);
                finalString = finalString.replaceAll(res, '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '">' + res + '</a>');
                const val = '<a style="text-decoration: none;" class = "font-color" href="/profile/' + element.id + '"></a>';
                AnchorLength += val.length;
              }
            }
          }
        });
      }
      hashData = finalString.match(/#[a-z]+/gi);
      if (hashData !== null && hashData.length > 0) {
        const map = {};
        hashData.map((hashValue) => {
          if ((Object.keys(map).filter(item => item === hashValue)).length > 0) {
            const cnt = map.[hashValue];
            map.[hashValue] = 1;
          } else {
            map.[hashValue] = 1;
            finalString = finalString.replaceAll(hashValue, '<span style="text-decoration: none;" class = "font-color" href="#">' + hashValue + '</span>');
          }
          const val = '<span style="text-decoration: none;" class ="font-color" href="#">' + hashValue + '</span>';
          hashlength += val.length;
        });
      }
      finalString = finalString.replace(/(\r\n|\r|\n)/g, '<br>');
      const breakstring = finalString.slice(0, AnchorLength + subStringval.length);
      const countbreak = breakstring.match(/<br>/gi);
      let breakcount = 0;
      if (countbreak !== null && countbreak.length > 0) {
        breakcount = countbreak.length;
      }
      if (finalString.length > (200 + EmailAnchorlength + Urllength + AnchorLength + hashlength + breakcount * 3) && !showMore) {
        return (
          <>
            <span dangerouslySetInnerHTML={{ __html: finalString.slice(0, EmailAnchorlength + Urllength + AnchorLength + hashlength + subStringval.length + breakcount * 3 + 1) }} />

            {isSame
              ? <a
                onClick={() => setShowMore(true)} >
                {t('appproperties.text399')} </a>
              : ' '}
          </>
        );
      } else {
        return (
          <span dangerouslySetInnerHTML={{ __html: finalString }} />
        );
      }
    } else {
      return '';
    }
  };

  const [replyMobileViewModel, setReplyMobileViewModel] = useState(false);
  const showReplyBoxBtnHandler = (showReplyBox, index, commentIndex) => {
    if (window.innerWidth < 991) {
      if (!document.querySelector('reply-modal')?.getAttribute('aria-modal')) {
        setReplyMobileViewModel(true);
      }
    }
    if (showReplyBox) {
      dispatch({
        type: 'reply_btn_feedsData_new',
        showReplyBox: false,
        index: index,
        commentIndex: commentIndex
      });
    } else {
      dispatch({
        type: 'reply_btn_feedsData_new',
        showReplyBox: true,
        index: index,
        commentIndex: commentIndex
      });
    }
  };
  const reactionDetails = async (postId, reactionCount) => {
    if (reactionCount !== 0) {
      setShowReactionModal(true);
      const allFeedDataResponse = await CallFor('api/v1/reaction/comment/' + postId, 'get', null, 'Auth');
      if (allFeedDataResponse.status === 200) {
        const json1Response = await allFeedDataResponse.json();
        if (json1Response.data !== null) {
          setReactionBtnData(json1Response.data);
        }
      } else if (allFeedDataResponse.status === 401) {
        localStorage.clear();
      }
      getReactionData('ALL', 0, postId);
    }
  };
  const getReactionData = async (reactionType, page, postId) => {
    setReactionInfiniteDisabled(false);
    setIsLoading(true);
    setReactionCount(1);
    if (reactionType === 'ALL') {
      setAllBtnClass('ion-button-color');
      setLikeBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'LIKE') {
      setAllBtnClass('category-btn-color');
      setLikeBtnClass('ion-button-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'CELEBRATE') {
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('ion-button-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'INTEREST') {
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('ion-button-color');
      setShakehandsBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
    } else if (reactionType === 'SHAKEHANDS') {
      setShakehandsBtnClass('ion-button-color');
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setSupportBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
    } else if (reactionType === 'SUPPORT') {
      setSupportBtnClass('ion-button-color');
      setAllBtnClass('category-btn-color');
      setCelebrateBtnClass('category-btn-color');
      setInterestBtnClass('category-btn-color');
      setShakehandsBtnClass('category-btn-color');
      setLikeBtnClass('category-btn-color');
    }
    const allFeedDataResponse = await CallFor('api/v1/reaction/list/comment/' + postId + '/' + reactionType,
      'POST', JSON.stringify({ page: 0 }), 'Auth');
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      setReactionData(json1Response.data.content);
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
    }
    setScollingReactionType(reactionType);
    setScollingPostId(postId);
    setIsLoading(false);
  };
  const getRepliesDetails = async (id) => {
    const data = '{"page": 0 }';
    const response1 = await CallFor('api/v1/post/' + props.opId + '/comments/' + id, 'POST', data, 'Auth');
    if (response1.status === 200) {
      const response = await response1.json();
      if (response.data.content.length > 0) {
        // if (replyPageCount === 0) {
        setRepliesList(response.data.content);
        // }
        setCount(1);
        setShowRepliesModal(true);
      } else {
        setRepliesList([]);
      }
    }
    setTempCommentId(id);
  };
  const [tempCommentId, setTempCommentId] = useState();
  const getRepliesScroll = async (id, page) => {
    const data = '{"page": ' + page + ' }';
    const response1 = await CallFor('api/v1/post/' + props.opId + '/comments/' + id, 'POST', data, 'Auth');
    if (response1.status === 200) {
      const response = await response1.json();
      if (response.data.content.length > 0) {
        // if (replyPageCount === 0) {
        setRepliesList([...repliesList,
        ...response.data.content]);
        // }
        setCount(count + 1);
      } else {
        setInfiniteDisabled(true);
      }
    }
  };
  const closeRepliesBtn = () => {
    setShowRepliesModal(false);
    setCount(0);
    setInfiniteDisabled(false);
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getRepliesScroll(tempCommentId, count);
      ev.target.complete();
    }, 500);
  };
  const [reportModal, setReportModel] = useState(false);
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr">
      {profileDetail.id !== UserId
        ? <IonItem
          lines="none"
          className="cursor-pointer"
          onClick={() => { openReportModelclearstate(); onHide() }}
        >
          <IonIcon icon={warningOutline} size="small" className="header-menu-img " />
          <p>{t('commonproperties.text19')}</p>
        </IonItem>
        : <><IonItem
          lines="none"
          className="cursor-pointer"
          onClick={() => { onHide(); openedit() }}
        >
          <IonIcon icon={edit} size="small" className="header-menu-img " />
          <p>{t('appproperties.text231')}</p>
        </IonItem><IonItem
          lines="none"
          className="cursor-pointer"
          onClick={() => { onHide(); setConfirmModel(true) }}
        >
            <IonIcon icon={trashBinOutline} size="small" className="header-menu-img " />
            <p>{t('commonproperties.text35')}</p>
          </IonItem></>
      }      </IonList>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });

  const openReportModelclearstate = () => {
    setReportModel(true);
    dismiss();
  };
  const [reportId, setReportId] = useState('');
  const [UserId, setUserId] = useState('');
  const [commentindex, setCommentIndex] = useState('');
  const [isEditedField, setIsEditedField] = useState('');
  const reportHander = (e, id, commentIndex, userId, isEdited) => {
    present({ event: e.nativeEvent });
    setReportId(id);
    setCommentIndex(commentIndex);
    setUserId(userId);
    if (isEdited !== undefined) {
      setIsEditedField(isEdited);
    } else {
      setIsEditedField(false);
    }
  };
  const openedit = () => {
    dismiss();
    document.getElementById('feedComment').classList.add('d-none'); 
    if (isEditedField) {
      dispatch({
        type: 'edit_comment',
        isEdited: false,
        index: props.feedKey,
        commentIndex: commentindex
      });
    } else {
      dispatch({
        type: 'edit_comment',
        isEdited: true,
        index: props.feedKey,
        commentIndex: commentindex
      });
    }
  };
  const deleteBtnHandler = async () => {
    dismiss();
    const response = await CallFor(
      'api/v1/comment/' + reportId,
      'DELETE',
      null,
      'Auth'
    );
    if (response.status === 201) {
      dispatch({
        type: 'delete_comment',
        isDeleted: true,
        index: props.feedKey,
        commentIndex: commentindex
      });
      if (getFeedDatas[props.feedKey].comments[commentindex].replyCount != null && getFeedDatas[props.feedKey].comments[commentindex].replyCount > 0) {
        dispatch({
          type: 'add_comments_feedsData_count',
          commentCount: getFeedDatas[props.feedKey].commentCount - (getFeedDatas[props.feedKey].comments[commentindex].replyCount + 1),
          index: props.feedKey
        });
      } else {
        dispatch({
          type: 'add_comments_feedsData_count',
          commentCount: getFeedDatas[props.feedKey].commentCount - 1,
          index: props.feedKey
        });
      }
    } else if (response.status === 400) {
      const json1Response = await response.json();
      console.log(json1Response.error.message);
    }
  };
  const [reactionCount, setReactionCount] = useState(1);
  const reactionLoadData = (ev: any) => {
    setTimeout(() => {
      scrollData();
      ev.target.complete();
    }, 500);
  };
  const scrollData = async () => {
    const allFeedDataResponse = await CallFor('api/v1/reaction/list/' + scollingPostId + '/' + scollingReactionType,
      'POST', JSON.stringify({ page: reactionCount }), 'Auth');
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      // setReactionData(json1Response.data.content);
      if (json1Response.data.content.length > 0) {
        setReactionData([...reactionData, ...json1Response.data.content]);
        setReactionCount(reactionCount + 1);
      } else {
        setReactionInfiniteDisabled(true);
      }
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
    }
  };
  const closeReactionModel = () => {
    setShowReactionModal(false);
    setReactionCount(1);
  };
  return (
    <>
      {props.commentObj.isDeleted === undefined && !props.commentObj.isDeleted
        ? <>
          {props.commentObj.isReport === undefined && !props.commentObj.isReport
            ? <>
              <IonRow className="full-width-row comment-box-content-box">
                <IonCol size-md="1" size-xs="2" className="ion-no-padding">
                  <div className="myprofile-feeds ion-padding">
                    <IonAvatar
                      slot="start"
                      className="MuiCardHeader-avatar MuiAvatar-circular"
                      onClick={() => history.push('/profile/' + props.commentObj.userId)}
                    >
                      {props.commentObj.userProfile !== null
                        ? <img onError={(ev) => { ev.target.src = userProfile; }} src={props.commentObj.userProfile} />
                        : <img src={userProfile} />}
                    </IonAvatar>
                  </div>
                </IonCol>
                <IonCol
                  size-md="11"
                  size-xs="10"
                  className="ion-no-padding "
                >
                  <div className='comment-box-content ion-padding-end'>
                    <IonCard className="MuiPaper-rounded ion-no-margin comment-box-text-content shadow-none">
                      <IonRow className="profileName ">
                        <IonCardTitle>
                          <div className='cursor-pointer' onClick={() => history.push('/profile/' + props.commentObj.userId)}>
                            <p className="margin MuiTypography-body2">
                              <strong>{props.commentObj.userName}</strong>
                            </p>
                            <span className="margin MuiTypography-caption">
                              {props.commentObj.userDesignation}
                            </span>
                          </div>
                          {!props.commentObj.isEdited
                            ? <div className="dot-btn">
                              <IonIcon
                                icon={ellipsisVertical}
                                slot="start"
                                className="test report cursor-pointer"
                                onClick={(e) => {
                                  if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                                    reportHander(e, props.commentObj.id, props.commentKey, props.commentObj.userId, props.commentObj.isEdited)
                                  } else {
                                    // history.push('/addnewcompany');
                                    setLoginModal(true);
                                  }
                                }} />
                            </div>
                            : ''}
                        </IonCardTitle>
                        {console.log(localStorage.getItem('isEdited'), "status")}
                        {!props.commentObj.isEdited
                          ? <p className='margin MuiTypography-body2'>{changeContent(JSON.parse(props.commentObj.content))}</p>
                          : <EditedCommentBox postId={props.opId} postUserId={props.postUserId} commentId={props.commentObj.id} feedIndex={props.feedKey}
                            commentIdex={props.commentKey} commentText={props.commentObj.content} type='Comment' placeholder={t('appproperties.text228')}
                          />
                        }
                      </IonRow>
                    </IonCard>
                    <IonRow className="action-buttons feed-inner-action">
                      <div className='col-left'>
                        <span className='like-cm-btn'>
                          <Emojis id={props.opId} reactionId={props.commentObj.reactionId} reaction={props.commentObj.reaction}
                            postUserId={props.postUserId} feedIndex={props.feedKey} type='comment' commentId={props.commentObj.id} commentIndex={props.commentKey}
                            profileDetail={profileDetail} />
                          <span className='ion-text-capitalize ion-no-padding reaction-color-tab pr-3 vertical-btn'>
                            <IonChip
                              className="post-btn ion-no-padding ion-padding-start ion-padding-end"
                              onClick={() => reactionDetails(props.commentObj.id, props.commentObj.reactionCount)}
                            >
                              <IonAvatar className="ion-no-padding reaction-btn bottom-like-btn">
                                {/* <img src ={Like} width='20'/> */}
                                {(() => {
                                  if (props.commentObj.reaction === '1') {
                                    return (
                                      <><img src={Like} width="20" /> </>
                                    );
                                  } else if (props.commentObj.reaction === '2') {
                                    return (
                                      <><img src={Celebrate} width="20" /></>
                                    );
                                  } else if (props.commentObj.reaction === '3') {
                                    return (
                                      <><img src={Interest} width="20" /></>
                                    );
                                  } else if (props.commentObj.reaction === '4') {
                                    return (
                                      <><img src={ShakeHand} width="20" /></>
                                    );
                                  } else if (props.commentObj.reaction === '5') {
                                    return (
                                      <><img src={Supports} width="20" /></>
                                    );
                                  } else {
                                    return (
                                      <><img src={Like} width="20" /> </>
                                    );
                                  }
                                })()}
                                {props.commentObj.reactionCount}
                              </IonAvatar>
                            </IonChip>
                          </span>
                        </span>
                        <span className="ion-text-capitalize ion-no-padding reaction-color-tab right-padding vertical-btn">
                          <IonButton
                            fill="clear"
                            className="ion-text-capitalize ion-no-padding reaction-color-tab right-padding vertical-btn pr-0 mr-0"
                            onClick={function (event) {
                              if (props.commentObj.showReplyBox === undefined) {
                                replyBoxBtnHandler(
                                  props.commentObj.id,
                                  0,
                                  props.feedKey,
                                  props.commentKey
                                );
                              }
                              showReplyBoxBtnHandler(props.commentObj.showReplyBox, props.feedKey, props.commentKey);
                            }}
                          >
                            <div className="vertical-btn">
                              <span>{t('appproperties.text229')}</span></div>
                          </IonButton>
                          <span className="dot"></span>
                          <span
                            className="ion-text-capitalize hashtage-color cursor-pointer"
                            onClick={() => getRepliesDetails(props.commentObj.id)}
                          >
                            {props.commentObj.replyCount} {t('appproperties.text230')}
                          </span>
                        </span>
                      </div>
                      <span className='ion-no-padding reaction-color-tab vertical-btn ml-auto replytime'>{props.commentObj.ageOfComment}</span>
                    </IonRow>
                  </div>
                  {props.commentInput && props.commentObj.showReplyBox !== undefined &&
                    props.commentObj.showReplyBox === true
                    ? (
                      <><IonRow className="full-width-row ion-no-padding replay-user-box">
                        <IonCol size-md="1" size-xs="2" className="ion-no-padding">
                          <div className="myprofile-feeds">
                            <IonAvatar
                              slot="start"
                              className="MuiCardHeader-avatar MuiAvatar-circular"
                            >
                              {profileDetail.profileImg !== null
                                ? <img onError={(ev) => { ev.target.src = userProfile; }} src={profileDetail.profileImg} />
                                : <img src={userProfile} />}
                            </IonAvatar>
                          </div>
                        </IonCol>
                        <IonCol
                          size-md="11"
                          size-xs="10"
                          className="ion-no-padding ion-padding-end ion-padding-bottom"
                        >
                          <Editor postId={props.opId} postUserId={props.postUserId} commentId={props.commentObj.id} feedIndex={props.feedKey} commentIdex={props.commentKey} type='Reply' placeholder={t('appproperties.text228')} />
                        </IonCol>
                      </IonRow><ReplyBox
                          commentMap={props.commentObj.reply}
                          feedKey={props.feedKey}
                          opId={props.opId}
                          commentInput={true}
                          commentKey={props.commentKey}
                          postUserId={props.postUserId}
                          commentId={props.commentObj.id} /></>
                    )
                    : (
                      ''
                    )}
                  {props.commentObj.showReplyBox !== undefined &&
                    props.commentObj.showReplyBox === true && props.commentObj.reply != null && props.commentObj.reply.length >= 5 && isLoaderShow
                    ? (
                      <IonRow className="full-width-row">
                        <IonCol size-md="1" size-xs="2" className="ion-no-padding"></IonCol>
                        <IonCol
                          size-md="11"
                          size-xs="10"
                          className="ion-no-padding"
                        >
                          <IonButton
                            fill="clear"
                            className="text-normal loadmore ion-no-margin "
                            onClick={() =>
                              replyBoxBtnHandler(
                                props.commentObj.id,
                                replyPageCount,
                                props.feedKey,
                                props.commentKey
                              )
                            }
                          >
                            {t('appproperties.text294')}
                          </IonButton>
                        </IonCol>
                      </IonRow>
                    )
                    : (
                      ''
                    )}
                </IonCol>
              </IonRow>
            </>
            : <IonRow className="full-width-row">
              <IonCol size-md="1" size-xs="2" className="ion-no-padding"></IonCol>
              <IonCol
                size-md="11"
                size-xs="10"
                className="ion-no-padding ion-padding-end"
              >
                <IonCard className='ion-padding ion-no-margin ion-margin-bottom ion-margin-top '>
                  {t('appproperties.text298')}
                </IonCard>
              </IonCol>
            </IonRow>
          }
        </>
        : <IonRow className="full-width-row">
          <IonCol size-md="1" size-xs="2" className="ion-no-padding"></IonCol>
          <IonCol
            size-md="11"
            size-xs="10"
            className="ion-no-padding ion-padding-end"
          >
            <IonCard className='ion-padding ion-no-margin ion-margin-bottom ion-margin-top cmntdelete'>
              {t('appproperties.text295')}
            </IonCard></IonCol>
        </IonRow>}
      <IonModal isOpen={showReactionModal} cssClass='add-award-model' backdropDismiss={false} onDidDismiss={() => setShowReactionModal(false)}>
        <div className='  '>
          <IonCol className="d-flex MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between custom-modal-heading">
            <IonLabel className="MuiTypography-h6">
              {t('appproperties.text219')}
            </IonLabel>
            <div onClick={closeReactionModel} className="close ion-no-padding me-2 mt-2" >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 cursor-pointer"
                slot="start"
                size="undefined"
              />
            </div>
          </IonCol>
          <IonRow className='reaction-icon-list scroll-mobile-horztl px-2 mt-1'>
            <IonButton
              className={allBtnClass}
              shape="round"
              size="small"
              onClick={() => getReactionData('ALL', 0, reactionBtnData.commentId)}
            >
              {t('appproperties.text15')}
            </IonButton>
            {reactionBtnData.likeCount !== 0
              ? <IonButton
                className={likeBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('LIKE', 0, reactionBtnData.commentId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Like} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.likeCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.celebrateCount !== 0
              ? <IonButton
                className={celebrateBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('CELEBRATE', 0, reactionBtnData.commentId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Celebrate} width="20" />
                  <span className='ion-padding-start'>{reactionBtnData.celebrateCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.interestCount !== 0
              ? <IonButton
                className={interestBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('INTEREST', 0, reactionBtnData.commentId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Interest} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.interestCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.shakeHandCount !== 0
              ? <IonButton
                className={shakehandsBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('SHAKEHANDS', 0, reactionBtnData.commentId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={ShakeHand} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.shakeHandCount}</span>
                </div>
              </IonButton>
              : ''}
            {reactionBtnData.supportCount !== 0
              ? <IonButton
                className={supportBtnClass}
                shape="round"
                size="small"
                onClick={() => getReactionData('SUPPORT', 0, reactionBtnData.commentId)}
              >
                <div className='d-flex align-items-center'>
                  <img src={Supports} width='20' />
                  <span className='ion-padding-start'>{reactionBtnData.supportCount}</span>
                </div>
              </IonButton>
              : ''}
          </IonRow>
        </div>
        <IonContent>
          <IonRow className='pb-2 px-3 px-xl-4 ion-padding-top reaction-list-content w-100'>
            {!isLoadding &&
              reactionData.map((reaction) => (
                <>
                  <IonRow className='full-width-row ion-no-padding'>
                    {(() => {
                      if (reaction.reaction === '1') {
                        return (
                          <div className='reation-emoji'><img src={Like} width='20' /></div>
                        );
                      } else if (reaction.reaction === '2') {
                        return (
                          <div className='reation-emoji'><img src={Celebrate} width='20' /></div>
                        );
                      } else if (reaction.reaction === '3') {
                        return (
                          <div className='reation-emoji'><img src={Interest} width='20' /></div>
                        );
                      } else if (reaction.reaction === '4') {
                        return (
                          <div className='reation-emoji'><img src={ShakeHand} width='20' /></div>
                        );
                      } else if (reaction.reaction === '5') {
                        return (
                          <div className='reation-emoji'><img src={Supports} width='20' /></div>
                        );
                      }
                    })()}
                    <div className="myprofile-feeds ion-padding-start">
                      <IonAvatar className="MuiAvatar ion-margin-end">
                        {reaction.profileImage != null
                          ? <img onError={(ev) => { ev.target.src = userProfile; }} src={reaction.profileImage} />
                          : <img src={userProfile} />
                        }
                      </IonAvatar>
                      <IonRow className="display-grid">
                        <span className='name'>{reaction.userName}</span>
                        <span className="margin MuiTypography-caption group-model-text nowrap-normal">
                          {reaction.designation}
                        </span>
                      </IonRow>
                    </div>
                  </IonRow>
                </>
              ))
            }
            <IonInfiniteScroll
              onIonInfinite={reactionLoadData}
              threshold="100px"
              disabled={isReactionInfiniteDisabled}
            >
              <IonInfiniteScrollContent
                loadingSpinner="circular"
                loadingText={t('appproperties.text215')}
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </IonRow>
        </IonContent>
      </IonModal>
      <IonModal isOpen={showRepliesModal} cssClass='add-award-model' onDidDismiss={() => closeRepliesBtn()}>
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">
              {t('appproperties.text230')}
            </IonLabel>
            <div onClick={closeRepliesBtn} className="close ion-no-padding">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined" />
            </div>
          </IonRow>
          <IonRow className='feed-cards-posts ion-padding-bottom full-width-row'>
            {repliesList.length > 0 ? repliesList.map((replies) => (
              <IonRow className="full-width-row comment-box-content-box ion-padding-top">
                <IonCol size-md="1" size-xs="2" className="ion-no-padding">
                  <div className="myprofile-feeds ion-padding">
                    <IonAvatar
                      slot="start"
                      className="MuiCardHeader-avatar MuiAvatar-circular"
                      onClick={() => history.push('/profile/' + replies.userId)}
                    >
                      {replies.userProfile !== null
                        ? <img onError={(ev) => { ev.target.src = userProfile; }} src={replies.userProfile} />
                        : <img src={userProfile} />}
                    </IonAvatar>
                  </div>
                </IonCol>
                <IonCol
                  size-md="11"
                  size-xs="10"
                  className="ion-no-padding ion-padding-start"
                >
                  <div className='comment-box-content ion-padding-end'>
                    <IonCard className="MuiPaper-rounded ion-no-margin comment-box-text-content shadow-none position-relative shadow-none">
                      <IonRow className="profileName ">
                        <IonCardTitle>
                          <div className='cursor-pointer' onClick={() => history.push('/profile/' + replies.userId)}>
                            <p className="margin MuiTypography-body2">
                              <strong>{replies.userName}</strong>
                            </p>
                            <span className="margin MuiTypography-caption">
                              {replies.userDesignation}
                            </span>
                          </div>
                        </IonCardTitle>
                        <p className='margin MuiTypography-body2'>{changeContent(JSON.parse(replies.content))}</p>
                      </IonRow>
                    </IonCard>
                  </div>
                </IonCol>
              </IonRow>
            )) : <IonCard className='ion-padding full-width-row'>
              {t('signuprecommendation.text6')}
            </IonCard>}
          </IonRow>
          <IonInfiniteScroll
            threshold="100px"
            onIonInfinite={loadData}
            disabled={isInfiniteDisabled}
          >
            <IonInfiniteScrollContent loadingText={t('appproperties.text215')}></IonInfiniteScrollContent>
          </IonInfiniteScroll>
        </IonContent>
      </IonModal>
      <ReportSpamCommon reportModal={reportModal} setReportModel={setReportModel} reportId={reportId} origin='COMMENT' mapData={label} message={t('toastmessages.toast20')} index={props.feedKey} commentIndex={commentindex} />
      <ConfirmModelCommon header={t('appproperties.text244')} message={t('appproperties.text245')} btn1={t('appproperties.text11')} btn2={t('commonproperties.text35')} confirmModel={confirmModel} setConfirmModel={setConfirmModel} deleteBtnHandler={deleteBtnHandler} />
      {replyMobileViewModel
        ? <MobileReplyFeed replyMobileViewModel={replyMobileViewModel} opId={props.opId}
          setReplyMobileViewModel={setReplyMobileViewModel} postUserId={props.postUserId}
          commentobj={props.commentObj} feedKey={props.feedKey} commentKey={props.commentKey} />
        : ''}
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}

    </>
  );
};
export default CommentBox;
