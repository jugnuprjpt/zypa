import { IonButton, IonCol, IonIcon, IonModal, IonRow } from '@ionic/react'
import { closeOutline} from 'ionicons/icons';
import React from 'react'
import { useTranslation } from 'react-i18next';

const EmptyCatelogueError = (props: any) => {
    const { t } = useTranslation();
    function submitHander() {
        props.addProductShowModal(true);
        props.setProductList([{ name: '', price: '', brandName: '', minimumQty: '', paymentTerms: '', description: '', image: null, index: 2, imageCount: 0, entitiesId: props.companyId }]);
        props.setOpenModal(false);
        props.setImagesList([[], []])

    }
    return (
        <IonModal
            isOpen={props.openModal}
            cssClass="addCompany-modal fileup-height"
            backdropDismiss={false}
        >
            <div
                onClick={() => props.setOpenModal(false)}
                className="close ion-no-padding cursor-pointer p-2 text-end"
            >
                <IonIcon
                    icon={closeOutline}
                    className="ion-button-color text-dark font-28"
                    slot="start"
                    size="undefined"
                />
            </div>
            <IonRow className=''>
                <IonCol sizeMd="12" sizeXs="12" className='text-center mb-4'>
                {t('appproperties.text302')}
                </IonCol>

                <IonCol sizeMd="12" sizeXs="12" className='text-center'>
                    <input
                        type="file"
                        accept=".xls, .xlsx, .csv"
                        color="dark"
                        onChange={props?.fileHandler}
                        className="ion-text-capitalize ion-no-padding ion-padding-end upload"
                        multiple
                        id="fileUpload"
                    ></input>
                    <div className='d-flex align-items-center justify-content-center mb-4'>
                        <label
                            htmlFor="fileUpload"
                            className="ion-text-capitalize cursor-pointer pb-2"
                            color="dark"
                        >
                            <div className='color-theme-dark d-flex align-items-center justify-content-center mt-2 mb-0 me-2 btnYes'>
                            {t('appproperties.text241')}
                            </div>
                        </label>
                        <div
                            className='color-theme-dark d-flex align-items-center justify-content-center  mb-0 me-2 btnNo'
                            onClick={() => props.setOpenModal(false)}
                        >
                            {t('appproperties.text242')}
                        </div>
                    </div>
                </IonCol>
            </IonRow>
        </IonModal>
    )
}

export default EmptyCatelogueError