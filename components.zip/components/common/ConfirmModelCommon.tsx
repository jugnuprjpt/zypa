import React from 'react';
import {
  IonButton,
  IonCol,
  IonFooter,
  IonIcon,
  IonLabel,
  IonModal,
  IonRow
} from '@ionic/react';
import { close } from 'ionicons/icons';
import ButtonComponent from './ButtonComponent';
const ConfirmModelCommon = (props: any) => {
  const deleteClick = () => {
    if (props.iD !== '' && props.indexId !== undefined && props.indexId !== '') {
      props.deleteBtnHandler(props.iD, props.indexId);
    } else if (props.iD !== '' && props.fromId !== '' && props.type !== '' && props.requestType !== undefined && props.requestType !== null) {
      props.deleteBtnHandler(props.fromId, props.type, props.iD, props.requestType);
    } else if (props.iD !== '' && props.fromId !== '' && props.type !== '') {
      props.deleteBtnHandler(props.fromId, props.type, props.iD);
    } else if (props.iD !== '') {
      props.deleteBtnHandler(props.iD);
    } else {
      props.deleteBtnHandler();
    }
    props.setConfirmModel(false);
  };
  return (
    <>
      <IonModal id="confirm-modal" isOpen={props.confirmModel} backdropDismiss={false} className="addCompany-modal report-modal" onDidDismiss={() => props.setConfirmModel(false)}>
        <div className="report-spam-type">
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between pt-2 mt-lg-0">
            <div className="MuiTypography-h4 font-18 ms-lg-3 ms-1">
              {props.header}
            </div>
            <IonButton fill="clear" onClick={() => props.setConfirmModel(false)} className="close link-btn-tx ion-no-padding ion-no-margin pt-0">
              <IonIcon
                icon={close}
                className="ion-button-color me-0 p-0"
                slot="start"
                size="undefined" />
            </IonButton>
          </IonRow>
          <div className="modal-body">
            <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row px-3">
              <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                <IonLabel className='msg-text' >
                  {props.message}
                </IonLabel>
              </IonCol>
            </IonRow>
            <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row px-3">
              <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                <IonLabel className='msg-text' >
                  {props.message2}
                </IonLabel>
              </IonCol>
            </IonRow>
          </div>
        </div>
        <IonFooter className="ion-no-border px-lg-3 pb-lg-3">
          <IonRow>
            <ButtonComponent className='btn-secondry' btnClick={deleteClick} name={props.btn2} parametersPass={0} />
            <IonButton
              className="ion-button-color mr-lg-2"
              onClick={() => props.setConfirmModel(false)}
            >
              {props.btn1}
            </IonButton>
          </IonRow>
        </IonFooter>
      </IonModal>
    </>
  );
};

export default ConfirmModelCommon;
