import React from 'react';
import {
  IonAvatar,
  IonIcon,
  IonItem,
  IonList,
  IonRow
} from '@ionic/react';
import { business, closeOutline, documentText, list, logOut, logOutOutline, people, settings, thumbsUp } from 'ionicons/icons';
import { Link, useHistory } from 'react-router-dom';
import { setLocalStore } from '../../util/Common';
import User from '../../assets/img/icons/user.svg';
import { useTranslation } from 'react-i18next';

const AppSlideBar = (props : any) => {
  const { t } = useTranslation();
  const history = useHistory();
  // const [present, dismiss] = useIonPopover(PopoverList, {
  //   onHide: () => dismiss()
  // });
  const clickHandler = (page: string) => {
    history.push(page);
    // dismiss();
    props.setActive(false);
  };
  const logOut = () => {
    localStorage.clear();
    setLocalStore('showHomeModel', false);
    history.push('/login');
    // dismiss();
    props.setActive(false);
  };
  const closeSideBar = () => {
    props.setActive(false);
  };
  return (
    <><div className='mobile-menu show-mobile'>
      <div className='inner-content'>
        <div className='mm-prfile-name'>
          <div className='col-left' onClick={() => clickHandler('/profile/' + props.userProfileData.id)}>
            <IonAvatar slot="start" className="header-menu-account-img">
              {props.userProfileData.profileImg
                ? <img onError={(ev) => { ev.target.src = User; }} src={props.userProfileData.profileImg} width="00" height="00" alt="Home" />
                : <img src={User} alt='Home' />}
            </IonAvatar>
            <IonRow className='display-grid'>
              <span className='name'>{props.userProfileData.name}</span>
              <div className='d-flex menu-pro-file'>
                <span className='name'>{t('appproperties.text342')} <span>({props.profileDetailsCount.views})</span></span>
                <span className='name'>Monthly post <span>({props.profileDetailsCount.monthlyPost})</span></span>
              </div>
            </IonRow>
          </div>
          <IonIcon icon={closeOutline} onClick={closeSideBar}></IonIcon>
        </div>
        <div className='mid-content'>
          <IonList>
            <IonItem>
              <Link to={'/page'} onClick={() => clickHandler('/page')}><IonIcon className='icon-mobile' icon={documentText}></IonIcon>{t('appproperties.text18')}</Link>
            </IonItem>
            <IonItem>
              <Link onClick={() => clickHandler('/teams/' + props.userProfileData.id + '/' + props.userProfileData.entityId)}><IonIcon className='icon-mobile' icon={people}></IonIcon> {t('appproperties.text17')}</Link>
            </IonItem>
            <IonItem>
              <Link onClick={() => clickHandler('/myActivity/' + props.userProfileData.id + '/' + props.userProfileData.name)}><IonIcon className='icon-mobile' icon={list}></IonIcon> {t('appproperties.text343')}</Link>
            </IonItem>
            <IonItem>
              <Link onClick={() => clickHandler('/companyList/' + props.userProfileData.id)}><IonIcon className='icon-mobile' icon={business}></IonIcon> {t('appproperties.text144')}</Link>
            </IonItem>
            <IonItem>
              <Link onClick={() => clickHandler('/recomdationList/' + props.userProfileData.id + '/' + props.userProfileData.name)}><IonIcon className='icon-mobile' icon={thumbsUp}></IonIcon> {t('appproperties.text145')}</Link>
            </IonItem>
            <IonItem>
              <Link to={'/settings'} onClick={() => props.setActive(false)}><IonIcon className='icon-mobile' icon={settings}></IonIcon> {t('appproperties.text101')}</Link>
            </IonItem>
          </IonList>
        </div>
        <div className='menu-footer'>
          <Link onClick={() => logOut()}><IonIcon className='icon-mobile' icon={logOutOutline}></IonIcon>{t('appproperties.text102')}</Link>
        </div>
      </div>
    </div><span className='overlay-menu' onClick={() => props.setActive(false)}></span></>
  );
};
export default AppSlideBar;
