import { IonModal, IonRow, IonLabel, IonButton, IonIcon, IonCol, IonCardTitle, IonSelect, IonSelectOption, IonItem, IonInput, IonFooter, IonCard } from '@ionic/react';
import React, { useState } from 'react';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { close } from 'ionicons/icons';
import { useForm } from 'react-hook-form';
import CallFor from '../../util/CallFor';
import { setLocalStore } from '../../util/Common';
import PopoverCommon from './PopoverCommon';
import { useSelector } from 'react-redux';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import { useHistory } from 'react-router';
import ToastCommon from './ToastCommon';
import { useTranslation } from 'react-i18next';
const AddCompanyModal = (props) => {
  const { t } = useTranslation();
  const identity = [
    {
      value: 'GSTIN',
      label: 'GSTIN'
    },
    {
      value: 'PAN',
      label: t('dropdownfields.text3')
    },
    {
      value: 'UDYOG_ADHAR',
      label: t('dropdownfields.text4')
    },
    {
      value: 'UDYAM_ADHAR',
      label: t('dropdownfields.text5')
    }
  ];
  const [show, setShow] = useState(true);
  const [formState, setformState] = useState({});
  const profileDetail = useSelector(getProfileDetails);
  const [loading, setLoading] = useState(false);
  const [disabled, setdisabled] = useState(true);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const history = useHistory();
  const openDisableNullState = () => {
    props.setAddCompanyModal(false);
    setShow(true);
    setformState({});
    clearErrors();
    resetField('identityType');
    resetField('identityNumber');
  };
  const validationSchema = Yup.object().shape({
    // identityType: Yup.string().required('Identity Type is Required'),
    identityNumber: Yup.string().trim()
      .required(t('companyproperties.text28'))
      .when('identityType', {
        is: 'GSTIN',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1}/, t('companyproperties.text29'))
          .test(
            'len',
            t('companyproperties.text29'),
            (val) => val && val.toString().length >= 15
          )
          .test(
            'len',
            t('companyproperties.text29'),
            (val) => val && val.toString().length <= 15
          )
      })
      .when('identityType', {
        is: 'UDYOG_ADHAR',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[a-zA-Z]{2}[0-9]{2}[a-zA-Z][0-9]{7}/, t('companyproperties.text30'))
          .test(
            'len',
            t('companyproperties.text30'),
            (val) => val && val.toString().length >= 12
          )
          .test(
            'len',
            t('companyproperties.text30'),
            (val) => val && val.toString().length <= 12
          )
      })
      .when('identityType', {
        is: 'UDYAM_ADHAR',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[Uu]{1}[Dd]{1}[Yy]{1}[Aa]{1}[Mm]{1}[-][A-Za-z]{2}[-][0-9]{2}[-][0-9]{7}/, t('companyproperties.text31'))
          .test(
            'len',
            t('companyproperties.text31'),
            (val) => val && val.toString().length >= 19
          )
          .test(
            'len',
            't('companyproperties.text31')',
            (val) => val && val.toString().length <= 19
          )
      })
      .when('identityType', {
        is: 'PAN',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[a-zA-Z]{3}[pcftghlabjPCFTGHLABJ]{1}[a-zA-Z]{1}[0-9]{4}[a-zA-Z]{1}/, t('companyproperties.text32'))
          .test(
            'len',
            t('companyproperties.text32'),
            (val) => val && val.toString().length >= 10
          )
          .test(
            'len',
            t('companyproperties.text32'),
            (val) => val && val.toString().length <= 10
          )
      })
  });
  const {
    clearErrors,
    register,
    handleSubmit,
    setError,
    resetField,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });

  const submitHandler = async(event: any) => {
    const identityType = formState.identityType;
    const identityNumber = formState.identityNumber.toUpperCase();
    if (identityType !== undefined && identityNumber !== undefined) {
      setdisabled(true);
      setLoading(true);
      const response = await CallFor(
        'api/v1.1/verify/identity',
        'POST',
        '{"identity":"' +
        identityType +
        '","identityNumber":"' +
        identityNumber +
        '"}',
        'Auth'
      );
      if (response.status === 200) {
        setLocalStore('identityType', identityType);
        setLocalStore('identityNumber', identityNumber);
        setdisabled(false);
        setLoading(false);
        history.push('/addcompany');
      } else if (response.status === 400) {
        setdisabled(false);
        setLoading(false);
        const jsonResponse = await response.json();
        if (jsonResponse.error.errors !== null) {
          if (jsonResponse.error.errors[0].field === 'identityNumber') {
            if (
              jsonResponse.error.errors[0].message ===
              'Company is Already registered with us'
            ) {
              setShow(false);
            }
          }
          setError(jsonResponse.error.errors[0].field, {
            message: jsonResponse.error.errors[0].message
          });
        } else {
          setError('identityNumber', {
            message: jsonResponse.error.message
          });
        }
      } else if (response.status === 401) {
        setdisabled(false);
        setLoading(false);
        localStorage.clear();
        history.push('/login');
      }
    } else {
      setdisabled(false);
      setLoading(false);
      setError('identityType', {
        message: 'Identity Type is Required'
      });
    }
  };
  const blurHandler = () => {
    const identityType = document.getElementById('identityType').value;
    if (identityType === undefined) {
      setError('identityType', {
        type: 'required',
        message: t('commonproperties.text26')
      });
    }
  };
  const companyVerificationChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined && event.target.value !== null) {
      if (event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      if (event.target.name === 'identityType') {
        setformState({ ...formState, identityNumber: '', [event.target.name]: event.target.value });
      } else {
        setformState({ ...formState, [event.target.name]: event.target.value });
      }
    }
    const identityType = document.getElementById('identityType');
    const identityNumber = document.getElementById('identityNumber');
    if (identityType !== undefined && identityType !== null) {
      if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 15 &&
        identityType.value === 'GSTIN'
      ) {
        setdisabled(false);
      } else if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 10 &&
        identityType.value === 'PAN'
      ) {
        setdisabled(false);
      } else if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 12 &&
        identityType.value === 'UDYOG_ADHAR'
      ) {
        setdisabled(false);
      } else if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 19 &&
        identityType.value === 'UDYAM_ADHAR'
      ) {
        setdisabled(false);
      } else {
        setdisabled(true);
      }
    } else {
      setdisabled(true);
    }
    // clearErrors([event.target.name]);
  };
  const handleSearch = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      e.stopPropagation();
    }
  };
  const sendTeamRequest = async() => {
    // setLoading(true);
    const response = await CallFor(
      'api/v1.1/companies/identity/' + formState.identityNumber.toUpperCase(),
      'POST',
      null,
      'Auth'
    );
    if (response.status === 201) {
      props.setAddCompanyModal(false);
      setShowToastMsg(t('appproperties.text426'));
      setShowToast(true);
      setTimeout(() => {
        openDisableNullState();
      }, 1000);
    } else if (response.status === 400) {
      props.setAddCompanyModal(false);
      openDisableNullState();
      const jsonResponse = await response.json();
      setShowToastMsg(jsonResponse.error.message);
      setShowToast(true);
    }
  };
  const clickHereToReport = async() => {
    const reportsData =
      '{"originId": "' + formState.identityNumber.toUpperCase() + '","origin": "COMPANY","remarks":"User entity claim." }';
    const response = await CallFor(
      'api/v1.1/spam-report',
      'POST',
      reportsData,
      'registrationWithAuth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast24'));
      setShowToast(true);
      setTimeout(() => {
        openDisableNullState();
      }, 1000);
    }
  };
  return (
    <><IonModal cssClass="addCompany-modal" backdropDismiss={false} isOpen={props.addCompanyModal} onDidDismiss={() => openDisableNullState()}>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
              <IonLabel className="MuiTypography-h6 pl-2">
                  {t('companyproperties.text2')}
              </IonLabel>
              <IonButton fill="clear" onClick={openDisableNullState} className="close link-btn-tx ion-no-padding ion-no-margin">
                  <IonIcon
                      icon={close}
                      className="ion-button-color pr-0 "
                      slot="start"
                      size="undefined" />
              </IonButton>
          </IonRow>

          <div className="modal-body  ion-no-margin">
              {show
                ? <form data-testid="form-submit "
                      autoComplete="off"
                      className='w-100 h-100'
                      onSubmit={handleSubmit(submitHandler, blurHandler)}>
                      <div className="body-content ion-padding-horizontal ion-no-margin ">
                          <IonRow>
                              <IonCol size="12">
                                  <IonCardTitle>
                                  {t('commonproperties.text30')}
                                  </IonCardTitle>
                              </IonCol>
                              <IonCol size="12" className='show-tooltip input-popover d-block mb-3'>
                                  <div className='form-group mb-0'>
                                      <div className='select-input-box'>
                                          <IonSelect
                                              interface="popover"
                                              className={errors.identityType
                                                ? 'error-border select-box'
                                                : 'select-box'}
                                              onIonChange={companyVerificationChangeHandler}
                                              onIonBlur={blurHandler}
                                              value={formState.identityType}
                                              id="identityType"
                                              {...register('identityType')}
                                          >
                                              {identity.map((option) => (
                                                  <IonSelectOption
                                                      key={option.label}
                                                      value={option.value}
                                                  >
                                                      {option.label}
                                                  </IonSelectOption>
                                              ))}
                                          </IonSelect>
                                          <span className='floating-label-outside'>{t('commonproperties.text37')}<sup>*</sup> </span>
                                      </div>
                                      <p className={errors.identityType ? 'error' : ''}>
                                          {errors.identityType?.message}
                                      </p>
                                      <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text155')} />
                                  </div>
                              </IonCol>
                              <IonCol size="12" className='show-tooltip input-popover position-relative'>
                                  <IonItem
                                      className={errors.identityNumber
                                        ? 'error-border form-group input-label-box mb-0'
                                        : 'form-group input-label-box mb-0'}
                                  >
                                      <IonLabel position="floating">{' '}{t('commonproperties.text32')}<sup className='font-22'>*</sup>{' '}</IonLabel>
                                      <IonInput
                                          autocomplete="off"
                                          type='text'
                                          className='input-box ion-text-uppercase'
                                          data-testid="identityNumber"
                                          placeholder=""
                                          onIonChange={companyVerificationChangeHandler}
                                          value={formState.identityNumber}
                                          id="identityNumber"
                                          {...register('identityNumber')}
                                          onKeyDown={(e) => e.key === 'Enter' && handleSearch(e)}
                                          style={{ textTransform: 'uppercase' }} />
                                      <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text155')} />
                                  </IonItem>
                                  <p className={errors.identityNumber ? 'error input-error left5' : ''}>
                                      {errors.identityNumber?.message}
                                  </p>
                              </IonCol>
                          </IonRow>
                      </div>
                      <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
                          <IonButton
                              disabled={disabled}
                              type="submit"
                              className="ion-button ion-button-color"
                          >
                              {t('appproperties.text154')}
                              {loading
                                ? <span className="loader" id="loader-2">
                                      <span></span>
                                      <span></span>
                                      <span></span>
                                  </span>
                                : ''}
                          </IonButton>
                      </IonFooter>
                  </form>
                : <IonCard>
                      <IonRow className='full-width-row ion-padding-top ion-padding-bottom pt-0'>
                          <IonRow>
                              <IonLabel className="MuiTypography-h6 ion-padding-start"> {t('companyproperties.text13')}</IonLabel>
                          </IonRow>
                      </IonRow>
                      <IonRow className='ion-padding-start ion-padding-end ion-padding-bottom ion-justify-content-center'>
                          <span>
                          {t('appproperties.text236a')}{profileDetail.name}{t('appproperties.text236b')}
                          </span>
                      </IonRow>
                      <IonRow className='ion-padding-start'>
                          <IonButton className="ion-button ion-button-color" onClick={sendTeamRequest}>
                          {t('appproperties.text237')}
                          </IonButton>
                      </IonRow>
                      <IonRow className='ion-padding-start ion-padding-top'>
                          <span className="error">
                              Note: {t('companyproperties.text38')} <a onClick={clickHereToReport}>{t('companyproperties.text39')}</a>.
                          </span>
                      </IonRow>
                  </IonCard>}
          </div>
      </IonModal><ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} /></>
  );
};
export default AddCompanyModal;
