import React, { useState } from 'react';
import { IonAvatar, IonContent, IonIcon, IonModal, IonRow } from '@ionic/react';
import { cameraOutline, closeOutline } from 'ionicons/icons';

const ProfilePicture = (props) => {
  const [showModelProfilePicture, setshowModelProfilePicture] = useState(false);
  return (
    <>
      <div className="profile-picture position-relative">
        <IonAvatar
          slot="start"
          className="MuiCardHeader-avatar avtar-img mx-auto profileAvtar ion-no-margin p-0"
        >
          {props.logo === 'LOGO'
            ? <>
              {
                props.croppedImage !== null && props.croppedImage !== ''
                  ? <div onClick={() => setshowModelProfilePicture(true)} className='cursor-pointer'>
                    <img className="group-img" src={props.croppedImage} />
                  </div>
                  : props.image !== null && props.image !== ''
                    ? <div onClick={() => setshowModelProfilePicture(true)} className='cursor-pointer'>
                      <img className="group-img" onError={(ev) => { ev.target.src = props.defultLogo; }} src={props.image} />
                    </div>
                    : props.croppedImage !== null && props.image !== null
                      ? <div onClick={() => setshowModelProfilePicture(true)} className='cursor-pointer'>
                        <img className="group-img" src={props.croppedImage} />
                      </div>
                      : props.image === null
                        ? <div onClick={() => setshowModelProfilePicture(true)} className='cursor-pointer'>
                          <img className="group-img" src={props.defultLogo} />
                        </div>
                        : ''
              }</>
            : ''
          }
          {!props.reportHideState && props.isHide !== true && props.isAdmin === true
            ? <div className='editimg cursor-pointer position-absolute d-flex ion-align-items-center ion-justify-content-center' onClick={props.openEditModal}>
              <span className='addImage'></span>
              <IonIcon
                icon={cameraOutline}
                className="text-white fa-3x"
                slot="start"
              />
            </div>
            : ''}
        </IonAvatar>
      </div>

      {/*  Profile Picture Zoom  */}
      <IonModal isOpen={showModelProfilePicture} cssClass="add-award-model awd-img-gallery" onDidDismiss={() => setshowModelProfilePicture(false)}>
        <IonContent>
          <div className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
            <div onClick={() => setshowModelProfilePicture(false)} className="close position-absolute right10 top10">
              <IonIcon
                icon={closeOutline}
                className="text-white font-28"
                slot="start"
                size="undefined" />
            </div>
          </div>
          <div className="mx-auto d-flex justify-content-center align-items-center h-100">
            {
              props.croppedImage !== null && props.croppedImage !== ''
                ? <img className="group-img border-radius0" src={props.croppedImage} />
                : props.image !== null && props.image !== ''
                  ? <img className="group-img border-radius0" onError={(ev) => { ev.target.src = props.defultLogo; }} src={props.image} />
                  : props.croppedImage !== null && props.image !== null
                    ? <img className="group-img border-radius0" src={props.croppedImage} />
                    : props.image === null
                      ? <img className="group-img border-radius0" src={props.defultLogo} />
                      : ''
            }
          </div>
        </IonContent>
      </IonModal>
      {/*  End Profile Picture Zoom  */}
    </>
  );
};
export default ProfilePicture;
