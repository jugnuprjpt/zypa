import { IonModal, IonContent, IonRow, IonLabel, IonIcon, IonCol, IonItem, IonInput, IonTextarea, IonFooter, IonButton, IonAvatar } from '@ionic/react';
import { close, pencilOutline, trashBinOutline } from 'ionicons/icons';
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import React, { useEffect, useState } from 'react';
import PopoverCommon from './PopoverCommon';
import CallFor from '../../util/CallFor';
import { useHistory } from 'react-router';
import { Device } from '@capacitor/device';
import CustomeFirebaseEvent from './CustomFirebaseEvent';
import productImg from '../../assets/img/Product_default.png';
import { useTranslation } from 'react-i18next';

const AddProducts = (props) => {
  const { t } = useTranslation();
  const [diviceInfo, setDiviceInfo] = useState();

  const [characterCount, setCharacterCount] = useState(0);
  const [addProductData, setAddProductData] = useState({ companyId: props.companyId });
  const [isValid, setIsValid] = useState(true);
  const [createDisabled, setCreateDisabled] = useState(false);
  const maxCount = 1000;
  const [files, setfiles] = useState('');
  const history = useHistory();

  useEffect(async() => {
    let subscription = true;
    if(subscription){
      setDiviceInfo(await Device.getInfo());
    }

    return () => {
      subscription = false;
    }
  }, []);

  const uploadProductlogoHandleChange = function loadFile(event) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        setIsValid(false);
      } else {
        if (event.target.files[0].size > 3145728) {
          setError('upload', {
            type: 'required',
            message: t('commonproperties.text2')
          });
          setIsValid(false);
        } else {
          clearErrors('upload');
          resetField('upload');
          setIsValid(true);
        }
      }
      setfiles(file1);
      setImageView(true);
    }
  };

  const digitsOnly = (value: string) => /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test(value);
  const validationSchema = Yup.object().shape({
    productName: Yup.string().trim().required(t('productproperties.text8')).test(
      'len',
      t('pageproperties.text8'),
      (val) => val && val.toString().length >= 2
    ).test(
      'len',
      t('pageproperties.text9'),
      (val) => val && val.toString().length <= 150
    ),
    minPrice: Yup.string().nullable().optional().trim()
      .required(t('productproperties.text11'))
      .test('typeError',
      t('productproperties.text12'),
        (val) => {
          if (val !== null && val !== '') {
            return Number(val);
          } else {
            return true;
          }
        })
      .test('Digits only', t('productproperties.text24'), digitsOnly),
    maxPrice: Yup.string().nullable().optional().trim()
      .required(t('productproperties.text13'))
      .test('typeError',
      t('productproperties.text14'),
        (val) => {
          if (val !== null && val !== '') {
            return Number(val);
          } else {
            return true;
          }
        })
      .test('Digits only', t('productproperties.text24'), digitsOnly)
      .test('match', t('productproperties.text15'),
        (val) => {
          if (Number(addProductData.minPrice) >= Number(val)) {
            return false;
          } else {
            return val;
          }
        }
      ),
    brandName: Yup.string().nullable(true).optional().notRequired()
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().length >= 2;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('productproperties.text10'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().length <= 150;
          } else {
            return true;
          }
        }
      ),
    minimumQty: Yup.string().required('Enter minimum quantity').max(100, t('userproperties.text15')).trim()
      .test('typeError',
      t('productproperties.text20'),
        (val) => {
          if (val <= 0) {
            return Number(val);
          } else {
            return true;
          }
        }),
    paymentTerms: Yup.string().trim().required(t('productproperties.text21')).test(
      'len',
      t('pageproperties.text8'),
      (val) => val && val.toString().length >= 2
    ).test(
      'len',
      t('pageproperties.text9'),
      (val) => val && val.toString().length <= 150
    ),
    
    description: Yup.string().trim()
      .required(t('signuprecommendation.text31'))
      .min(10, t('commonproperties.text28'))
      .max(500, t('commonproperties.text40'))
  });

  const {
    register,
    handleSubmit,
    clearErrors,
    resetField,
    setError,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });

  const showModalHandle = () => {
    props.setShowModal(false);
    setCharacterCount(0);
    if (props.redirection !== undefined && props.redirection) {
      history.push('/catalogue/' + props.userId);
    }
  };

  const testHandler = () => {
    const productPhoto = document.getElementById('upload');
    let isUserLogoValid = true;
    if (productPhoto.files[0] !== undefined && productPhoto.files[0] !== '') {
      if (productPhoto.files[0].size > 3145728) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text2')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
      if (!productPhoto.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
    }

    if (isUserLogoValid) {
      setIsValid(true);
      return true;
    } else {
      setIsValid(false);
      return false;
    }
  };

  const userformDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined && event.target.value.length > 0) {
      event.target.classList.add('input-fill');
    } else {
      event.target.classList.remove('input-fill');
    }
    setAddProductData({
      ...addProductData,
      [event.target.name]: event.target.value
    });
  };
  
  const submitHandler = async() => {
    if (testHandler() && isValid) {
      setCreateDisabled(true);
      const logo = document.getElementById('upload');
      const data = new FormData();
      data.append('productImage', logo.files[0]);

      let productname = '';
      let minprice = '';
      let maxprice = '';
      let brandname = '';
      let minqty = '';
      let paymentteam = '';
      let productdescription = '';
      if (addProductData.productName !== undefined && addProductData.productName !== null) {
        productname = addProductData.productName.trim();
        addProductData.productName = productname;
      }
      if (addProductData.minPrice !== undefined && addProductData.minPrice !== null) {
        minprice = addProductData.minPrice.trim();
        addProductData.minPrice = minprice;
      }
      if (addProductData.maxPrice !== undefined && addProductData.maxPrice !== null) {
        maxprice = addProductData.maxPrice.trim();
        addProductData.maxPrice = maxprice;
      }
      if (addProductData.brandName !== undefined && addProductData.brandName !== null) {
        brandname = addProductData.brandName.trim();
        addProductData.brandName = brandname;
      }
      if (addProductData.minimumQty !== undefined && addProductData.minimumQty !== null) {
        minqty = addProductData.minimumQty.trim();
        addProductData.minimumQty = minqty;
      }
      if (addProductData.paymentTerms !== undefined && addProductData.paymentTerms !== null) {
        paymentteam = addProductData.paymentTerms.trim();
        addProductData.paymentTerms = paymentteam;
      }
      if (addProductData.description !== undefined && addProductData.description !== null) {
        productdescription = addProductData.description.trim();
        addProductData.description = productdescription;
      }

      data.append('productInfo', JSON.stringify(addProductData));
      const response = await CallFor(
        'api/v1.1/products',
        'POST',
        data,
        'authWithoutContentType'
      );
      if (response.status === 201) {
        props.setShowModal(false);
        if (props.productList !== undefined) {
          props.productList();
        }
        CustomeFirebaseEvent('products_event', diviceInfo);
        // const datares = await response.json();
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else if (response.status === 400) {
        const datares = await response.json();
        setCreateDisabled(false);
        datares.error.errors.map((details) => {
          setError(details.field, {
            type: 'server',
            message: details.message
          });
        });
      } else if (response.status === 404) {
        const datares = await response.json();
        setCreateDisabled(false);
      } else {
        setCreateDisabled(false);
      }
    }
  };
  const descriptionChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setAddProductData({
        ...addProductData,
        description: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };
  const deleteImg = () => {
    setfiles('');
    setImageView(true);
    document.getElementById('upload').value = '';
  };
  const [imageView, setImageView] = useState(false);
  const removeOverLay = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const addClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.add('imageHover');
  };
  const removeClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const addImg = () => {
    setImageView(false);
  };
  const imageEditHandle = () => {
    setImageView(false);
    // uploadCompanylogoHandleChange()
  };
  return (
        <IonModal
        isOpen={props.showModal}
        cssClass="createGroupModal"
        onDidDismiss={showModalHandle}
        backdropDismiss={false}
      >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">{t('productproperties.text1')}</IonLabel>
            <div
              onClick={showModalHandle}
              className="close ion-no-padding cursor-pointer"
            >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <div className="modal-body">
            <form
              data-testid="form-submit"
              autoComplete="off"
              className="h-100"
              noValidate
              onSubmit={handleSubmit(submitHandler, testHandler)}
            >
              <div className="body-content">
                <IonRow className="MuiCardContent-root ion-padding-start ion-padding-end ">
                <IonCol size-md="12" size-sm="12" size-xs="12" className='mx-auto'>
                    <div className="ion-justify-content-center mobile-avtar d-flex">
                      <input
                        type="file"
                        autoComplete='off'
                        color="primary"
                        onChange={uploadProductlogoHandleChange}
                        id="upload"
                        accept="image/png, image/jpg, image/jpeg"
                        className="upload"
                        disabled={imageView}
                      />
                      <label htmlFor="upload" className='cursor-pointer up-img hover-avtar' id='lblupload' onClick={removeOverLay} onMouseEnter={addClass} onMouseLeave={removeClass}>
                        <IonAvatar
                          id="companyAvatar"
                          slot="start"
                          className="MuiCardHeader-avatar avtar-img"
                        >
                          {files
                            ? (
                              <img
                                src={files}
                                className="group-img groupPhoto" id='groupImg'
                              />
                              )
                            : (
                              <img src={productImg} className="group-img" />
                              )}
                        </IonAvatar>
                        <span className='addImage' onClick={addImg}></span>
                        {files !== '' && files !== null
                          ? <><div className='avr-edit-del-icon'>
                            <span className="icon edit cursor-pointer">
                              <IonIcon icon={trashBinOutline} onClick={deleteImg} />
                            </span>
                            <span className="icon edit cursor-pointer">
                              <IonIcon icon={pencilOutline} onClick={imageEditHandle}/>
                            </span>
                          </div>
                          </>
                          : ''}
                      </label>
                    </div>
                    <div className='error ion-text-center w-100 position-relative'>
                      {errors.upload?.message}
                    </div>
                  </IonCol>
                  <IonCol size-md="12" size-xs="12" className="input-label-box">
                    <IonItem
                      className={
                        errors.productName
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0'
                      }
                    >
                      <IonLabel position="floating">{' '}{t('productproperties.text2')} <sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box'
                        data-testid="productName"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="productName"
                        {...register('productName')}
                        value={addProductData.productName}
                      />
                    </IonItem>
                    <p className={errors.productName ? 'error' : ''}>
                      {errors.productName?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className="input-label-box tooltipc input-popover">
                    <IonItem
                      className={
                        errors.minPrice
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0'
                      }
                    >
                      <IonLabel position="floating">{' '}{t('productproperties.text3')}<sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box input-custom-width'
                        data-testid="minPrice"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="minPrice"
                        {...register('minPrice')}
                        value={addProductData.minPrice}
                      />
                    </IonItem>
                    <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text248')}/>
                    <p className={errors.minPrice ? 'error' : ''}>
                      {errors.minPrice?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className="input-label-box tooltipc input-popover">
                    <IonItem
                      className={
                        errors.maxPrice
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0'
                      }
                    >
                      <IonLabel position="floating">{' '}{t('productproperties.text4')}<sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box input-custom-width'
                        data-testid="maxPrice"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="maxPrice"
                        {...register('maxPrice')}
                        value={addProductData.maxPrice}
                      />
                    </IonItem>
                    <PopoverCommon className='popover-zyapaar' Description='Show the range of the products by mentioning price of your premium products.' />
                    <p className={errors.maxPrice ? 'error' : ''}>
                      {errors.maxPrice?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="12" size-xs="12" className="input-label-box tooltipc input-popover ">
                    <IonItem
                      className={
                        errors.brandName
                          ? 'error-border form-group input-label-box position-relative mb-0'
                          : 'form-group input-label-box position-relative mb-0'
                      }
                    >
                      <IonLabel position="floating">{t('productproperties.text5')}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box input-custom-width'
                        data-testid="brandName"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="brandName"
                        {...register('brandName')}
                        value={addProductData.brandName}
                      />
                    </IonItem>
                    <PopoverCommon className="popover-zyapaar" Description={t('appproperties.text249')}/>
                    <p className={errors.brandName ? 'error' : ''}>
                      {errors.brandName?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className="input-label-box show-tooltip input-popover">
                    <IonItem
                      className={
                        errors.minimumQty
                          ? 'error-border form-group input-label-box position-relative mb-0 pt-0'
                          : 'form-group input-label-box position-relative mb-0 pt-0'
                      }
                    >
                      <IonLabel position="floating">{t('productproperties.text6')}<sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box input-custom-width'
                        data-testid="minimumQty"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="minimumQty"
                        {...register('minimumQty')}
                        value={addProductData.minimumQty}
                      />
                    </IonItem>
                    <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text250')}/>
                    <p className={errors.minimumQty ? 'error' : ''}>
                      {errors.minimumQty?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className="input-label-box show-tooltip input-popover">
                    <IonItem
                      className={
                        errors.paymentTerms
                          ? 'error-border form-group input-label-box position-relative mb-0 pt-0'
                          : 'form-group input-label-box position-relative mb-0 pt-0'
                      }
                    >
                      <IonLabel position="floating">{t('productproperties.text7')}<sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type='text'
                        className='input-box input-custom-width'
                        data-testid="paymentTerms"
                        placeholder=""
                        onIonChange={userformDataChangeHandler}
                        id="paymentTerms"
                        {...register('paymentTerms')}
                        value={addProductData.paymentTerms}
                      />
                    </IonItem>
                    <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text251')}/>
                    <p className={errors.paymentTerms ? 'error' : ''}>
                      {errors.paymentTerms?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="12" sizeXs="12" className="input-label-box mb-0">
                    <IonItem
                      className={
                        errors.description
                          ? 'error-border form-group input-label-box position-relative full-width-row mb-0 pt-0'
                          : 'form-group input-label-box position-relative full-width-row mb-0 pt-0'
                      }
                    >
                      <IonLabel position="floating">{t('commonproperties.text39')}<sup>*</sup></IonLabel>
                        <IonTextarea
                          className='input-box full-width-row'
                          onIonChange={descriptionChangeHandler}
                          hahandleSubmit={handleSubmit}
                          value={addProductData.description}
                          errors={errors.description}
                          {...register('description')}
                          rows={3}
                          maxlength={500}
                          id='description'
                        />
                    </IonItem>
                    <p className={errors.description ? 'error' : ''}>
                      {errors.description?.message}
                    </p>
                    <p className='text-grey text-end font-14'>{characterCount}/{maxCount}</p>
                  </IonCol>
                  {/* <IonCol size-md="12" sizeXs="12" id='productDisable'>
                    <IonItem className='form-group input-label-box position-relative mb-0'>
                      <input
                        type="file"
                        color="primary"
                        onChange={uploadProductlogoHandleChange}
                        id="upload"
                        accept="image/png, image/jpg, image/jpeg"
                        className="upload ion-padding-start"
                        disabled={files}
                      />
                      <label
                        htmlFor="upload"
                        className="input-box upload-img-control cursor-pointer d-flex align-items-center ps-0 mb-0"
                      >
                        <IonIcon
                          icon={images}
                          className="ion-button-color pr-0 me-2 font-20 color-grey"
                          slot="start"
                          size="undefined"
                        />{' '}
                        {t('awardproperties.text4')}
                      </label>
                    </IonItem>
                  </IonCol> */}
                  {/* {files
                    ? (
                    <IonCol size-md="12" sizeXs="12">
                      <div className="addPhoto-editor">
                        <IonList>
                          <>
                            <IonItem lines="none" className="ion-no-padding">
                              <img src={files} />
                              <span className="icon" onClick={deleteImg}>
                                <IonIcon icon={trashBinOutline} />
                              </span>
                            </IonItem>
                          </>
                        </IonList>
                      </div>
                      <div className='error ion-text-left w-100'>
                        {errors.upload?.message}
                      </div>
                    </IonCol>
                      )
                    : (
                        ''
                      )} */}
                </IonRow>
              </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
                <IonRow>
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto"
                    size="small"
                    type="submit"
                    disabled={createDisabled}
                  >
                    {t('productproperties.text1')}
                    {createDisabled
                      ? <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                      : ''
                    }
                  </IonButton>
                </IonRow>
              </IonFooter>
            </form>
          </div>
        </IonContent>
      </IonModal>
  );
};
export default AddProducts;
