import { IonCard, IonCol, IonRow } from '@ionic/react';
import React from 'react';

const PrivacyPolicy = () => {
  return (
    <IonRow className="plane-bg">
      <IonRow className="container">
        <IonCol sizeMd="12">
          <h2>
            <b> Privacy Policy </b>
          </h2>
        </IonCol>
        <IonCol size="12">
          <IonCard className="profile-details left-cards ion-no-margin MuiPaper-rounded ion-padding-bottom ion-padding-end">
            <IonRow className = "ion-padding-start ion-padding-end ion-padding-top">
              <IonRow>
            <b > the Council of Europe began to study</b>
            <p>
              n 1968, the Council of Europe began to study the effects of
              technology on human rights, recognizing the new threats posed by
              computer technology that could link and transmit in ways not
              widely available before. In 1969 the Organisation for Economic
              Co-operation and Development (OECD) began to examine the
              implications of personal information leaving the country. All this
              led the council to recommend that policy be developed to protect
              personal data held by both the private and public sectors, leading
              to Convention 108. In 1981, Convention for the Protection of
              Individuals with regard to Automatic Processing of Personal Data
              (Convention 108) was introduced. One of the first privacy laws
              ever enacted was the Swedish Data Act in 1973, followed by the
              West German Data Protection Act in 1977 and the French Law on
              Informatics, Data Banks and Freedoms in 1978.[5] In the United
              States, concern over privacy policy starting around the late 1960s
              and 1970s led to the passage of the Fair Credit Reporting Act.
              Although this act was not designed to be a privacy law, the act
              gave consumers the opportunity to examine their credit files and
              correct errors. It also placed restrictions on the use of
              information in credit records. Several congressional study groups
              in the late 1960s examined the growing ease with which automated
              personal information could be gathered and matched with other
              information. One such group was an advisory committee of the
              United States Department of Health and Human Services, which in
              1973 drafted a code of principles called the Fair Information
              Practices. The work of the advisory committee led to the Privacy
              Act in 1974. The United States signed the Organisation for
              Economic Co-operation and Development guidelines in 1980.[5] In
              Canada, a Privacy Commissioner of Canada was established under the
              Canadian Human Rights Act in 1977. In 1982, the appointment of a
              Privacy Commissioner was part of the new Privacy Act. Canada
              signed the OECD guidelines in 1984.[5]
            </p></IonRow>
            <IonRow>
            <b > the Council of Europe began to study</b>
            <p >
              n 1968, the Council of Europe began to study the effects of
              technology on human rights, recognizing the new threats posed by
              computer technology that could link and transmit in ways not
              widely available before. In 1969 the Organisation for Economic
              Co-operation and Development (OECD) began to examine the
              implications of personal information leaving the country. All this
              led the council to recommend that policy be developed to protect
              personal data held by both the private and public sectors, leading
              to Convention 108. In 1981, Convention for the Protection of
              Individuals with regard to Automatic Processing of Personal Data
              (Convention 108) was introduced. One of the first privacy laws
              ever enacted was the Swedish Data Act in 1973, followed by the
              West German Data Protection Act in 1977 and the French Law on
              Informatics, Data Banks and Freedoms in 1978.[5] In the United
              States, concern over privacy policy starting around the late 1960s
              and 1970s led to the passage of the Fair Credit Reporting Act.
              Although this act was not designed to be a privacy law, the act
              gave consumers the opportunity to examine their credit files and
              correct errors. It also placed restrictions on the use of
              information in credit records. Several congressional study groups
              in the late 1960s examined the growing ease with which automated
              personal information could be gathered and matched with other
              information. One such group was an advisory committee of the
              United States Department of Health and Human Services, which in
              1973 drafted a code of principles called the Fair Information
              Practices. The work of the advisory committee led to the Privacy
              Act in 1974. The United States signed the Organisation for
              Economic Co-operation and Development guidelines in 1980.[5] In
              Canada, a Privacy Commissioner of Canada was established under the
              Canadian Human Rights Act in 1977. In 1982, the appointment of a
              Privacy Commissioner was part of the new Privacy Act. Canada
              signed the OECD guidelines in 1984.[5]
            </p>
            </IonRow>
            <IonRow>
            <b > the Council of Europe began to study</b>
            <p >
              n 1968, the Council of Europe began to study the effects of
              technology on human rights, recognizing the new threats posed by
              computer technology that could link and transmit in ways not
              widely available before. In 1969 the Organisation for Economic
              Co-operation and Development (OECD) began to examine the
              implications of personal information leaving the country. All this
              led the council to recommend that policy be developed to protect
              personal data held by both the private and public sectors, leading
              to Convention 108. In 1981, Convention for the Protection of
              Individuals with regard to Automatic Processing of Personal Data
              (Convention 108) was introduced. One of the first privacy laws
              ever enacted was the Swedish Data Act in 1973, followed by the
              West German Data Protection Act in 1977 and the French Law on
              Informatics, Data Banks and Freedoms in 1978.[5] In the United
              States, concern over privacy policy starting around the late 1960s
              and 1970s led to the passage of the Fair Credit Reporting Act.
              Although this act was not designed to be a privacy law, the act
              gave consumers the opportunity to examine their credit files and
              correct errors. It also placed restrictions on the use of
              information in credit records. Several congressional study groups
              in the late 1960s examined the growing ease with which automated
              personal information could be gathered and matched with other
              information. One such group was an advisory committee of the
              United States Department of Health and Human Services, which in
              1973 drafted a code of principles called the Fair Information
              Practices. The work of the advisory committee led to the Privacy
              Act in 1974. The United States signed the Organisation for
              Economic Co-operation and Development guidelines in 1980.[5] In
              Canada, a Privacy Commissioner of Canada was established under the
              Canadian Human Rights Act in 1977. In 1982, the appointment of a
              Privacy Commissioner was part of the new Privacy Act. Canada
              signed the OECD guidelines in 1984.[5]
            </p>
            </IonRow></IonRow>
          </IonCard>
        </IonCol>
      </IonRow>
    </IonRow>
  );
};
export default PrivacyPolicy;
