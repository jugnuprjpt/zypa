/* eslint-disable multiline-ternary */
/* eslint-disable react/prop-types */
import {
  IonAvatar,
  IonCol,
  IonIcon,
  IonLabel,
  IonRow,
  useIonPopover,
  IonList,
  IonItem
} from '@ionic/react';
import logo from '../../assets/img/logo.svg';
import React, { useEffect, useState } from 'react';
import { getlocalStore, getToken, setLocalStore } from '../../util/Common';
import {
  addCircleOutline,
  chatbubbleOutline,
  chatbubblesOutline,
  documentTextOutline,
  homeOutline,
  logOutOutline,
  notificationsOutline,
  peopleOutline,
  reorderFourOutline,
  searchOutline,
  settingsOutline
} from 'ionicons/icons';
import { useDispatch, useSelector } from 'react-redux';
import callFor from '../../util/CallFor';
import { useHistory, useParams } from 'react-router';
import AsyncSelect from 'react-select/async';
import { components } from 'react-select';
import userProfile from '../../assets/img/user-profile-placeholder.png';
import groupImg from '../../assets/img/group-profile-placeholder.png';
import pageImg from '../../assets/img/page-logo-default.png';
import companyImg from '../../assets/img/page-company-profile-placeholder.png';
import User from '../../assets/img/icons/user.svg';
import Mini from '../../assets/img/icons/mini.svg';
import Network from '../../assets/img/icons/network.svg';
import ConectionsIconFill from '../../assets/img/conections-fill.svg';
import TeamsIcon from '../../assets/img/icons/teams-icon.svg';
import catalogueactive from '../../assets/img/catalogue-active.svg';
import catalogue from '../../assets/img/catalogue-icon.svg';
import { Link } from 'react-router-dom';
import { Device } from '@capacitor/device';
import HandlePushNotification from '../common/pushNotification/HandlePushNotifcation';
import { menuController } from '@ionic/core';
import Post from '../feed/Post';
import { useTranslation } from 'react-i18next';
import { getProfileDetails } from '../../Redux/reducers/UserProfile';
import NotAuthorizeModal from '../common/NotAuthorizeModal';

const Header = () => {
  const profileDetail = useSelector(getProfileDetails);
  const [loginModal, setLoginModal] = useState(false);
  const { t } = useTranslation();
  const [userProfileData, setUserProfileData] = useState([]);
  const [isActive, setActive] = useState(false);
  const dispatch = useDispatch();
  const [NotificationCount, setNotificationCount] = useState(0);
  // const [GroupCount, setGroupCount] = useState(0);
  const [ConnectionCount, setConnectionCount] = useState(0);
  const searchValue = useParams();
  const [textmsg, setTextMsg] = useState('');
  const [postFlag, setPostFlag] = useState(false);

  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <IonList className="my-account-pr">
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() => clickHandler('/profile/' + userProfileData.id)}
      >
        <IonAvatar slot="start" className="header-menu-account-img">
          {userProfileData.profileImg !== null
            ? (
              <img onError={(ev) => { ev.target.src = userProfile; }} src={userProfileData.profileImg} width="20" height="20" />
            )
            : (
              <img src={userProfile} width="20" height="20" />
            )}
        </IonAvatar>{' '}
        <p className="ion-padding-start fixed-textline2">{userProfileData.name}</p>
      </IonItem>
      {userProfileData.entityId !== undefined && userProfileData.entityId !== null
        ? <IonItem
          lines="none"
          className="cursor-pointer"
          onClick={() =>{
            onHide(); 
            if (userProfileData.entityId !== undefined && userProfileData.entityId !== null) {
              clickHandler('/teams/' + userProfileData.id + '/' + userProfileData.entityId);
            }
          }
          }
        >
          <img src={TeamsIcon} alt='Conections' width='24' height='24' />
          <p className="ion-padding-start">{t('appproperties.text17')}</p>
        </IonItem>
        : ''}
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() =>{onHide();  clickHandler('/groups')}}
      > <img src={ConectionsIconFill} alt='Conections' width='23' height='23' />{' '}
        <p className="ion-padding-start">{t('appproperties.text35')}</p>
      </IonItem>
      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() =>{onHide(); clickHandler('/page')}}
      > <IonIcon icon={documentTextOutline} size="small" className="header-menu-img " />{' '}
        <p className="ion-padding-start">{t('appproperties.text18')}</p>
      </IonItem>

      <IonItem
        lines="none"
        className="cursor-pointer"
        onClick={() =>{onHide();  clickHandler('/settings')}}
      >
        <IonIcon icon={settingsOutline} size="small" className="header-menu-img " />{' '}
        <p className="ion-padding-start">{t('appproperties.text101')}</p>
      </IonItem>
      <IonItem lines="none" className="cursor-pointer" onClick={() =>{onHide();  logOut()}}>
        <IonIcon
          icon={logOutOutline}
          size="small"
          className="header-menu-img "
        />{' '}
        <p className="ion-padding-start">{t('appproperties.text102')}</p>
      </IonItem>
    </IonList>
  );

  const logOut = () => {
    localStorage.clear();
    setLocalStore('showHomeModel', false);
    history.push('/login');
    dismiss();
    setActive(false);
  };

  const customStyles = {
    control: (provided: any) => ({
      ...provided,
      background: 'rgb(231 237 245)',
      border: '1px solid #e7edf5 !important',
      '&:focus': {
        border: '0px solid #e7edf5 !important',
        outline: 'none !important'
      }
    }),
    indicatorSeparator: () => { }, // removes the "stick"
    dropdownIndicator: (defaultStyles: any) => ({
      ...defaultStyles,
      '& svg': { display: 'none' }
    })
  };
  const [diviceInfo, setDiviceInfo] = useState();
  useEffect(async () => {
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
    window.addEventListener('offline', () => {
      // Do task when no internet connection
      history.push('/internetError');
    });
    setDiviceInfo(await Device.getInfo());
    let element;
    if (window.location.pathname.includes('home')) {
      element = document.getElementById('home');
    } else if (window.location.pathname.includes('notification')) {
      element = document.getElementById('notification');
    } else if (window.location.pathname.includes('network')) {
      element = document.getElementById('network');
    } else if (window.location.pathname.includes('catalogue')) {
      element = document.getElementById('catalogue');
    } else if (window.location.pathname.includes('connection')) {
      element = document.getElementById('network');
    }
    if (element !== undefined) {
      element.classList.add('active');
    }
    if (window.location.pathname.includes('home')) {
      document.getElementsByTagName('html')[0].classList.add('home');
    } else if (window.location.pathname.includes('registration')) {
      document.getElementsByTagName('html')[0].classList.add('home');
    } else if (window.location.pathname.includes('login')) {
      document.getElementsByTagName('html')[0].classList.add('home');
    } else if (window.location.pathname.includes('createCompany')) {
      document.getElementsByTagName('html')[0].classList.add('home');
    } else if (window.location.pathname.includes('searchFeeds')) {
      const decodedSearchValue = decodeURIComponent(escape(window.atob(searchValue.searchValue.replace('&quot;', '/'))));
      setTextMsg(decodedSearchValue);
    } else {
      document.getElementsByTagName('html')[0].classList.remove('home');
    }
    if (getlocalStore('token') !== null) {
      getUserDetails();
      getNotificationCount('api/v1.1/notifications/count', 1);
      getNotificationCount('api/v1.1/users/request/count', 3);
    }
  }, []);
  if (diviceInfo !== undefined && (diviceInfo.platform === 'ios' || diviceInfo.platform === 'android')) {
    HandlePushNotification();
  }
  const encodedString = (str) => {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (match, p1) {
      return String.fromCharCode(parseInt(p1, 16));
    }));
  };
  const getUserDetails = async () => {
    const response = await callFor('api/v1.1/user', 'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response !== null) {
        setUserProfileData(json1Response.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      setLocalStore('showHomeModel', false);
      history.push('/login');
    }
  };

  dispatch({ type: 'Add_Profile', userProfile: userProfileData });
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });
  const history = useHistory();
  const clickHandler = (page: string) => {
    history.push(page);
    dismiss();
    setActive(false);
  };
  const promiseOptions = (inputValue: string) =>
    new Promise<any>((resolve) => {
      resolve(filterSearchData(inputValue));
    });
  const filterSearchData = async (inputValue: string) => {
    if (inputValue.trim().length >= 3) {
      const productsRes = await callFor(
        'api/v1.1/searches/keywords/' + inputValue.trim() + '?page=0&size=5',
        'GET',
        null,
        'Auth'
      );
      if (productsRes.status === 200) {
        const json1Response = await productsRes.json();
        const options = await json1Response.data.map(
          (details) => ({
            value: details.id,
            label: (
              <div>
                <IonRow className='ion-align-items-center' onClick={() => selectClickHandler(details.name, details.type, details.id)}>
                  <IonAvatar className="MuiAvatar ion-margin-end avr-small">
                    {details.logo !== null
                      ? (
                        <img onError={(ev) => { ev.target.src = userProfile; }} src={details.logo} className="MuiAvatar-circular" />
                      )
                      : (
                        <>
                          {(() => {
                            if (details.type === 'user') {
                              return (
                                <img src={userProfile} className="MuiAvatar-circular" />
                              );
                            } else if (details.type === 'group') {
                              return (
                                <img src={groupImg} className="MuiAvatar-circular" />
                              );
                            } else if (details.type === 'page') {
                              return (
                                <img src={pageImg} className="MuiAvatar-circular" />
                              );
                            } else if (details.type === 'company') {
                              return (
                                <img src={companyImg} className="MuiAvatar-circular" />
                              );
                            } else if (details.type === 'supplier') {
                              return (
                                <img src={companyImg} className="MuiAvatar-circular" />
                              );
                            } else if (details.type === 'buyer') {
                              return (
                                <img src={userProfile} className="MuiAvatar-circular" />
                              );
                          }
                          })()}</>
                      )}
                  </IonAvatar>
                  <span className='result-user-option'>
                    <b className='fixed-textline2'>{details.name}</b> <span className='text-nowrap'>in {details.type}</span>
                  </span>
                </IonRow>
              </div>
            )
          })
        );
        if (options != null && options.length > 0) {
          options.push({
            value: 1,
            label: (
              <div>
                <IonRow className='full-width-row ion-justify-content-center' onClick={() => selectClickHandler(inputValue, 'ALL')}>
                  <span>
                    <b>{t('commonproperties.text3')}</b>
                  </span>
                </IonRow>
              </div>
            )
          });
        }
        return options;
      } else if (productsRes.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    }
    return '';
  };
  const selectClickHandler = (name, type, id) => {
    if (name != null) {
      const encodedData = encodedString(name);
      history.push('/searchFeeds/' + encodedData.replace('/', '&quot;') + '/' + type.toUpperCase());
    }
  };
  const CustomOption = (props) => {
    const { data, innerRef, innerProps } = props;
    return data.custom
      ? (
        <div ref={innerRef} {...innerProps}>
          link
        </div>
      )
      : (
        <components.Option {...props} />
      );
  };
  const onClickValue = (e) => {
    const encodeddata = encodedString(e.target.value);
    if (e.key === 'Enter' || e.key === 'Tab') {
      if (e.target.value.trim().length > 0) {
        history.push('/searchFeeds/' + encodeddata.replace('/', '&quot;') + '/ALL');
      }
    }
  };

  const getNotificationCount = async (url, type) => {
    const response = await callFor(
      url,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const jsonResponse = await response.json();
      if (jsonResponse.data !== null) {
        if (type === 1) {
          setNotificationCount(jsonResponse.data);
        } else if (type === 3) {
          setConnectionCount(jsonResponse.data);
        }
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const onSearchFocus = () => {
    setTextMsg('');
  };

  return (
    <>
      <header className={isActive ? 'show-mobile-menu' : null}>
        {getToken() ? (
          <><IonRow className="container">
            <div className="row full-width-row top-header position-relative">
              <IonRow className="for-mobile-grid m-logo-menu">
                <div className="show-mobile mobile-m-icon" onClick={async () => await menuController.toggle()}>
                  {userProfileData.profileImg
                    ? <img onError={(ev) => { ev.target.src = User; }} src={userProfileData.profileImg}></img>
                    : <img src={User}></img>}
                </div>
                <Link to='/' className='d-lg-block d-none'>
                  <img src={logo} alt="Zyapaar" className='logo' />
                </Link>
              </IonRow>
              <>
                <IonCol size-lg="4" size-md="12" size-sm="12" size-xs="11" className="icon-input-left autoSearchContent">
                  <AsyncSelect
                    placeholder={t('appproperties.text92')}
                    id="comments"
                    name="comments"
                    onFocus={onSearchFocus}
                    value={textmsg ? { label: textmsg } : { label: t('appproperties.text92') }}
                    cacheOptions
                    loadOptions={promiseOptions}
                    className="header-search"
                    defaultOptions
                    onKeyDown={onClickValue}
                    styles={customStyles}
                    components={{ Option: CustomOption }}
                    noOptionsMessage={() => t('nodatafound.text11')} />
                  <IonIcon
                    icon={searchOutline}
                    size="small"
                    className="header-menu-img" />
                </IonCol>

                <IonCol
                onClick={() => clickHandler('/chat/' + userProfileData.id)}
                  className='drawerMenu position-absolute d-block d-lg-none'
                >
                  <IonIcon icon={chatbubblesOutline} size='large' className='text-grey' />
                </IonCol>

                <IonRow className="header-row-margin-left head-menu">
                  <IonCol className='mobile-bottom-menu d-flex ion-align-items-center'>
                    <IonList
                      lines="none"
                      className="row pb-1"
                    >
                      <IonLabel
                        className="ion-no-margin "
                        id='home'
                        onClick={() => clickHandler('/home')}>
                        <span className="header-menu ion-justify-content-center" >
                          <IonIcon icon={homeOutline} className='font-22 color-theme' fill="red"></IonIcon>
                        </span>
                        <p className="ion-font-color">{t('appproperties.text93')}</p>
                      </IonLabel>

                      <IonLabel id='network' className="ion-no-margin" onClick={() => clickHandler('/network')}>
                        {ConnectionCount !== 0
                          ? <>
                            {ConnectionCount > 99
                              ? <span className='count'>99+</span>
                              : <span className='count'>{ConnectionCount}</span>}
                          </> : ''}
                        <span className="header-menu ion-justify-content-center">
                          <IonIcon icon={Network} className='font-24 color-theme rotateY'></IonIcon>
                        </span>
                        <p className="ion-font-color">{t('appproperties.text4')}</p>
                      </IonLabel>


                      <IonLabel id='mini' className="ion-no-margin">
                      {/* onClick={() => clickHandler('/network')} */}
                        <span className="header-menu ion-justify-content-center">
                          <IonIcon icon={Mini} className='font-24 color-theme rotateY'></IonIcon>
                        </span>
                        <p className="ion-font-color">Mini</p>
                      </IonLabel>

                    {/* </IonList>

                    <IonList
                      lines="none"
                      className="top-header pb-1 row"
                    > */}

                      <IonLabel
                        id='catalogue'
                        className="ion-no-margin catalogue-hover"
                        onClick={() => {
                          if (userProfileData.id !== undefined) {
                            if (userProfileData.entityId !== undefined && userProfileData.entityId !== null) {
                              clickHandler('/catalogue/' + userProfileData.id);
                            } else {
                              // history.push('/addnewcompany');
                              setLoginModal(true);
                            }
                          } else {
                            if (profileDetail.id !== undefined) {
                              if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                                clickHandler('/catalogue/' + profileDetail.id);
                              } else {
                                // history.push('/addnewcompany');
                                setLoginModal(true);
                              }
                            }
                          }
                        }}
                      >
                        <span className="header-menu ion-justify-content-center connections">
                          <img src={catalogue} alt='Catalogue' width='30' height='28' className='catalogue1' />
                          <img src={catalogueactive} alt='Catalogue' width='30' height='28' className='connection2' />
                          <img src={catalogueactive} alt='Catalogue' width='30' height='28' className='catalogue3' />
                        </span>
                        <p className="ion-font-color">{t('appproperties.text95')}</p>
                      </IonLabel>

                      <IonLabel
                        id='notification'
                        className="ion-no-margin"
                        onClick={() => clickHandler('/notification')}
                      >
                        {NotificationCount !== 0
                          ? <>
                            {NotificationCount > 99
                              ? <span className='count notify'> 99+</span>
                              : <span className='count notify'> {NotificationCount}</span>}
                          </> : ''}
                        <span className="header-menu ion-justify-content-center">
                          <IonIcon icon={notificationsOutline} className='font-24 color-theme'></IonIcon>
                        </span>
                        <p className="ion-font-color" >{t('appproperties.text96')}</p>
                      </IonLabel>

                      <IonLabel
                        className="ion-no-margin cursor-pointer dn-mobile"
                        onClick={(e) => present({ event: e.nativeEvent })}>
                        <span className="header-menu ion-justify-content-center">
                          <IonAvatar slot="start" className="header-menu-account-img">
                            {userProfileData.profileImg
                              ? <img onError={(ev) => { ev.target.src = User; }} src={userProfileData.profileImg} width="00" height="00" alt="User" />
                              : <img src={User} alt='User' />}
                          </IonAvatar>
                        </span>
                        <p className="ion-font-color">{t('appproperties.text97')}</p>
                      </IonLabel>
                    </IonList>
                  </IonCol>

                  {/** *********  Post Button *************/}

                  <div className='menu-post show-mobile'>
                    <div className='btn-post'>
                      <div className='fab-button'>
                        <IonLabel className="mx-auto ion-no-margin post-mobile-icon d-flex justfy-mobile-center align-items-center" onClick={() => {
                          if (userProfileData.entityId !== undefined && userProfileData.entityId !== null) {
                            setPostFlag(true);
                          } else {
                            // history.push('/addnewcompany');
                            setLoginModal(true);
                          }
                        }
                        }>
                          <span className="header-menu ion-justify-content-center">
                            <IonIcon icon={addCircleOutline}></IonIcon>
                          </span>
                          <p className="ion-font-color">{t('appproperties.text87')}</p>
                        </IonLabel>
                      </div>
                    </div>
                  </div>

                  {postFlag
                    ? <Post origin="USER" originId={0} postFlag={postFlag} setPostFlag={setPostFlag} />
                    : ''}
                </IonRow>
              </>
            </div>
          </IonRow>
          </>
        ) : (
          <IonRow className="container">
            <div className="row full-width-row top-header">
              <IonRow className="for-mobile-grid">
                <Link to='/'><img src={logo} alt="Zyapaar" className='logo' /></Link>
              </IonRow>
            </div>
          </IonRow>
        )}
      </header>
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}
    </>
  );
};
export default Header;
