/* eslint-disable multiline-ternary */
/* eslint-disable react/prop-types */

import { IonCol, IonRow } from '@ionic/react';
import React, { useEffect }  from 'react';
import { useTranslation } from 'react-i18next';
import { Link, NavLink } from 'react-router-dom';
import logo from '../../assets/img/new-web/logo.svg';
import logocoin from '../../assets/img/new-web/zyapaar-icon.png';

export default function Headerwb() {
  const { t } = useTranslation();
  // useEffect(() => {
  //   const header = document.getElementById("myNavbar");
  //   const scrollCallBack = window.addEventListener("scroll", () => {
  //       if (window.scrollY > 60) {
  //           header.classList.add("is-sticky");
  //       } else {
  //           header.classList.remove("is-sticky");
  //       }
  //   });
  //   return () => {
  //     window.removeEventListener("scroll", scrollCallBack);
  //   };
  // }, []);
  if (window.location.pathname === '/') {
    document.getElementsByTagName('html')[0].classList.add('homstatic');
  } else if (window.location.pathname.includes('registration')) {
    document.getElementsByTagName('html')[0].classList.add('registration');
  } else {
    document.getElementsByTagName('html')[0].classList.remove('homstatic');
    document.getElementsByTagName('html')[0].classList.remove('registration');
  }

  return (
    <>
     <header className='home-header'>
        <div className="container">
          <IonRow className="align-items-center">
            <IonCol sizeSm='6' sizeXs='8' className='d-flex align-items-center justify-content-flex-start'>
              <div className="me-lg-5 me-2">
              <Link to='/'>
                <img src={logo} alt='Logo' className="d-none d-lg-block" />
                <img src={logocoin} alt='Logo' className="d-lg-none d-block" width='40' />
                </Link>
              </div>
              <div className="me-lg-5 me-0">
                <ul className="d-flex align-items-center justify-content-center mb-0">
                  <li><NavLink to="/content/about-us" activeClassName="active" className="text-decoration-none">{t('commonproperties.text17')}</NavLink></li>
                  <li><NavLink to="/content/career" activeClassName="active" className="text-decoration-none">Career</NavLink></li>
                  <li><NavLink to="/content/contact-us" activeClassName="active" className="text-decoration-none">Contact</NavLink></li>
                </ul>
              </div>
            </IonCol>
            <IonCol sizeSm='6' sizeXs='4' className='justify-content-end d-flex'>
              <Link className='btn-login text-nowrap' to='/login'> Sign Up / Login </Link>
            </IonCol>
          </IonRow>
        </div>
      </header>
    </>
  );
}