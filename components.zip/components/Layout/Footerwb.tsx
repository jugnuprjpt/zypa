import React from 'react';
import indiaflag from '../../assets/img/new-web/indian-flag.svg';
import AndroidApp from '../../assets/img/new-web/android-app.svg';
import IosApp from '../../assets/img/new-web/ios-app.svg';
import Scan from '../../assets/img/new-web/zyapaar-scan.svg';
import logocoin from '../../assets/img/new-web/zyapaar-icon.png';
import { IonCol, IonRow } from '@ionic/react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const Footer = () => {
  const { t } = useTranslation();
  return (

    <footer className='home-footer'>

        <div className="container position-relative">
          <IonRow className="align-items-center py-3">
            <IonCol sizeMd='8' sizeSm='12' sizeXs='12' className='d-flex align-items-center justify-content-flex-start newfooter-menu'>
              <IonRow className="w-100">
                <IonCol sizeSm='2' sizeXs='6' className='justify-content-center d-flex d-none d-lg-block'>
                  <img src={logocoin} alt='Zyapaar Coin' width={50} className="d-lg-block" />
                </IonCol>
                <IonCol sizeMd='3' sizeSm='4' sizeXs='4'>
                  <ul className="align-items-center justify-content-center mb-0">
                    <li><Link to="/content/about-us" className="text-decoration-none">{t('commonproperties.text17')}</Link></li>
                    <li><Link to="/blog" className="text-decoration-none">Blog</Link></li>
                    <li><Link to="/content/contact-us" className="text-decoration-none">Contact</Link></li>
                    <li><a href='mailto:nirav@zyapaar.com' className="text-decoration-none">Press Inquiry</a></li>
                  </ul>
                </IonCol>
                <IonCol sizeMd='3' sizeSm='4' sizeXs='4'>
                  <ul className="align-items-center justify-content-center mb-0">
                    <li><Link to="/content/career" className="text-decoration-none">Jobs</Link></li>
                    <li><Link to="/content/exhibition" className="text-decoration-none">Exhibition</Link></li>
                    <li><Link to="/content/faq" className="text-decoration-none">FAQ's</Link></li>
                    <li><Link to="/content/privacy-policy" className="text-decoration-none">Privacy</Link></li>
                    <li><Link to="/content/terms" className="text-decoration-none">Terms</Link></li>
                  </ul>
                </IonCol>
                <IonCol sizeMd='3' sizeSm='4' sizeXs='4'>
                  <ul className="align-items-center justify-content-center mb-0">
                    <li><a href="https://www.facebook.com/zyapaar/" target='_blank' rel="noopener noreferrer" className="text-decoration-none">Facebook</a></li>
                    <li><a href="https://www.linkedin.com/company/lets-talk-business-pvt-ltd" rel="noopener noreferrer" target='_blank' className="text-decoration-none">Linkedin</a></li>
                    <li><a href="https://instagram.com/zyapaar?igshid=YmMyMTA2M2Y=" target='_blank' rel="noopener noreferrer" className="text-decoration-none">Instagram</a></li>
                    <li><a href="https://www.youtube.com/channel/UCqXoM4Olk8UyxwEGVialg6g" target='_blank' rel="noopener noreferrer" className="text-decoration-none">YouTube</a></li>
                  </ul>
                </IonCol>
              </IonRow>
            </IonCol>
            <IonCol sizeMd='4' sizeSm='12' sizeXs='12' className='app-icon d-flex flex-column hydrated'>
              <div>
                <div className='justify-content-center d-md-flex pb-2 d-none'>
                  <img src={Scan} alt='Zyapaar Scan' width={100} className="d-lg-block" />
                </div>
                <div className='align-items-center d-flex mt-4 mt-lg-0'>
                  Also available on
                  <a href='https://apps.apple.com/in/app/zyapaar-b2b-networking-app/id1622370449' target='_blank' rel="noopener noreferrer"><img src={IosApp} alt='App Store' width={40} className="d-lg-block" /></a>
                  <a href='https://play.google.com/store/apps/details?id=com.zyapaar.mobile' target='_blank' rel="noopener noreferrer"><img src={AndroidApp} alt='Play Store' width={40} className="d-lg-block" /></a>
                </div>
              </div>
            </IonCol>
          </IonRow>

          <IonRow className="align-items-center footer-border">
            <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='d-flex align-items-center justify-content-flex-start justfy-mobile-center'>
              Copyright © 2022. Lets Talk Business Pvt. Ltd. All rights reserved.
            </IonCol>

            <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='justify-lg-content-end d-flex justfy-mobile-center'>
              Made in &nbsp;<img src={indiaflag} alt='Indian Flag' className="d-lg-block" />
            </IonCol>
          </IonRow>
        </div>
      </footer>
  );
};
export default Footer;
