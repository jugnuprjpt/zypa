import { IonFooter, IonRow } from '@ionic/react';
import React from 'react';
import { useTranslation } from 'react-i18next';

const Footer = () => {
  const { t } = useTranslation();
  return (
    <IonFooter className="footer ion-justify-content-center pb-0 mb-o">
      <IonRow className="copyright-text ion-justify-content-center text-center">
        <IonRow className="copyright-text">
        {t('appproperties.text103a')} {new Date().getFullYear()} {t('appproperties.text103b')}
        </IonRow>
        <IonRow className="copyright-text">
          <ul className="list-unstyled footer-items">
            <li className="footer-link" ><a href='https://www.zyapaar.com/content/privacy-policy' target="_blank">{t('appproperties.text132')}</a></li>
            <li className="footer-link" ><a href='https://www.zyapaar.com/content/terms' target="_blank">{t('appproperties.text133')}</a></li>
          </ul>
        </IonRow>
      </IonRow>
    </IonFooter>
  );
};
export default Footer;