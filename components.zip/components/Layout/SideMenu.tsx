import React, { useEffect, useState } from 'react';
import { IonMenu, IonHeader, IonContent, IonList, IonItem, IonRouterOutlet, IonIcon, IonRow, IonAvatar, IonMenuToggle } from '@ionic/react';
import { arrowRedoOutline, businessOutline, documentTextOutline, listOutline, logOutOutline, settingsOutline } from 'ionicons/icons';
import { useHistory } from 'react-router-dom';
import { getlocalStore, setLocalStore } from '../../util/Common';
import User from '../../assets/img/icons/user.svg';
import ConectionsIconFill from '../../assets/img/conections-fill.svg';
import language from '../../assets/img/language.svg';
import Faq from '../../assets/img/faqs.png';
import BusinessLeads from '../../assets/img/business-leads.png';
import LikeIcon from '../../assets/img/like-icon-dark.svg';
import TeamsIcon from '../../assets/img/icons/teams-icon.svg';
import callFor from '../../util/CallFor';
import { Device } from '@capacitor/device';
import { Share } from '@capacitor/share';
import GlobalProperties from '../../constants/GlobalProperties';
import { useTranslation } from 'react-i18next';

const SidebarMenu = () => {
  const { t } = useTranslation();
  const [deviceInfo, setDeviceInfo] = useState();
  const [userProfileData, setUserProfileData] = useState([]);
  const history = useHistory();
  const [profileDetailsCount, setProfileDetailsCount] = useState([{ connections: 0, views: 0, postView: 0, following: 0, follower: 0, post: 0 }]);

  const clickHandler = (page: string) => {
    history.push(page);
  };

  const logOut = () => {
    localStorage.clear();
    setLocalStore('showHomeModel', false);
    history.push('/login');
  };

  useEffect(async () => {
    setDeviceInfo(await Device.getInfo());
    if (getlocalStore('token') !== null) {
      getUserDetails();
      getUserProfileDetailCount();
    }
  }, []);

  const getUserDetails = async () => {
    const response = await callFor('api/v1.1/user', 'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response !== null) {
        setUserProfileData(json1Response.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      setLocalStore('showHomeModel', false);
      history.push('/login');
    }
  };

  const getUserProfileDetailCount = async () => {
    const stateres = await callFor(
      'api/v1.1/users/overview',
      'GET',
      null,
      'Auth'
    );
    if (stateres.status === 200) {
      const json1Response = await stateres.json();
      if (json1Response.data !== null) {
        setProfileDetailsCount(json1Response.data);
      }
    } else if (stateres.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const sidebarmenuClass = (type) => {
    if (type === 'addClass') {
      document.getElementsByTagName('html')[0].classList.add('sidebar-menu-show');
    } else {
      document.getElementsByTagName('html')[0].classList.remove('sidebar-menu-show');
    }
  };
  const referLinkHandler = async () => {
    const deviceDetails = await Device.getInfo();
    if (deviceDetails.platform === 'ios' || deviceDetails.platform === 'android') {
      await Share.share({
        text: "Hi! I have joined Zyapaar, India's first B2B networking platform that helps you connect with buyers, sellers and service providers across India. Besides, Zyapaar is absolutely free So join now. Ab Vyapaar nahi Zyapaar Karo!",
        url: 'https://www.zyapaar.com/download/' + userProfileData.name
      });
    }
  };
  return (
    <>
      <IonMenu side="start" menuId="first" contentId="mainmenu" className='mobile-sidemenu' onIonDidOpen={() => sidebarmenuClass('addClass')} onIonDidClose={() => sidebarmenuClass('removeClass')}>
        <IonMenuToggle>
          <IonHeader className='mm-prfile-name'>
            <div className='col-left' onClick={() => clickHandler('/profile/' + userProfileData.id)}>
              <IonAvatar slot="start" className="header-menu-account-img">
                {
                  userProfileData.profileImg
                    ? <img onError={(ev) => { ev.target.src = User; }} src={userProfileData.profileImg} width="00" height="00" alt="Home" />
                    : <img src={User} alt='Home' />
                }
              </IonAvatar>
              <IonRow className='display-grid'>
                <span className='name'>{userProfileData.name}</span>
                {/* <div className='d-flex menu-pro-file'>
                                    <span className='name'>{t('appproperties.text342')} <span>({profileDetailsCount.views})</span></span>
                                    <span className='name'>{t('userproperties.text3')} <span>({profileDetailsCount.connections})</span></span>
                                </div> */}
              </IonRow>
            </div>
          </IonHeader>
        </IonMenuToggle>
        <IonContent className='mid-content'>
          <IonMenuToggle>
            <IonList lines="none">
              <IonItem className='d-flex align-items-center leader-color'>
                <img src={BusinessLeads} alt="Faq's" width='25  ' className='me-3' /><div className='font-16 font-bold'>Leads</div><span className="count notify">15</span>
              </IonItem>
              <IonItem onClick={() => clickHandler('/myActivity/' + userProfileData.id + '/' + userProfileData.name)} className='d-flex align-items-center'>
                <IonIcon className='icon-mobile' icon={listOutline}></IonIcon> {t('appproperties.text343')}
              </IonItem>
              <IonItem onClick={() => clickHandler('/companyList/' + userProfileData.id)} className='d-flex align-items-center'>
                <IonIcon className='icon-mobile' icon={businessOutline}></IonIcon> {t('appproperties.text347')}
              </IonItem>
              {userProfileData.entityId !== undefined && userProfileData.entityId !== null
                ? <IonItem onClick={() => clickHandler('/teams/' + userProfileData.id + '/' + userProfileData.entityId)} className='d-flex align-items-center'>
                  <img src={TeamsIcon} alt='Teams' width='23' height='23' className='icon-mobile group-sideicon' />{t('appproperties.text17')}
                </IonItem>
                : ''}
              <IonItem onClick={() => clickHandler('/groups')} className='d-flex align-items-center'>
                <img src={ConectionsIconFill} alt='Conections' width='23' height='23' className='icon-mobile group-sideicon' />{t('appproperties.text345')}
              </IonItem>
              <IonItem onClick={() => clickHandler('/page')} className='d-flex align-items-center'>
                <IonIcon className='icon-mobile' icon={documentTextOutline}></IonIcon> {t('appproperties.text349')}
              </IonItem>
              <IonItem onClick={() => clickHandler('/recomdationList/' + userProfileData.id + '/' + userProfileData.name)} className='d-flex align-items-center'>
                <img src={LikeIcon} alt='Like Icon' width='22' className='me-4' /> {t('appproperties.text145')}
              </IonItem>
              <IonItem className='d-flex align-items-center leader-color' onClick={() => clickHandler('/language')}>
                <img src={language} alt="language" width='22' className='me-3' />  Language
              </IonItem>
              <IonItem onClick={() => clickHandler('/content/faq')} className='d-flex align-items-center leader-color'>
                <img src={Faq} alt="Faq's" width='22' className='me-3' /> FAQ's
              </IonItem>
              <IonItem onClick={() => clickHandler('/settings')} className='d-flex align-items-center'>
                <IonIcon className='icon-mobile' icon={settingsOutline}></IonIcon> {t('appproperties.text101')}
              </IonItem>
              <IonItem onClick={() => referLinkHandler()} className='d-flex align-items-center'>
                <IonIcon className='icon-mobile' icon={arrowRedoOutline}></IonIcon> {t('appproperties.text344')}
              </IonItem>
            </IonList>
          </IonMenuToggle>
        </IonContent>
        {deviceInfo !== undefined
          ? <>
            {deviceInfo.platform === 'android'
              ? <p className='ion-padding ps-4'>Version {GlobalProperties.androidAppVersion}</p>
              : deviceInfo.platform === 'ios' ? <p className='ion-padding ps-4'>Version {GlobalProperties.iosAppVersion}</p> : ''} </>
          : ''}
        <IonMenuToggle>
          <IonItem onClick={() => logOut()} className='d-flex align-items-center menu-footer'>
            <IonIcon className='icon-mobile' icon={logOutOutline}></IonIcon>{t('appproperties.text102')}
          </IonItem>
        </IonMenuToggle>
      </IonMenu>
      <IonRouterOutlet id="mainmenu"></IonRouterOutlet>
    </>
  );
};
export default SidebarMenu;
