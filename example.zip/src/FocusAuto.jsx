import React, { useRef, useState } from 'react'
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

function FocusAuto() {
    const antic = useRef("");
    const [name,setName] = useState("")
    
    const handleEvenet =()=>{
        console.log(alert)
        setName("")
        antic.current.focus()

    }
  return (
    <>
    <h1>Welcome</h1>
    {/* <input ref={antic} type="text" onClick={(e)=>{setName(e.target.value)}}/> */}
    <ReactQuill  ref={antic} type="text" onClick={(e)=>{setName(e.target.value)}} />;
    <button onClick={handleEvenet}>Click</button>
    </>
  )
}

export default FocusAuto