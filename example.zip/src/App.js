import logo from './logo.svg';
import './App.css';
import FocusAuto from './FocusAuto';

function App() {
//   const getVideoDuration = (file) =>
//   new Promise((resolve, reject) => {
//     const reader = new FileReader();
//     reader.onload = () => {
//       const media = new Audio(reader.result);
//       media.onloadedmetadata = () => resolve(media.duration);
//     };
//     reader.readAsDataURL(file);
//     reader.onerror = (error) => reject(error);
//   });

// const handleChange = async (e) => {
//   const duration = await getVideoDuration(e.target.files[0]);
//   document.querySelector("#duration").innerText = `Duration: ${duration} Second`;

  
// };

  return (
    <div className="App">
      <FocusAuto></FocusAuto>
     {/* <div>
  <input type="file" onChange={handleChange} />
  <p id="duration">Duration: </p>
</div> */}
    </div>
  );
}

export default App;






