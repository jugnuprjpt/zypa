import { IonCard, IonCol, IonRow } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useParams } from 'react-router';
import FeedCard from '../components/common/FeedCard';
import ProfileDetails from '../components/feed/profile/ProfileDetails';
import CallFor from '../util/CallFor';
import MetaTags from 'react-meta-tags';
import { getFeedData } from '../Redux/reducers/feeds';
import SkeletonFeedComon from '../components/common/skeleton/SkeletonFeedComon';
const ViewFeedDetails = () => {
  const { feedId } = useParams();
  const history = useHistory();
  const getFeedDatas = useSelector(getFeedData);
  const dispatch = useDispatch();
  const [postDelMsg, setPostDelMsg] = useState();
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    getFeedDatafun();
  }, []);

  const getFeedDatafun = async() => {
    setLoading(true);
    const response = await CallFor('api/v1/feed/' + feedId, 'GET', null, 'Auth');
    if (response.status === 200) {
      const jsonResponse = await response.json();
      if (jsonResponse.data !== '' && jsonResponse.data !== null) {
        dispatch({
          type: 'add_feedsData',
          Feeds: [jsonResponse.data]
        });
      } else {
        dispatch({
          type: 'add_feedsData',
          Feeds: []
        });
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 400) {
      const jsonResponse = await response.json();
      setPostDelMsg(jsonResponse.error.message);
      dispatch({
        type: 'add_feedsData',
        Feeds: []
      });
    } else if (response.status === 404) {
      const jsonResponse = await response.json();
      setPostDelMsg(jsonResponse.error.message);
      dispatch({
        type: 'add_feedsData',
        Feeds: []
      });
    } else if (response.status === 500) {
      dispatch({
        type: 'add_feedsData',
        Feeds: []
      });
    }
    setLoading(false);
  };
  return (
    <><MetaTags>
      <title>
       Zyapaar - view feed
      </title>
      {/* <meta name="description" content='Zyapaar - view feed' /> */}
      <meta property="og:title" content='Zyapaar - view feed' />
      {/* <meta property="og:site_name" content="Zyapaar" /> */}
      <meta property="og:url" content={window.location.href} />
      <meta property="og:image" content='https://zyapaar-image-test.s3.ap-south-1.amazonaws.com/1652873326512_zyapaar.png' key="image" />
    </MetaTags>
    <IonRow className="plane-bg">
        <IonRow className="container">
          <div className="row full-width-row main-page-content-row">
            <IonCol
              size-md="12"
              size-lg="4"
              size-xs="12"
              className="left-col col-mobile-none ion-no-padding"
            >
              <div className='sidebar-main'>
                <ProfileDetails />
              </div>
            </IonCol>
            <IonCol size-lg="8" size-md="12" size-xs="12" className="right-col" >
         {loading
           ? <SkeletonFeedComon column={1}/>
           : getFeedDatas[0] != null
             ? <FeedCard feeds={getFeedDatas[0]} feedKey={0} origin = 'USER' originId='0'/>
             : <>
             {postDelMsg
               ? <IonCard className='ion-padding ion-no-margin ion-margin-bottom ion-margin-top'>
                    {postDelMsg}
                  </IonCard>
               : ''}
                </>
              }
             </IonCol>
        </div>
        </IonRow>
      </IonRow></>
  );
};
export default ViewFeedDetails;
