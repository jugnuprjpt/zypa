import React, { useEffect } from 'react';

import {
  isAndroid,
  isIOS
} from 'react-device-detect';
import { useParams } from 'react-router';

const DownloadApp = () => {
  const { code } = useParams();
  useEffect(() => {
    if (code) {
      localStorage.setItem('refcode', JSON.stringify(code))
    }
  }, [])


  if (isAndroid) {
    window.location.href =
      'https://play.google.com/store/apps/details?id=com.zyapaar.mobile';
  } else if (isIOS) {
    window.location.href =
      'https://apps.apple.com/in/app/zyapaar-b2b-networking-app/id1622370449';
  } else {
    window.location.href =
      'https://www.zyapaar.com/';
  }
  return (
    <p></p>
  );
};
export default DownloadApp;
