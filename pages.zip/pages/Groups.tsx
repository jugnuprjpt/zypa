/* eslint-disable multiline-ternary */
/* eslint-disable react/no-unescaped-entities */
/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCol,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  IonTextarea
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import GroupList from '../components/groups/GroupList';
import { close, chevronForward, arrowBack, pencilOutline, trashBinOutline } from 'ionicons/icons';
import groupImg from '../assets/img/group-profile-placeholder.png';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import callFor from '../util/CallFor';
import { useHistory } from 'react-router';
import Select from 'react-select';
import MetaTags from 'react-meta-tags';
import Footer from '../components/Layout/Footer';
import PopoverCommon from '../components/common/PopoverCommon';
import SkeletonComonInvitaion from '../components/common/skeleton/SkeletonComonInvitaion';
import InterestedScrollCommon from '../components/common/InterestedScrollCommon';
import ButtonComponent from '../components/common/ButtonComponent';
import InviteUserCommon from '../components/myPage/InviteUserCommon';
import CustomeFirebaseEvent from '../components/common/CustomFirebaseEvent';
import { Device } from '@capacitor/device';
import { useTranslation } from 'react-i18next';

const customStyles = {
  control: (provided: any) => ({
    ...provided,
    height: 46,
    background: '#fff !important',
    border: 'none !important',
    '&:focus': {
      border: '1px solid #0763b2'
    }
  }),
  multiValue: (styles, { data }) => {
    return {
      ...styles,
      padding: 4,
      backgroundColor: '#0073ae!important',
      borderRadius: '50px'
    };
  },
  multiValueLabel: (styles, { data }) => ({
    ...styles,
    color: '#fff'
  }),
  multiValueRemove: (styles, { data }) => ({
    ...styles,
    color: '#0073ae!important',
    borderRadius: '50px',
    margin: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    ':hover': {
      backgroundColor: '#fff'
    }
  }),
  indicatorSeparator: () => { }, // removes the "stick"
  dropdownIndicator: (defaultStyles: any) => ({
    ...defaultStyles,
    '& svg': { display: 'none' }
  })
};
const Groups = () => {
  const { t } = useTranslation();
  const [groupFormState, setGroupFormState] = useState({});
  const [diviceInfo, setDiviceInfo] = useState();
  const [invitationModal, setInvitationModal] = useState(false);
  const [modalData, setModalData] = useState({});
  const [industry, setIndustry] = useState([]);
  const [createDisabled, setCreateDisabled] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [inviteConnection, setInviteConnection] = useState([]);
  const history = useHistory();
  const [groupFile, setGroupFile] = useState('');
  const [adminInvite, setAdminInvite] = useState([]);
  const [imageView, setImageView] = useState(false);
  const [inviteMemberBtnClass, setInviteMemberBtnClass] = useState('ion-button-color');
  const [inviteAdminGroupClass, setInviteAdminBtnClass] = useState('category-btn-color');
  const [type, setType] = useState();
  const [characterCount, setCharacterCount] = useState(0);
  const [ruleCharacterCount, setRuleCharacterCount] = useState(0);
  const maxAboutCount = 500;
  const maxRuleCount = 500;
  const validationSchema = Yup.object().shape({
    name: Yup.string().trim().required(t('groupproperties.text8'))
      .test(
        'len',
        t('groupproperties.text9'),
        (val) => val && val.toString().length >= 1
      )
      .test(
        'len',
        t('groupproperties.text10'),
        (val) => val && val.toString().length <= 250
      ),
    // industry: Yup.string().required('Industry is Required'),
    // industry: Yup
    //   .object()
    //   .shape({
    //     label: Yup.string().required('Industry is required'),
    //     value: Yup.string().required('Industry is required')
    //   })
    //   .nullable() // for handling null value when clearing options via clicking "x"
    //   .required('Industry is required'),
    // discoverability: Yup.string().required('Group Discoverability is Required'),
    about: Yup.string().trim().nullable(true).optional().notRequired()
      .test(
        'len',
        t('groupproperties.text11'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length >= 10;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('groupproperties.text12'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length <= 500;
          } else {
            return true;
          }
        }
      ),
    rule: Yup.string().trim().nullable(true).optional().notRequired()
      .test(
        'len',
        t('groupproperties.text11'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length >= 10;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('groupproperties.text12'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length <= 500;
          } else {
            return true;
          }
        }
      ),
    location: Yup
      .string().trim().nullable(true).notRequired().optional()
      .matches(/^[A-Za-z0-9@&-\s][A-Za-z0-9@&-\s]*$/, { message: t('groupproperties.text15'), excludeEmptyString: true }).test(
        'len',
        t('groupproperties.text16'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().trim().length <= 100;
          } else {
            return true;
          }
        }
      )
  });
  const [loading, setLoading] = useState(false);
  const [isValid, setIsValid] = useState(true);
  const [classMobile, setclassMobile] = useState(false);
  const {
    register,
    handleSubmit,
    setError,
    clearErrors,
    control,
    resetField,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });
  const userformDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.checked !== undefined) {
      setGroupFormState({
        ...groupFormState,
        [event.target.name]: event.target.checked
      });
    } else {
      if (event !== null && event.target !== undefined) {
        if (event.target.value !== undefined && event.target.value.length > 0) {
          event.target.classList.add('input-fill');
        } else {
          event.target.classList.remove('input-fill');
        }
        setGroupFormState({
          ...groupFormState,
          [event.target.name]: event.target.value
        });
      }
    }
  };

  const aboutChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value !== null && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setGroupFormState({
        ...groupFormState,
        about: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value != null) {
      setCharacterCount(event.target.value.length);
    }
  };
  const ruleChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value !== null && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setGroupFormState({
        ...groupFormState,
        rule: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value != null) {
      setRuleCharacterCount(event.target.value.length);
    }
  };

  const uploadCompanylogoHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        setIsValid(false);
        // setCreateDisabled(true);
      } else {
        if (event.target.files[0].size > 3145728) {
          setError('upload', {
            type: 'required',
            message: t('commonproperties.text2')
          });
          // setCreateDisabled(true);
          setIsValid(false);
        } else {
          setIsValid(true);
          clearErrors('upload');
          resetField('upload');
          // setCreateDisabled(false);
        }
      }
      setGroupFile(file1);
      setImageView(true);
    }
  };

  const [intrestGroups, setIntrestGroup] = useState([]);
  useEffect(async() => {
    // getinvitedlist(0, false, 'admin');
    viewRecursivegetInvitationList('admin');
    getIndustry();
    viewRecursivegetGroupDataaList();
    setDiviceInfo(await Device.getInfo());
  }, []);

  const getinvited = async(page, type) => {
    setType(type);
    const response = await callFor(
      'api/v1.1/group/request/' + type,
      'POST',
      '{"page": ' + page + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content.length > 0) {
        return json1Response.data.content;
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    return [];
  };

  const submitHandle = () => {
    if (isValid && industryBlure()) {
      groupSubmitHandler();
    } else {
      imgValidactionHandler();
    }
  };
  const getConnectionList = async(page: string | number) => {
    const response = await callFor(
      'api/v1.1/connection/list/ALL',
      'POST',
      '{"page": ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      return json1Response.data.content;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
      return [];
    }
  };
  const groupSubmitHandler = async() => {
    // if (imgValidactionHandler() && isValid) {
    setCreateDisabled(true);
    const logo = document.getElementById('upload');
    const industryName = document.formName.elements.industry.value;
    let groupNameData = '';
    let groupLocationData = '';
    let groupAboutData = '';
    let groupRuleData = '';
    if (groupFormState.name !== undefined && groupFormState.name !== null) {
      groupNameData = groupFormState.name.trim();
    }
    if (groupFormState.location !== undefined && groupFormState.location !== null) {
      groupLocationData = groupFormState.location.trim();
    }
    if (groupFormState.about !== undefined && groupFormState.about !== null) {
      groupAboutData = groupFormState.about.trim();
    }
    if (groupFormState.rule !== undefined && groupFormState.rule !== null) {
      groupRuleData = groupFormState.rule.trim();
    }
    const groupData = { name: groupNameData, industry: industryName, location: groupLocationData, about: groupAboutData, rule: groupRuleData };
    const data = new FormData();
    data.append('logo', logo.files[0]);
    // data.append('group', JSON.stringify(groupFormState));
    data.append('group', JSON.stringify(groupData));

    const response = await callFor(
      'api/v1.1/groups',
      'POST',
      data,
      'authWithoutContentType'
    );
    if (response.status === 201) {
      const datares = await response.json();
      const inviteData = await getConnectionList(0);
      if (inviteData.length > 0) {
        const data = {};
        data.id = datares.data.id;
        data.name = datares.data.name;
        setModalData(data);
        setInviteConnection(inviteData);
        setInvitationModal(true);
      } else {
        history.push('/groups');
        setShowModal(false);
      }
      setGroupFormState({});
      setGroupFile('');
      clearErrors();
      setRuleCharacterCount(0);
      setCharacterCount(0);
      resetField();
      // openModelWithClearState();
      CustomeFirebaseEvent('groups_event', diviceInfo);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 400) {
      const dataress = await response.json();
      dataress.error.errors.map((details) => {
        setError(details.field, {
          type: 'server',
          message: details.message
        });
      });
    }
    setCreateDisabled(false);
    // } else {
    //   imgValidactionHandler();
    // }
  };

  const openModelWithClearState = () => {
    setShowModal(true);
    setGroupFormState({});
    setGroupFile('');
    // setIndustry([]);
    // clearErrors();
    clearErrors();
    setRuleCharacterCount(0);
    setCharacterCount(0);
    // resetField('about');
    // resetField('rule');
    resetField();
  };
  const [count, setCount] = useState();
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [requestloading, setRequestLoading] = useState(false);
  const getinvitedlist = async(page, scrolling, type) => {
    if (!scrolling) {
      setRequestLoading(true);
    }
    setType(type);
    if (type === 'user') {
      setInviteMemberBtnClass('ion-button-color');
      setInviteAdminBtnClass('category-btn-color');
    } else {
      setInviteMemberBtnClass('category-btn-color');
      setInviteAdminBtnClass('ion-button-color');
    }
    const response = await callFor(
      'api/v1.1/group/request/' + type,
      'POST',
      '{"page": ' + page + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (scrolling) {
        if (json1Response.data.content.length > 0) {
          setAdminInvite([
            ...adminInvite,
            ...json1Response.data.content
          ]);
        } else {
          setInfiniteDisabled(true);
        }
      } else {
        setAdminInvite(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setCount(page + 1);
    if (!scrolling) {
      setRequestLoading(false);
    }
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getinvitedlist(count, true, type);
      ev.target.complete();
    }, 500);
  };
  const invitationAcceptBtnHandler = async(type, id) => {
    const response = await callFor(
      'api/v1.1/group/request/' + type + '/' + id,
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setAdminInvite(adminInvite.filter((item) => item.id !== id));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const getIndustry = async() => {
    const response = await callFor('api/v1.1/industries', 'GET', null, 'Auth');
    if (response.status === 200) {
      const json1Response = await response.json();
      const states = await json1Response.data.map(
        (d: { subIndustryID: any; subindustryID: any }) => ({
          value: d.subIndustryID,
          label: d.subIndustry
        })
      );
      setIndustry(states);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const cancelBtnHandler = async(id) => {
    const response = await callFor(
      'api/v1.1/group/request/cancle/' + id,
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setAdminInvite(adminInvite.filter((item) => item.id !== id));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  const imgValidactionHandler = () => {
    const logo = document.getElementById('upload');
    if (logo === '') {
      clearErrors('upload');
    }
    let isUserLogoValid = true;
    if (logo.files[0] !== undefined && logo.files[0] !== '') {
      if (logo.files[0].size > 3145728) {
        setError('upload', {
          type: 'required',
          message:t('commonproperties.text2')
        });
        isUserLogoValid = false;
      }
      if (!logo.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        isUserLogoValid = false;
      }
    }

    if (isUserLogoValid) {
      setIsValid(true);
      return true;
    } else {
      setIsValid(false);
      return false;
    }
  };
  // const deleteImg = () => {
  //   setGroupFile();
  //   document.getElementById('upload').value = '';
  //   clearErrors('upload');
  // };
  const imageEditHandle = () => {
    setImageView(false);
    // uploadCompanylogoHandleChange()
  };
  const deleteImageHandle = () => {
    setIsValid(true);
    setGroupFile('');
    document.getElementById('upload').value = '';
    clearErrors('upload');
    setImageView(true);
  };
  const addImg = () => {
    setImageView(false);
  };
  const industrySelectHandler = (event) => {
    if (event !== null && event.value !== undefined) {
      setGroupFormState({ ...groupFormState, industry: event.value });
      if (event.value !== 0) {
        setTimeout(function() {
          clearErrors('industry');
        }, 1);
      }

      // industryBlure();
    } else {
      setGroupFormState({ ...groupFormState, industry: '' });
      // industryBlure();
    }
    clearErrors('industry');
  };
  const industryBlure = () => {
    if (groupFormState.industry !== undefined) {
      if (groupFormState.industry.length === 0) {
        setError('industry', {
          type: 'required',
          message: t('groupproperties.text17')
        });
        return false;
      } else {
        // resetField('industry');
        clearErrors('industry');
        return true;
      }
    } else if (groupFormState.industry === undefined) {
      setError('industry', {
        type: 'required',
        message: t('groupproperties.text17')
      });
      return false;
    }
  };
  const removeOverLay = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const addClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.add('imageHover');
  };
  const removeClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const addMobileCss = () => {
    setclassMobile(true);
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  };
  const removeMobileCss = () => {
    setclassMobile(false);
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  };
  const getRecursiveGroupDataaList = async(page: string | number) => {
    const response = await callFor(
      'api/v1.1/suggestions/groups',
      'POST',
      '{"page": ' + page + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      return json1Response.data.content;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
      return [];
    }
  };
  const viewRecursivegetInvitationList = async(type) => {
    setType(type);
    if (type === 'user') {
      setInviteMemberBtnClass('ion-button-color');
      setInviteAdminBtnClass('category-btn-color');
    } else {
      setInviteMemberBtnClass('category-btn-color');
      setInviteAdminBtnClass('ion-button-color');
    }
    const data = await getinvited(0, type);
    if (data.length > 0) {
      const data1 = await getinvited(1, type);
      if (data1.length > 0) {
        setAdminInvite([...data, ...data1]);
        setCount(2);
      } else {
        setAdminInvite(data);
        setInfiniteDisabled(false);
      }
    } else {
      setAdminInvite([]);
      setInfiniteDisabled(false);
    }
  };
  const viewRecursivegetGroupDataaList = async() => {
    const data = await getRecursiveGroupDataaList(0);
    if (data !== undefined && data.length > 0) {
      const data1 = await getRecursiveGroupDataaList(1);
      if (data1.length > 0) {
        const data2 = await getRecursiveGroupDataaList(2);
        if (data2.length > 0) {
          const data3 = await getRecursiveGroupDataaList(3);
          if (data3.length > 0) {
            setIntrestGroup([...data, ...data1, ...data2, ...data3]);
            setCountComon(4);
          } else {
            setIntrestGroup([...data, ...data1, ...data2]);
            setInfiniteDisabledComon(true);
          }
        } else {
          setIntrestGroup([...data, ...data1]);
          setInfiniteDisabledComon(true);
        }
      } else {
        setIntrestGroup(data);
        setInfiniteDisabledComon(true);
      }
    } else {
      setInfiniteDisabledComon(true);
    }
    setRequestLoadingComon(false);
  };

  const [requestloadingComon, setRequestLoadingComon] = useState(true);
  const [isInfiniteDisabledComon, setInfiniteDisabledComon] = useState(false);
  const [countComon, setCountComon] = useState(0);
  const getGroupDataa = async(page, scrolling) => {
    if (!scrolling) {
      setRequestLoadingComon(true);
    }
    const responseData = await callFor(
      'api/v1.1/suggestions/groups',
      'POST',
      '{"page": ' + page + '}',
      'Auth'
    );
    if (responseData.status === 200) {
      const json1Response = await responseData.json();
      if (scrolling) {
        if (json1Response.data.content.length > 0) {
          setIntrestGroup([
            ...intrestGroups,
            ...json1Response.data.content
          ]);
        } else {
          setInfiniteDisabledComon(true);
        }
      } else {
        setIntrestGroup(json1Response.data.content);
      }
    } else if (responseData.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setCountComon(page + 1);
    if (!scrolling) {
      setRequestLoadingComon(false);
    }
  };
  const loadDataComon = (ev: any) => {
    setTimeout(() => {
      getGroupDataa(countComon, true);
      ev.target.complete();
    }, 500);
  };

  return (
    <>
      <MetaTags>
        <title>
          Zyapaar
        </title>
      </MetaTags>
      <IonRow className="plane-bg ">
        <IonRow className="container">
          <div className="row full-width-row main-page-content-row">
            <IonCol
              size-lg="4"
              size-md="12"
              size-xs="12"
              className="left-col ion-no-padding"
            >
              {/* <ActivityCard
              header="My Groups"
              headerLinkLable="View All"
              headerLink="/groups"
              mapData={group}
              icon={caretForward}
              fieldLink="/groups/"
              className="sidebar-pages"
            /> */}
              <IonRow className='mobile-heading-title pb-0 mt-1 d-flex d-lg-none'>
                <h3 className="page-title-hd plm-0 mtm-0">{t('appproperties.text35')}</h3>
                <ButtonComponent btnClick={openModelWithClearState}
                className='ion-button-color btn-sm-cn-mobile ion-margin-top ion-margin-bottom ml-auto no-pd-r'
                size ='small' name={t('groupproperties.text1')} parametersPass={0} />
              </IonRow>
              <div className='sidebar-main groups-bottom-border'>
                <IonCard className={classMobile ? 'showpage sdb-box profile-details left-cards no-shadow MuiPaper-rounded ion-margin-top ion-margin-bottom ' : 'sdb-box profile-details left-cards no-shadow  MuiPaper-rounded ion-margin-top ion-margin-bottom'}>
                  <IonHeader className="card-header-text ion-padding-start ion-padding-end card-header-text dn-mobile">
                    <IonRow className="ion-no-padding ion-align-items-center ion-justify-content-between w-100">
                      <p>{t('groupproperties.text18')}</p>
                      <div className="ml-auto">
                        <IonButton
                          className={
                            inviteAdminGroupClass + ' ion-no-margin btn-sm-cn'
                          }
                          shape="round"
                          onClick={() => { viewRecursivegetInvitationList('admin'); setInfiniteDisabled(false); }}
                        >
                          {t('appproperties.text193')}
                        </IonButton>
                        <IonButton
                          className={
                            inviteMemberBtnClass +
                            ' no-pd-r ion-no-margin btn-sm-cn '
                          }
                          shape="round"
                          onClick={() => { viewRecursivegetInvitationList('user'); setInfiniteDisabled(false); }}
                        >
                          {t('appproperties.text209')}
                        </IonButton>
                      </div>
                    </IonRow>
                  </IonHeader>
                  <IonHeader className="card-header-text ion-padding-start ion-padding-end card-header-text show-mobile head-angle" onClick={addMobileCss}>
                    <IonRow className="ion-no-padding mb-0  ion-align-items-center ion-justify-content-between w-100">
                      <p>{t('appproperties.text12')}</p>
                      <IonIcon className='icon-mobile' icon={chevronForward}></IonIcon>
                    </IonRow>
                  </IonHeader>
                  <IonRow className={classMobile ? 'showpage sdb-box profile-details left-cards no-shadow  MuiPaper-rounded ion-margin-top ion-margin-bottom' : 'sdb-box profile-details left-cards no-shadow  MuiPaper-rounded ion-margin-top ion-margin-bottom'} className='mobile-overlay-screen with-sb-box with-sox-head-btn'>
                    <div className='mobile-back-screen show-mobile head-angle back-with-heading '>
                      <IonIcon className='icon-mobile' icon={arrowBack} onClick={removeMobileCss}></IonIcon>
                      <h3>{t('groupproperties.text18')}</h3>
                      <div className="ml-auto">
                        <IonButton
                          className={
                            inviteAdminGroupClass + ' ion-no-margin btn-sm-cn'
                          }
                          shape="round"
                          onClick={() => { viewRecursivegetInvitationList('admin'); setInfiniteDisabled(false); }}

                        >
                         {t('appproperties.text208')}
                        </IonButton>
                        <IonButton
                          className={
                            inviteMemberBtnClass +
                            ' no-pd-r ion-no-margin btn-sm-cn '
                          }
                          shape="round"
                          onClick={() => { viewRecursivegetInvitationList('user'); setInfiniteDisabled(false); }}
                        >
                          {t('appproperties.text209')}
                        </IonButton>
                      </div>
                    </div>
                    {requestloading ? <SkeletonComonInvitaion />
                      : adminInvite.length > 0
                        ? (
                          <IonList
                            lines="none"
                            className="full-width-row GroupInvitation-list custom-scroll"
                          >
                            {adminInvite.length > 4
                              ? <IonContent className='custom-scroll custom-content-scroll mobilespace-bottom'>
                                {adminInvite.map((detail) => (
                                  <IonRow className="ion-padding-start ion-padding-end ion-align-items-center ion-bottom-padding-smallcom GroupInvitation-list-item ion-justify-content-between">
                                    <IonRow className='GroupInvitation-left-col'>
                                      <div className="myprofile-feeds ion-no-padding cursor-pointer" onClick={() => {
                                        if (type === 'user') {
                                          history.push('/groups/' + detail.groupId);
                                        } else {
                                          history.push('/profile/' + detail.userId);
                                        }
                                      }}>
                                        <IonAvatar className="MuiAvatar ion-margin-end">
                                          {detail.groupLogo !== undefined &&
                                            detail.groupLogo !== null
                                            ? (
                                              <img onError={(ev) => { ev.target.src = groupImg; }} src={detail.groupLogo} />
                                              )
                                            : detail.userLogo !== undefined &&
                                              detail.userLogo !== null
                                              ? (
                                                <img onError={(ev) => { ev.target.src = groupImg; }} src={detail.userLogo} />
                                                )
                                              : (
                                                <img src={groupImg} />
                                                )}
                                        </IonAvatar>
                                        <IonRow className="display-grid">
                                          {detail.userName !== undefined &&
                                            detail.userName !== null
                                            ? (
                                              <>
                                                <span>{detail.userName}</span>
                                                <span className="margin MuiTypography-caption group-model-text">
                                                  {detail.groupName}
                                                </span>
                                              </>
                                              )
                                            : (
                                              <>
                                                <span>{detail.groupName}</span>
                                                <span className="margin MuiTypography-caption group-model-text">
                                                  {/* {detail.about} */}
                                                </span>
                                              </>
                                              )}
                                        </IonRow>
                                      </div>
                                    </IonRow>
                                    {detail.userName !== undefined &&
                                      detail.userName !== null
                                      ? (
                                          detail.status === '1'
                                            ? (
                                            <ButtonComponent
                                              className='category-btn-color cursor-pointer btn-sm-cn mt-lg-1 pe-0 btnIgnore btnWeb'
                                              btnClick={cancelBtnHandler} field1={detail.id}
                                              name={t('appproperties.text19')} parametersPass={1}
                                            />
                                              )
                                            : (
                                            <IonRow className="header-row-margin-left ms-0">
                                              <ButtonComponent
                                                className='category-btn-color cursor-pointer btn-sm-cn mt-lg-1 pe-0 btnIgnore btnWeb'
                                                btnClick={invitationAcceptBtnHandler} field2={detail.id}
                                                field1='reject' name={t('appproperties.text19')} parametersPass={2}
                                              />
                                              <ButtonComponent
                                                className='btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnAccept btnWeb'
                                                btnClick={invitationAcceptBtnHandler} field2={detail.id}
                                                field1='accept' field3={detail.id} name={t('appproperties.text20')} parametersPass={3}
                                              />
                                            </IonRow>
                                              )
                                        )
                                      : detail.status === '1'
                                        ? (
                                          <IonRow className="header-row-margin-left ms-0">
                                            <ButtonComponent
                                                className='category-btn-color cursor-pointer btn-sm-cn mt-lg-1 pe-0 btnIgnore btnWeb'
                                                btnClick={invitationAcceptBtnHandler} field2={detail.id}
                                                field1='reject' name={t('appproperties.text19')} parametersPass={2}
                                              />
                                              <ButtonComponent
                                                className='btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnAccept btnWeb'
                                                btnClick={invitationAcceptBtnHandler} field2={detail.id}
                                                field1='accept' field3={detail.id} name={t('appproperties.text20')} parametersPass={3}
                                              />
                                          </IonRow>
                                          )
                                        : (
                                          <IonRow className="header-row-margin-left ms-0">
                                            <ButtonComponent
                                              className='category-btn-color cursor-pointer btn-sm-cn mt-lg-1 pe-0 btnIgnore btnWeb'
                                              btnClick={cancelBtnHandler} field1={detail.id}
                                              name={t('appproperties.text19')} parametersPass={1}
                                            />
                                          </IonRow>
                                          )}
                                  </IonRow>
                                ))}
                                <IonInfiniteScroll
                                  onIonInfinite={loadData}
                                  disabled={isInfiniteDisabled}
                                >
                                  <IonInfiniteScrollContent
                                    loadingSpinner="circular"
                                    loadingText={t('appproperties.text215')}
                                  ></IonInfiniteScrollContent>
                                </IonInfiniteScroll>
                              </IonContent>
                              : adminInvite.map((detail) => (
                                <IonRow className="ion-padding-start ion-padding-end ion-align-items-center ion-bottom-padding-smallcom GroupInvitation-list-item ion-justify-content-between">
                                  <IonRow className='GroupInvitation-left-col'>
                                    <div className="myprofile-feeds ion-no-padding cursor-pointer" onClick={() => {
                                      if (type === 'user') {
                                        history.push('/groups/' + detail.groupId);
                                      } else {
                                        history.push('/profile/' + detail.userId);
                                      }
                                    }}>
                                      <IonAvatar className="MuiAvatar ion-margin-end">
                                        {detail.groupLogo !== undefined &&
                                          detail.groupLogo !== null
                                          ? (
                                            <img onError={(ev) => { ev.target.src = groupImg; }} src={detail.groupLogo} />
                                            )
                                          : detail.userLogo !== undefined &&
                                            detail.userLogo !== null
                                            ? (
                                              <img onError={(ev) => { ev.target.src = groupImg; }} src={detail.userLogo} />
                                              )
                                            : (
                                              <img src={groupImg} />
                                              )}
                                      </IonAvatar>
                                      <IonRow className="display-grid">
                                        {detail.userName !== undefined &&
                                          detail.userName !== null
                                          ? (
                                            <>
                                              <span>{detail.userName}</span>
                                              <span className="margin MuiTypography-caption group-model-text">
                                                {detail.groupName}
                                              </span>
                                            </>
                                            )
                                          : (
                                            <>
                                              <span>{detail.groupName}</span>
                                              <span className="margin MuiTypography-caption group-model-text">
                                                {/* {detail.about} */}
                                              </span>
                                            </>
                                            )}
                                      </IonRow>
                                    </div>
                                  </IonRow>
                                  {detail.userName !== undefined &&
                                    detail.userName !== null
                                    ? (
                                        detail.status === '1'
                                          ? (
                                            <ButtonComponent
                                            className='category-btn-color cursor-pointer btn-sm-cn mt-lg-1 pe-0 btnIgnore btnWeb'
                                            btnClick={cancelBtnHandler} field1={detail.id}
                                            name={t('appproperties.text19')} parametersPass={1}
                                          />
                                            )
                                          : (
                                          <IonRow className="header-row-margin-left ms-0">
                                            <ButtonComponent
                                                className='category-btn-color cursor-pointer btn-sm-cn mt-lg-1 pe-0 btnIgnore btnWeb'
                                                btnClick={invitationAcceptBtnHandler} field2={detail.id}
                                                field1='reject' name={t('appproperties.text19')} parametersPass={2}
                                              />
                                              <ButtonComponent
                                                className='btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnAccept btnWeb'
                                                btnClick={invitationAcceptBtnHandler} field2={detail.id}
                                                field1='accept' field3={detail.id} name={t('appproperties.text20')} parametersPass={3}
                                              />
                                          </IonRow>
                                            )
                                      )
                                    : detail.status === '1'
                                      ? (
                                        <IonRow className="header-row-margin-left ms-0">
                                          <ButtonComponent
                                                className='category-btn-color cursor-pointer btn-sm-cn mt-lg-1 pe-0 btnIgnore btnWeb'
                                                btnClick={invitationAcceptBtnHandler} field2={detail.id}
                                                field1='reject' name={t('appproperties.text19')} parametersPass={2}
                                              />
                                              <ButtonComponent
                                                className='btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnAccept btnWeb'
                                                btnClick={invitationAcceptBtnHandler} field2={detail.id}
                                                field1='accept' field3={detail.id} name={t('appproperties.text20')} parametersPass={3}
                                              />
                                        </IonRow>
                                        )
                                      : (
                                        <IonRow className="header-row-margin-left ms-0">
                                         <ButtonComponent
                                            className='category-btn-color cursor-pointer btn-sm-cn mt-lg-1 pe-0 btnIgnore btnWeb'
                                            btnClick={cancelBtnHandler} field1={detail.id}
                                            name={t('appproperties.text19')} parametersPass={1}
                                          />
                                        </IonRow>
                                        )}
                                </IonRow>
                              ))}
                          </IonList>
                          )
                        : <>
                          {type === 'user'
                            ? <p className="ion-padding-start ion-padding-top ion-padding-bottom">
                              {t('nodatafound.text21')}
                            </p>
                            : <p className="ion-padding-start ion-padding-top ion-padding-bottom">
                              {t('nodatafound.text23')}
                            </p>}
                        </>}
                  </IonRow>
                </IonCard>
                <InterestedScrollCommon
                  header={t('groupproperties.text28')}
                  mapData={intrestGroups}
                  fieldLink="/groups/"
                  noDataFound={t('nodatafound.text22')}
                  image={groupImg}
                  requestloadingComon={requestloadingComon}
                  loadDataComon={loadDataComon}
                  isInfiniteDisabledComon={isInfiniteDisabledComon}
                />
                <Footer />
              </div>
            </IonCol>
            <IonCol
              size-lg="8"
              size-md="12"
              size-xs="12"
              className="right-col ion-no-padding"
            >
              <IonRow className='mobile-heading-title d-none d-lg-flex'>
                <h3 className="page-title-hd plm-0 mtm-0">{t('appproperties.text35')}</h3>
                <ButtonComponent btnClick={openModelWithClearState}
                className='ion-button-color btn-sm-cn-mobile ion-margin-top ion-margin-bottom ml-auto no-pd-r'
                size ='small' name={t('groupproperties.text1')} parametersPass={0} />
              </IonRow>
              <GroupList />
            </IonCol>
          </div>
        </IonRow>
      </IonRow>
      <IonModal
        isOpen={showModal}
        className="createGroupModal grouppageModal"
        onDidDismiss={() => { setShowModal(false); resetField('name'); resetField('rule'); resetField('about'); setCharacterCount(0); setRuleCharacterCount(0); }}
      >
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6 ps-lg-2 ps-3">
              {t('groupproperties.text1')}
            </IonLabel>
            <div
              onClick={() => { setShowModal(false); resetField('name'); resetField('about'); resetField('rule'); setCharacterCount(0); setRuleCharacterCount(0); }}
              className="close ion-no-padding cursor-pointer"
            >
              <IonIcon
                icon={close}
                className="ion-button-color "
                slot="start"
                size="undefined"
              />
            </div>
          </IonRow>
          <div className="modal-body">
            <form
              data-testid="form-submit"
              autoComplete="off"
              noValidate
              className="h-100"
              name='formName'
              onSubmit={handleSubmit(submitHandle, industryBlure)}
            >
              <div className="body-content">
                <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
                  <IonCol size-md="12" size-sm="12" size-xs="12" className='mx-auto'>
                    <div className="ion-justify-content-center mobile-avtar d-flex">
                      <input
                        type="file" autoComplete='off'
                        color="primary"
                        onChange={uploadCompanylogoHandleChange}
                        id="upload"
                        accept="image/png, image/jpg, image/jpeg"
                        className="upload"
                        disabled={imageView}
                      />
                      <label htmlFor="upload" className='cursor-pointer up-img hover-avtar' id='lblupload' onClick={removeOverLay} onMouseEnter={addClass} onMouseLeave={removeClass}>
                        <IonAvatar
                          id="companyAvatar"
                          slot="start"
                          className="MuiCardHeader-avatar avtar-img"
                        >
                          {groupFile
                            ? (
                              <img
                                src={groupFile}
                                className="group-img groupPhoto" id='groupImg'
                              />
                              )
                            : (
                              <img src={groupImg} className="group-img" />
                              )}
                        </IonAvatar>
                        <span className='addImage' onClick={addImg}></span>
                        {groupFile !== '' && groupFile !== null
                          ? <><div className='avr-edit-del-icon'>
                            <span className="icon edit cursor-pointer">
                              <IonIcon icon={trashBinOutline} onClick={deleteImageHandle} />
                            </span>
                            <span className="icon edit cursor-pointer">
                              <IonIcon icon={pencilOutline} onClick={imageEditHandle} />
                            </span>
                          </div>
                          </>
                          : ''}
                      </label>
                    </div>
                    <div className='error ion-text-center w-100 position-relative'>
                      {errors.upload?.message}
                    </div>
                  </IonCol>
                  <IonCol size-md="12" size-sm="12" size-xs="12" className='mop-0 mt-3'>
                    <IonRow className='m-xr-5'>
                      <IonCol className="input-label-box mb-3" size-md="12" size-sm="12" size-xs="12">
                        <IonItem
                          className={
                            errors.name
                              ? 'error-border input-box form-group input-label-box position-relative mb-0'
                              : 'form-group input-label-box position-relative mb-0 input-box'
                          }
                        >
                          <IonLabel position="floating">{' '}{t('groupproperties.text2')} <sup>*</sup>{' '}</IonLabel>
                          <IonInput type='text' autocomplete='off'
                            className='input-box'
                            placeholder=""
                            id="name"
                            {...register('name')}
                            onIonChange={userformDataChangeHandler}
                            value={groupFormState.name}
                          />
                          <span className={errors.name ? 'error input-error' : ''}>
                            {errors.name?.message}
                          </span>
                        </IonItem>
                      </IonCol>
                      <IonCol size-md="6" size-sm="12" size-xs="12" className='show-tooltip input-popover input-label-box d-block mb-3 select-cross'>
                        <Controller
                          name="industry"
                          control={control}
                          render={({ field }) => (
                            <Select type='text' autocomplete='off'
                              // defaultValue={options[0]}
                              {...field}
                              isClearable // enable isClearable to demonstrate extra error handling
                              isSearchable={true}
                              onChange={industrySelectHandler}
                              onBlur={industryBlure}
                              value={industry.filter(
                                (obj) => obj.value === groupFormState.industry)}
                              className={
                                errors.industry
                                  ? 'error-border selectOption moreimp v-imp form-group position-relative border borderradius6 mb-0 pt-0 selectcorss-btn group-crosbtn'
                                  : 'selectOption moreimp v-imp form-group position-relative border borderradius6 mb-0 pt-0 selectcorss-btn group-crosbtn'}
                              classNamePrefix="dropdown"
                              options={industry}
                              id='industry'
                              placeholder={t('groupproperties.text6')+'*'}
                              styles={customStyles} />)}
                        />
                        <span className={errors.industry ? 'error' : ''}>
                          {errors.industry?.message || errors.industry?.label.message}
                        </span>
                        {/* <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text259')}/> */}
                      </IonCol>
                      <IonCol className="input-label-box show-tooltip input-popover mb-3 mb-lg-0" size-md="6" size-sm="12" size-xs="12">
                        <IonItem className='form-group input-label-box position-relative pt-0 mb-0'>
                          <IonLabel position="floating">{t('groupproperties.text3')}</IonLabel>
                          <IonInput type='text' autocomplete='off'
                            className={
                              errors.location ? 'error-border input-box input-custom-width' : 'input-box input-custom-width'
                            }
                            placeholder=""
                            {...register('location')}
                            onIonChange={userformDataChangeHandler}
                            value={groupFormState.location}
                          />
                          <span className={errors.location ? 'error input-error' : ''}>
                            {errors.location?.message}
                          </span>
                        </IonItem>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text260')}/>
                      </IonCol>
                    </IonRow>
                  </IonCol>
                </IonRow>
                <IonRow className="ion-padding-start ion-padding-end">
                  <IonCol size-md="6" size-xs="12" className="ion-no-padding">
                    <div className='input-label-box'>
                      <IonItem className='form-group input-label-box position-relative mb-0'>
                        <IonLabel position="floating">{t('groupproperties.text4')}</IonLabel>
                        <IonTextarea type='text' autocomplete='off'
                          className={
                            errors.about
                              ? 'error-border input-box'
                              : 'input-box mt-0'
                          }
                          value={groupFormState.about}
                          {...register('about')}
                          onIonChange={aboutChangeHandler}
                          rows={4}
                          maxlength={500}
                        />
                        <span className={errors.about ? 'error input-error' : ''}>
                          {errors.about?.message || errors.about?.label.message}
                        </span>
                      </IonItem>
                      <p className='text-grey text-end font-14'>{characterCount}/{maxAboutCount}</p>
                    </div>
                  </IonCol>
                  <IonCol
                    size-md="6"
                    size-xs="12"
                    className="ion-no-padding text-area-padding show-tooltip input-popover"
                  >
                    <div className='input-label-box groupdetailsRules'>
                      <IonItem className='form-group input-label-box position-relative mb-0'>
                        <IonLabel position="floating">{t('groupproperties.text5')}</IonLabel>
                        <IonTextarea type='text' autocomplete='off'
                          className={
                            errors.rule
                              ? 'error-border input-box'
                              : 'input-box mt-0'
                          }
                          value={groupFormState.rule}
                          {...register('rule')}
                          onIonChange={ruleChangeHandler}
                          rows={4}
                          maxlength={500}
                        />
                        <span className={errors.rule ? 'error input-error' : ''}>
                          {errors.rule?.message || errors.rule?.label.message}
                        </span>
                      </IonItem>
                      <p className='text-grey text-end font-14'>
                        {ruleCharacterCount}/{maxRuleCount}
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text261')}/>
                      </p>
                    </div>
                  </IonCol>
                </IonRow>
              </div>
              <IonFooter className="ion-no-border ion-padding-end ion-padding-start ion-padding-bottom">
                <IonRow className="ion-padding-start">
                  <IonButton
                    className="header-row-margin-left ion-button-color ml-auto pr-20"
                    size="small"
                    type="submit"
                    disabled={createDisabled}
                  >
                    {t('groupproperties.text1')}
                    {createDisabled
                      ? <span className="loader" id="loader-2">
                        <span></span>
                        <span></span>
                        <span></span>
                      </span>
                      : ''
                    }
                  </IonButton>
                </IonRow>
              </IonFooter>
            </form>
          </div>
        </IonContent>
      </IonModal>
      {invitationModal && modalData.id !== undefined
        ? <InviteUserCommon invitationModal ={invitationModal} setInvitationModal ={setInvitationModal}
        inviteConnection ={inviteConnection}
        setInviteConnection={setInviteConnection}
        modalData ={modalData} redirectUrl = {'/groups/' + modalData.id} type ={'group'}/>
        : ''}
    </>
  );
};
export default Groups;
