/* eslint-disable react/no-unescaped-entities */
import React, { useState } from 'react';
import MetaTage from '../components/common/MetaTage';
import MetaTagProperties from '../properties/MetaTagProperties';
import career from '../assets/img/career.png';
import { IonCol, IonModal, IonRow } from '@ionic/react';
// import TagManager from 'react-gtm-module';
// import { IonModal } from '@ionic/react';
// const tagManagerArgs = {
//   gtmId: 'GTM-K26PQF2'
// };
// TagManager.initialize(tagManagerArgs); // Google Tag Manager
const Career = () => {
  const [showModal, setShowModal] = useState(false);
  const [showModalJava, setShowModalJava] = useState(false);
  const [showModalSeo, setShowModalseo] = useState(false);
  const [showModalMobile, setShowModalMobile] = useState(false);
  const [showModalGraphics, setShowModalGraphics] = useState(false);
  const [showModalITSoftware, setShowModalITSoftware] = useState(false);
  const [showModalDevOps, setShowModalDevOps] = useState(false);
  const [showModalmobileui, setShowModalmobileui] = useState(false);

  const showModalData = () => {
    setShowModal(true);
  };
  const showModalData1 = () => {
    setShowModalJava(true);
  };
  const showModalData2 = () => {
    setShowModalseo(true);
  };
  const showModalData3 = () => {
    setShowModalMobile(true);
  };
  const showModalData4 = () => {
    setShowModalGraphics(true);
  };
  const showModalData5 = () => {
    setShowModalITSoftware(true);
  };
  const showModalData6 = () => {
    setShowModalDevOps(true);
  };
  const showModalData7 = () => {
    setShowModalmobileui(true);
  };
  const hideModalData = () => {
    setShowModal(false);
  };
  const hideModalDataJava = () => {
    setShowModalJava(false);
  };
  const hideModalDataSeo = () => {
    setShowModalseo(false);
  };
  const hideModalDataMobile = () => {
    setShowModalMobile(false);
  };
  const hideModalDataGraphics = () => {
    setShowModalGraphics(false);
  };
  const hideModalITSoftware = () => {
    setShowModalITSoftware(false);
  };
  const hideModalDevOps = () => {
    setShowModalDevOps(false);
  };
  const hideModalmobileui = () => {
    setShowModalmobileui(false);
  };

  return (<>
        <MetaTage metaDetails={MetaTagProperties.career} />
        <div className='web-pages-before careerpage'>

            <section className="career-content">
                <div className="container">
                    <h1 className="pb-5 text-center">Career</h1>
                    <IonRow>
                        <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='align-items-center justify-content-flex-start'>

                            <h3>"It’s Never Too Late To Be What You Might Have Been" </h3>
                            <h3 className=""><span>- George Eliot.</span></h3>

                            <p>Zyapaar is on a quest to connect all Indian businesses in order to assist them to boost sales and cutting costs associated with purchasing.</p>
                            <p className='pt-2'>We are helping Retailers, Wholesalers, Manufacturer, Traders, Consultant &amp; Freelancers to connect-collaborate and grow!                        </p>
                            <p className='pt-2'>Come and join us on our journey!</p>
                            <p className='pt-2'>Join Us to make a difference, please email us with your detailed resume at <a href="mailto:hr@zyapaar.com" className="SecondryText">hr@zyapaar.com</a></p>
                        </IonCol>

                        <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='align-items-center justify-content-flex-start'>
                            <img src={career} alt="Indian business to do business" />
                        </IonCol>
                    </IonRow>
                </div>
            </section>

            <section className="jobListing jopOpening pb-3 pt-5 py-md-5 py-sm-2 pt-sm-5 ">
                <div className="container">
                    <div className="heading text-center mb-2">
                        <h1>Job Opening</h1>
                    </div>
                    <div className="JobContent d-flex justify-content-center pt-4 mb-0">
                        {/* Full Stack Developer */}
                        <div className="job-item wow fadeInUp">
                            <div className="job-title PrimeryText fw-bold">Full Stack Developer </div>
                            <div className="job-exp">5+ year experience</div>
                            <div className="job-position  fw-bold mb-3">2 positions</div>
                            <button className="btn-about" data-bs-toggle="modal" data-bs-target="#WebDes" onClick={showModalData3} >More details</button>
                        </div>
                        <IonModal isOpen={showModalMobile}
                            onDidDismiss={() => setShowModalMobile(false)} className="career">
                            <div className="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
                                <div className="modal-content">
                                    <div className="modal-body">
                                        <div className="job-description p-2">
                                            <div className="Job-title mb-4">
                                                <h2 className="fw-bold PrimeryText">Full Stack Developer </h2>
                                                <span className="fw-bold">Experience: 5+ Years </span>
                                            </div>

                                            <div className="brife mb-4">
                                                <h4>Education:</h4>
                                                <p>B.E./B.Tech./M.E./M.Tech/MCA</p>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Desired Skills :</h4>
                                                <p>Java8, Spring Boot, MySQL, Micro Services, React.js, JavaScript, Redux, RESTful APIs, TypeScript, PostGreSQL, MongoDB</p>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Job Summary :</h4>
                                                <ul className="ps-3">
                                                    <li>Significant coding skills in Java, with other languages being a major plus.</li>
                                                    <li>Exceptional problem-solving and analytical abilities.</li>
                                                    <li>Knowledge of current frameworks, SDKs, APIs, and libraries.</li>
                                                    <li>Thorough understanding of React.js and its core principles</li>
                                                    <li>Experience with popular React.js workflows (such as Flux or Redux)</li>
                                                    <li>Familiarity with newer specifications of EcmaScript</li>
                                                    <li>Familiarity with RESTful APIs</li>
                                                    <li>Knowledge of modern authorization mechanisms, such as JWT Web Token</li>
                                                    <li>Familiarity with modern front-end build pipelines and tools</li>
                                                    <li>Experience with common front-end development tools such as Babel, Webpack, NPM, etc.</li>
                                                    <li>Ability to understand business requirements and translate them into technical requirements</li>
                                                    <li>Excellent written and verbal communication.</li>
                                                    <li>Good organizational and time-management skills.</li>
                                                    <li>A strong portfolio of top-class coding and builds to your name.</li>
                                                    <li>Ability to work with other developers and assist junior team members.</li>
                                                </ul>
                                                <p>Join Us to make a difference, please email us at with your detailed resume to <a href="mailto:hr@zyapaar.com" className="SecondryText">hr@zyapaar.com</a></p>

                                            </div>

                                        </div>
                                    </div>
                                    <div className="modal-footer justify-content-center">
                                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={hideModalDataMobile}>Close</button>
                                        <a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSctVMcmPl3Dr_G-cYzUr4EsRvOElfqAgR0UwRJBWT49PRQkPg/viewform" className="btn-about" rel="noreferrer">Apply Now</a>
                                    </div>
                                </div>
                            </div>
                        </IonModal >
                        {/* End Full Stack Developer */}

                        {/* Java Developer */}
                        <div className="job-item wow fadeInUp">
                            <div className="job-title PrimeryText fw-bold">Java Developer</div>
                            <div className="job-exp">3+ year experience</div>
                            <div className="job-position  fw-bold mb-3">4 positions</div>
                            <button className="btn-about" data-bs-toggle="modal" data-bs-target="#JavaOps" onClick={showModalData1}>More details</button>
                        </div>
                        <IonModal isOpen={showModalJava}
                            onDidDismiss={() => setShowModalJava(false)} className="career">
                            <div className="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
                                <div className="modal-content">
                                    <div className="modal-body">
                                        <div className="job-description p-2">
                                            <div className="Job-title mb-4">
                                                <h2 className="fw-bold PrimeryText">Java Developer</h2>
                                                <span className="fw-bold">Experience: 3+ Years </span>
                                            </div>

                                            <div className="brife mb-4">
                                                <h4>Education:</h4>
                                                <p>B.E./B.Tech./M.E./M.Tech/MCA</p>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Desired Skills :</h4>
                                                <p>Java8, Spring Boot, MySQL, Micro Services</p>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Job Summary :</h4>
                                                <ul className="ps-3">
                                                    <li>Significant coding skills in Java, with other languages being a major plus.</li>
                                                    <li>Exceptional problem-solving and analytical abilities.</li>
                                                    <li>Knowledge of current frameworks, SDKs, APIs, and libraries.</li>
                                                    <li>Excellent written and verbal communication.</li>
                                                    <li>Good organizational and time-management skills.</li>
                                                    <li>A strong portfolio of top-class coding and builds to your name.</li>
                                                    <li>Ability to work with other developers and assist junior team members.</li>
                                                </ul>
                                                <p>Join Us to make a difference, please email us at with your detailed resume to <a href="mailto:hr@zyapaar.com" className="SecondryText">hr@zyapaar.com</a></p>

                                            </div>

                                        </div>
                                    </div>
                                    <div className="modal-footer justify-content-center">
                                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={hideModalDataJava}>Close</button>
                                        <a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSctVMcmPl3Dr_G-cYzUr4EsRvOElfqAgR0UwRJBWT49PRQkPg/viewform" className="btn-about" rel="noreferrer">Apply Now</a>
                                    </div>
                                </div>
                            </div>
                        </IonModal>
                        {/* End Java Developer */}

                        {/* React.js Developer */}
                        <div className="job-item wow fadeInUp">
                            <div className="job-title PrimeryText fw-bold">React.js Developer</div>
                            <div className="job-exp">1+ year experience</div>
                            <div className="job-position  fw-bold mb-3">4 positions</div>
                            <button className="btn-about" data-bs-toggle="modal" data-bs-target="#RectOps" onClick={showModalData} >More details</button>
                        </div>
                        <IonModal isOpen={showModal}
                            onDidDismiss={() => setShowModal(false)} className="career">

                            <div className="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
                                <div className="modal-content">
                                    <div className="modal-body">
                                        <div className="job-description p-2">
                                            <div className="Job-title mb-4">
                                                <h2 className="fw-bold PrimeryText">React.js Developer</h2>
                                                <span className="fw-bold">Experience: 1+ Years </span>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Education:</h4>
                                                <p>B.E./B.Tech./M.E./M.Tech/MCA</p>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Desired Skills :</h4>
                                                <p>React.js, JavaScript, Redux, RESTful APIs, TypeScript</p>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Job Summary :</h4>
                                                <ul className="ps-3">
                                                    <li>Thorough understanding of React.js and its core principles</li>
                                                    <li>Experience with popular React.js workflows (such as Flux or Redux)</li>
                                                    <li>Familiarity with newer specifications of EcmaScript</li>
                                                    <li>Familiarity with RESTful APIs</li>
                                                    <li>Knowledge of modern authorization mechanisms, such as JWT Web Token</li>
                                                    <li>Familiarity with modern front-end build pipelines and tools</li>
                                                    <li>Experience with common front-end development tools such as Babel, Webpack, NPM, etc.</li>
                                                    <li>Ability to understand business requirements and translate them into technical requirements</li>
                                                    <li>A knack for benchmarking and optimization</li>
                                                    <li>Familiarity with code versioning tools (such as Git, SVN, and Mercurial)</li>
                                                    <li>Familiarity with any ReactJS testing framework is plus</li>
                                                </ul>
                                                <p>Join Us to make a difference, please email us at with your detailed resume to <a href="mailto:hr@zyapaar.com" className="SecondryText">hr@zyapaar.com</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="modal-footer justify-content-center">
                                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={hideModalData}>Close</button>
                                        <a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSctVMcmPl3Dr_G-cYzUr4EsRvOElfqAgR0UwRJBWT49PRQkPg/viewform" className="btn-about" rel="noreferrer">Apply Now</a>
                                    </div>
                                </div>
                            </div>
                        </IonModal>
                        {/* End React.js Developer */}

                        {/* DevOps Developer */}
                        <div className="job-item wow fadeInUp">
                            <div className="job-title PrimeryText fw-bold">DevOps Developer</div>
                            <div className="job-exp">2+ year experience</div>
                            <div className="job-position  fw-bold mb-3">1 position</div>
                            <button className="btn-about" data-bs-toggle="modal" data-bs-target="#GraDes" onClick={showModalData6}>More details</button>
                        </div>
                        <IonModal isOpen={showModalDevOps}
                            onDidDismiss={() => setShowModalDevOps(false)} className="career">
                            <div className="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
                                <div className="modal-content">
                                    <div className="modal-body">
                                        <div className="job-description p-2">
                                            <div className="Job-title mb-4">
                                                <h2 className="fw-bold PrimeryText">DevOps Developer</h2>
                                                <span className="fw-bold">2+ year experience</span>
                                            </div>

                                            <div className="brife mb-4">
                                                <h4>Education:</h4>
                                                <p>B.E./B.Tech./M.E./M.Tech/MCA</p>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Desired Skills :</h4>
                                                <p>Dev Ops, AWS Admin, terraform, Infrastructure as a Code</p>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Job Summary :</h4>
                                                <ul className="ps-3">
                                                    <li>Have good hands on experience on Dev Ops, AWS Admin, terraform, Infrastructure as a Code</li>
                                                    <li>Have knowledge on EC2, Lambda, S3, ELB, VPC, IAM, Cloud Watch, CentOS, Server Hardening</li>
                                                    <li>Ability to understand business requirements and translate them into technical requirements</li>
                                                    <li>A knack for benchmarking and optimization</li>
                                                </ul>
                                                <p>Join Us to make a difference, please email us at with your detailed resume to <a href="mailto:hr@zyapaar.com" className="SecondryText">hr@zyapaar.com</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="modal-footer justify-content-center">
                                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={hideModalDevOps}>Close</button>
                                        <a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSctVMcmPl3Dr_G-cYzUr4EsRvOElfqAgR0UwRJBWT49PRQkPg/viewform" className="btn-about" rel="noreferrer">Apply Now</a>
                                    </div>
                                </div>
                            </div>
                        </IonModal>
                        {/* End DevOps Developer */}

                        {/* Web / Mobile Designer */}
                        <div className="job-item wow fadeInUp">
                            <div className="job-title PrimeryText fw-bold">Web / Mobile Designer</div>
                            <div className="job-exp"> 3+ year experience</div>
                            <div className="job-position  fw-bold mb-3">2 positions</div>
                            <button className="btn-about" data-bs-toggle="modal" data-bs-target="#GraDes" onClick={showModalData7}>More details</button>
                        </div>
                        <IonModal isOpen={showModalmobileui}
                            onDidDismiss={() => setShowModalmobileui(false)} className="career">
                            <div className="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
                                <div className="modal-content">
                                    <div className="modal-body">
                                        <div className="job-description p-2">
                                            <div className="Job-title mb-4">
                                                <h2 className="fw-bold PrimeryText">Web / Mobile Designer</h2>
                                                <span className="fw-bold">Experience: 3+ Years</span>
                                            </div>

                                            <div className="brife">
                                                <h4>Responsibilities :</h4>
                                                <ul className="ps-3">
                                                    <li>Execute all visual design stages from concept to final hand-off to engineering</li>
                                                    <li>Conceptualize original website design ideas that bring simplicity and user friendliness to complex roadblocks</li>
                                                    <li>Create wireframes, storyboards, user flows, process flows and site maps to communicate interaction and design ideas</li>
                                                    <li>Present and defend designs and key deliverables to peers and executive level stakeholders</li>
                                                    <li>Establish and promote design guidelines, best practices and standards</li>
                                                </ul>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Requirements :</h4>
                                                <ul className="ps-3">
                                                    <li>Proficiency in Photoshop, Illustrator or other visual design and wire-framing tools</li>
                                                    <li>Proficiency in HTML, CSS and JavaScript for rapid prototyping</li>
                                                    <li>Experience working in an Agile/Scrum development process</li>
                                                    <li>Excellent visual design skills with sensitivity to user-system interaction</li>
                                                    <li>Proven work experience as a Web Designer</li>
                                                    <li>Demonstrable graphic design skills with a strong portfolio</li>
                                                    <li>Solid experience in creating wireframes, storyboards, user flows, process flows and site maps</li>
                                                    <li>Up-to-date with the latest Web trends, techniques and technologies</li>
                                                    <li>Prepare and present rough drafts to internal teams and key stakeholders</li>
                                                    <li>Identify and troubleshoot UX problems (e.g. responsiveness)</li>
                                                    <li>Conduct layout adjustments based on user feedback</li>
                                                    <li>Adhere to style standards on fonts, colors and images and design logos</li>
                                                </ul>
                                                <p>Join Us to make a difference, please email us at with your detailed resume to <a href="mailto:hr@zyapaar.com" className="SecondryText">hr@zyapaar.com</a></p>
                                            </div>

                                        </div>
                                    </div>
                                    <div className="modal-footer justify-content-center">
                                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={hideModalmobileui}>Close</button>
                                        <a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSctVMcmPl3Dr_G-cYzUr4EsRvOElfqAgR0UwRJBWT49PRQkPg/viewform" className="btn-about" rel="noreferrer">Apply Now</a>
                                    </div>
                                </div>
                            </div>
                        </IonModal>
                        {/* End Web / Mobile Designer */}

                        {/* IT/Software Freshers &amp; Project Training */}
                        <div className="job-item wow fadeInUp">
                            <div className="job-title PrimeryText fw-bold">IT/Software Freshers &amp; Project Training</div>
                            <div className="job-exp">Freshers/Project Trainee</div>
                            <div className="job-position  fw-bold mb-3">10 positions</div>
                            <button className="btn-about" data-bs-toggle="modal" data-bs-target="#GraDes" onClick={showModalData5}>More details</button>
                        </div>
                        <IonModal isOpen={showModalITSoftware}
                            onDidDismiss={() => setShowModalITSoftware(false)} className="career">
                            <div className="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
                                <div className="modal-content">
                                    <div className="modal-body">
                                        <div className="job-description p-2">
                                            <div className="Job-title mb-4">
                                                <h2 className="fw-bold PrimeryText">IT/Software Freshers &amp; Project Training</h2>
                                                <span className="fw-bold">Freshers/Project Trainee</span>
                                            </div>

                                            <div className="brife mb-4">
                                                <p>A great opportunity for freshers or last year students looking for project training cum job at Lets Talk Business Pvt Ltd!<br />
                                                    We not only provide training but also gives you hands-on experience on live project. <br />
                                                    We have experienced professionals from whom you can learn from basic HTML to complex software development.</p>
                                            </div>

                                            <div className="brife">
                                                {/* <h4>Responsibilities :</h4> */}
                                                <ul className="ps-3">
                                                    <li>FREE Training with stipend during the training period</li>
                                                    <li>Job offer of ₹15,000 to ₹30,000 based on performance after training</li>
                                                    <li>Individual mentor for each trainee</li>
                                                    <li>Latest Technologies (React js, Node js, Java Spring, MSSQL / MYSQL) and Live Projects</li>
                                                    <li>Training Batch Starts in November On wards</li>
                                                </ul>
                                            </div>
                                            <div className="brife mb-4">
                                                <p className='fw-bold'>Selection Process for Freshers &amp; Project Training</p>
                                                <p className='fw-bold'>Eligibility Criteria</p>
                                                <ul className="ps-3 pt-3">
                                                    <li>50% in 10th Standard</li>
                                                    <li>50% in (10+2)12th Standard</li>
                                                    <li>50% aggregate in MCA or BE (Computer) or BE(IT) or BE(EC) or MSc(IT)</li>
                                                    <li>*Apply if you are in the last semester or completed college recently.</li>
                                                </ul>
                                                <p className='fw-bold'>Test and Interview </p>
                                                <ul className="ps-3 pt-3">
                                                    <li>Aptitude Test</li>
                                                    <li>Face-to-Face or Video Interview</li>
                                                    <li>Interview with HR</li>
                                                </ul>
                                                <p className='fw-bold'>CV or Resume Submission</p>
                                                <p>Email at <a href="mailto:hr@zyapaar.com" className="SecondryText">hr@zyapaar.com</a> Or Visit our office address between Monday to Friday (10 am to 7 pm)</p>
                                            </div>

                                        </div>
                                    </div>
                                    <div className="modal-footer justify-content-center">
                                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={hideModalITSoftware}>Close</button>
                                        <a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSctVMcmPl3Dr_G-cYzUr4EsRvOElfqAgR0UwRJBWT49PRQkPg/viewform" className="btn-about" rel="noreferrer">Apply Now</a>
                                    </div>
                                </div>
                            </div>
                        </IonModal>
                        {/* End IT/Software Freshers &amp; Project Training */}

                        {/* Marketing Manager */}
                        <div className="job-item wow fadeInUp">
                            <div className="job-title PrimeryText fw-bold">Marketing Manager</div>
                            <div className="job-exp">2+ year experience</div>
                            <div className="job-position  fw-bold mb-3">1 position</div>
                            <button className="btn-about" data-bs-toggle="modal" data-bs-target="#SeoModal" onClick={showModalData2} >More details</button>
                        </div>
                        <IonModal isOpen={showModalSeo}
                            onDidDismiss={() => setShowModalseo(false)} className="career">
                            <div className="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
                                <div className="modal-content">
                                    <div className="modal-body">
                                        <div className="job-description p-2">
                                            <div className="Job-title mb-4">
                                                <h2 className="fw-bold PrimeryText">Marketing Manager</h2>
                                                <span className="fw-bold">Experience: 2+ Years </span>
                                            </div>

                                            <div className="brife mb-4">
                                                <h4>Job Brief :</h4>
                                                <p>The marketing manager's responsible to generate sustainable financial development and improve our company's visibility, we are looking for an experienced marketer who is data-driven to own our demand generation, brand awareness, and product marketing functions.</p>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Education:</h4>
                                                <p>B.com/MBA/PGDM+Marketing.</p>
                                            </div>

                                            <div className="brife">
                                                <h4>Responsibilities :</h4>
                                                <ul className="ps-3">
                                                    <li>Planning strategy for customer acquisition.</li>
                                                    <li>Identifying new channel partners for customer acquisition.</li>
                                                    <li>Drive Digital Acquisition Channels</li>
                                                    <li>Run social media campaigns for the platform</li>
                                                    <li>Responsible for working with various agencies to execute various marketing plans</li>
                                                    <li>Develop a brand style guide to ensure consistency in marketing efforts </li>
                                                    <li>Create a multi-channel marketing content strategy</li>
                                                    <li>Manage external partners for marketing collateral creation </li>
                                                    <li>Track KPIs of marketing campaigns </li>
                                                    <li>Write marketing messages for online and offline campaigns</li>
                                                </ul>
                                            </div>
                                            <div className="brife">
                                                <h4>Requirements :</h4>
                                                <ul className="ps-3">
                                                    <li>At least two years experience as Marketing Manager in a Product Company </li>
                                                    <li>Extensive knowledge of marketing strategies, channels, and branding</li>
                                                    <li>Superb leadership, communication, and collaboration abilities</li>
                                                    <li>Proven experience in identifying target audiences and in creatively devising and leading across channels marketing campaigns that engage, educate and motivate </li>
                                                    <li>Preferable experience in B2B/Digital Marketing </li>
                                                    <li>A sense of aesthetics and a love for great copy and witty communication </li>
                                                    <li>Up-to-date with the latest trends and best practices in online marketing and measurement </li>
                                                    <li>Exceptional analytical and problem-solving skills. </li>
                                                    <li>Strong time management and organizational abilities </li>
                                                    <li>A Masters degree in relevant field will be advantageous. </li>
                                                </ul>
                                                <p>Join Us to make a difference, please email us at with your detailed resume to <a href="mailto:hr@zyapaar.com" className="SecondryText">hr@zyapaar.com</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="modal-footer justify-content-center">
                                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={hideModalDataSeo}>Close</button>
                                        <a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSctVMcmPl3Dr_G-cYzUr4EsRvOElfqAgR0UwRJBWT49PRQkPg/viewform" className="btn-about" rel="noreferrer">Apply Now</a>
                                    </div>
                                </div>
                            </div>
                        </IonModal>
                        {/* End Marketing Manager */}

                        {/* Marketing Executive */}
                        <div className="job-item wow fadeInUp">
                            <div className="job-title PrimeryText fw-bold">Marketing Executive</div>
                            <div className="job-exp"> 0 to 1 year experience</div>
                            <div className="job-position  fw-bold mb-3">5 positions</div>
                            <button className="btn-about" data-bs-toggle="modal" data-bs-target="#GraDes" onClick={showModalData4}>More details</button>
                        </div>
                        <IonModal isOpen={showModalGraphics}
                            onDidDismiss={() => setShowModalGraphics(false)} className="career">
                            <div className="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
                                <div className="modal-content">
                                    <div className="modal-body">
                                        <div className="job-description p-2">
                                            <div className="Job-title mb-4">
                                                <h2 className="fw-bold PrimeryText">Marketing Executive</h2>
                                                <span className="fw-bold">0 to 1 year experience</span>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Job Brief :</h4>
                                                <p>Marketing Executive will be responsible for brainstorming meetings with team members to implement marketing strategies for both internal and external initiatives. Work together to carry out sales and marketing efforts. Consultations with clients are held to develop and implement a variety of lead generation and brand-building marketing initiatives that are in line with the overall objectives of the business.</p>
                                            </div>

                                            <div className="brife mb-4">
                                                <h4>Education:</h4>
                                                <p>B.com/MBA/PGDM+Marketing.</p>
                                            </div>

                                            <div className="brife">
                                                <h4>Responsibilities :</h4>
                                                <ul className="ps-3">
                                                    <li>Planning strategy for customer acquisition.  </li>
                                                    <li>Identifying new channel partners for customer acquisition. </li>
                                                    <li>Drive Digital Acquisition Channels </li>
                                                    <li>Run social media campaigns for the platform </li>
                                                    <li>Responsible for working with various agencies to execute various marketing plans </li>
                                                    <li>Develop a brand style guide to ensure consistency in marketing efforts   </li>
                                                    <li>Create a multi-channel marketing content strategy </li>
                                                    <li>Manage external partners for marketing collateral creation  </li>
                                                    <li>Track KPIs of marketing campaigns  </li>
                                                    <li>Write marketing messages for online and offline campaigns </li>
                                                </ul>
                                            </div>
                                            <div className="brife mb-4">
                                                <h4>Requirements :</h4>
                                                <ul className="ps-3">
                                                    <li>Extensive knowledge of marketing strategies, channels, and branding </li>
                                                    <li>Superb leadership, communication, and collaboration abilities </li>
                                                    <li>Proven experience in identifying target audiences and in creatively devising and leading across channels marketing campaigns that engage, educate and motivate   </li>
                                                    <li>Preferable experience in B2B/Digital Marketing  </li>
                                                    <li>A sense of aesthetics and a love for great copy and witty communication  </li>
                                                    <li>Up-to-date with the latest trends and best practices in online marketing and measurement  </li>
                                                    <li>Exceptional analytical and problem-solving skills.  </li>
                                                    <li>Strong time management and organizational abilities  </li>
                                                    <li>A Masters degree in relevant field will be advantageous. </li>
                                                </ul>
                                                <p>Join Us to make a difference, please email us at with your detailed resume to <a href="mailto:hr@zyapaar.com" className="SecondryText">hr@zyapaar.com</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="modal-footer justify-content-center">
                                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={hideModalDataGraphics}>Close</button>
                                        <a target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSctVMcmPl3Dr_G-cYzUr4EsRvOElfqAgR0UwRJBWT49PRQkPg/viewform" className="btn-about" rel="noreferrer">Apply Now</a>
                                    </div>
                                </div>
                            </div>
                        </IonModal>
                        {/* End Marketing Executive */}
                    </div>
                </div>
            </section>
        </div>
    </>);
};
export default Career;
