/* eslint-disable multiline-ternary */
import { IonButton, IonCard, IonCol, IonContent, IonIcon, IonInfiniteScroll, IonInfiniteScrollContent, IonRow } from '@ionic/react';
import { arrowBack } from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import { useParams, useHistory } from 'react-router';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import GroupDetail from '../components/groups/GroupDetail';
import CallFor from '../util/CallFor';
import AboutGroup from '../components/groups/AboutGroup';
import GroupRule from '../components/groups/GroupRule';
import image from '../assets/img/group-profile-placeholder.png';
import GroupMember from '../components/groups/GroupMember';
import Post from '../components/feed/Post';
import FeedCard from '../components/common/FeedCard';
import { useDispatch, useSelector } from 'react-redux';
import { getFeedData } from '../Redux/reducers/feeds';
import CommonCard from '../components/common/CommonCard';
import Footer from '../components/Layout/Footer';
import SkeletonFeedComon from '../components/common/skeleton/SkeletonFeedComon';
import { Device } from '@capacitor/device';
import { isAndroid, isIOS } from 'react-device-detect';
import { useTranslation } from 'react-i18next';

const GroupDetailsPage = () => {
  const { t } = useTranslation();
  const getFeedDatas = useSelector(getFeedData);
  const { groupId } = useParams();
  const dispatch = useDispatch();
  const [postBtnClass, setPostBtnClass] = useState('ion-button-color');
  const [aboutBtnClass, setAboutBtnClass] = useState('category-btn-color');
  const [groupRuleBtnClass, setGroupRuleBtnClass] = useState('category-btn-color');
  const [memberBtnClass, setMemberBtnClass] = useState('category-btn-color');
  const [aboutGroupDetails, setAboutGroupDetails] = useState();
  const [categoryState, setCategoryState] = useState('POST');
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [gId, setgID] = useState(groupId);
  const [count, setCount] = useState(0);
  const [classMobile, setClassMobile] = useState(true);
  const [loading, setLoading] = useState(false);
  const [feedloading, setFeedLoading] = useState(false);
  const deviceDetails = Device.getInfo();
  const [loadComponent, setLoadComponent] = useState(false);
  const [reportHideState, setReportHideState] = useState(false);
  const getAllCategoryData = (category: any) => {
    if (category === 'POST') {
      setPostBtnClass('ion-button-color');
      setAboutBtnClass('category-btn-color');
      setGroupRuleBtnClass('category-btn-color');
      setMemberBtnClass('category-btn-color');
    } else if (category === 'ABOUT') {
      setAboutBtnClass('ion-button-color');
      setPostBtnClass('category-btn-color');
      setGroupRuleBtnClass('category-btn-color');
      setMemberBtnClass('category-btn-color');
    } else if (category === 'RULE') {
      setGroupRuleBtnClass('ion-button-color');
      setPostBtnClass('category-btn-color');
      setAboutBtnClass('category-btn-color');
      setMemberBtnClass('category-btn-color');
    } else if (category === 'MEMBER') {
      setMemberBtnClass('ion-button-color');
      setGroupRuleBtnClass('category-btn-color');
      setPostBtnClass('category-btn-color');
      setAboutBtnClass('category-btn-color');
    }
    setCategoryState(category);
  };
  const getAllFeedData = async (groupId) => {
    setFeedLoading(true);
    setInfiniteDisabled(false);
    const allFeedDataResponse = await CallFor('api/v1/feed/GROUP/' + groupId,
      'PATCH',
      '{"page": 0 }',
      'Auth'
    );
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      if (json1Response.data.content.length > 0) {
        dispatch({
          type: 'add_feedsData',
          Feeds: json1Response.data.content
        });
      } else {
        dispatch({
          type: 'add_feedsData',
          Feeds: []
        });
      }
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else {
      dispatch({
        type: 'add_feedsData',
        Feeds: []
      });
    }
    setCount(1);
    setFeedLoading(false);
  };
  const history = useHistory();
  const [grouplists, setGroupLists] = useState([]);
  const [groupDetail, setGroupDetails] = useState({
    id: '',
    logo: '',
    name: '',
    location: '',
    members: ''
  });
  useEffect(() => {
    dispatch({
      type: 'add_feedsData',
      Feeds: []
    });
    getGroupLists();
    getAllCategoryData('POST');
    if (isAndroid || isIOS) {
      setLoadComponent(true);
    }
  }, []);
  const getGroupDetails = async (groupId: string) => {
    setLoading(true);
    dispatch({
      type: 'add_feedsData',
      Feeds: []
    });
    const response = await CallFor(
      'api/v1.1/group/' + groupId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const jsonResponse = await response.json();
      if (jsonResponse.data !== '' && jsonResponse.data !== null) {
        setGroupDetails(jsonResponse.data);
        setAboutGroupDetails(jsonResponse.data);
        getAllFeedData(groupId);
        setReportHideState(false);
      } else if (jsonResponse.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else {
        history.push('/home');
      }
    }
    setLoading(false);
  };
  const getGroupLists = async () => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/groups/list/MEMBER',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setGroupLists(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const scrollData = async () => {
    const allFeedDataResponse = await CallFor('api/v1/feed/GROUP/' + gId,
      'PATCH',
      '{"page": ' + count + ' }',
      'Auth'
    );
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      if (json1Response.data.content.length > 0) {
        json1Response.data.content.map((details) => {
          dispatch({
            type: 'add_feedsData_new',
            Feeds: details
          });
        });
      } else {
        setInfiniteDisabled(true);
      }
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else {
      setInfiniteDisabled(true);
    }
  };
  const loadData = (ev: any) => {
    setCount(count + 1);
    setTimeout(() => {
      scrollData();
      ev.target.complete();
    }, 500);
  };
  if (classMobile) {
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  } else {
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  }
  const removeMobileCss = () => {
    history.goBack();
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  };
  return (
    <IonRow className="plane-bg">
      <IonRow className="container">
        <div className={classMobile ? 'showpage row full-width-row main-page-content-row group-bottom-border' : 'row full-width-row main-page-content-row group-bottom-border'}>
          <IonCol
            size-lg="4" size-md="12" size-xs="12"
            className="left-col ion-no-padding group-border"
          >
            <div className='sidebar-main'>
              <CommonCard
                // header="My Groups"
                headerLinkLable={t('groupproperties.text27')}
                headerLink="/groups"
                fieldLink='/groups/'
                mapData={grouplists}
                image={image}
                className="sidebar-pages pages-scroll"
                setId={setgID}
                btnHandler={getGroupDetails}
                btnHandler2={getAllCategoryData}
                param1='POST'
                setClassMobile={setClassMobile}
                loading={loading}
                paramId={groupId}
              />
              <Footer />
            </div>
          </IonCol>
          <IonCol size-lg="8" size-md="12" size-xs="12" className="right-col ion-no-padding">
            <IonContent className='mobile-overlay-screen show-mobile activity-content-card-div back-screen-mobile group-pagedetails'>
              <div className='mobile-back-screen show-mobile back-icon-mobile'>
                <IonIcon className='icon-mobile' icon={arrowBack} onClick={removeMobileCss}></IonIcon>
              </div>
              <GroupDetail
                groupId={gId}
                setGroupDetails={setGroupDetails}
                groupDetail={groupDetail}
                getGroupDetails={getGroupDetails}
                getGroupLists={getGroupLists}
                loading={loading}
                setReportHideState={setReportHideState}
                reportHideState={reportHideState}
              />
              {!reportHideState ? groupDetail.isHide !== true
                ? <IonRow className="ion-padding-top gup-btn-action company-capsule-btn bg-white ps-3">
                  {aboutGroupDetails !== undefined && aboutGroupDetails.isMember === true
                    ? <IonButton
                      className={postBtnClass}
                      shape="round"
                      size="small"
                      onClick={() => getAllCategoryData('POST')}
                    >
                      {t('appproperties.text73')}
                    </IonButton>
                    : ''}
                  {aboutGroupDetails !== undefined
                    ? <><IonButton
                      className={aboutBtnClass}
                      shape="round"
                      size="small"
                      onClick={() => getAllCategoryData('ABOUT')}
                    >
                      {t('commonproperties.text17')}
                    </IonButton>
                      <IonButton
                        className={groupRuleBtnClass}
                        shape="round"
                        size="small"
                        onClick={() => getAllCategoryData('RULE')}
                      >
                        {t('appproperties.text309')}
                      </IonButton>
                    </>
                    : ''
                  }
                  {aboutGroupDetails !== undefined && aboutGroupDetails.isMember === true
                    ? <IonButton
                      className={memberBtnClass}
                      shape="round"
                      size="small"
                      onClick={() => getAllCategoryData('MEMBER')}
                    >
                      {t('appproperties.text192')}
                    </IonButton>
                    : ''
                  }
                </IonRow>
                : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                  {t('groupproperties.text25')}
                </p>
                : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                  {t('groupproperties.text25')}
                </p>
              }
              {!reportHideState ? groupDetail.isHide !== true
                ? loadComponent
                  ? <>
                    {(() => {
                      if (categoryState === 'POST') {
                        if (aboutGroupDetails !== undefined && aboutGroupDetails.isMember !== true) {
                          getAllCategoryData('ABOUT');
                        }
                        return (
                          <>
                            {aboutGroupDetails !== undefined && aboutGroupDetails.isMember === true ? <div className='mt-n2'><Post origin="GROUP" originId={aboutGroupDetails.id} /></div> : ''}
                            {aboutGroupDetails !== undefined && aboutGroupDetails.isMember === true
                              ? <>
                                <div className='mb-lg-3 mb-5 pb-4'>
                                  {feedloading
                                    ? <SkeletonFeedComon column={5} />
                                    : getFeedDatas.length > 0
                                      ? Object.entries(getFeedDatas).map(([feedKey, feeds]) => (
                                        <>
                                          <FeedCard feeds={feeds} feedKey={feedKey} origin='GROUP' originId={aboutGroupDetails.id} />
                                        </>
                                      ))
                                      : (
                                        <>
                                          <IonCard className='ion-padding ion-no-margin ion-margin-bottom ion-margin-top'>
                                            {t('groupproperties.text26')}
                                          </IonCard>
                                        </>
                                      )}
                                </div>
                                <IonInfiniteScroll
                                  onIonInfinite={loadData}
                                  threshold="100px"
                                  disabled={isInfiniteDisabled}
                                >
                                  <IonInfiniteScrollContent
                                    loadingSpinner="circular"
                                    loadingText={t('appproperties.text215')}
                                  ></IonInfiniteScrollContent>
                                </IonInfiniteScroll>   </>
                              : ''}
                          </>
                        );
                      } else if (categoryState === 'ABOUT') {
                        return <div className='mt-n3'><AboutGroup aboutGroupDetails={aboutGroupDetails} /></div>;
                      } else if (categoryState === 'RULE') {
                        return <div className='mt-n3'><GroupRule aboutGroupDetails={aboutGroupDetails} /></div>;
                      } else if (categoryState === 'MEMBER') {
                        return <div className='mt-n3'><GroupMember /></div>;
                      }
                    })()}
                  </>
                  : ''
                : '' : ''}
            </IonContent>
            <div className='mobile-back-screen show-mobile'>
              <IonIcon className='icon-mobile' icon={arrowBack} onClick={removeMobileCss}></IonIcon>
            </div>
            <GroupDetail
              groupId={gId}
              setGroupDetails={setGroupDetails}
              groupDetail={groupDetail}
              getGroupDetails={getGroupDetails}
              getGroupLists={getGroupLists}
              loading={loading}
              setReportHideState={setReportHideState}
              reportHideState={reportHideState}
            />
            {!reportHideState ? groupDetail.isHide !== true
              ? <IonRow className="ion-padding-top gup-btn-action">
                {aboutGroupDetails !== undefined && aboutGroupDetails.isMember === true
                  ? <IonButton
                    className={postBtnClass}
                    shape="round"
                    size="small"
                    onClick={() => getAllCategoryData('POST')}
                  >
                    {t('appproperties.text73')}
                  </IonButton>
                  : ''}
                {aboutGroupDetails !== undefined
                  ? <><IonButton
                    className={aboutBtnClass}
                    shape="round"
                    size="small"
                    onClick={() => getAllCategoryData('ABOUT')}
                  >
                    {t('commonproperties.text17')}
                  </IonButton>
                    <IonButton
                      className={groupRuleBtnClass}
                      shape="round"
                      size="small"
                      onClick={() => getAllCategoryData('RULE')}
                    >
                      {t('appproperties.text309')}
                    </IonButton></>
                  : ''}
                {aboutGroupDetails !== undefined && aboutGroupDetails.isMember === true
                  ? <IonButton
                    className={memberBtnClass}
                    shape="round"
                    size="small"
                    onClick={() => getAllCategoryData('MEMBER')}
                  >
                    {t('appproperties.text192')}
                  </IonButton>
                  : ''}
              </IonRow>
              : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                {t('groupproperties.text25')}
              </p> : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
              {t('groupproperties.text25')}
            </p>}
            {!reportHideState ? groupDetail.isHide !== true
              ? !loadComponent
                ? <>
                  {(() => {
                    if (categoryState === 'POST') {
                      if (aboutGroupDetails !== undefined && aboutGroupDetails.isMember !== true) {
                        getAllCategoryData('ABOUT');
                      }
                      return (
                        <>
                          {aboutGroupDetails !== undefined && aboutGroupDetails.isMember === true ? <Post origin="GROUP" originId={aboutGroupDetails.id} /> : ''}
                          {aboutGroupDetails !== undefined && aboutGroupDetails.isMember === true
                            ? <>
                              <div>
                                {feedloading
                                  ? <SkeletonFeedComon column={5} />
                                  : getFeedDatas.length > 0
                                    ? Object.entries(getFeedDatas).map(([feedKey, feeds]) => (
                                      <>
                                        <FeedCard feeds={feeds} feedKey={feedKey} origin='GROUP' originId={aboutGroupDetails.id} />
                                      </>
                                    ))
                                    : (
                                      <>
                                        <IonCard className='ion-padding ion-no-margin ion-margin-bottom ion-margin-top'>
                                          {t('groupproperties.text26')}
                                        </IonCard>
                                      </>
                                    )}
                              </div>
                              {!feedloading
                                ? <IonInfiniteScroll
                                  onIonInfinite={loadData}
                                  threshold="100px"
                                  disabled={isInfiniteDisabled}
                                >
                                  <IonInfiniteScrollContent
                                    loadingSpinner="circular"
                                    loadingText={t('appproperties.text215')}
                                  ></IonInfiniteScrollContent>
                                </IonInfiniteScroll> : <SkeletonFeedComon column={5} />}   </>
                            : ''}
                        </>
                      );
                    } else if (categoryState === 'ABOUT') {
                      return <AboutGroup aboutGroupDetails={aboutGroupDetails} />;
                    } else if (categoryState === 'RULE') {
                      return <GroupRule aboutGroupDetails={aboutGroupDetails} />;
                    } else if (categoryState === 'MEMBER') {
                      return <GroupMember />;
                    }
                  })()}
                </>
                : ''
              : '' : ''}
          </IonCol>
        </div>
      </IonRow>
    </IonRow>
  );
};
export default GroupDetailsPage;
