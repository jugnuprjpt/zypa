import { IonRow } from '@ionic/react';
import React from 'react';
import { useParams } from 'react-router';
import Recommendations from '../components/profile/Recommendations';

const RecommendationsPage = () => {
  const { userId, userName } = useParams();
  return (
        <IonRow className="plane-bg">
        <IonRow className="container full-width-row myactivity-display-block">
            <Recommendations userId={userId} userName={userName} />
        </IonRow>
    </IonRow>
  );
};
export default RecommendationsPage;
