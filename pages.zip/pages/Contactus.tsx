import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import contactusv2 from '../assets/img/contactusv2.png';
import ClientCaptcha from 'react-client-captcha';
import MetaTage from '../components/common/MetaTage';
import MetaTagProperties from '../properties/MetaTagProperties';
import CallFor from '../util/CallFor';
import { useTranslation } from 'react-i18next';

const Contactus = () => {
  const { t } = useTranslation();
  const [captchaCode, setCaptcha] = useState();
  const [userFormState, setUserFormState] = useState({});
  const [btnSubmit, setBtnSubmit] = useState(false);
  const [loading, setloading] = useState(false);
  const [isValid, setIsValid] = useState(false);
  const [lastNameIsValid, setLastNameIsValid] = useState(false);
  const [phoneNumberIsValid, setPhoneNumberIsValid] = useState(false);
  const [subjectIsValid, setSubjectIsValid] = useState(false);
  const [descriptionIsValid, setDescriptionIsValid] = useState(false);
  const [captchaIsValid, setCaptchaIsValid] = useState(false);
  const letters = /^[A-Za-z ]+$/;
  const {
    register,
    handleSubmit,
    reset,
    clearErrors,
    setError,
    formState: { errors }
  } = useForm({
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });
  const userformDataChangeHandler = (event) => {
    if (event.target.value !== undefined) {
      if (event.target.value.length > 0) {
        event.target.className =
          'form-control input-fill';
        // $(this).parent().addClass('color');
      } else {
        event.target.className =
          'form-control';
        // $(this).parent().removeClass('color');
      }
    }
    setUserFormState({
      ...userFormState,
      [event.target.name]: event.target.value
    });
  };
  const firstNameHandler = (event) => {
    const fname = document.getElementById('firstName').value;
    if (fname !== undefined && fname !== null) {
      const fnameText = fname.trim();
      if (fname.length === 0) {
        setError('firstName', {
          type: 'manual',
          message: t('commonproperties.text10')
        });
        setIsValid(false);
      } else if (fnameText.length === 0) {
        setError('firstName', {
          type: 'manual',
          message: t('commonproperties.text10')
        });
        setIsValid(false);
      } else if (fnameText.length < 2) {
        setError('firstName', {
          type: 'manual',
          message: t('commonproperties.text13')
        });
        setIsValid(false);
      } else if (fnameText.length > 100) {
        setError('firstName', {
          type: 'manual',
          message: t('userproperties.text15')
        });
        setIsValid(false);
      } else if (!letters.test(fnameText)) {
        setError('firstName', {
          type: 'manual',
          message: t('commonproperties.text4')
        });
        setIsValid(false);
      } else {
        clearErrors('firstName');
        setIsValid(true);
      }
    }
    setUserFormState({
      ...userFormState,
      [event.target.name]: event.target.value
    });
  };
  const firstNameblurHandler = () => {
    const fname = document.getElementById('firstName').value;
    // const letters = /^[A-Za-z]+$/;
    if (fname !== undefined && fname !== null) {
      const fnameText = fname.trim();
      if (fname.length === 0) {
        setError('firstName', {
          type: 'manual',
          message: t('commonproperties.text10')
        });
        setIsValid(false);
      } else if (fnameText.length === 0) {
        setError('firstName', {
          type: 'manual',
          message: t('commonproperties.text10')
        });
        setIsValid(false);
      } else if (fnameText.length < 2) {
        setError('firstName', {
          type: 'manual',
          message: t('commonproperties.text13')
        });
        setIsValid(false);
      } else if (fnameText.length > 100) {
        setError('firstName', {
          type: 'manual',
          message: t('userproperties.text15')
        });
        setIsValid(false);
      } else if (!letters.test(fnameText)) {
        setError('firstName', {
          type: 'manual',
          message: t('commonproperties.text4')
        });
        setIsValid(false);
      } else {
        clearErrors('firstName');
        setIsValid(true);
      }
    }
  };
  const lastNameHandler = (event) => {
    const lname = document.getElementById('lastName').value;
    if (lname !== undefined && lname !== null) {
      const lnameText = lname.trim();
      if (lname.length === 0) {
        setError('lastName', {
          type: 'manual',
          message: t('commonproperties.text11')
        });
        setLastNameIsValid(false);
      } else if (lnameText.length === 0) {
        setError('lastName', {
          type: 'manual',
          message: t('commonproperties.text11')
        });
        setLastNameIsValid(false);
      } else if (lnameText.length < 2) {
        setError('lastName', {
          type: 'manual',
          message: t('commonproperties.text13')
        });
        setLastNameIsValid(false);
      } else if (lnameText.length > 100) {
        setError('lastName', {
          type: 'manual',
          message: t('userproperties.text15')
        });
        setLastNameIsValid(false);
      } else if (!letters.test(lnameText)) {
        setError('lastName', {
          type: 'manual',
          message: t('commonproperties.text4')
        });
        setLastNameIsValid(false);
      } else {
        clearErrors('lastName');
        setLastNameIsValid(true);
      }
    }
    setUserFormState({
      ...userFormState,
      [event.target.name]: event.target.value
    });
  };
  const lastNameblurHandler = () => {
    const lname = document.getElementById('lastName').value;
    if (lname !== undefined && lname !== null) {
      const lnameText = lname.trim();
      if (lname.length === 0) {
        setError('lastName', {
          type: 'manual',
          message: t('commonproperties.text11')
        });
        setLastNameIsValid(false);
      } else if (lnameText.length === 0) {
        setError('lastName', {
          type: 'manual',
          message: t('commonproperties.text11')
        });
        setLastNameIsValid(false);
      } else if (lnameText.length < 2) {
        setError('lastName', {
          type: 'manual',
          message: t('commonproperties.text13')
        });
        setLastNameIsValid(false);
      } else if (lnameText.length > 100) {
        setError('lastName', {
          type: 'manual',
          message: t('userproperties.text15')
        });
        setLastNameIsValid(false);
      } else if (!letters.test(lnameText)) {
        setError('lastName', {
          type: 'manual',
          message: t('commonproperties.text4')
        });
        setLastNameIsValid(false);
      } else {
        clearErrors('lastName');
        setLastNameIsValid(true);
      }
    }
  };
  const phoneHandler = (event) => {
    const phone = document.getElementById('phoneNumber').value;
    if (phone !== undefined && phone !== null) {
      const phoneNumber = phone.trim();
      if (phone.length === 0) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text23')
        });
        setPhoneNumberIsValid(false);
      } else if (phoneNumber.length === 0) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text23')
        });
        setPhoneNumberIsValid(false);
      } else if (phoneNumber.length < 10) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text24')
        });
        setPhoneNumberIsValid(false);
        if (isNaN(phoneNumber)) {
          setError('phoneNumber', {
            type: 'manual',
            message: t('signuprecommendation.text24')
          });
          setPhoneNumberIsValid(false);
        }
      } else if (phoneNumber.length > 15) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text24')
        });
        setPhoneNumberIsValid(false);
        if (isNaN(phoneNumber)) {
          setError('phoneNumber', {
            type: 'manual',
            message: t('signuprecommendation.text24')
          });
          setPhoneNumberIsValid(false);
        }
      } else if (isNaN(phoneNumber)) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text24')
        });
        setPhoneNumberIsValid(false);
      } else {
        clearErrors('phoneNumber');
        setPhoneNumberIsValid(true);
      }
    }
    setUserFormState({
      ...userFormState,
      [event.target.name]: event.target.value
    });
  };
  const phoneblurHandler = () => {
    const phone = document.getElementById('phoneNumber').value;
    if (phone !== undefined && phone !== null) {
      const phoneNumber = phone.trim();
      if (phone.length === 0) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text23')
        });
        setPhoneNumberIsValid(false);
      } else if (phoneNumber.length === 0) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text23')
        });
        setPhoneNumberIsValid(false);
      } else if (phoneNumber.length < 10) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text24')
        });
        setPhoneNumberIsValid(false);
        if (isNaN(phoneNumber)) {
          setError('phoneNumber', {
            type: 'manual',
            message: t('signuprecommendation.text24')
          });
          setPhoneNumberIsValid(false);
        }
      } else if (phoneNumber.length > 15) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text24')
        });
        setPhoneNumberIsValid(false);
        if (isNaN(phoneNumber)) {
          setError('phoneNumber', {
            type: 'manual',
            message: t('signuprecommendation.text24')
          });
          setPhoneNumberIsValid(false);
        }
      } else if (isNaN(phoneNumber)) {
        setError('phoneNumber', {
          type: 'manual',
          message: t('signuprecommendation.text24')
        });
        setPhoneNumberIsValid(false);
      } else {
        clearErrors('phoneNumber');
        setPhoneNumberIsValid(true);
      }
    }
  };
  const subjectHandler = (event) => {
    const subject = document.getElementById('subject').value;
    if (subject !== undefined && subject !== null) {
      const subjectText = subject.trim();
      if (subject.length === 0) {
        setError('subject', {
          type: 'manual',
          message: t('signuprecommendation.text26')
        });
        setSubjectIsValid(false);
      } else if (subjectText.length === 0) {
        setError('subject', {
          type: 'manual',
          message: t('signuprecommendation.text26')
        });
        setSubjectIsValid(false);
      } else if (subjectText.length < 10) {
        setError('subject', {
          type: 'manual',
          message: t('commonproperties.text28')
        });
        setSubjectIsValid(false);
      } else if (subjectText.length > 100) {
        setError('subject', {
          type: 'manual',
          message: 'Subject must be at least 100 characters'
        });
        setSubjectIsValid(false);
      } else {
        clearErrors('subject');
        setSubjectIsValid(true);
      }
    }
    setUserFormState({
      ...userFormState,
      [event.target.name]: event.target.value
    });
  };
  const subjectblurHandler = () => {
    const subject = document.getElementById('subject').value;
    if (subject !== undefined && subject !== null) {
      const subjectText = subject.trim();
      if (subject.length === 0) {
        setError('subject', {
          type: 'manual',
          message: t('signuprecommendation.text26')
        });
        setSubjectIsValid(false);
      } else if (subjectText.length === 0) {
        setError('subject', {
          type: 'manual',
          message: t('signuprecommendation.text26')
        });
        setSubjectIsValid(false);
      } else if (subjectText.length < 10) {
        setError('subject', {
          type: 'manual',
          message: t('commonproperties.text28')
        });
        setSubjectIsValid(false);
      } else if (subjectText.length > 100) {
        setError('subject', {
          type: 'manual',
          message: 'Subject must be at least 100 characters'
        });
        setSubjectIsValid(false);
      } else {
        clearErrors('subject');
        setSubjectIsValid(true);
      }
    }
  };
  const descriptionHandler = (event) => {
    const description = document.getElementById('description').value;
    if (description !== undefined && description !== null) {
      const descriptionText = description.trim();
      if (description.length === 0) {
        setError('description', {
          type: 'manual',
          message: t('signuprecommendation.text31')
        });
        setDescriptionIsValid(false);
      } else if (descriptionText.length === 0) {
        setError('description', {
          type: 'manual',
          message: t('signuprecommendation.text31')
        });
        setDescriptionIsValid(false);
      } else if (descriptionText.length < 10) {
        setError('description', {
          type: 'manual',
          message: t('commonproperties.text28')
        });
        setDescriptionIsValid(false);
      } else if (descriptionText.length > 100) {
        setError('description', {
          type: 'manual',
          message: 'Description must be at least 100 characters'
        });
      } else {
        clearErrors('description');
        setDescriptionIsValid(true);
      }
    }
    setUserFormState({
      ...userFormState,
      [event.target.name]: event.target.value
    });
  };
  const descriptionblurHandler = () => {
    const description = document.getElementById('description').value;
    if (description !== undefined && description !== null) {
      const descriptionText = description.trim();
      if (description.length === 0) {
        setError('description', {
          type: 'manual',
          message: t('signuprecommendation.text31')
        });
        setDescriptionIsValid(false);
      } else if (descriptionText.length === 0) {
        setError('description', {
          type: 'manual',
          message: t('signuprecommendation.text31')
        });
        setDescriptionIsValid(false);
      } else if (descriptionText.length < 10) {
        setError('description', {
          type: 'manual',
          message: t('commonproperties.text28')
        });
        setDescriptionIsValid(false);
      } else if (descriptionText.length > 100) {
        setError('description', {
          type: 'manual',
          message: 'Description must be at least 100 characters'
        });
        setDescriptionIsValid(false);
      } else {
        clearErrors('description');
        setDescriptionIsValid(true);
      }
    }
  };
  const chapchaHandler = () => {
    const captchaValue = document.getElementById('captcha').value;
    if (captchaValue !== undefined && captchaValue !== null) {
      if (captchaValue.length === 0) {
        setError('captcha', {
          type: 'manual',
          message: t('signuprecommendation.text35')
        });
        setCaptchaIsValid(false);
      } else if (captchaValue.length > 0 && captchaValue !== captchaCode) {
        const remText = captchaValue.trim();
        if (remText.length === 0) {
          setError('captcha', {
            type: 'manual',
            message: t('signuprecommendation.text35')
          });
          setCaptchaIsValid(false);
        } else {
          setError('captcha', {
            type: 'manual',
            message: t('signuprecommendation.text36')
          });
          setCaptchaIsValid(false);
        }
        setCaptchaIsValid(false);
      } else {
        clearErrors('captcha');
        setCaptchaIsValid(true);
      }
      // setCaptchaIsValid(true);
    }
  };
  const blurHandler = () => {
    const captchaValue = document.getElementById('captcha').value;
    if (captchaValue !== undefined && captchaValue !== null) {
      if (captchaValue.length === 0) {
        setError('captcha', {
          type: 'manual',
          message: t('signuprecommendation.text35')
        });
        setCaptchaIsValid(false);
      } else if (captchaValue.length > 0 && captchaValue !== captchaCode) {
        setError('captcha', {
          type: 'manual',
          message: t('signuprecommendation.text36')
        });
        setCaptchaIsValid(false);
      } else {
        clearErrors('captcha');
        setCaptchaIsValid(true);
      }
      // setCaptchaIsValid(true);
    }
  };
  const submitHandler = async(event: any) => {
    setloading(true);
    setBtnSubmit(true);
    descriptionblurHandler();
    firstNameblurHandler();
    lastNameblurHandler();
    subjectblurHandler();
    descriptionblurHandler();
    phoneblurHandler();
    blurHandler();
    if (isValid && lastNameIsValid && phoneNumberIsValid && subjectIsValid && descriptionIsValid && captchaIsValid) {
      const data = new FormData();
      let firstName = '';
      let lastName = '';
      let phoneNumber = '';
      let subject = '';
      let description = '';
      if (userFormState.firstName !== undefined && userFormState.firstName !== null) {
        firstName = userFormState.firstName.trim();
        userFormState.firstName = firstName;
      }
      if (userFormState.lastName !== undefined && userFormState.lastName !== null) {
        lastName = userFormState.lastName.trim();
        userFormState.lastName = lastName;
      }
      if (userFormState.phoneNumber !== undefined && userFormState.phoneNumber !== null) {
        phoneNumber = userFormState.phoneNumber.trim();
        userFormState.phoneNumber = phoneNumber;
      }
      if (userFormState.subject !== undefined && userFormState.subject !== null) {
        subject = userFormState.subject.trim();
        userFormState.subject = subject;
      }
      if (userFormState.description !== undefined && userFormState.description !== null) {
        description = userFormState.description.trim();
        userFormState.description = description;
      }
      data.append('contactus', JSON.stringify(userFormState));
      const response = await CallFor(
        'api/v1/contactus',
        'POST',
        JSON.stringify(userFormState),
        'withoutAuth'
      );
      if (response.status === 200) {
        setUserFormState({});
        reset({
          firstName: '',
          lastName: '',
          subject: '',
          phoneNumber: '',
          description: '',
          captcha: ''
        });
        document.getElementById('retryButton').click();

        // document.getElementById('firstName').value = '';
        // document.getElementById('lastName').value = '';
        // document.getElementById('phoneNumber').value = '';
        // document.getElementById('subject').value = '';
        // document.getElementById('description').value = '';
        // document.getElementById('captcha').value = '';
        // document.getElementById('captchaCode').value = '';
        setIsValid(false);
        setLastNameIsValid(false);
        setPhoneNumberIsValid(false);
        setSubjectIsValid(false);
        setDescriptionIsValid(false);
        setCaptchaIsValid(false);
      } else if (response.status === 400) {
        const jsonresponse = await response.json();
        console.log(jsonresponse.error.errors[0].field);
        if (jsonresponse.error.errors[0].field === 'phoneNumber') {
          setError('phoneNumber', {
            type: 'manual',
            message: t('signuprecommendation.text24')
          });
        }
      }
    }

    setloading(false);
    setBtnSubmit(false);
  };
  return (<>
    <MetaTage metaDetails ={MetaTagProperties.contactus}/>
    <div className='web-pages-before contactus-page'>
       <section className="wow fadeIn sts-web contactus-tag">
       <div className="container">
         <h1 className="WhiteText wow fadeInUp text-center">{t('signuprecommendation.text11')}</h1>
         </div>
       </section>
       <section className="contact-form-sec">
         <div className="container">
           <div className="content-row contact-form">
             <div className="ContentRL pb-0">
               <div className="CLeft wow fadeInLeft" data-wow-offset="100">
                 <h2 className="PrimeryText text-left">Get In <span className="SecondryText fw-bold"> Touch</span></h2>
                 <div>
                   <form onSubmit={handleSubmit(submitHandler)} data-testid="form-submit" autoComplete="off"
              className="h-100" noValidate>
                     <div className="row">
                       <div className="col-sm-6">
                         <div className="form-group">
                           <input type="text"
                             id='firstName'
                             {...register('firstName')}
                             className={
                               errors.firstName
                                 ? 'error-border form-control'
                                 : 'form-control'
                             }
                              placeholder="" autoComplete='off'
                              onChange={firstNameHandler}
                              onBlur={firstNameblurHandler}
                              value={userFormState.firstName}
                               />
                           <span>{t('commonproperties.text5')}</span>
                           <p className={errors.firstName ? 'error' : ''}>
                             {errors.firstName?.message}
                           </p>
                         </div>
                       </div>
                       <div className="col-sm-6">
                         <div className="form-group">
                           <input type="text"
                             className={
                               errors.lastName
                                 ? 'error-border form-control'
                                 : 'form-control'
                             }
                             id='lastName'
                             value={userFormState.lastName}
                             {...register('lastName')} autoComplete='off'
                             onChange={lastNameHandler}
                             onBlur={lastNameblurHandler}
                             />
                           <span>{t('commonproperties.text6')}</span>
                           <p className={errors.lastName ? 'error' : ''}>
                             {errors.lastName?.message}
                           </p>
                         </div>
                       </div>
                     </div>
                     <div className="row">
                       <div className="col">
                         <div className="form-group">
                           <input type="text" inputMode='numeric'
                           className={
                             errors.phoneNumber
                               ? 'error-border form-control'
                               : 'form-control'
                             }
                              id='phoneNumber'
                              {...register('phoneNumber')}
                              autoComplete='off'
                              maxLength={15}
                              onChange={phoneHandler}
                              onBlur={phoneblurHandler}
                              value={userFormState.phoneNumber}
                           />
                           <span>{t('signuprecommendation.text22')}</span>
                           <p className={errors.phoneNumber ? 'error' : ''}>
                             {errors.phoneNumber?.message}
                           </p>
                         </div>
                       </div>
                     </div>
                     <div className="row">
                       <div className="col">
                         <div className="form-group">
                           <input type="text"
                             className={
                               errors.subject
                                 ? 'error-border form-control'
                                 : 'form-control'
                               }
                           id='subject' {...register('subject')}
                            autoComplete='off'
                            // onChange={userformDataChangeHandler}
                            onChange={subjectHandler}
                            onBlur={subjectblurHandler}
                            value={userFormState.subject}
                           />
                           <span>{t('signuprecommendation.text25')}</span>
                           <p className={errors.subject ? 'error' : ''}>
                             {errors.subject?.message}
                           </p>
                         </div>
                       </div>
                     </div>
                     <div className="row">
                       <div className="col">
                         <div className="form-group">
                           <textarea className={
                               errors.description
                                 ? 'error-border form-control p-2'
                                 : 'form-control p-2'
                               } rows="3" placeholder="" id='description' {...register('description')}
                            autoComplete='off'
                            // onChange={userformDataChangeHandler}
                            onChange={descriptionHandler}
                            onBlur={descriptionblurHandler}
                            value={userFormState.description}
                           ></textarea>
                           <span className='floating'>{t('commonproperties.text39')}</span>
                           <p className={errors.description ? 'error' : ''}>
                             {errors.description?.message}
                           </p>
                         </div>
                       </div>
                     </div>
                     <div className="row">
                       <div className="col-sm-6">
                         <div className="form-group">
                          <input
                             type="text"
                             id='captcha'
                             className={
                               errors.captcha
                                 ? 'error-border form-control'
                                 : 'form-control'
                               }
                             {...register('captcha')}
                             // onChange={userformDataChangeHandler}
                             onChange={chapchaHandler}
                             onBlur={blurHandler}
                             value={userFormState.captcha}
                           />

                           <span>{t('signuprecommendation.text34')}</span>
                           <p className={errors.captcha ? 'error' : ''}>
                             {errors.captcha?.message}
                           </p>
                           <input
                             type="hidden" id='captchaCode'
                             value={captchaCode}
                             {...register('captchaCode')}
                           />
                           <ClientCaptcha
                                 captchaCode={setCaptcha}
                                 chars="abc123@"
                                 charsCount={6}
                                 width={250}
                                 fontSize={35}
                                 fontColor="#00b6ad"
                                 captchaClassName="captch-content"
                           />
                         </div>
                       </div>
                     </div>
                     <div className="row">
                       <div className="col">
                         <button className="btn-about mt-2 btn-full" type='submit' size='default' disabled={btnSubmit}>Submit
                         {loading
                           ? <span className="loader" id="loader-2">
                              <span></span>
                              <span></span>
                              <span></span>
                            </span>
                           : ''
                            }
                         </button>
                       </div>
                     </div>
                   </form>
                 </div>
               </div>
               <div className="CRight wow fadeInRight" data-wow-offset="100">
                 <img src={contactusv2} alt="Indian business to do business" />
               </div>
             </div>
           </div>
           <div className="contact-address-details">
             <div className="ContentRL">
               <div className="CLeft wow fadeInLeft" data-wow-offset="100">
                 <div className="block">
                   <span className="icon"> <i className="fas fa-building"></i> </span>
                   <h4 className="PrimeryText">t('appproperties.text266')</h4>
                   <div className="SecondryText">Lets Talk Business Pvt. Ltd.</div>
                 </div>
                 <div className="block">
                   <span className="icon"><i className="fas fa-envelope"></i></span>
                   <h4 className="PrimeryText">Email Address</h4>
                   <div className="SecondryText"><a href="mailto:info@zyapaar.com" className="SecondryText">info@zyapaar.com</a> </div>
                 </div>
               </div>
               <div className="CRight wow fadeInRight" data-wow-offset="100">
                 <div className="block">
                   <span className="icon"><i className="fas fa-map-marker-alt"></i></span>
                   <h4 className="PrimeryText">Address</h4>
                   <address className="SecondryText">
                     601, Shikhar Complex, <br />
                     Nr.Adani House, Mithakhali Six Road, <br />
                     Navrangpura, Ahmedabad - 380009,  <br />
                     Gujarat, India.<br />
                   </address>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </section>
    </div>
  </>);
};

export default Contactus;
