import { IonIcon } from '@ionic/react';
import { arrowBack } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';
import MetaTags from 'react-meta-tags';
import { useHistory } from 'react-router';

const TermsOfUse = () => {
    const { t } = useTranslation();
  const history = useHistory();
  const backbtn = () => {
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
    history.goBack();
  };
  return (
    <>
    <MetaTags>
            <meta charSet="UTF-8" />
            <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>Terms of use - Zyapaar</title>
            <link rel="canonical" href={window.location.href} />
            <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png" />
            <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png" />
            <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png" />
            <link rel="manifest" href="assets/img/site.webmanifest" />
    </MetaTags>
    <div className='web-pages-before privacy-policypage'>
<section className="wow fadeIn heading-background sts-web contactus-tag">
        <div className= 'mobile-back-screen show-mobile title-back ion-margin-bottom back-with-heading mt-3 ms-3'>
            <IonIcon className='icon-mobile' icon={arrowBack} onClick= {backbtn} ></IonIcon>
            <h3 className='mt-0'>Terms of use</h3>
        </div>
        <div className="container dn-mobile">
            <h1 className="text-center WhiteText wow fadeInUp ">Terms of use</h1>
        </div>
</section>
<section className="terms py-lg-5 py-4 pr-2 pl-2">
    <div className="container">
    <div className="trm-block">
            <h3>1. Introduction</h3>
            <p>Welcome to https://www.zyapaar.com/ <strong>(“Website”)</strong> and Zyapaar mobile applications for android and IOS operating systems <strong> (“Application”) </strong>, a platform that provides virtual networking opportunity and related services for service provider, manufacturer, trader, dealer, retailers and their employees/associates (Website and Application are hereinafter collectively referred to as <strong>“Platform”</strong>) owned and managed by Lets Talk Business Private Limited and its affiliates <strong>(“Company”)</strong>.</p>
            <p>These Terms of Service (<strong>“Terms”</strong>/ <strong>“Terms of Service”</strong>)) along with privacy policy of the Platform (“Privacy Policy”) and other terms and conditions of the Platform, govern your visit and use of the Platform for virtual networking opportunity and related services (together or individually referred to as <strong>“Service”</strong>) operated by the Company.</p>
            <p>In this Terms of Services "we", "our" and "us" refers to the Company and "you", "your" and/or “Users” refers to the user of the Platform. Our Platform is for the users intending to avail the Services.</p>
            <p>You must be 18 years of age or older to visit or use the Website and/or Application in any manner. If you are under the age of 18, you should review this Terms of Service with your parent or legal guardian to make sure that you and your parent or legal guardian understands and agrees to it and further, if required, you shall perform or undertake such activities which will entitle you to enter into a legally binding agreement with the Company. If you are availing the Services on behalf of your business organization as an admin user (“Admin User”), you represent and warrant that you have the actual authority to agree to the terms and conditions of this agreement on behalf of such legal entity. By visiting this Website and/or Application or accepting this Terms of Services, you represent and warrant to the Company that you are 18 years of age or older, and that you have the right, authority and capacity to use the Website and/or Application and agree to and abide by this Terms of Services.</p>
            <p>This Terms of Services is an electronic record in the form of an electronic contract formed under the Information Technology Act, 2000, rules made thereunder, and any other applicable statutes, as amended from time to time. This Terms of Services does not require any physical, electronic or digital signature.</p>
            <p>Please read these Terms of Services carefully. By accessing the Website, and utilising the Services on the Platform, you indicate, agree and acknowledge that you understand, agree and consent to this Terms of Services, our Privacy Policy and other terms and conditions of the Platform (“Agreement”), and to the collection and use of information in accordance with this Terms of Services.</p>
            <p>If you are representing your business organisation as an Admin User, you will have right to create and/or update and/or manage the account credential on behalf of the business entity. Your use of the Services on behalf of your business organization shall also be governed by this Agreement.
            If you do not agree with (or cannot comply with) Agreements, then you may not use the Service, but please let us know by emailing at <a href="mailto:customercare@zyapaar.com">customercare@zyapaar.com</a> so we can try to find a solution. These Terms apply to all visitors, users and others who wish to access or use Service.
            The User expressly agrees and acknowledges that these Terms of Services and Privacy Policy are co-terminus in nature and that expiry/termination of either one will lead to the termination of the other.</p>
    </div>
    <div className="trm-block">
            <h3>2. System Requirements</h3>
            <p>Use of the Services requires one or more compatible devices, Internet access (fees may apply), and certain software (fees may apply), and may require obtaining updates or upgrades from time to time. Because use of the Services involves hardware, software, and Internet access, your ability to access and use the Services may be affected by the performance of these factors. High speed Internet access is recommended. You acknowledge and agree that such system requirements, which may be changed from time to time, are your responsibility.</p>
        </div>

        <div className="trm-block">
            <h3>3. Services</h3>
           <p> The Company will provide the Services, and standard updates to the Services that are made generally available by the Company during the term. The Company may, in its sole discretion, discontinue the Services or modify the features of the Services from time to time without prior notice.</p>

           <p> Subject to all the terms and conditions of the Agreement, the Company grants non-exclusive, non-transferable, non-sublicensable right and license to access and use the Platform and the Service(s) solely for your business purposes, but only in accordance with the Agreement and these Terms of Services (including without limitation any applicable service-specific terms), the documentation, and all applicable scope of Use descriptions.</p>

           <p> Users can access different modules on the Platform based on access rights given to them by their Admin User. Users of business organisation generate data on the Platform based on their access rights and usage.</p>
        </div>
        <div className="trm-block">
            <h3>4. Accounts</h3>
            <p>Use of Services on the Platform is available only to persons who can form legally binding contract. When you create an account with us, you guarantee that you are above the age of 18 years, and that the information you provide us is accurate, complete, and current at all times. Inaccurate, incomplete, or obsolete information may result in the immediate termination of your account on the Platform. </p>
            <p>In case the Service needs to be used by a person under the age of 18 years, then the account must be created by the parents or legal guardian who has agreed to these Terms of Services. In the event Services is to be used by an entity, then the account for such entity must be created by authorised personal of such entity. In the event a person below the age of 18 years utilizes the Service, it is assumed that he/she has obtained the consent of the parents or legal guardian and such use is made available by the parents or legal guardian. The Company will not be responsible for any consequence that arises as a result of misuse of any kind that may occur by virtue of any person registering for the Service.</p>
            <p>Users need to sign up for a user account by providing all required information in order to access or use the Services. To use various Services on the Platform, User is required to provide the name and other requisite information of the business organization he/she belongs to. We recommend that you, and all other users from your organization, sign up for user accounts by providing your corporate contact information. You agree to:
                <ul className='my-ul-element'>
                    <li>(a) provide true, accurate, current and complete information about yourself as prompted by the sign up process; and </li>
                    <li>(b) Maintain and promptly update the information provided during sign up to keep it true, accurate, current, and complete. If you provide any information that is untrue, inaccurate, outdated, or incomplete, or if the Company has reasonable grounds to suspect that such information is untrue, inaccurate, outdated, or incomplete, the Company may terminate your user account and refuse current or future use of any or all of the Services.</li>
                </ul>

            </p>
            <p>When you as an Admin User create an account for your business organization you may specify one or more administrators. The administrators will have the right to configure the Services based on your requirements and manage Users in your organization account.</p>
            <p>You are responsible for maintaining the confidentiality of your account and/or password, including but not limited to the restriction of access to your computer and/or account. You agree to accept responsibility for any and all activities or actions that occur under your account and/or password, whether your password is with our Service or a third-party service. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account. </p>
            <p>If you are using the Service as an Admin User, you are responsible for:
                <ul className='my-ul-element'>
                    <li>(i) Ensuring confidentiality of your organization account and/or password,</li>
                    <li>(ii) Appointing / registering competent individuals as administrators for managing your organization account, and </li>
                    <li>(iii) Ensuring that all activities that occur in connection with your organization account comply with this Terms of Services. You understand that the Company is not responsible for account administration and internal management of the Services for you.</li>

                </ul>
            </p>
            <p>You may not use the name of another person or entity or that is not lawfully available for as a username, a name or trademark that is subject to any rights of another person or entity other than you, without appropriate authorization. You may not use any name that is offensive, vulgar or obscene as a username.</p>
            <p>Your business organization’s Admin User shall authorise your User account to be liked with its business organisation through the admin panel of the Platform. The administrator of your business organisation might require you to follow additional rules and Admin User may be able to access your User account and/or delink your User account from its business organisation on the Platform, in its sole discretion. User may also change and/or delink himself / herself from his/her business organisation by editing his/her the account information on the Platform. However, User will not be able to use various Services on the Platform if his/her User account is not linked with any business organisation.</p>
            <p>We reserve the right to refuse service, terminate accounts, remove or edit content, or cancel orders in our sole discretion.</p>
       </div>

       <div className="trm-block">
        <h3>5. Communications</h3>
       <p> When You use the Services or send emails or other data, information or communication to the Platform You agree and understand that you are communicating with the Company through electronic modes and other telecommunication modes and by using our Service, you agree to subscribe to newsletters, marketing or promotional materials and other information we may send via any and all electronic, digital and other telecommunication modes. However, you may opt out of receiving any, or all, of these communications from us by following the unsubscribe link or by emailing at <a href="mailto:customercare@zyapaar.com">customercare@zyapaar.com</a>.</p>
       <p> The Company may, based on any form of access to the Application (including free download/trials) or Services or Website or registrations through any source whatsoever, contact the User through WhatsApp, SMS, email, and call, to give information about its products as well as notifications on various important updates and/or to seek permission for demonstration of its products. The User expressly grants such permission to contact him/her through telephone, WhatsApp, SMS, e-mail and holds the Company indemnified against any liabilities including financial penalties, damages, expenses in case the User’s mobile number is registered with Do not Call (DNC) database. By registering yourself, you agree to make your contact details available to Our employees, associates and partners so that you may be contacted for business information and promotions through telephone, WhatsApp, SMS, email, etc.</p>
    </div>

    <div className="trm-block">
        <h3>6. Fees and Charges</h3>
        <p>Membership on the Platform: The Services of the Company offered on the Platform are free at present. The Company reserves the right to charge fees and change its policies thereafter and from time to time. The Company may at its sole discretion introduce new services and modify some or all of the existing services offered on the Platform. In such an event the Company reserves the unrestricted and discretionary right to change, rearrange, add or delete services offerings, the selections in those offerings, prices, and any other service may offer, at any time and accordingly, reserves, the right to introduce fees for the new services and/or for some or all of the existing services on the Platform, as the case may be. Changes to the fee and related policies shall automatically become effective immediately once implemented on the Platform. You shall be solely responsible for compliance of all applicable laws including those in India for making payments to the Company. The Company will endeavor to notify you of any such change and its effective date.</p>
        <p>Pricing / typographical error: If the Company comes across any typographic errors with respect to pricing or services information, the Company shall have the right to rectify the same or cancel the order(s) and refund monies, if any, collected from the customer within 90 (ninety) business days of such corrective action taken.</p>
    </div>
    <div className="trm-block">
        <h3>7. Content</h3>
        <p>Our Service allows you to post, link, store, share and otherwise make available certain information, text, graphics, audio, videos, or other material (“Content”). You are responsible for Content that you post on or through Service, including its legality, reliability, and appropriateness.</p>
        <p>By posting Content on or through the Platform, you represent and warrant that: (i) Content is yours (you own it) and/or you have the right to use it and the right to grant us the rights and license as provided in these Terms, and (ii) that the posting of your Content on or through the Platform does not violate the privacy rights, publicity rights, copyrights, contract rights or any other rights of any person or entity.</p>
        <p>You shall not post, host, display, upload, modify, publish, transmit, store, update or share any Content or information on the Platform that:</p>
        <ul>
            <li> belongs to another person and to which you do not have any right to; or</li>
            <li> that is grossly harmful, harassing, blasphemous, defamatory, libellous, obscene, pornographic, paedophilic, libellous, invasive of another’s privacy, including bodily privacy, hateful, insulting or harassing on the basis of gender, religiously, racially or, ethnically objectionable, disparaging, relating or encouraging money laundering or gambling, or otherwise unlawful in any manner whatever, or unlawfully threatening or unlawfully harassing or misleading in any way; or promoting any such illegal activities; or otherwise inconsistent with or contrary to the laws in force;</li>
            <li> is patently offensive to the online community, such as sexually explicit content, religiously offensive content or content that promotes obscenity, paedophilia, racism, bigotry, hatred or physical harm of any kind against any group or individual; or</li>
            <li> harasses or advocates harassment of another person; or involves the transmission of “junk mail,” “chain letters,” or unsolicited mass mailing or “spamming”; or</li>
            <li> infringes upon or violates any third party’s rights, including without limitation unauthorized disclosure of any person’s personal information e.g. a person’s name, email address, physical address or phone number or rights of publicity; or</li>
            <li> infringes any patent, trademark, copyright, or other proprietary rights or third party’s trade secrets or rights of publicity or privacy or shall not be fraudulent; or</li>
            <li> promotes an infringement of, or illegal or unauthorized copy of another person’s copyrighted work; or</li>
            <li> provides material that exploits people in a sexual, violent, or otherwise inappropriate manner or solicits personal information from anyone; or</li>
            <li> contains video, photographs, or images of another person without his or her express written consent and permission or the permission or the consent of his/her guardian in the case of minor; or</li>
            <li> refers to any website or URL that, in the sole discretion of the Company contains material that is inappropriate for the Platform, or URL of any other website contains content that would be prohibited or violates the letter or spirit of these Terms of Service; or</li>
            <li> tries to gain unauthorized access or exceeds the scope of authorized access to the Platform or to profiles, blogs, communities, account information, bulletins or other areas of the Platform or solicits passwords or personal identifying information for commercial or unlawful purposes from other Users; or</li>
            <li> intends to advertise or engage in commercial activities and/or sales without prior written consent of the Company or intends to mislead, defraud or cheat any person. Throughout these Terms of Service, the Company’s prior written consent” means a communication coming from the Company’s legal personnel, specifically in response to Your request, and specifically addressing the activity or conduct for which you seek authorization; or</li>
            <li> interferes with another User’s use and access to the Platform; or</li>
            <li> is harmful to child or harms minors in any way; or</li>
            <li> violates any law for the time being in force; or</li>
            <li> deceives or misleads the reader/ addressee/ Users about the origin of such messages or knowingly and intentionally communicates any information which is patently false or misleading in nature but may reasonably be perceived as a fact, or grossly offensive or menacing in nature; or impersonate another person; or</li>
            <li> contains software viruses or any other computer code, files or programs designed to interrupt, destroy or limit the functionality of any computer resource; or contains virus, malware or other computer programming routines that may damage, detrimentally interfere with, diminish value of, surreptitiously intercept or expropriate any system, data or personal identifiable information; or</li>
            <li> threatens the unity, integrity, defence, security or sovereignty of India, friendly relations with foreign states, or public order or causes incitement to the commission of any cognizable offence or prevents investigation of any offence or is insulting to any other nation; or</li>
            <li> is patently false and untrue, and is written or published in any form, with the intent to mislead or harass a person, entity or agency for financial gain or to cause any injury to any person; or</li>
            <li> shall not create liability for us or cause us to lose (in whole or in part) the services of our ISPs or other suppliers.</li>
        </ul>

       <p> The Company is under no obligation to examine or verify any Content posted on the Platform by You, and the Company assumes no responsibility or liability relating to any such Content on the Platform nor does the Company assumes or shall assume responsibility or liability for breach of any of your obligation(s) under these Terms of Service. Notwithstanding the above, the Company has the right but not the obligation to monitor, edit, delete the Content provided by users and may decline to accept and/or remove any Content that contain any information inconsistence with these Terms of Service. Any Content uploaded by you shall be subject to relevant laws and these Terms of Service and may be disabled, or and may be subject to investigation under appropriate laws. Furthermore, if you are found to be in non-compliance with the laws and regulations, these Terms, or the privacy policy of the Platform, we may terminate your account/block your access to the Platform and we reserve the right to remove any non- compliant Content uploaded by you and/or claim indemnity on account of such non-compliance. We reserve the right to terminate the account of anyone found to be infringing any intellectual property right of any other person or violating any applicable laws or these Terms of Service. You specifically agree that the Company shall not be responsible for unauthorized access to or alteration of your transmissions or data, any material or data sent or received or not sent or received through the Platform. Further, under no circumstances, the Company shall be liable for any unlawful act of the User or its affiliates, relatives, employees, agents including but not limited to misuse of any data, unfair trade practices, fraud, cyber squatting, hacking and other cyber crimes.</p>
       <p> You retain any and all of your rights to any Content you submit, post or display on or through the Platform and you are responsible for protecting those rights. We take no responsibility and assume no liability for Content you or any third party posts on or through the Platform. However, by posting Content using Service you grant us non-exclusive, worldwide, perpetual, irrevocable, royalty-free, sub-licensable (through multiple tiers) right and license to use, modify, publicly perform, publicly display, reproduce, and distribute such Content on and through Service. You agree that this license includes the right for us to make your Content available to other users of the Platform and the Service, who may also use your Content subject to these Terms.</p>
       <p> In addition, any data, information, material and other content found on or through the Platform are the property of the Company or licensed to the Company. You may not distribute, modify, transmit, reuse, download, repost, copy, or use said data, information, material or other content, whether in whole or in part, for commercial purposes or for personal gain, without express advance written permission from us.</p>
       <p> You understand that the Company has the right at all times to disclose any information (including the identity of the User providing information or materials on the Platform) as necessary to satisfy any law, regulation or valid governmental request, or in response to any court order or summons. In addition, the Company can (and you hereby expressly authorize us to) disclose any information about you to law enforcement or other government officials, as we, in our sole discretion, believe necessary or appropriate in connection with the investigation and/or resolution of possible crimes, especially those that may involve personal injury.</p>
    </div>
    <div className="trm-block">
        <h3>8. Use of the Platform and the Services</h3>
        <p>You may use the Platform and the Services only for lawful purposes and in accordance with these Terms of Services.</p>
        <p>You hereby agree not to use the Platform and the Services:</p>

        <ul>
            <li> In any way that violates any applicable national or international law or regulation.</li>
            <li> For the purpose of exploiting, harming, or attempting to exploit any person or harm minors in any way by exposing them to inappropriate content or otherwise.</li>
            <li> To transmit, or procure the sending of, any advertising or promotional material, including any “junk mail”, “chain letter,” “spam,” or any other similar solicitation.</li>
            <li> To impersonate or attempt to impersonate Company, a Company employee, another user, or any other person or entity.</li>
            <li> In any way that infringes upon the rights of others, or in any way is illegal, threatening, fraudulent, or harmful, or in connection with any unlawful, illegal, fraudulent, or harmful purpose or activity.</li>
            <li> To engage in any other conduct that restricts or inhibits anyone’s use or enjoyment of Service, or which, as determined by us, may harm or offend Company or users of Service or expose them to liability.</li>
        </ul>

        <p>Additionally, you agree not to:</p>
        <ul>

            <li> Use Service in any manner that could disable, overburden, damage, or impair Service or interfere with any other party’s use of Service, including their ability to engage in real time activities through Service.</li>
            <li> Use any “deep-link”, “page-scrape”, “robot”, “spider”, or other automatic device, process, program or means to access the Platform and/or the Service for any purpose, including monitoring or copying any of the material on the Platform.</li>
            <li> Use any manual process to monitor or copy any of the material on Service or for any other unauthorized purpose without our prior written consent.</li>
            <li> Use for any purpose that is unlawful or otherwise prohibited by these Terms of Services, or for other activity which infringes the rights of the Company or others;</li>
            <li> Use any device, software, or routine that interferes with the proper working of the Platform.</li>
            <li> Introduce any viruses, trojan horses, worms, logic bombs, or other material which is malicious or technologically harmful.</li>
            <li> Attempt to gain unauthorized access to, interfere with, damage, or disrupt any parts of Service, the server on which the Platform is stored, or any server, computer, or database connected to Service.</li>
            <li> Attack the Platform via a denial-of-service attack or a distributed denial-of-service attack.</li>
            <li> Take any action that may damage or falsify Company rating.</li>
            <li> In any way decompile, reverse engineer, or disassemble any material or content on the Website.</li>
            <li> Otherwise attempt to interfere with the proper working of the Platform and the Service.</li>
        </ul>

    </div>
    <div className="trm-block">
        <h3>9.Payment</h3>
        <p>For the purpose of paid Services, the Company may enable payments via third party payment service providers (“PSP”) partners and the User should take care not to share the credential for authenticating the payment including UPI pin or OTP with any third party intentionally or unintentionally. The Company never solicits credential information for authenticating the payment such as UPI pin or OTP over a call or otherwise. The Company shall not be liable for any fraud due to the sharing of such details by the User. The providers providing Third Party Services / PSP partners shall not be liable for any fraud due to sharing of such details by the User.</p>
        <ul>
            <li>While availing any of the payment methods available on the Platform, the Company shall not be responsible or assume any liability, whatsoever in respect of any loss or damage arising directly or indirectly to you due to:</li>
            <li>Lack of authorisation for any transaction; or</li>
            <li>Exceeding the pre-set limit mutually agreed by you and between the third-party bank; or</li>
            <li>Any payment issues arising out of the transaction; or</li>
            <li>Decline of transaction for any other reasons.</li>
        </ul>
        <p>The Company will not be responsible for any money collected by third party by impersonating the representative of the Company.</p>
    </div>

    <div className="trm-block">
        <h3>10. Analytics</h3>
        <p>We may use third-party service providers to monitor and analyze the use of our Service.</p>
    </div>
    <div className="trm-block">
        <h3>11. Intellectual Property</h3>
       <p> The Platform and its original content (excluding Content provided by users), features and functionality, structure, expression, “look and feel”, all graphics, user interfaces, visual interfaces, photographs, trademarks, logos, sounds, music, artwork and computer code (“Company Data”) are and will remain the exclusive property of the Company and its licensors. The Platform is protected by copyright, trademark, and other applicable laws in the jurisdiction applicable to the operations of the Company . Our trademarks may not be used in connection with any product or service without the prior written consent of the Company.</p>
       <p> Except as expressly provided in these Terms of Services, no part of the Platform and no Company Data may be copied, reproduced, republished, uploaded, posted, publicly displayed, encoded, translated, transmitted or distributed in any way (including “mirroring”) to any other computer, server, website or other medium for publication or distribution or for any commercial use, without the Company’s express prior written consent. Company Data on the Platform is solely for your personal, limited and non-exclusive use. Use of the Company Data on any other web site or networked computer environment or use of the Company Data for any purpose other than personal, non-commercial use is a violation of the copyrights, trademarks, and other proprietary rights, and is prohibited.</p>

    </div>
    <div className="trm-block">
        <h3>12. Copyright Policy</h3>
        <p>We respect the intellectual property rights of others and expect our users to do the same. The Company may terminate in appropriate circumstances the accounts of users who infringe or are believed to be infringing the rights of copyright holders.</p>
    </div>
    <div className="trm-block">
        <h3>13. Error Reporting and Feedback</h3>
        <p>You may provide us either directly at <a href="mailto:customercare@zyapaar.com">customercare@zyapaar.com</a> or via third party sites and tools with information and feedback concerning errors, suggestions for improvements, ideas, problems, complaints, and other matters related to our Service (“Feedback”). </p>
        <p>You acknowledge and agree that:
            <ul className='my-ul-element'>
                <li>(i) you shall not retain, acquire or assert any intellectual property right or other right, title or interest in or to the Feedback;</li>
                <li>(ii) Company may have development ideas similar to the Feedback;</li> 
                <li>(iii) Feedback shall not contain confidential information or proprietary information from you or any third party; and </li>
                <li>(iv) Company is not under any obligation of confidentiality with respect to the Feedback. In the event the transfer of the ownership to the Feedback is not possible due to applicable mandatory laws, you grant Company and its affiliates an exclusive, transferable, irrevocable, free-of-charge, sub-licensable, unlimited and perpetual right to use (including copy, modify, create derivative works, publish, distribute and commercialize) Feedback in any manner and for any purpose.</li>    
            </ul>
        </p>
    </div>
    <div className="trm-block">
        <h3>14. Links To Other Web Sites</h3>
        <p>Our platform uses third party application program interfaces and may contain links to third party web sites or services that are not owned or controlled by the company.</p>
        <p>The company has no control over, and assumes no responsibility for the content, privacy policies, or practices of any third party web sites or services. we do not warrant the offerings of any of these entities/individuals or their websites.</p>
        <p>You acknowledge and agree that company shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or services available on or through any such third party web sites or services.</p>
        <p>We strongly advise you to read these terms of service and privacy policies of any third party web sites or services that you visit.</p>
    </div>
    <div className="trm-block">
        <h3>15. Disclaimer Of Warranty</h3>
        <p>The platform and services and the company data are provided by company on an “as is” and “as available” basis. company makes no representations or warranties of any kind, express or implied, as to the operation of their platform and the services, or the information, content or materials included therein. you expressly agree that your use of the platform, their content, and any services or items obtained from us is at your sole risk.</p>
        <p>Neither company nor any person associated with company makes any warranty or representation with respect to the completeness, security, reliability, quality, accuracy, or availability of the services or its content. without limiting the foregoing, neither company nor anyone associated with company represents or warrants that the platform, their content, or any services or items obtained through the services will be accurate, reliable, error-free, or uninterrupted, that defects will be corrected, that the services or the platform that makes it available are free of viruses or other harmful components or that the platform or any services or items obtained through the platform will otherwise meet your needs or expectations.</p>
        <p>Company hereby disclaims all warranties of any kind, whether express or implied, statutory, or otherwise, including but not limited to any warranties of merchantability, non-infringement, and fitness for particular purpose. the company will not be liable for any losses, damages or claims by you or any third-party in this regard.</p>
        <p>The foregoing does not affect any warranties which cannot be excluded or limited under applicable law.</p>
     </div>
    <div className="trm-block">
        <h3>16. Indemnity and Limitation Of Liability</h3>
        <p>Except as prohibited by law, you will hold us and our licensor, officers, directors, employees, other licensee and agents harmless for any loss, damage, or claim, however it arises (including attorneys’ fees and all related costs and expenses of litigation and arbitration, or at trial or on appeal, if any, whether or not litigation or arbitration is instituted), whether in an action of contract, negligence, or other tortious action, or arising out of or in connection with this agreement, including without limitation any claim for personal injury or property damage, arising from this agreement and any violation by you of any central, state, or local laws, statutes, rules, or regulations or terms of service, even if company has been previously advised of the possibility of such losses or damage or claims. except as prohibited by law, if there is liability found on the part of company, it will be limited to the amount paid by you for the products and/or services on the platform.</p>
        <p>Under no circumstance, including, but not limited to, negligence, shall the company be liable for any indirect, incidental, special, exemplary, damages for lost profits, business interruption and loss of programs or information arising out of the use of or inability to use the platform or consequential damages that result from the use of, or the inability to use, including but not limited to the information, content, materials on the platform, or any part thereof. while the company shall take reasonable precautions against security breaches, the platform or internet transmission is not completely secure, and as such, the company shall not be liable for any indirect, special, exemplary, or consequential damages that may result from unauthorized access, hacking, data loss, or other breaches that may occur.</p>
     </div>
    <div className="trm-block">
        <h3>17. Termination</h3>
        <p>We may terminate or suspend your account and bar access to the Platform or any of the Services immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever and without limitation, including but not limited to a breach of these Terms of Services or any other Agreement.</p>
        <p>All provisions of these Terms of Services which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability. Notwithstanding the foregoing, if you breach these Terms of Services or Privacy Policy or other rules and policies, the Company reserves the right to recover any amounts due and owing by you or to take strict legal action including but not limited to a referral to the appropriate police or other authorities for initiating criminal or other proceedings against you.</p>
     </div>
    <div className="trm-block">
        <h3>18. Governing Law</h3>
        <p>These Terms of Services shall be governed and construed in accordance with the laws of India, which governing law applies to agreement without regard to its conflict of law provisions, and any disputes relating to these Terms of Services and other Agreements will be subject to the exclusive jurisdiction of the courts of Ahmedabad, Gujarat, India.</p>
     </div>
    <div className="trm-block">
        <h3>19. Force Majeure</h3>
        <p>The Company is not liable for any delay in the performance or non-performance of any of its obligations hereunder and shall not be liable for any loss or damages caused thereby where the same is occasioned by any cause whatsoever that is beyond our control including but not limited to an act of God, war, civil disturbance, governmental or parliamentary restrictions, prohibitions or enactments of any kind, or accident or non-availability/ delay in transport, any endemic, pandemic, epidemic or outbreak of any disease.</p>
     </div>
    <div className="trm-block">
        <h3>20. Changes To Service</h3>
        <p>We reserve the right to withdraw or amend our Services, and any service or material we provide via the Platform, in our sole discretion without notice. We will not be liable if for any reason all or any part of Service is unavailable at any time or for any period. From time to time, we may restrict access to some parts of the Platform or the Services, or the entire Platform, to users, including registered users.</p>
     </div>
    <div className="trm-block">
        <h3>21. Amendments To Terms</h3>
        <p>We may amend this Terms of Services at any time by posting the amended terms on the Platform. It is your responsibility to review these Terms of Services periodically.</p>
        <p>Your continued use of the Platform following the posting of revised Terms means that you accept and agree to the changes. You are expected to check this page frequently so you are aware of any changes, as they are binding on you.</p>
        <p>By continuing to access or use our Platform and the Services after any revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, you are no longer authorized to use the Platform and the Service.</p>
     </div>
    <div className="trm-block">
        <h3>22. Waiver And Severability</h3>
        <p>No waiver by Company of any term or condition set forth in Terms shall be deemed a further or continuing waiver of such term or condition or a waiver of any other term or condition, and any failure of Company to assert any right or provision under Terms of Services shall not constitute a waiver of such right or provision.</p>
        <p>If any provision of Terms is held by a court or other tribunal of competent jurisdiction to be invalid, illegal or unenforceable for any reason, such provision shall be eliminated or limited to the minimum extent such that the remaining provisions of these Terms of Services will continue in full force and effect.</p>
     </div>
    <div className="trm-block">
        <h3>23. Assignment</h3>
       <p> The Company may transfer, sub-contract or otherwise deal with its rights and/or obligations under these Terms of Services without notifying you or obtaining your consent.</p>
       <p> You may not transfer, sub-contract or otherwise deal with your rights and/or obligations under these Terms of Services.</p>
       <p> In the event you are representing your business organisation as an Admin User, you may change the name of your institution after following the process prescribed by the Company, and you may add or change the Admin Users from the admin panel.</p>
     </div>
    <div className="trm-block">
        <h3>24. Acknowledgement</h3>
        <p>By using the platform or other services provided by us, you acknowledge that you have read these terms of service and agree to be bound by them.</p>
     </div>
    <div className="trm-block">
        <h3>25. {t('signuprecommendation.text11')}</h3>
        <p>Please send your comments or requests for technical support by email: <a href="mailto:customercare@zyapaar.com">customercare@zyapaar.com</a></p>

          <p>  In accordance with the Information Technology, 2000 and Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021, the name and contact details of the Grievance Officer are provided below:</p>
    <p>
       <strong> The Grievance Officer</strong> <br/>
       <strong> Company:</strong> Lets Talk Business Private Limited<br/>
       <strong> Name:</strong> Umesh Prajapati<br/>
       <strong> {t('companyproperties.text4')}:</strong> 601, Shikhar Complex, Nr. Adani House, Mithakhali Six Road, Navrangpura, Ahmedabad - 380009, Gujarat, India. <br/>
       <strong> Email:</strong> <a href="mailto:grievance@zyapaar.com">grievance@zyapaar.com</a>
    </p>

     </div></div>
</section>
</div>
</>
  );
};

export default TermsOfUse;
