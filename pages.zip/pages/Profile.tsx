/* eslint-disable multiline-ternary */
/* eslint-disable react/jsx-key */
import {
  IonButton,
  IonCard,
  IonCol,
  IonContent,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonRow
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import Company from '../components/profile/Company';
import Recommendations from '../components/profile/Recommendations';
import UserDetails from '../components/profile/UserDetails';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { arrowBack, lockClosed } from 'ionicons/icons';
import { useHistory, useParams } from 'react-router';
import CallFor from '../util/CallFor';
import image from '../assets/img/user-profile-placeholder.png';
import CommonCard from '../components/common/CommonCard';
import ActivityComman from '../components/common/ActivityComon';
import Footer from '../components/Layout/Footer';
import ToastCommon from '../components/common/ToastCommon';
import SkeletonFeedComon from '../components/common/skeleton/SkeletonFeedComon';
import { isAndroid, isIOS } from 'react-device-detect';
import { useTranslation } from 'react-i18next';

const Profile = () => {
  const { t } = useTranslation();
  const { userId } = useParams();
  const history = useHistory();
  const [activeBtnClass, setActiveBtnClass] = useState('ion-button-color');
  const [userName, setUserName] = useState('');
  const [myCompanyBtnClass, setMyCompanyBtnClass] =
    useState('category-btn-color');
  const [recommendationsBtnClass, setRecommendationsBtnClass] =
    useState('category-btn-color');
  const [categoryState, setCategoryState] = useState('ACTIVITY');
  const [showToast, setShowToast] = useState(false);
  const [isLocked, setIsLocked] = useState('');
  const [profileId, setProfileId] = useState(userId);
  const [userProfileData, setUserProfileData] = useState([{}]);
  const [classMobile, setClassMobile] = useState(true);
  const [loading, setLoading] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [reportHideState, setReportHideState] = useState(false);
  const [activityLoading, setActivityLoading] = useState(true);
  const [loadComponent, setLoadComponent] = useState(false);
  useEffect(() => {
    setClassMobile(true);
    getconnectionList();
    getRecentlyViewList();
    getActivityList(0, userId, false);
    if (isAndroid || isIOS) {
      setLoadComponent(true);
    }
  }, []);
  const getUserDetails = async(pamUserId) => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/users/' + pamUserId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data !== null) {
        setUserProfileData(json1Response.data);
        setUserName(json1Response.data.name);
        setIsLocked(json1Response.data);
        setInfiniteDisabled(false);
        // setCount(0);
        // getActivityList(0, pamUserId, false);
      }
    } else if (response.status === 404) {
      history.push('/404');
    } else if (response.status === 500) {
      history.push('/500');
    }
    setLoading(false);
  };
  const getAllCategoryData = (category: any) => {
    // if (category === 'ACTIVITY') {
    //   setActiveBtnClass('ion-button-color');
    //   setMyCompanyBtnClass('category-btn-color');
    //   setRecommendationsBtnClass('category-btn-color');
    // } else if (category === 'MYCOMPANY') {
    //   setActiveBtnClass('category-btn-color');
    //   setMyCompanyBtnClass('ion-button-color');
    //   setRecommendationsBtnClass('category-btn-color');
    // } else if (category === 'RECOMMENDATIONS') {
    //   setActiveBtnClass('category-btn-color');
    //   setMyCompanyBtnClass('category-btn-color');
    //   setRecommendationsBtnClass('ion-button-color');
    // } else if (category === 'PRODUCTCATALOGUE') {
    //   setActiveBtnClass('category-btn-color');
    //   setMyCompanyBtnClass('category-btn-color');
    //   setRecommendationsBtnClass('category-btn-color');
    // }
    setCategoryState(category);
  };
  const getconnectionList = async() => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.2/suggestions/users',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setPeoples(json1Response.data.content);
      }
    }
    setLoading(false);
  };
  const connectionBtnHandler = async(id) => {
    const response = await CallFor(
      'api/v1.1/connect/' + id + '/INITIATE',
      'POST',
      '{"status": "INITIATE" }',
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('appproperties.text430'));
      setShowToast(true);
    }
  };
  const [peoples, setPeoples] = useState([]);
  const [recentlyView, setRecentlyView] = useState([]);
  const getRecentlyViewList = async() => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/users/view',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setRecentlyView(json1Response.data.content);
      }
    }
    setLoading(false);
  };

  const [activityDetails, setActivityDetails] = useState([]);
  const [count, setCount] = useState(0);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const getActivityList = async(count, paramUserId, scrolling) => {
    const response = await CallFor(
      'api/v1/user/activity?userId=' + paramUserId,
      'POST',
      '{"page": ' + count + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      setActivityLoading(false);
      if (json1Response.data.content !== null) {
        if (scrolling) {
          if (json1Response.data.content.length > 0) {
            setActivityDetails([
              ...activityDetails,
              ...json1Response.data.content
            ]);
          } else {
            setInfiniteDisabled(true);
          }
        } else {
          setActivityDetails(json1Response.data.content);
        }
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setCount(count + 1);
    setActivityLoading(false);
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getActivityList(count, profileId, true);
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  };
  if (classMobile) {
    document
      .getElementsByTagName('html')[0]
      .classList.add('mobileOverlayHandel');
  } else {
    document
      .getElementsByTagName('html')[0]
      .classList.remove('mobileOverlayHandel');
  }
  const removeMobileCss = () => {
    history.goBack();
  };
  return (
    <>
      <IonRow className="plane-bg">
        <IonRow className="container">
          <div
            className={
              classMobile
                ? 'showpage row full-width-row main-page-content-row activity-page zsdadda'
                : 'row full-width-row main-page-content-row '
            }
          >
            <IonCol
              size-md="4"
              size-xs="12"
              className="left-col ion-no-padding"
            >
              <div className="sidebar-main profile-page">
                <CommonCard
                  header={t('appproperties.text136')}
                  mapData={peoples}
                  // icon ={personAdd}
                  subHeader={true}
                  fieldLink="/profile/"
                  btn={connectionBtnHandler}
                  image={image}
                  className="sidebar-pages inner-pages-scroll"
                  noDataFound={t('nodatafound.text2')}
                  setId={setProfileId}
                  btnHandler={getUserDetails}
                  btnHandler2={getAllCategoryData}
                  param1="ACTIVITY"
                  setClassMobile={setClassMobile}
                  loading={loading}
                />
                <CommonCard
                  header={t('appproperties.text137')}
                  mapData={recentlyView}
                  // icon ={personAdd}
                  subHeader={true}
                  fieldLink="/profile/"
                  btn={connectionBtnHandler}
                  image={image}
                  className="sidebar-pages inner-pages-scroll"
                  noDataFound={t('nodatafound.text3')}
                  setId={setProfileId}
                  btnHandler={getUserDetails}
                  btnHandler2={getAllCategoryData}
                  param1="ACTIVITY"
                  setClassMobile={setClassMobile}
                  loading={loading}
                />
                <Footer />
              </div>
            </IonCol>
            <IonCol
              size-lg="8"
              size-md="12"
              size-xs="12"
              className="right-col ion-no-padding"
            >
              {loadComponent ? (
                <IonContent className="mobile-overlay-screen show-mobile activity-content-card-div back-screen-mobile">
                  <div className="mobile-back-screen show-mobile back-icon-mobile show-mobile mt-3">
                    <IonIcon
                      className="icon-mobile"
                      icon={arrowBack}
                      onClick={removeMobileCss}
                    ></IonIcon>
                  </div>
                  <UserDetails
                    userId={profileId}
                    setUserName={setUserName}
                    setIsLocked={setIsLocked}
                    setUserProfileData={setUserProfileData}
                    userProfileData={userProfileData}
                    getUserDetails={getUserDetails}
                    loading={loading}
                    setReportHideState={setReportHideState}
                    reportHideState={reportHideState}
                    setCategoryState ={setCategoryState}
                  />
                  {!reportHideState ? (
                    userProfileData.isHide !== true ? (
                      <>
                        {isLocked.isLocked === true ? (
                          <p className="ion-padding-top ion-margin-top ion-padding-bottom w-100 ion-text-center">
                            <IonIcon className="test  " icon={lockClosed} />{' '}
                            {t('userproperties.text24')}
                          </p>
                        ) : ''}
                      </>
                    ) : (
                      <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                      {t('userproperties.text25')}
                      </p>
                    )
                  ) : (
                    <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                     {t('userproperties.text25')}
                    </p>
                  )}
                  {!reportHideState ? (
                    userProfileData.isHide !== true ? (
                      <>
                        {isLocked.isLocked === false ? (
                          <>
                            {(() => {
                              if (categoryState === 'ACTIVITY') {
                                return (
                                  <>
                                    {activityLoading &&
                                    activityDetails.length === 0 ? (
                                      <SkeletonFeedComon column={5} />
                                        ) : activityDetails.length > 0 ? (
                                          activityDetails.map((activity) => (
                                        <ActivityComman
                                          activity={activity}
                                          userName={userName}
                                          userId={userId}
                                        />
                                          ))
                                        ) : (
                                      <IonCard className="MuiPaper-rounded ion-margin-top ion-margin-bottom ion-padding ion-no-margin follower-list-card">
                                        <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">
                                        {t('nodatafound.text1')}
                                        </p>
                                      </IonCard>
                                        )}
                                    <IonInfiniteScroll
                                      onIonInfinite={loadData}
                                      threshold="100px"
                                      disabled={isInfiniteDisabled}
                                    >
                                      <IonInfiniteScrollContent
                                        loadingSpinner="circular"
                                        loadingText={t('appproperties.text215')}
                                      ></IonInfiniteScrollContent>
                                    </IonInfiniteScroll>
                                  </>
                                );
                              }
                              if (categoryState === 'MYCOMPANY') {
                                return <Company />;
                              } else if (categoryState === 'RECOMMENDATIONS') {
                                return (
                                  <Recommendations
                                    userId={profileId}
                                    userName={userName}
                                  />
                                );
                              }
                            })()}
                          </>
                        ) : (
                          ''
                        )}
                      </>
                    ) : (
                      ''
                    )
                  ) : (
                    ''
                  )}
                </IonContent>
              ) : (
                ''
              )}
              <div className="mobile-back-screen dn-mobile">
                <IonIcon
                  className="icon-mobile show-mobile"
                  icon={arrowBack}
                  onClick={removeMobileCss}
                ></IonIcon>
              </div>
              {!loadComponent ? (
                <UserDetails
                  userId={profileId}
                  setUserName={setUserName}
                  setIsLocked={setIsLocked}
                  setUserProfileData={setUserProfileData}
                  userProfileData={userProfileData}
                  getUserDetails={getUserDetails}
                  setReportHideState={setReportHideState}
                  reportHideState={reportHideState}
                  loading={loading}
                />
              ) : (
                ''
              )}
              {!reportHideState ? (
                userProfileData.isHide !== true ? (
                  <>
                    {isLocked.isLocked === false ? (
                      <IonRow className="gup-btn-action mb-10">
                        <IonButton
                          className={activeBtnClass + ' no-shadow '}
                          shape="round"
                          size="small"
                          onClick={() => getAllCategoryData('ACTIVITY')}
                        >
                          {t('appproperties.text143')}
                        </IonButton>
                        <IonButton
                          className={myCompanyBtnClass + ' no-shadow '}
                          shape="round"
                          size="small"
                          onClick={() => getAllCategoryData('MYCOMPANY')}
                        >
                          {t('appproperties.text144')}
                        </IonButton>
                        <IonButton
                          className={recommendationsBtnClass + ' no-shadow '}
                          shape="round"
                          size="small"
                          onClick={() => getAllCategoryData('RECOMMENDATIONS')}
                        >
                         {t('appproperties.text145')}
                        </IonButton>
                      </IonRow>
                    ) : isLocked.isLocked === undefined ? (
                      ''
                    ) : (
                      <p className="ion-padding-top ion-margin-top ion-padding-bottom w-100 ion-text-center">
                        <IonIcon className="test  " icon={lockClosed} /> This
                        {t('appproperties.text300')}
                      </p>
                    )}
                  </>
                ) : (
                  <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                  {t('userproperties.text25')}
                  </p>
                )
              ) : (
                <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                 {t('userproperties.text25')}
                </p>
              )}
              {!reportHideState ? (
                userProfileData.isHide !== true ? (
                  <>
                    {isLocked.isLocked === false ? (
                      <>
                        {(() => {
                          if (categoryState === 'ACTIVITY') {
                            return (
                              <>
                                {activityLoading &&
                                activityDetails.length === 0 ? (
                                  <SkeletonFeedComon column={5} />
                                    ) : activityDetails.length > 0 ? (
                                      activityDetails.map((activity) => (
                                    <ActivityComman
                                      activity={activity}
                                      userName={userName}
                                      userId={userId}
                                    />
                                      ))
                                    ) : (
                                  <IonCard className="MuiPaper-rounded ion-margin-top ion-margin-bottom ion-padding ion-no-margin follower-list-card shadow-none border-0">
                                    <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">
                                    {t('nodatafound.text1')} 
                                    </p>
                                  </IonCard>
                                    )}
                                <IonInfiniteScroll
                                  onIonInfinite={loadData}
                                  threshold="100px"
                                  disabled={isInfiniteDisabled}
                                >
                                  <IonInfiniteScrollContent
                                    loadingSpinner="circular"
                                    loadingText={t('appproperties.text215')}
                                  ></IonInfiniteScrollContent>
                                </IonInfiniteScroll>
                              </>
                            );
                          }
                          if (categoryState === 'MYCOMPANY') {
                            return <Company />;
                          } else if (categoryState === 'RECOMMENDATIONS') {
                            return (
                              <Recommendations
                                userId={profileId}
                                userName={userName}
                              />
                            );
                          }
                        })()}
                      </>
                    ) : (
                      ''
                    )}
                  </>
                ) : (
                  ''
                )
              ) : (
                ''
              )}
            </IonCol>
          </div>
        </IonRow>
        <ToastCommon
          setShowToast={setShowToast}
          setShowToastMsg={setShowToastMsg}
          showToast={showToast}
          showToastMsg={showToastMsg}
          duration={5000}
        />
      </IonRow>
    </>
  );
};
export default Profile;
