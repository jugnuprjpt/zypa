/* eslint-disable no-tabs */
import React from 'react';
import MetaTage from '../../components/common/MetaTage';
import MetaTagProperties from '../../properties/MetaTagProperties';
import { IonRow, IonCol, IonInput } from '@ionic/react';
import banner from '../../assets/img/blog/blog-cover-1.jpg';
import blogbanner from '../../assets/img/blog/blog-cover-2.jpg';
import blogbannerthree from '../../assets/img/blog/blog-cover-3.jpg';
import blogbannerfour from '../../assets/img/blog/blog-cover-4.jpg';
import blogbannerfive from '../../assets/img/blog/blog-cover-5.jpg';
import blogbannersix from '../../assets/img/blog/blog-cover-6.jpg';
import calendar from '../../assets/img/blog/blog-calendar.svg';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
const Blog = () => {
    const { t } = useTranslation();
  return (
        <>
            <MetaTage metaDetails={MetaTagProperties.Bloghome} />
            <div className='web-pages-before Blogpage'>
                <div className="container">
                    <IonRow>
                        <IonCol sizeLg='7' sizeMd='12' sizeSm='12' sizeXs='12' className='blog-left'>

                        <div className='blogbox'>
                                <div className='blog-banner'><img src={blogbannersix} alt='Easy Steps To Profitably Sell Furniture Online'/></div>
                                <div className='blog-main-content p-3 position-relative'>
                                    <div className='blog-title font-bold'> Easy Steps To Profitably Sell Furniture Online</div>
                                    <div className='blog-author d-lg-flex pt-2 justify-content-between'>
                                        <div className='py-2 d-flex'><img src={calendar} alt='Main Banner' /> Published: <span className='font-bold ps-2'>NOV 22, 2022</span></div>
                                    </div>
                                    <div className='blog-innercontent'>
                                        <p className='pt-3'>House, offices, workstations, factories and many more places do require furniture. People love to upgrade and add new furniture to their places from time to time. </p>
                                        <Link to='/blog/sell-furniture-online' className='d-block pt-3'>{t('appproperties.text239')}</Link>
                                    </div>
                                </div>
                            </div>

                            <div className='blogbox'>
                                <div className='blog-banner'><img src={blogbannerthree} alt='A quick guide to flourish your business this diwali 2022' /></div>
                                <div className='blog-main-content p-3 position-relative'>
                                    <div className='blog-title font-bold'>A Quick Guide to Flourish your Business this Diwali 2022</div>
                                    <div className='blog-author d-lg-flex pt-2 justify-content-between'>
                                        <div className='py-2 d-flex'><img src={calendar} alt='Main Banner' /> Published: <span className='font-bold ps-2'>OCT 10, 2022</span></div>
                                    </div>
                                    <div className='blog-innercontent'>
                                        <p className='pt-3'>India is a huge nation with the world's 2nd largest population, thus making it the most prosperous market for every sort of business regardless of its size.</p>
                                        <Link to='/blog/flourish-business-this-diwali-2022' className='d-block pt-3'>{t('appproperties.text239')}</Link>
                                    </div>
                                </div>
                            </div>

                            <div className='blogbox'>
                                <div className='blog-banner'><img src={blogbannerfour} alt='A Quick Guide to choose B2B Marketplace wisely' /></div>
                                <div className='blog-main-content p-3 position-relative'>
                                    <div className='blog-title font-bold'>A Quick Guide to choose B2B Marketplace wisely</div>
                                    <div className='blog-author d-lg-flex pt-2 justify-content-between'>
                                        <div className='py-2 d-flex'><img src={calendar} alt='Main Banner' /> Published: <span className='font-bold ps-2'>SEP 29, 2022</span></div>
                                    </div>
                                    <div className='blog-innercontent'>
                                        <p className='pt-3'>Online B2C businesses have already experienced the sweet fruits of success and are continuing to do so. But B2B businesses are following the same path and are attaining growth as well.</p>
                                        <Link to='/blog/quick-guide-to-b2b-marketplace' className='d-block pt-3'>{t('appproperties.text239')}</Link>
                                    </div>
                                </div>
                            </div>

                            <div className='blogbox'>
                                <div className='blog-banner'><img src={blogbannerfive} alt='B2B Sales : Meaning, Buying Process & Strategies' /></div>
                                <div className='blog-main-content p-3 position-relative'>
                                    <div className='blog-title font-bold'>B2B Sales : Meaning, Buying Process & Strategies</div>
                                    <div className='blog-author d-lg-flex pt-2 justify-content-between'>
                                        <div className='py-2 d-flex'><img src={calendar} alt='Main Banner' /> Published: <span className='font-bold ps-2'>SEP 14, 2022</span></div>
                                    </div>
                                    <div className='blog-innercontent'>
                                        <p className='pt-3'>In the new age businesses no longer just wish to survive but rather thrive and reach new potentials. This applies to every industry. Recognizing the advent of digitisation, a large </p>
                                        <Link to='/blog/b2b-sales-strategies' className='d-block pt-3'>{t('appproperties.text239')}</Link>
                                    </div>
                                </div>
                            </div>

                            <div className='blogbox'>
                                <div className='blog-banner'><img src={blogbanner} alt='How to find new buyers and suppliers online using B2B leads?' /></div>
                                <div className='blog-main-content p-3 position-relative'>
                                    <div className='blog-title font-bold'>How to find new buyers and suppliers online using B2B leads?</div>
                                    <div className='blog-author d-lg-flex pt-2 justify-content-between'>
                                        <div className='py-2 d-flex'><img src={calendar} alt='Main Banner' /> Published: <span className='font-bold ps-2'>SEP 02, 2022</span></div>
                                    </div>
                                    <div className='blog-innercontent'>
                                        <p className='pt-3'>According to Hubspot, 61% of marketers consider lead generation as their number one challenge. Moreover, 53% of marketers spend at least half of their budget on lead generation.</p>
                                        <Link to='/blog/Buyers-and-suppliers-online' className='d-block pt-3'>{t('appproperties.text239')}</Link>
                                    </div>
                                </div>
                            </div>

                            <div className='blogbox'>
                                <div className='blog-banner'><img src={banner} alt='Skyrocket your growth via business networking'/></div>
                                <div className='blog-main-content p-3 position-relative'>
                                    <div className='blog-title font-bold'>Want to skyrocket your growth via business networking? Here's a quick guide</div>
                                    <div className='blog-author d-lg-flex pt-2 justify-content-between'>
                                        <div className='py-2 d-flex'><img src={calendar} alt='Main Banner' /> Published: <span className='font-bold ps-2'>AUG 23, 2022</span></div>
                                    </div>
                                    <div className='blog-innercontent'>
                                        <p className='pt-3'>"Your network is your net worth" is a powerful statement by Porter Gale, a renowned entrepreneur, and networker.</p>
                                        <Link to='/blog/growth-via-business-networking' className='d-block pt-3'>{t('appproperties.text239')}</Link>
                                    </div>
                                </div>
                            </div>
                        </IonCol>

                        <IonCol offsetLg='1' sizeLg='4' sizeMd='12' sizeSm='12' sizeXs='12'>
                            <div className='blog-right p-5'>
                                <div className='blogbox'>
                                    <IonInput type='text' className='blogsearch p-2' placeholder='Search Here'></IonInput>
                                </div>

                                <div className='blogbox'>
                                    <div className='blog-banner'><img src={blogbannerfive} alt='B2B Sales : Meaning, Buying Process & Strategies' /></div>
                                    <div className='blog-main-content  p-3 position-relative'>
                                        <div className='blog-title font-bold'><a href='/blog/b2b-sales-strategies' target='_blank'> B2B Sales : Meaning, Buying Process & Strategies</a></div>
                                    </div>
                                </div>

                                <div className='blogbox'>
                                    <div className='blog-banner'><img src={blogbannersix} alt='Easy Steps To Profitably Sell Furniture Online' /></div>
                                    <div className='blog-main-content  p-3 position-relative'>
                                        <div className='blog-title font-bold'><a href='/blog/b2b-sales-strategies' target='_blank'>Easy Steps To Profitably Sell Furniture Online</a></div>
                                    </div>
                                </div>

                                <div className='blogbox'>
                                    <div className='blog-banner'><img src={blogbanner} alt='How to find new buyers and suppliers online using B2B leads?' /></div>
                                    <div className='blog-main-content  p-3 position-relative'>
                                        <div className='blog-title font-bold'><a href='/blog/Buyers-and-suppliers-online' target='_blank'>How to find new buyers and suppliers online using B2B leads?</a></div>
                                    </div>
                                </div>

                                <div className='blogbox'>
                                    <div className='blog-banner'><img src={banner} alt='Skyrocket your growth via business networking' /></div>
                                    <div className='blog-main-content  p-3 position-relative'>
                                        <div className='blog-title font-bold'><a href='/blog/growth-via-business-networking' target='_blank'>Want to skyrocket your growth via business networking? Here's a quick guide</a></div>
                                    </div>
                                </div>

                                <div className='blogbox'>
                                    <div className='blog-banner'><img src={blogbannerfour} alt='A Quick Guide to choose B2B Marketplace wisely' /></div>
                                    <div className='blog-main-content  p-3 position-relative'>
                                        <div className='blog-title font-bold'><a href='/blog/quick-guide-to-b2b-marketplace' target='_blank'>A Quick Guide to choose B2B Marketplace wisely</a></div>
                                    </div>
                                </div>

                                <div className='blogbox'>
                                    <div className='blog-banner'><img src={blogbannerthree} alt='A quick guide to flourish your business this diwali 2022' /></div>
                                    <div className='blog-main-content  p-3 position-relative'>
                                        <div className='blog-title font-bold'><a href='/blog/flourish-business-this-diwali-2022' target='_blank'>A Quick Guide to Flourish your Business this Diwali 2022</a></div>
                                    </div>
                                </div>
                            </div>
                        </IonCol>
                    </IonRow>
                </div>
            </div>
        </>
  );
};
export default Blog;
