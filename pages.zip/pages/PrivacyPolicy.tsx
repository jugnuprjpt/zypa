import { IonIcon } from '@ionic/react';
import { arrowBack } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';
import MetaTags from 'react-meta-tags';
import { useHistory } from 'react-router';

const PrivacyPolicy = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const backbtn = () => {
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
    history.goBack();
  };
  return (
    <>
        <MetaTags>
        <meta charSet="UTF-8" />
                <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <title>Priva1cy Policy - Zyapaar</title>
                <link rel="canonical" href={window.location.href} />
                <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png" />
                <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png" />
                <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png" />
                <link rel="manifest" href="assets/img/site.webmanifest" />
        </MetaTags>
        <div className='web-pages-before privacy-policypage'>
       <section className="wow fadeIn heading-background sts-web contactus-tag">
        <div className= 'mobile-back-screen show-mobile title-back ion-margin-bottom back-with-heading mt-3 ms-3'>
            <IonIcon className='icon-mobile' icon={arrowBack} onClick= {backbtn} ></IonIcon> 
            <h3 className='mt-0'>Privacy Policy</h3>
        </div>
        <div className="container dn-mobile">
            <h1 className="text-center WhiteText wow fadeInUp">Privacy Policy</h1>
        </div>
   </section>
   <section className="terms py-lg-5 py-4 pr-2 pl-2">
        <div className="container">
            <div className="trm-block">
                <h3>1. Introduction</h3>
               <p>Welcome to https://www.zyapaar.com/ (“<strong>Website</strong>”) and Zyapaar mobile applications for android and IOS operating systems (“<strong>Application</strong>”), a platform that provides virtual networking opportunity and related services for service provider, manufacturer, trader, dealer, retailers and their employees/associates (Website and Application are hereinafter collectively referred to as “<strong>Platform</strong>”) owned and managed by Lets Talk Business Private Limited and its affiliates (“<strong>Company</strong>”).</p>
               <p>Your visit and use of platform for services offered on the Platform (“<strong>Services</strong>”) are subject to this privacy, security and cookies policy ("<strong>Privacy Policy</strong>") and other terms and conditions of the Platform. This Privacy Policy ensures our firm commitment to your privacy vis-à-vis the protection of your information.</p>
               <p>In this Privacy Policy "we", "our" and "us" refers to the Company and "you", "your" and/or “<strong>Users</strong>” refers to the user of the Platform.</p>
               <p>You must be 18 years of age or older to visit or use the Website and/or Application in any manner. If you are under the age of 18, you should review this Privacy Policy with your parent or legal guardian to make sure that you and your parent or legal guardian understands and agrees to it and further, if required, you shall perform or undertake such activities which will entitle you to enter into a legally binding agreement with the Company. If you are availing the Services on behalf of a legal entity as an admin user (“Admin User”), you represent and warrant that you have the actual authority to agree to the terms and conditions of this agreement on behalf of such legal entity. By visiting this Website and/or Application or accepting this Privacy Policy, you represent and warrant to the Company that you are 18 years of age or older, and that you have the right, authority and capacity to use the Website and/or Application and agree to and abide by this Privacy Policy. You also represent and warrant to the Company that you will use this Privacy Policy in a manner consistent with any and all applicable laws and regulations.</p>
               <p>This document is published and shall be construed in accordance with the provisions of the Information Technology (Reasonable Security Practices and Procedures and Sensitive Personal Data of Information) Rules, 2011 (“<strong>Data Protection Rules</strong>”) under the Information Technology Act, 2000; that require publishing of the Privacy Policy for collection, use, storage and transfer of information. The information collected from you could be categorized as “<strong>Personal Information</strong>”, and “<strong>Sensitive Personal Information</strong>”. Personal Information, and Sensitive Personal Information (each as individually defined under the Data Protection Rules) shall collectively be referred to as “<strong>Information</strong>” or “<strong>Personal Information</strong>” or “<strong>Personal Data</strong>” in this Policy.</p>
               <p>This Privacy Policy is an electronic record in the form of an electronic contract formed under the Information Technology Act, 2000, rules made thereunder, and any other applicable statutes, as amended from time to time. This Privacy Policy does not require any physical, electronic or digital signature.</p>
               <p>Please read this Privacy Policy carefully. By using the Platform, (<strong>you indicate, agrees, and acknowledge that you understand, agree and consent to this Privacy Policy</strong>) and to the collection and use of information in accordance with this Privacy Policy.</p>
               <p>Our Privacy Policy governs your use of the Services on the Platform, and explains how we collect, safeguard and disclose information that results from your use of the Service. We reserve the right to amend and supplement to complete this Privacy Policy at any time. Whenever there is a change to our Privacy Policy, we will post updates on our Website and/or Application. We encourage you to regularly review this Privacy Policy to get the latest updates to ensure you know and exercise the right to manage your Personal Information.</p>
               <p>Our Terms and Conditions (“<strong>Terms</strong>”) govern all use of our Service and together with the Privacy Policy constitutes your agreement with us (“<strong>Agreement</strong>”).</p>
            </div>
            <div className="trm-block">
                <h3>2. Definitions</h3>
                <p>Unless otherwise defined elsewhere in this Privacy Policy, the following terms shall have the meanings assigned to them as herein below for the purposes of this Privacy Policy:</p>
                <p>“USAGE DATA” means information and data collected and captured as a result of the use of Service.</p>
                <p>“COOKIES” mean small data files stored on your device (computer or mobile device).</p>
                <p>“DATA CONTROLLER” means a natural or legal person who (either alone or jointly or in common with other persons) determines the purposes for which and the manner in which any Personal Data are, or are to be, processed. For the purpose of this Privacy Policy, we are a Data Controller of your data.</p>
                <p>“DATA PROCESSORS” OR “SERVICE PROVIDERS” means any natural or legal person who processes the data on behalf of the Data Controller. We may use the services of various Service Providers in order to process your data more effectively.</p>
            </div>
            <div className="trm-block">
                <h3>3. Information Collection and Use</h3>
                <div className="trm-inner-block">
                <h4>3.1 Collection of Data</h4>
                <p>In order to avail the Services under the Platform, registration by the User is mandatory. A valid mobile number may be required to register on the Platform, to complete the registration process, a one-time password (OTP) may be sent to you on the mobile number provided by you at the time of registration for the purpose of user validation. </p>
                <p>Further, a valid Goods and Service Tax number or Permanent Account Number or Udyam Registration of the business user, would be required to register on the Platform, to complete the registration process, for the purpose of user validation. </p>
                <p>You are fully responsible for all activities that occur under your account. You specifically agree that the Company shall not be responsible for unauthorized access to or alteration of your transmissions or data, any material or data sent or received or not sent or received through the Platform. By registering, you consent to provide information including Personal Data.</p>
                    <p>The Company respects the privacy of the Users of the Services and is committed to reasonably protect it in all respects. The information about the user as collected by the Company are:</p>
                    <ul>
                        <li>Information supplied by Users</li>
                        <li>Information tracked automatically while navigation</li>
                        <li>Inferred information through usage and log data</li>
                        <li>Information collected from any other sources (such as third party providers or other social media platforms)</li>
                        <li>Information accessed on the Users’ device.</li>
                    </ul>
                    <p>In order to provide Services and to maintain and improve the Platform, we require certain information (including Personal Data), when you express an interest in obtaining information about us or our products and Services, when you participate in activities on our Platform or otherwise contact us. Such Personal Data may be collected in various ways including during the course of your:</p>
                    <ul>
                        <li>Registration as a User on the Platform and/or registering for an event, promotion or a campaign and/or otherwise interact with us,</li>
                        <li>Availing Services offered on the Platform. Instances of such Services include but are not limited to, communicating with the other users of the Platform by phone, email, SMS or otherwise or posting user reviews in relation to Services/products available on the Platform.</li>
                    </ul>
                    <p>In order to provide Services and to maintain and improve the Platform, we require you to grant certain access right to your phone or other system including but not limited to Microphone, Camera, Location, Storage, Calendar etc.</p>
                  </div>
                  <div className="trm-inner-block">
                    <h4 className='ptage'>3.2 Types of Data Collected</h4>
                    <p>We collect different types of information, including Personal Data, for various purposes to provide and improve our Service for you.</p>
                    <ul>
                        <li>
                            <div className="mb-3"><strong>Personal Data</strong></div>
                            <p>While using our Service, we may ask you to provide us with certain Personal Data i.e. personally identifiable information that can be used to contact or identify you. Personal Data may include, but is not limited to:</p>

                            <ul className="pb-3">
                                <li>Email address</li>
                                <li>First name and last name</li>
                                <li>Phone number and Mobile Number</li>
                                <li>Permanent Account Number and such other unique identification issued by government or any other third party organisation</li>
                                <li>Address, Country, State, Province, ZIP/Postal/Pin code, City</li>
                                <li>Other contact information</li>
                                <li>Gender and other demographics</li>
                                <li>Employer / business organisation information</li>
                            </ul>
                            <p>
                            We may use your Personal Data to contact you with newsletters, marketing or promotional materials and other information that may be of interest to you. You may opt out of receiving any, or all, of these communications from us by following the unsubscribe link.
                            </p>
                        </li>

                        <li>
                            <div className="mb-3">
                                <strong>Business Organisation’s Data</strong>
                            </div>
                            <p>While using our Service, we may ask you to provide us with certain data related to the business organisation you belong to, i.e. information of the business owner and managers that can be used to identify you and verify your user details. Such business organisation’s data may include, but is not limited to:</p>
                            <ul className="pb-3">
                                <li>Permanent Account Number, Goods and Services Tax identification number, Udyam Registration number and such other unique identification issued by government or any other third party organisation</li>
                                <li>Brand name and logo of business organisation</li>
                                <li>Employee strength of business organisation</li>
                                <li>Year of incorporation and date of commencement of business</li>
                                <li>Description of products and services</li>
                                <li>Office address and contact details</li>
                            </ul>
                        </li>

                        <li>
                            <div className="mb-3">
                                <strong>Usage Data</strong>
                            </div>
                            <p>We may also collect information that your browser sends whenever you visit our Platform and/or use the Service or when you access the Platform by or through any device and any browser application (“Usage Data”).</p>
                            <p>This Usage Data may include information such as server log, your computer’s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, referring site/webpage, the time and date of your visit, the time spent on those pages, unique device identifiers, browser information and other diagnostic data.</p>
                            <p>When you access the Platform with a device, this Usage Data may include information such as the type of device you use, your device unique ID, the IP address of your device, your device operating system, the type of Internet browser you use, unique device identifiers and other diagnostic data.</p>

                        </li>
                        <li>
                            <div className="mb-3">
                                <strong>Location Data</strong>
                            </div>
                            <p>We may use and store information about your location if you give us permission to do so (“Location Data”). We use this data to provide features of our Service, to improve and customize our Service.</p>

                        </li>

                        <li>
                            <div className="mb-3">
                                <strong>Tracking Cookies Data</strong>
                            </div>
                            <p>We use cookies, web beacons and similar tracking technologies to track the activity on our Platform and we hold certain information. We may use a web beacon (electronic images or also known as clear gifs) to recognize certain types of information on users computer such as time and date of page view, users cookie number, page description.</p>
                            <p>Cookies are files with a small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Other tracking technologies are also used such as beacons, tags and scripts to collect and track information and to improve and analyze our Service.</p>
                            <p>You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.</p>
                            <p>Examples of Cookies we use:</p>
                            <ul className="mb-3">
                                <li >Session Cookies: We use Session Cookies to operate our Service.</li>
                                <li>Preference Cookies: We use Preference Cookies to remember your preferences and various settings.</li>
                                <li>Security Cookies: We use Security Cookies for security purposes.</li>
                                <li>Advertising Cookies: Advertising Cookies are used to serve you with advertisements that may be relevant to you and your interests.</li>
                            </ul>
                        </li>
                        <li>
                            <div className="mb-3">
                                <strong>Other Data</strong>
                            </div>
                            <p>We may also collect the following information and data: details of documents on education, qualification, professional training, office location, photograph, information regarding your transactions on the Platform, (including interest history), your financial information such as bank account information or credit card or debit card or other payment instrument details and other data.</p>
                            <p>We may also access and collect phone book details and email addresses stored available on User’s devises and/or any third party Service Provider.</p>
                      </li>

                    </ul>
                </div>
                <div className="trm-inner-block">
                    <h4>3.3 Purpose for Collection and Use of Data</h4>
                    <p>All required information is Service dependent, and the Company may use the above said user Information to, maintain, protect, and improve the Services (including advertising) and for developing new services, to build the connection/network based on user’s connections, products, category and showing advertisement based on product, category and search. Any Personal Data provided by you will not be considered as sensitive if it is freely available and / or accessible in the public domain like any comments, messages, blogs, scribbles available on social media platforms like Facebook, twitter etc.</p>
                    <p>The Company uses the collected data for various purposes including as follows:</p>

                    <ul className="mb-3">
                        <li>To create and maintain an online account with the Platform;</li>
                        <li>To maintain our Platform and enable you to avail the Services;</li>
                        <li>To notify you about changes to our Service and to execute your request for the products and the services;</li>
                        <li>To allow you to participate in interactive features of our Service when you choose to do so;</li>
                        <li>To provide customer support;</li>
                        <li>To analyse information so that we can improve our Platform and Services;</li>
                        <li>To notify the necessary information related to the Platform and Services, your online account on the Platform from time to time, and contact you to provide the relevant information regarding any events, promotions;</li>
                        <li>To monitor your usage of our Platform and Services;</li>
                        <li>To maintain records and provide you with an efficient, safe and customized experience while using the Platform;</li>
                        <li>To detect, prevent and address technical issues;</li>
                        <li>To furnish your information to Service Providers to the extent necessary for delivering the relevant Services;</li>
                        <li>Aggregated and individual, anonymized and non-anonymized data may periodically be transmitted to Service Providers to help us improve the Platform and our Services;</li>
                        <li>To fulfill any other purpose for which you provide it;</li>
                        <li>To verify your identity and prevent fraud or other unauthorized or illegal activity;</li>
                        <li>To carry out our obligations and enforce our rights arising from any contracts entered into between you and us, including for billing and collection;</li>
                        <li>To provide you with notices about your account and/or subscription, including expiration and renewal notices, email-instructions, etc.;</li>
                        <li>For general management and reporting purposes, such as invoicing and account management;</li>
                        <li>To provide you with news, special offers and general information about other goods, services and events which you may be interested in and offer similar to those that you have already enquired about;</li>
                        <li>To send you offer based on your interests and prior activity, also to view the content preferred by you;</li>
                        <li>In any other way we may describe when you provide the information;</li>
                        <li>To provide aggregate statistics about Users, traffic patterns, and other related information to third parties, however this information when disclosed will be in an aggregate form and does not contain any of personally identifiable information;</li>
                        <li>To comply with applicable laws, rules, and regulations; and</li>
                        <li>For any other purpose with your consent.</li>
                    </ul>

                    <p>You agree that we may use Personal Information about you or share the same with third party service provider to improve our marketing and promotional efforts, to analyse site usage, improve the Platform's content and Service offerings, and customise the Platform's content, layout, and Services. These uses improve the Platform and better tailor it to meet your needs, so as to provide you with an efficient, safe and customized experience while using the Platform. It is clarified that the third-party service provider shall not have right with respect to Personal Information and shall use the Personal Information for the limited purpose for which it has been provided or retain the same for purposes of compliance of applicable law or in complete anonymize form for analytical purposes. Such third-party service provider may store the Personal Information in the servers located in India or outside India.</p>
                    <p>You authorize us to contact you via email or phone call or SMS and offer you our services, for which reasons, Personal Information collected may be used. Further, irrespective of the fact that you may have registered yourself under DND or DNC or NCPR service, you still authorize us to give you a call for the above mentioned purposes till 365 days of your registration with us.</p>
                </div>
                <div className="trm-inner-block">
                    <h4>3.4 Retention of Data</h4>
                    <p>We will retain your Personal Data only for as long as is necessary for the purposes set out in this Privacy Policy. We will retain and use your Personal Data to the extent necessary to comply with our legal obligations (for example, if we are required to retain your data to comply with applicable laws), resolve disputes, and enforce our legal agreements and policies.</p>
                    <p>We will also retain Usage Data for internal analysis purposes. Usage Data is generally retained for a shorter period, except when this data is used to strengthen the security or to improve the functionality of our Service, or we are legally obligated to retain this data for longer time periods.</p>
                    <p>Mailing list information, discussion posts and email are kept for only the period of time considered reasonable to facilitate the User's requests.</p>
                    <p>We reserve the right to retain the aggregated and anonymized data derived from the Personal Data collected from the users of the Platform including your Personal Data, for any purposes (commercial and non-commercial) as the Company deem fit and proper.</p>
                </div>
                <div className="trm-inner-block">
                    <h4>3.5 Withdrawal of Consent</h4>
                    <p>You may withdraw your consent given for collecting any Information and Personal Data under this Privacy Policy and pursuant to use of the Services, at any time by sending an email to <a href="mailto:customercare@zyapaar.com">customercare@zyapaar.com</a>. In such an event, the Company reserves the right to not allow you further usage of the Website and the Application or provide/use any Services thereunder, without any obligations or liability, whatsoever, whether in contract, tort, law, equity or otherwise, in this regard.</p>
                </div>
            </div>
            <div className="trm-block">
            <h3>4. Disclosure of Data</h3>
            <p>We may disclose the information including Personal Data that we collect, or provided by you on our Platform as follows:</p>
            <div className="trm-inner-block">
                    <h4>4.1 Disclosure for Law Enforcement and other legal necessity.</h4>
                    <p>We reserve the right to use or disclose your Personal Data in response to any statutory or legal requirements. We will use and disclose your Personal Data if we believe you will harm the property or our rights or right of the other Users of our Platform. Finally, we will use or disclose your Personal Data if we believe it is necessary to share information in order to investigate, prevent, or take action regarding illegal activities, suspected fraud, situations involving potential threats to the physical safety of any person or property, violations of the Platform’s other policies, or as otherwise required by law when responding to subpoenas, court orders and other legal processes.</p>
                    <p>We reserve the right to use or disclose your Personal Data and other information if we believe that disclosure is necessary or appropriate to protect rights, property and safety of the Company, its users, customers, Service Providers, officers and shareholders. We may also in good faith share information with other organizations and entities for the purposes of fraud protection and credit risk reduction.</p>
            </div>
            <div className="trm-inner-block">
                    <h4>4.2 Business Transaction</h4>
                    <p>If we or our group entities are involved in a merger, acquisition or asset sale, and/or in the event the ownership or control of our Platform changes, we may transfer your information to the new owner.</p>
                </div>
                <div className="trm-inner-block">
                    <h4>4.3 Disclosure by the User</h4>
                    <p>When you use certain features on the Platform like the discussion forums and you post or share your Personal Information as comments, messages, files, photos on such discussion forums on the Platform, which is freely accessible to group of other users and/or the public, the same will be available to all such users and/or public. All such sharing of information will be done at your own risk. Please keep in mind that if you disclose Personal Information in posting as comments, messages, files, photos on the discussion forums on the Platform, such information may become publicly available.</p>
                </div>
                <div className="trm-inner-block">
                    <h4>4.4 Other Disclosures</h4>
                    <p>We may also disclose your Personal Data as follows:</p>
                    <ul className="mb-3">
                        <li>To our subsidiaries and affiliates;</li>
                        <li>To contractors, Service Providers, and other third parties we use to support our business in compliance with the provisions of this Privacy Policy;</li>
                        <li>To fulfill the purpose for which you provide it;</li>
                        <li>For the purpose of including your institution / company’s logo on our website;</li>
                        <li>For any other purpose disclosed by us when you provide the information; and</li>
                        <li>With your consent in any other cases.</li>
                    </ul>
                </div>
                <div className="trm-inner-block">
                    <h4>4.5  Data Processing by the Service Providers</h4>
                    <p>We may engage and employ third party companies and individuals to perform certain processing activities and to perform Service (“Service Providers”), to provide Service on our behalf, perform Service-related activities or assist us in analysing how our Service is used. Towards that objective, we may share your Personal Information with such Service Providers</p>
                    <p>The Service Providers may be engaged and employed for various purposes including following:</p>

                    <ul className="mb-3">
                        <li>Analytics: We may use Service Providers to monitor and analyze the use of our Service and the Usage Data.</li>
                        <li>We may use Service Providers to update and automate the development process of our Platform.</li>
                        <li>Behavioural Remarketing</li>
                    </ul>
                    <p>We may use remarketing services to advertise on third party websites to you after you visited our Platform. We and our Service Provider use cookies to inform, optimise and serve ads based on your past visits to our Platform.</p>
                </div>
              </div>
              <div className="trm-block">
              <h3>5. Data Security Practice and Procedure</h3>
           <p> The security of your data is important to us but remember that no method of transmission over the Internet or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.</p>

           <div className="trm-inner-block">
            <h4>5.1 Security of Data</h4>
               <p>We maintain strong security safeguards to ensure the security and confidentiality of the User’s data, protect against any anticipated threats to the security of your Personal Information, protect against unauthorized access to your information, and ensure the proper disposal of your Personal Information. We have adopted a comprehensive security policy that complies with laws and regulations and reflects industry standards. We have in place appropriate safeguards and security measures to protect the personal data you provide on this Platform against accidental or any other unlawful forms of processing. We use third party Service Providers for the purposes of payment collections and information shared by you in relation to payments, shall be governed by privacy policy adopted by such Service Providers.</p>
               <p>Our security policy requires us to consistently monitor the risk of any threats to the administrative, technical, and physical safeguards we have put in place to protect your information. The safeguards include, at a minimum, firewalls and data encryption and restricting access to your Personal Information only to those employees who have a need to know such information to carry on our operations. These safeguards are reviewed and adjusted periodically based on ongoing risk assessments.</p>
             </div>
             <div className="trm-inner-block">
             <h4>5.2 Grievance Officer</h4>
            <p >In accordance with Information Technology Act 2000 and the Information Technology (Reasonable Security Practices and Procedures and Sensitive Personal Data or Information) Rules, 2011 prescribed there under, the name and contact details of the Grievance Officer are provided below: </p>
            <p>
                <strong> The Grievance Officer</strong> <br/>
                <strong> Company:</strong> Lets Talk Business Private Limited<br/>
                <strong> Name:</strong> Umesh Prajapati<br/>
                <strong> {t('companyproperties.text4')}:</strong> 601, Shikhar Complex, Nr. Adani House, Mithakhali Six Road, Navrangpura, Ahmedabad - 380009, Gujarat, India.<br/>
                <strong> Email:</strong> <a href="mailto:grievance@zyapaar.com">grievance@zyapaar.com</a>
             </p>
             </div>
             <div className="trm-inner-block">
            <h4>5.3 Transfer of Data</h4>
            <p>The information, including Personal Data, we obtain from or about you may be maintained, processed and stored by us on the systems situated in the territory of Republic of India.</p>
            <p>However, subject to applicable laws, your information, including Personal Data, may be transferred to – and maintained on – computers located in the countries other than India where the data protection laws may differ from those of the Data Protection Rules applicable in India.</p>
            <p>If you are located outside India and choose to provide information to us, please note that we transfer the data, including Personal Data, to India and process it there.</p>
            <p>Your consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.</p>
            <p>The Company will take all the steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organisation or a country unless there are adequate controls in place including the security of your data and other Personal Information.</p>
            <p>We comply with generally accepted industry standard regulations regarding the collection, use, and retention of data under the Information Technology Act, 2000 and Data Protection Rules. By using the Platform and/or Services, you consent to the collection, transfer, use, storage and disclosure of your information as described in this Privacy Policy, including to the transfer of your information outside of your country of residence.</p>
      </div>
      <div className="trm-block">
            <h3>6. Links to Other Sites</h3>
            <p>Our Platform may contain links to third party websites and mobile applications that are not operated by us. If you click such link, you may be directed to such third party’s websites and mobile applications. We strongly advise you to review the Privacy Policy of every site you visit.</p>
            <p>We also use APIs, tools and other services of third party for offering our services to the Users.</p>
            <p>We have no control over and assume no responsibility for the content, privacy policies or practices of any third party websites and mobile applications or any services offered by such third parties. You agree that we shall not be liable for any breach of your privacy of Personal Information or loss incurred by your use of such websites or services.</p>
            <p>We may host surveys for survey creators for our Platform who are the owners and users of your survey responses. We do not own or sell your responses. Anything you expressly disclose in your responses will be disclosed to survey creators. Please contact the survey creator directly to better understand how they might share your survey responses.    </p>
        </div>

        <div className="trm-block">
            <h3>7.Changes to this Privacy Policy</h3>

            <p>This Privacy Policy will remain in effect except with respect to any changes in its provisions in the future. We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page, which will be in effect immediately after being posted on this page.</p>
            <p>We reserve the right to update or change our Privacy Policy at any time and you are advised to review this Privacy Policy periodically for any changes. Your continued use of the Platform and our Service after we post any modifications to the Privacy Policy on this page will constitute your acknowledgment of the modifications and your consent to abide and be bound by the modified Privacy Policy.</p>
            <p>We may let you know via email and/or a prominent notice on our Platform, prior to the material change becoming effective and update “effective date” at the top of this Privacy Policy.</p>
        </div>
        <div className="trm-block">
            <h3>8. Copyright, Trademark, and other Intellectual Property Protection</h3>
            <p>The Company is an intellectual property of the Company, all materials on the Platform are protected by copyright laws, trademark laws, and other intellectual property laws. Any unauthorized use of any such information or materials may violate copyright laws, trademarks laws, intellectual property laws, and other laws and regulations.</p>

        </div>
        <div className="trm-block">
            <h3>9. {t('signuprecommendation.text11')}</h3>
            <p>If you have any question about this Privacy Policy, please contact us by email: <a href="mailto:customercare@zyapaar.com">customercare@zyapaar.com</a>.</p>
        </div>
              </div>
          </div>
      </section>
      </div>
    </>
  );
};

export default PrivacyPolicy;
