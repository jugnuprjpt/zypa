/* eslint-disable multiline-ternary */
import { IonButton, IonCol, IonRow, IonCard, IonHeader, IonList, IonAvatar, IonIcon, IonInfiniteScroll, IonInfiniteScrollContent, IonContent, IonItem, useIonPopover } from '@ionic/react';
import React, { useEffect, useState } from 'react';
// import Post from '../components/feed/Post';
import CompanyDetails from '../components/company/CompanyDetail';
import Award from '../components/company/Award';
import TeamMember from '../components/company/TeamMember';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import CompanyProduct from '../components/company/CompanyProduct';
import About from '../components/company/About';
import CallFor from '../util/CallFor';
import { useHistory, useParams } from 'react-router';
import Footer from '../components/Layout/Footer';
import SkeletonComonInvitaion from '../components/common/skeleton/SkeletonComonInvitaion';
import { arrowBack, chevronForward, ellipsisVertical } from 'ionicons/icons';
import userImage from '../assets/img/user-profile-placeholder.png';
import { useSelector } from 'react-redux';
import ToastCommon from '../components/common/ToastCommon';
import { getProfileDetails } from '../Redux/reducers/UserProfile';
import { useTranslation } from 'react-i18next';
import SkeletonAbout from '../components/common/skeleton/SkeletonAbout';
import NotAuthorizeModal from '../components/common/NotAuthorizeModal';

const CompanyDetailsPage = () => {
  const { t } = useTranslation();
  const [loginModal, setLoginModal] = useState(false);
  const profileDetail = useSelector(getProfileDetails);
  const history = useHistory();
  const [myCompanyBtnClass, setMyCompanyBtnClass] = useState('category-btn-color');
  const [companyName, setCompanyName] = useState('');
  const [aboutDetails, setAboutDetails] = useState({});
  const [recommendationsBtnClass, setRecommendationsBtnClass] = useState('category-btn-color');
  const [aboutBtnClass, setAboutBtnClass] = useState('button-color');
  const [productBtnClass, setProductBtnClass] = useState('category-btn-color');
  const [categoryState, setCategoryState] = useState('ABOUT');
  const { companyId } = useParams();
  const [admin, setAdmin] = useState([]);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [loading, setLoading] = useState(false);
  const [classMobile, setClassMobile] = useState(false);
  const [reportHideState, setReportHideState] = useState(false);
  const [count, setCount] = useState();

  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [inviteSentBtnClass, setInviteSentBtnClass] = useState('category-btn-color');
  const [inviteReceivedBtnClass, setInviteReceivedBtnClass] = useState('button-color');
  const [acordionInputAbout, setAcordionInputAbout] = useState(true);
  const [type, setType] = useState('received');
  const [aboutCompany, setAboutCompany] = useState(true);

  useEffect(() => {
    setTimeout(function() {
      setAboutCompany(false);
    }, 100);
  }, []);

  useEffect(() => {
    getAdminDetails();
    getinvitedlist(0, false, type);
  }, []);

  const getinvitedlist = async(page, scrolling, type) => {
    if (!scrolling) {
      setLoading(true);
    }
    setType(type);
    if (type === 'sent') {
      setInviteSentBtnClass('button-color');
      setInviteReceivedBtnClass('category-btn-color');
    } else {
      setInviteSentBtnClass('category-btn-color');
      setInviteReceivedBtnClass('button-color');
    }
    const response = await CallFor(
      'api/v1.1/companies/' + companyId + '/ADMIN',
      'POST',
      '{"page":  ' + page + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (scrolling) {
        if (json1Response.data.content.length > 0) {
          // setAdmin((adminInvite:any) => ([...adminInvite, ...json1Response.data.content]))
          setAdmin([
            ...admin,
            ...json1Response.data.content
          ]);
        } else {
          setInfiniteDisabled(true);
        }
      } else {
        // setAdmin((adminInvite:any) => ([...adminInvite, ...json1Response.data.content]))
        setAdmin(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setCount(page + 1);
    if (!scrolling) {
      setLoading(false);
    }
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getinvitedlist(count, true, type);
      ev.target.complete();
    }, 500);
  };
  const getAdminDetails = async() => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/companies/' + companyId + '/ADMIN',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setAdmin(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const getAllCategoryData = (category: any) => {
    if (category === 'ABOUT') {
      setMyCompanyBtnClass('category-btn-color');
      setAboutBtnClass('ion-button-color');
      setRecommendationsBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
    } else if (category === 'AWARD') {
      setMyCompanyBtnClass('ion-button-color');
      setAboutBtnClass('category-btn-color');
      setRecommendationsBtnClass('category-btn-color');
      setProductBtnClass('category-btn-color');
    } else if (category === 'TEAMMEMBER') {
      setMyCompanyBtnClass('category-btn-color');
      setAboutBtnClass('category-btn-color');
      setRecommendationsBtnClass('ion-button-color');
      setProductBtnClass('category-btn-color');
    } else if (category === 'PRODUCT') {
      setMyCompanyBtnClass('category-btn-color');
      setAboutBtnClass('category-btn-color');
      setRecommendationsBtnClass('category-btn-color');
      setProductBtnClass('ion-button-color');
    }
    setCategoryState(category);
  };
  const removeMobileCss = () => {
    history.goBack();
  };
  const addMobileCss = () => {
    setClassMobile(true);
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  };
  const acordionInpuChangeHander = () => {
    setAcordionInputAbout((prev: any) => (!prev));
  };
  // const openThreeDot = (e, userId) => {
  //   present({ event: e.nativeEvent });
  //   const data = {};
  //   data.id = userId;
  //   setRemoveConnectionModalData(data);
  // };

  // const PopoverList: React.FC<{
  //   onHide: () => void;
  // }> = ({ onHide }) => (
  //   <>
  //     <IonList className="my-account-pr">
  //       <IonItem
  //         lines="none"
  //         className="cursor-pointer"
  //         onClick={() => { setRemoveAdminState(true); dismiss(); }}
  //       >
  //         <IonIcon icon={trashBinOutline} size="small" className="header-menu-img " />
  //         <p>{t('appproperties.text274')}</p>
  //       </IonItem>
  //       <IonItem
  //         lines="none"
  //         className="cursor-pointer"
  //         onClick={() => { setRemoveMemberState(true); dismiss(); }}
  //       >
  //         <IonIcon icon={trashBinOutline} size="small" className="header-menu-img " />
  //         <p>{t('appproperties.text246')}</p>
  //       </IonItem>
  //     </IonList>
  //   </>
  // );
  // const [present, dismiss] = useIonPopover(PopoverList, {
  //   onHide: () => dismiss()
  // });

  // const removeAsAdmin = async() => {
  //   const response = await CallFor(
  //     'api/v1.1/companies/admin/remove/' + removeConnectionModalData.id + '/' + companyId,
  //     'GET',
  //     null,
  //     'Auth'
  //   );
  //   if (response.status === 200) {
  //     setShowToastMsg(t('toastmessages.toast7'));
  //     setShowToast(true);
  //     setTimeout(() => {
  //       history.push('/manageCompanyTeam/' + companyId + '/' + companyName);
  //     }, 1000);
  //   } else if (response.status === 401) {
  //     localStorage.clear();
  //     history.push('/login');
  //   }
  // };
  // const removeAsMember = async() => {
  //   const response = await CallFor(
  //     'api/v1.1/companies/member/remove/' + removeConnectionModalData.id + '/' + companyId,
  //     'GET',
  //     null,
  //     'Auth'
  //   );
  //   if (response.status === 200) {
  //     setShowToastMsg(t('toastmessages.toast1'));
  //     setShowToast(true);
  //     setTimeout(() => {
  //       history.push('/manageCompanyTeam/' + companyId + '/' + companyName);
  //     }, 1000);
  //   } else if (response.status === 401) {
  //     localStorage.clear();
  //     history.push('/login');
  //   }
  // };
  return (
    <>
      <IonContent className="scrolling award-scrolling">
        <IonRow className="plane-bg">
          <IonRow className="container">
            <div className="row full-width-row main-page-content-row">
              <IonCol size-lg="4" size-md="12" size-xs="12" className="left-col col-mobile-none ion-no-padding">
                <div className='sidebar-main'>
                  <h3 className='ps-lg-3 ps-2 pb-2'>{t('appproperties.text176')}</h3>
                  <IonCard className='sdb-box profile-details left-cards no-shadow sidebar-pages data-saprater remove-connections-border'>
                    <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between dn-mobile">
                      <p className="ion-align-self-start">{t('appproperties.text176')}</p>
                    </IonHeader>
                    <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between show-mobile head-angle" onClick={addMobileCss}>
                      <p className="ion-align-self-start">{t('appproperties.text176')}</p>
                      <IonIcon className='icon-mobile' icon={chevronForward} onClick={removeMobileCss}></IonIcon>
                    </IonHeader>
                    {loading
                      ? <SkeletonComonInvitaion />
                      : admin.length > 0
                        ? (
                          <IonList
                            lines="none"
                            className={classMobile ? 'showpage sdb-box profile-details left-cards no-shadow sidebar-pages data-saprate remove-connections-border p-0 m-0' : 'sdb-box profile-details left-cards no-shadow sidebar-pages data-saprater remove-connections-border p-0 m-0'}
                          >
                            <div className='mobile-overlay-screen h-300 overflow-y'>
                              <div className='mobile-back-screen show-mobile title-back  back-with-heading position-sticky'>
                                <IonIcon className='icon-mobile' icon={arrowBack} onClick={removeMobileCss}></IonIcon> <h3>{t('appproperties.text176')}</h3>
                              </div>
                              {admin.length > 4
                                ? <IonContent className='custom-scroll'>
                                  {admin.map((detail) => (
                                    <>
                                      <IonRow className="p-2 GroupInvitation-list-item position-relative border-bottom">
                                        <IonCol className="GroupInvitation-left-col">
                                          <div className="myprofile-feeds ion-no-padding cursor-pointer" >
                                            <IonAvatar className="MuiAvatar ion-margin-end" onClick={() => {
                                              history.push('/profile/' + detail.id);
                                            }}>
                                              {detail.img !== undefined &&
                                                detail.img !== null
                                                ? (
                                                  <img onError={(ev) => { ev.target.src = userImage; }} src={detail.img} />
                                                  )
                                                : (
                                                  <img src={userImage} />
                                                  )}
                                            </IonAvatar>
                                            <IonRow className="display-grid" onClick={() => {
                                              history.push('/profile/' + detail.id);
                                            }} >
                                              <span>{detail.name}</span>
                                              <span className="margin MuiTypography-caption group-model-text w-lg-85">
                                                {detail.designation}
                                              </span>
                                            </IonRow>
                                            {/* {detail.owner === true
                                          ? ''
                                          : <>{profileDetail.id !== detail.id
                                            ? <div className="dot-btn position-absolute right0">
                                              <IonIcon
                                                icon={ellipsisVertical}
                                                slot="start"
                                                className="color-theme font-20 text-grey report cursor-pointer"
                                                onClick={(e) => {
                                                  if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                                                    openThreeDot(e, detail.id);
                                                  } else {
                                                    // history.push('/addnewcompany');
                                                    setLoginModal(true);
                                                  }
                                                }
                                                }
                                              />
                                            </div>
                                            : ''}
                                          </>
                                        } */}
                                          </div>
                                        </IonCol>
                                      </IonRow>
                                    </>
                                  ))}
                                  <IonInfiniteScroll
                                    onIonInfinite={loadData}
                                    disabled={isInfiniteDisabled}
                                  >
                                    <IonInfiniteScrollContent
                                      loadingSpinner="circular"
                                      loadingText={t('appproperties.text215')}
                                    ></IonInfiniteScrollContent>
                                  </IonInfiniteScroll>
                                </IonContent>
                                : admin.map((detail) => (
                                  <>
                                    <IonRow className="p-2 GroupInvitation-list-item position-relative border-bottom">
                                      <IonRow className="GroupInvitation-left-col">
                                        <div className="myprofile-feeds ion-no-padding cursor-pointer">
                                          <IonAvatar className="MuiAvatar ion-margin-end"
                                            onClick={() => {
                                              if (detail.entityId !== undefined) {
                                                history.push('/companyDetail/' + detail.entityId);
                                              } else {
                                                history.push('/profile/' + detail.id);
                                              }
                                            }}>
                                            {detail.img !== undefined &&
                                              detail.img !== null
                                              ? (
                                                <img onError={(ev) => { ev.target.src = userImage; }} src={detail.img} />
                                                )
                                              : (
                                                <img src={userImage} />
                                                )}
                                          </IonAvatar>

                                          <IonRow className="display-grid"
                                            onClick={() => {
                                              if (detail.entityId !== undefined) {
                                                history.push('/companyDetail/' + detail.entityId);
                                              } else {
                                                history.push('/profile/' + detail.id);
                                              }
                                            }}>
                                            <span>{detail.name}</span>
                                            <span className="margin MuiTypography-caption group-model-text w-lg-85">
                                              {detail.designation}
                                              {/* {detail.userDesignation} */}
                                            </span>
                                          </IonRow>

                                          {detail.owner === true
                                            ? ''
                                            : <>{profileDetail.id !== detail.id
                                              ? <div className="dot-btn position-absolute right0">
                                                <IonIcon
                                                  icon={ellipsisVertical}
                                                  slot="start"
                                                  className="color-theme font-20 text-grey report cursor-pointer"
                                                  onClick={(e) => {
                                                    if (profileDetail.entityId !== undefined && profileDetail.entityId !== null) {
                                                      openThreeDot(e, detail.id);
                                                    } else {
                                                      // history.push('/addnewcompany');
                                                      setLoginModal(true);
                                                    }
                                                  }
                                                  }
                                                />
                                              </div>
                                              : ''}
                                            </>
                                          }
                                        </div>
                                      </IonRow>
                                    </IonRow>
                                  </>
                                ))}
                            </div>
                          </IonList>
                          )
                        : <>
                          <p className="p-3">
                            Send Requests to your Company employees !!
                          </p>
                        </>}

                  </IonCard>
                  <Footer />
                </div>
              </IonCol>
              <IonCol size-lg="8" size-md="12" size-xs="12" className="right-col ion-no-padding ">
                <div className="mobile-back-screen show-mobile back-icon-mobile show-mobile mt-3">
                  <IonIcon
                    className="icon-mobile"
                    icon={arrowBack}
                    onClick={removeMobileCss}
                  ></IonIcon>
                </div>
                <CompanyDetails setCompanyName={setCompanyName} setAboutDetails={setAboutDetails} reportHideState={reportHideState} setReportHideState={setReportHideState} />
                {/* <Post/> */}
                {aboutDetails !== undefined
                  ? <>
                    {!reportHideState
                      ? aboutDetails.hide !== true
                        ? <IonRow className="ion-padding-top gup-btn-action px-2 px-lg-0 bg-white company-capsule-btn">
                          {aboutCompany
                            ? <SkeletonAbout column={1} />
                            : <>
                              <IonButton className={aboutBtnClass + ' m-0'} shape='round' size='small' onClick={() => getAllCategoryData('ABOUT')}>
                                {t('commonproperties.text17')}
                              </IonButton>
                              {/* <IonButton className={myCompanyBtnClass} shape='round' size='small' onClick={() => getAllCategoryData('AWARD')}>
                                {t('appproperties.text188')}
                              </IonButton> */}
                              <IonButton className={productBtnClass + ' m-0'} shape='round' size='small' onClick={() => getAllCategoryData('PRODUCT')}>
                                {t('appproperties.text183')}
                              </IonButton><IonButton className={recommendationsBtnClass + ' m-0'} shape='round' size='small' onClick={() => getAllCategoryData('TEAMMEMBER')}>
                                {t('teamproperties.text1')}
                              </IonButton>
                            </>
                          }
                        </IonRow>
                        : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                          {t('appproperties.text346')}
                        </p>
                      : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                        {t('appproperties.text346')}
                      </p>}
                  </> : ''}
                {(() => {
                  if (categoryState === 'ABOUT') {
                    if (aboutDetails !== undefined && aboutDetails.hide !== true && !reportHideState) {
                      return (
                        <>
                          {aboutCompany
                            ? <SkeletonAbout column={1} />
                            : <div className="collapse-container">
                              <div className="tab">
                                <input type="checkbox" id="rd1" name="rd" onClick={acordionInpuChangeHander} checked={acordionInputAbout} />
                                <label className="tab-label p-2" htmlFor="rd1"> {t('commonproperties.text17')} </label>
                                <div className="tab-content">
                                  <About aboutDetails={aboutDetails} />
                                </div>
                              </div>

                              <div className="tab">
                                <input type="checkbox" id="rd2" name="rd" />
                                <label className="tab-label p-2" htmlFor="rd2"> {t('appproperties.text182')}</label>
                                <div className="tab-content">
                                  <Award aboutDetails={aboutDetails} />
                                </div>
                              </div>
                            </div>
                          }
                        </>
                      );
                    }
                  // } else if (categoryState === 'AWARD') {
                  //   return (
                  //     <>
                  //       {
                  //         aboutCompany
                  //           ? <SkeletonAbout column={1} />
                  //           : <Award aboutDetails={aboutDetails} />
                  //       }
                  //     </>
                  //   );
                  } else if (categoryState === 'TEAMMEMBER') {
                    return (
                      <>
                        {aboutCompany
                          ? <SkeletonAbout column={1} />
                          : <TeamMember companyName={companyName} aboutDetails={aboutDetails} />
                        }
                      </>
                    );
                  } else if (categoryState === 'PRODUCT') {
                    return (
                      <CompanyProduct aboutDetails={aboutDetails} companyId={companyId} admin={aboutDetails.admin} setClassMobile={setClassMobile} />
                    );
                  }
                })()}
              </IonCol>
            </div>
          </IonRow>
        </IonRow>

        {/* <ConfirmModelCommon
        header={t('appproperties.text274')}
        message={t('appproperties.text385')}
        btn1="Cancel"
        btn2={t('appproperties.text247')}
        confirmModel={removeAdminState}
        setConfirmModel={setRemoveAdminState}
        deleteBtnHandler={removeAsAdmin}
      />
      <ConfirmModelCommon
        header={t('appproperties.text246')}
        message={t('appproperties.text305')}
        btn1="Cancel"
        btn2={t('appproperties.text247')}
        confirmModel={removeMemberState}
        setConfirmModel={setRemoveMemberState}
        deleteBtnHandler={removeAsMember}
      /> */}
        {showToast && <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />}
      </IonContent>
      {loginModal
        ? <NotAuthorizeModal setAuthModal= {setLoginModal} authModal ={loginModal}/>
        : ''}
    </>
  );
};
export default CompanyDetailsPage;
