/* eslint-disable array-callback-return */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonTextarea
} from '@ionic/react';
import AsyncSelect from 'react-select/async';
import React, { useEffect, useState } from 'react';
import CallFor from '../util/CallFor';
import { Controller, useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import companyProfile from '../assets/img/page-company-profile-placeholder.png';
import { getlocalStore } from '../util/Common';
import { useHistory } from 'react-router';
import ReactLoading from 'react-loading';
import { close, pencilOutline, trashBinOutline } from 'ionicons/icons';
import Select from 'react-select';
import MetaTags from 'react-meta-tags';
import ToastCommon from '../components/common/ToastCommon';
import PopoverCommon from '../components/common/PopoverCommon';
import { useTranslation } from 'react-i18next';

const customStyles = {
  control: (provided: any) => ({
    ...provided,
    minHeight: 56,
    background: '#fff !important',
    '&:focus': {
      border: '1px solid #d8d8d8'
    }
  }),
  multiValue: (styles, { data }) => {
    return {
      ...styles,
      padding: 4,
      backgroundColor: '#0073ae!important',
      borderRadius: '50px'
    };
  },
  multiValueLabel: (styles, { data }) => ({
    ...styles,
    color: '#fff'
  }),
  multiValueRemove: (styles, { data }) => ({
    ...styles,
    color: '#0073ae!important',
    borderRadius: '50px',
    margin: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    ':hover': {
      backgroundColor: '#fff'
    }
  }),
  indicatorSeparator: () => { }, // removes the "stick"
  dropdownIndicator: (defaultStyles: any) => ({
    ...defaultStyles,
    '& svg': { display: 'none' }
  })
};
const AddNewCompanyPage = () => {
  const { t } = useTranslation();
  const firmType = [
    {
      value: 'PROPRIETORSHIP',
      label: t('dropdownfields.text15')
    },
    {
      value: 'PARTNERSHIP_LLP',
      label: t('dropdownfields.text16')
    },
    {
      value: 'PUBLIC_LIMITED_COMPANY',
      label: t('dropdownfields.text17')
    },
    {
      value: 'PVT_LIMITED_COMPANY',
      label: t('dropdownfields.text18')
    },
    {
      value: 'TRUST',
      label: t('dropdownfields.text19')
    },
    {
      value: 'SOCIETIES',
      label: t('dropdownfields.text20')
    },
    {
      value: 'ASSOCIATIONS_CLUB',
      label: t('dropdownfields.text21')
    },
    {
      value: 'BANK_FINANCIAL_INSTITUTATION',
      label: t('dropdownfields.text22')
    },
    {
      value: 'EDUCATION_INSTUATION',
      label: t('dropdownfields.text23')
    },
    {
      value: 'GOVERNMENT_PUBLIC_SECTOR_Undertaking',
      label: t('dropdownfields.text24')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];
  
  const identity = [
    {
      value: 'GSTIN',
      label: 'GSTIN'
    },
    {
      value: 'PAN',
      label: t('dropdownfields.text3')
    },
    {
      value: 'UDYOG_ADHAR',
      label: t('dropdownfields.text4')
    },
    {
      value: 'UDYAM_ADHAR',
      label: 'Udyam Aadhar'
    }
  ];
  
  const businessType = [
    {
      value: 'MANUFACTURING',
      label: t('dropdownfields.text7')
    },
    {
      value: 'TRADER',
      label: t('dropdownfields.text8')
    },
    {
      value: 'SERVICE_PROVIDER',
      label: t('dropdownfields.text9')
    },
    {
      value: 'WORKS_CONTRACT',
      label: t('dropdownfields.text10')
    },
    {
      value: 'FREELANCER',
      label: t('dropdownfields.text11')
    },
    {
      value: 'NON_PROFIT_ORGANIZATION',
      label: t('dropdownfields.text12')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];
  const [companyFile, setCompanyFile] = useState('');
  const [companyModel, setCompanyModel] = useState(false);
  const [stateCombo, setstate] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isValid, setIsValid] = useState(true);
  const [disabled, setdisabled] = useState(true);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [imageView, setImageView] = useState(false);
  const [characterCount, setCharacterCount] = useState(0);
  const maxCount = 500;
  const [formState, setformState] = useState({
    userMobile: getlocalStore('mobileNo'),
    companyEmailId: '',
    contactNo2: null,
    designation: '',
    comments: '',
    contactNo1: null,
    addressLine2: ''
  });
  const [buySelectedValue, setBuySelectedValue] = useState([]);
  const [saveDisabled, setSaveDisabled] = useState(false);
  const formDataChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value !== null && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setformState({ ...formState, [event.target.name]: event.target.value });
    }
  };
  const stateDataChangeHandler = (event) => {
    if (event !== null && event.value !== undefined) {
      setformState({ ...formState, stateId: event.value });
    } else {
      setformState({ ...formState, stateId: null });
    }
  };
  const buyHandleChange = (e) => {
    setBuySelectedValue(Array.isArray(e) ? e.map((x) => x.value) : []);
  };

  const companyVerificationChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    // setError({});
    if (event.target.value !== undefined && event.target.value !== null) {
      if (event.target.name === 'identityType') {
        if (event.target.value.length > 0) {
          event.target.classList.add('input-fill');
        } else {
          event.target.classList.remove('input-fill');
        }
        setformState({
          ...formState,
          identityNumber: '',
          [event.target.name]: event.target.value
        });
      } else {
        setformState({ ...formState, [event.target.name]: event.target.value });
      }
    }
    const identityType = document.getElementById('identityType');
    const identityNumber = document.getElementById('identityNumber');
    if (identityType !== undefined && identityType !== null) {
      if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 15 &&
        identityType.value === 'GSTIN'
      ) {
        setdisabled(false);
      } else if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 10 &&
        identityType.value === 'PAN'
      ) {
        setdisabled(false);
      } else if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 12 &&
        identityType.value === 'UDYOG_ADHAR'
      ) {
        setdisabled(false);
      } else if (
        identityNumber.value !== undefined &&
        identityNumber.value !== null &&
        identityNumber.value !== '' &&
        identityNumber.value.length === 19 &&
        identityType.value === 'UDYAM_ADHAR'
      ) {
        setdisabled(false);
      } else {
        setdisabled(true);
      }
    } else {
      setdisabled(true);
    }
    clearErrors([event.target.name]);
    // buttonRef.current.disabled = true;
    setSaveDisabled(false);
    setVerify(false);
  };

  const validationSchema = Yup.object().shape({
    companyName: Yup.string().trim()
      .required(t('commonproperties.text24'))
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length <= 200
      ),
    addressLine1: Yup.string().trim()
      .required(t('companyproperties.text16'))
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length <= 150
      ),
    companyEmailId: Yup.string().trim().email(t('commonproperties.text9')),
    contactNo1: Yup.string()
      .nullable()
      .optional()
      .test('typeError', t('companyproperties.text18'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return Number(val);
        } else {
          return true;
        }
      })
      .test('len', t('companyproperties.text18'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().length >= 6;
        } else {
          return true;
        }
      })
      .test('len', t('companyproperties.text19'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().length <= 10;
        } else {
          return true;
        }
      }),
    contactNo2: Yup.string()
      .optional()
      .nullable()
      .test('typeError', t('commonproperties.text23'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return Number(val);
        } else {
          return true;
        }
      })
      .test('len', t('commonproperties.text12'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().length >= 10;
        } else {
          return true;
        }
      })
      .test('len', t('commonproperties.text12'), (val) => {
        if (val !== null && val !== '' && val !== undefined) {
          return val && val.toString().length <= 10;
        } else {
          return true;
        }
      }),
    pincode: Yup.string()
      .required(t('companyproperties.text20'))
      .test('typeError', t('companyproperties.text21'), (val) => Number(val))
      .test(
        'len',
        t('companyproperties.text21'),
        (val) => val && val.toString().length === 6
      ),
    designation: Yup.string().trim()
      .required(t('companyproperties.text22'))
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length <= 150
      ),
    cityName: Yup.string().trim()
      .required(t('companyproperties.text23'))
      .matches(/^[A-Za-z-&-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('userproperties.text15'),
        (val) => val && val.toString().length <= 100
      ),
    aboutFirm: Yup.string().trim()
      .required(t('companyproperties.text26'))
      .test(
        'len',
        t('companyproperties.text27'),
        (val) => val && val.toString().length >= 10
      )
      .test(
        'len',
        t('companyproperties.text27'),
        (val) => val && val.toString().length <= 500
      ),
    sales: Yup.array()
      .min(1, t('commonproperties.text36'))
      .of(
        Yup.object().shape({
          label: Yup.string().required(),
          value: Yup.string().required()
        })
      )
      .nullable()
      .required(t('commonproperties.text36')),
    // identityType: Yup.string().required('Identity type is required'),
    identityNumber: Yup.string().trim()
      .required(t('companyproperties.text28'))
      .when('identityType', {
        is: 'GSTIN',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(
            /[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1}/,
            t('companyproperties.text29')
          )
          .test(
            'len',
            t('companyproperties.text29'),
            (val) => val && val.toString().length >= 15
          )
          .test(
            'len',
            t('companyproperties.text29'),
            (val) => val && val.toString().length <= 15
          )
      })
      .when('identityType', {
        is: 'UDYOG_ADHAR',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(
            /[a-zA-Z]{2}[0-9]{2}[a-zA-Z][0-9]{7}/,
            t('companyproperties.text30')
          )
          .test(
            'len',
            t('companyproperties.text30'),
            (val) => val && val.toString().length >= 12
          )
          .test(
            'len',
            t('companyproperties.text30'),
            (val) => val && val.toString().length <= 12
          )
      })
      .when('identityType', {
        is: 'UDYAM_ADHAR',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(
            /[Uu]{1}[Dd]{1}[Yy]{1}[Aa]{1}[Mm]{1}[-][A-Za-z]{2}[-][0-9]{2}[-][0-9]{7}/,
            t('companyproperties.text31')
          )
          .test(
            'len',
            t('companyproperties.text31'),
            (val) => val && val.toString().length >= 19
          )
          .test(
            'len',
            t('companyproperties.text31'),
            (val) => val && val.toString().length <= 19
          )
      })
      .when('identityType', {
        is: 'PAN',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(
            /[a-zA-Z]{3}[pcftghlabjPCFTGHLABJ]{1}[a-zA-Z]{1}[0-9]{4}[a-zA-Z]{1}/,
            t('companyproperties.text32')
          )
          .test(
            'len',
            t('companyproperties.text32'),
            (val) => val && val.toString().length >= 10
          )
          .test(
            'len',
            t('companyproperties.text32'),
            (val) => val && val.toString().length <= 10
          )
      })
  });

  useEffect(() => {
    comboData(101);
  }, []);
  const history = useHistory();
  const comboData = async(companyId: string | number) => {
    const response = await CallFor(
      'api/v1.1/states/' + companyId,
      'GET',
      null,
      'registrationWithAuth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      const states = await json1Response.data.map(
        (d: { id: any; name: any }) => ({
          value: d.id,
          label: d.name
        })
      );
      setstate(states);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };

  const promiseOptions = (inputValue: string) =>
    new Promise<any>((resolve) => {
      resolve(selectProducts(inputValue.trim()));
    });

  const selectProducts = async(inputValue: string) => {
    let productLists = [];
    if (inputValue.length >= 3) {
      const productsRes = await CallFor(
        'api/v1.1/searches/products/' + inputValue,
        'GET',
        null,
        'registrationWithAuth'
      );
      if (productsRes.status === 200) {
        const json1Response = await productsRes.json();
        productLists = await json1Response.data.map(
          (d: { id: any; keyword: any }) => ({
            value: d.id,
            label: d.keyword
          })
        );
      } else if (productsRes.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    }
    return productLists;
  };
  const {
    register,
    handleSubmit,
    setError,
    control,
    clearErrors,
    resetField,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });
  const onClickValidationHandler = () => {
    blurHandler();
    industryBlurHandler();
    businessBlurHandler();
    const profilePhoto = document.getElementById('companylogo');
    let isUserLogoValid = true;
    if (profilePhoto.files[0] !== undefined && profilePhoto.files[0] !== '') {
      if (profilePhoto.files[0].size > 3145728) {
        setError('companylogo', {
          type: 'required',
          message: t('companyproperties.text33')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
      if (!profilePhoto.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('companylogo', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
    }

    if (isUserLogoValid) {
      setIsValid(true);
      return true;
    } else {
      setIsValid(false);
      return false;
    }
  };
  const submitHandler = async(event: any) => {
    if (onClickValidationHandler() && isValid) {
      setSaveDisabled(true);
      let prodcustlist = null;
      const productsd = document.getElementsByName('sales');
      if (productsd.length > 0) {
        const sell = [];
        for (let i = 0; i < productsd.length; i++) {
          sell.push(productsd[i].value);
        }
        prodcustlist = sell;
      }
      let buys = null;
      if (buySelectedValue.length > 0) {
        buys = buySelectedValue;
      }
      let contactNo1 = null;
      if (formState.contactNo1 !== null) {
        contactNo1 = formState.contactNo1;
      }
      let contactNo2 = null;
      if (formState.contactNo2 !== null) {
        contactNo2 = formState.contactNo2;
      }
      let stateId = null;
      if (formState.stateId !== null) {
        stateId = formState.stateId;
      }
      let companyname = '';
      let companyemail = '';
      let companydesignation = '';
      let add1 = '';
      let add2 = '';
      let companycity = '';
      let companyabout = '';

      if (formState.companyName !== undefined && formState.companyName !== null) {
        companyname = formState.companyName.trim();
        formState.companyName = companyname;
      }
      if (formState.designation !== undefined && formState.designation !== null) {
        companydesignation = formState.designation.trim();
        formState.designation = companydesignation;
      }
      if (formState.companyEmailId !== undefined && formState.companyEmailId !== null) {
        companyemail = formState.companyEmailId.trim();
        formState.companyEmailId = companyemail;
      }
      if (formState.addressLine1 !== undefined && formState.addressLine1 !== null) {
        add1 = formState.addressLine1.trim();
        formState.addressLine1 = add1;
      }
      if (formState.addressLine2 !== undefined && formState.addressLine2 !== null) {
        add2 = formState.addressLine2.trim();
        formState.addressLine2 = add2;
      }
      if (formState.cityName !== undefined && formState.cityName !== null) {
        companycity = formState.cityName.trim();
        formState.cityName = companycity;
      }
      if (formState.aboutFirm !== undefined && formState.aboutFirm !== null) {
        companyabout = formState.aboutFirm.trim();
        formState.aboutFirm = companyabout;
      }

      const companyData = {
        designation: formState.designation,
        contactNo1: contactNo1,
        verifiedBy: formState.identityType,
        identityNumber: formState.identityNumber.toUpperCase(),
        name: formState.companyName,
        type: formState.industryTypeText,
        natureOfBusiness: formState.businessTypeText,
        addressLine1: formState.addressLine1,
        addressLine2: formState.addressLine2,
        firmPincode: formState.pincode,
        city: formState.cityName,
        contactNo2: contactNo2,
        email: formState.companyEmailId,
        sales: prodcustlist,
        buys: buys,
        about: formState.aboutFirm,
        states: stateId,
        country: 101
      };
      const companyProfile = document.getElementById('companylogo');
      const data = new FormData();
      data.append('logo', companyProfile.files[0]);
      data.append('companyDto', JSON.stringify(companyData));
      const response = await CallFor(
        'api/v1/companies/users',
        'POST',
        data,
        'registrationWithoutContentType'
      );
      if (response.status === 201) {
        setSaveDisabled(true);
        const datares = await response.json();
        history.push('/login');
        setLoading(false);
        localStorage.clear();
      } else if (response.status === 400) {
        const datares = await response.json();
        if (datares.error.errors !== null) {
          datares.error.errors.map((details) => {
            setError(details.field, {
              type: 'server',
              message: details.message
            });
          });

          if (datares.error.errors[0].field === 'identityNumber') {
            if (
              datares.error.errors[0].message ===
              'Company is Already registered with us'
            ) {
              setCompanyModel(true);
            }
          }
        }
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else {
        setSaveDisabled(false);
      }
    }
  };
  const validateIsNumericInput = (evt: { which: any; keyCode: any }) => {
    const ASCIICode = evt.which ? evt.which : evt.keyCode;
    const permittedKeys = [8, 9, 46, 37, 39, 13, 46, 116, 50];
    if (
      (ASCIICode >= 48 && ASCIICode <= 57) ||
      (ASCIICode >= 96 && ASCIICode <= 105)
    ) {
      return true;
    }
    if (permittedKeys.includes(ASCIICode)) {
      return true;
    }
    return false;
  };

  const uploadCompanylogoHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('companylogo', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        setIsValid(false);
      } else {
        if (event.target.files[0].size > 3145728) {
          setError('companylogo', {
            type: 'required',
            message: t('companyproperties.text33')
          });
          setIsValid(false);
        } else {
          clearErrors('companylogo');
          resetField('companylogo');
          setIsValid(true);
        }
      }
      setCompanyFile(file1);
      setImageView(true);
    }
  };
  const sendTeamRequest = async() => {
    // setLoading(true);
    const response = await CallFor(
      'api/v1.1/companies/identity/' + formState.identityNumber.toUpperCase(),
      'POST',
      null,
      'registrationWithAuth'
    );
    if (response.status === 201) {
      setCompanyModel(false);
      setShowToastMsg(t('appproperties.text262'));
      setShowToast(true);
      setTimeout(() => {
        history.push('/login');
      }, 3000);
    } else if (response.status === 400) {
      setCompanyModel(false);
    }
  };
  const imageEditHandle = () => {
    setImageView(false);
  };
  const deleteImageHandle = () => {
    // document.getElementById('groupImg').src = `${product}`;
    setIsValid(true);
    setCompanyFile('');
    document.getElementById('companylogo').value = '';
    clearErrors('companylogo');
    setImageView(true);
  };
  const addImg = () => {
    setImageView(false);
  };
  const clickHereToReport = async() => {
    const reportsData =
      '{"originId": "' +
      formState.identityNumber.toUpperCase() +
      '","origin": "COMPANY","remarks":"User entity claim." }';
    const response = await CallFor(
      'api/v1.1/spam-report',
      'POST',
      reportsData,
      'registrationWithAuth'
    );
    if (response.status === 200) {
      setShowToastMsg(
        t('toastmessages.toast24')
      );
      setShowToast(true);
      // const datares = await response.json();
      // setUserSession(datares.data);
      // history.push('/login');
    }
  };
  const [verify, setVerify] = useState(false);
  const verifybtn = async() => {
    const identityType = formState.identityType;
    const identityNumber = formState.identityNumber.toUpperCase();
    if (identityType !== undefined && identityNumber !== undefined) {
      setLoading(true);
      const response = await CallFor(
        'api/v1/verify/identity',
        'POST',
        '{"identity":"' +
        identityType +
        '","identityNumber":"' +
        identityNumber.toUpperCase() +
        '"}',
        'registrationWithAuth'
      );
      if (response.status === 200) {
        setVerify(!verify);
        setLoading(false);
        setdisabled(true);
      } else if (response.status === 400) {
        const datares = await response.json();
        setSaveDisabled(false);
        if (datares.error.errors !== null) {
          datares.error.errors.map((details) => {
            setError(details.field, {
              type: 'server',
              message: details.message
            });
          });
          if (datares.error.errors[0].field === 'identityNumber') {
            if (
              datares.error.errors[0].message ===
              'Company is Already registered with us'
            ) {
              setCompanyModel(true);
              setdisabled(true);
              setLoading(false);
              setVerify(!verify);
            }
          } setLoading(false);
        } else {
          setVerify(verify);
          setError('identityNumber', {
            type: 'server',
            message: datares.error.message
          });
          setLoading(false);
        }
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else {
        setLoading(false);
      }
    } else {
      alert('Please select identity type and enter identity number');
    }
  };
  const removeOverLay = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const addClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.add('imageHover');
  };
  const removeClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const blurHandler = () => {
    const identityType = formState.identityType;
    if (identityType === undefined) {
      setError('identityType', {
        type: 'required',
        message: t('commonproperties.text26')
      });
    }
  };
  const industryBlurHandler = () => {
    const industryTypeText = formState.industryTypeText;
    if (industryTypeText === undefined) {
      setError('industryTypeText', {
        type: 'required',
        message: t('commonproperties.text25')
      });
    }
  };
  const businessBlurHandler = () => {
    const businessTypeText = formState.businessTypeText;
    if (businessTypeText === undefined) {
      setError('businessTypeText', {
        type: 'required',
        message: t('companyproperties.text35')
      });
    }
  };
  const aboutFirmChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setformState({
        ...formState,
        aboutFirm: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };
  return (
    <IonRow className="auth-screen with-header">
      <MetaTags>
        <title>
          Zyapaar
        </title>
      </MetaTags>
      {loading
        ? (
          <div className="loader">
            <div key="spokes">
              <ReactLoading type="spokes" color="#fff" />
            </div>
          </div>
          )
        : (
          <div></div>
          )}
      <div className="auth-container company-container registration-page">
        <form
          data-testid="form-submit"
          autoComplete="off"
          noValidate
          onSubmit={handleSubmit(submitHandler, onClickValidationHandler)}
        >
          <div className="">
            <IonCol col-md-12>
              <IonCard className="MuiCard-root MuiPaper-rounded asddaada ">
                <IonRow className="full-width-row">
                  <IonCol size-md="12">
                    <IonCardTitle>
                      <h3 className="ion-no-margin">{t('commonproperties.text30')}</h3>
                    </IonCardTitle>
                  </IonCol>
                  <IonCol size-md="4" size-xs="12" className='show-tooltip input-popover d-block'>
                    <IonSelect
                      interface="popover"
                      className={
                        errors.identityType
                          ? 'error-border select-box'
                          : 'select-box'
                      }
                      placeholder={t('commonproperties.text37')}
                      onIonChange={companyVerificationChangeHandler}
                      onIonBlur={blurHandler}
                      value={formState.identityType}
                      id="identityType"
                      {...register('identityType')}
                    >
                      {identity.map((option) => (
                        <IonSelectOption
                          className="select-background"
                          key={option.label}
                          value={option.value}
                        >
                          {option.label}
                        </IonSelectOption>
                      ))}
                    </IonSelect>
                    <p className={errors.identityType ? 'error' : ''}>
                      {errors.identityType?.message}
                    </p>
                    <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text155')} />
                  </IonCol>
                  <IonCol size-md="4" size-xs="12" className="input-label-box show-tooltip input-popover">
                    <IonItem
                      className={
                        errors.identityNumber
                          ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                          : 'form-group input-label-box position-relative pt-0 mt-0'
                      }
                    >
                      <IonLabel position="floating">{' '}{t('commonproperties.text32')} <sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        autocomplete="off`"
                        type="text"
                        className='input-box ion-text-uppercase'
                        data-testid="identityNumber"
                        placeholder=""
                        onIonChange={companyVerificationChangeHandler}
                        value={formState.identityNumber}
                        id="identityNumber"
                        {...register('identityNumber')}
                      />
                      <PopoverCommon className='popover-zyapaar' headLine={t('appproperties.text155')}  />
                    </IonItem>
                    <p className={errors.identityNumber ? 'error' : ''}>
                      {errors.identityNumber?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="4" size-xs="12">
                    <IonButton
                      disabled={disabled}
                      type="button"
                      size='large'
                      className="ion-button ion-button-color m-0 item-basline m-w-100 mpr-0 ms-lg-3"
                      onClick={verifybtn}
                    >
                      {!verify ? 'VERIFY' : 'VERIFIED'}
                    </IonButton>
                  </IonCol>
                </IonRow>
              </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ">
                <IonRow className="full-width-row">
                  <IonCol size="12">
                    <IonCardTitle>
                      <h3 className="ion-no-margin">{t('companyproperties.text3')}</h3>
                    </IonCardTitle>
                  </IonCol>
                  <IonCol size-md="2" className='ion-text-center' size-xs="12">
                    <input
                      type="file"
                      color="primary"
                      onChange={uploadCompanylogoHandleChange}
                      id="companylogo"
                      accept="image/png, image/jpg, image/jpeg"
                      className="upload"
                      autoComplete="off"
                      disabled={imageView}
                    />
                    <label htmlFor="companylogo" className="cursor-pointer up-img hover-avtar m-auto" id='lblupload' onClick={removeOverLay} onMouseEnter={addClass} onMouseLeave={removeClass}>
                      <IonAvatar
                        id="companyAvatar"
                        slot="start"
                        className="MuiCardHeader-avatar cursor-pointer "
                      >
                        {companyFile
                          ? (
                            <img src={companyFile} className="profileAvtar" />
                            )
                          : (
                            <img src={companyProfile} className="profileAvtar" />
                            )}
                      </IonAvatar>
                      <span className='addImage' onClick={addImg}></span>
                      {companyFile
                        ? <><div className='avr-edit-del-icon'>
                          <span className="icon edit cursor-pointer">
                            <IonIcon icon={trashBinOutline} onClick={deleteImageHandle} />
                          </span>
                          <span className="icon edit cursor-pointer">
                            <IonIcon icon={pencilOutline} onClick={imageEditHandle} />
                          </span>
                        </div>
                        </>
                        : ''}
                    </label>
                    <div className="error ion-text-center w-100">
                      {errors.companylogo?.message}
                    </div>
                  </IonCol>
                  <IonCol size-md="10" size-xs="12" className="input-label-box">
                    <IonRow>
                      <IonCol
                        size-md="6"
                        size-xs="12"
                        className="input-label-box show-tooltip input-popover"
                      >
                        <IonItem
                          className={
                            errors.companyName
                              ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                              : 'form-group input-label-box position-relative pt-0 mt-0'
                          }
                        >
                          <IonLabel position="floating">{' '} {t('commonproperties.text27')}<sup>*</sup>{' '}</IonLabel>
                          <IonInput
                            autocomplete="off"
                            type="text"
                            className='input-box'
                            data-testid="companyName"
                            placeholder=""
                            onIonChange={formDataChangeHandler}
                            value={formState.companyName}
                            id="companyName"
                            {...register('companyName')}
                          />
                          <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text160')} />
                        </IonItem>
                        <p className={errors.companyName ? 'error' : ''}>
                          {errors.companyName?.message}
                        </p>
                      </IonCol>
                      <IonCol size-md="6" size-xs="12" className='show-tooltip input-popover d-block'>
                        <div className="select-input-box">
                          <IonSelect
                            interface="popover"
                            className={
                              errors.industryTypeText
                                ? 'error-border select-box'
                                : 'select-box'
                            }
                            id="industryTypeText"
                            onIonChange={formDataChangeHandler}
                            onIonBlur={industryBlurHandler}
                            value={formState.industryTypeText}
                            {...register('industryTypeText')}
                          >
                            {firmType.map((option) => (
                              <IonSelectOption
                                key={option.value}
                                value={option.value}
                              >
                                {option.label}
                              </IonSelectOption>
                            ))}
                          </IonSelect>
                          <span className='floating-label-outside'>{t('companyproperties.text37')}</span>
                          <sup>*</sup> </div>
                        <p className={errors.industryTypeText ? 'error' : ''}>
                          {errors.industryTypeText?.message}
                        </p>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text161')}/>
                      </IonCol>
                      <IonCol size-md="6" size-xs="12" className='show-tooltip input-popover d-block pb-0'>
                        <div className="select-input-box">
                          <IonSelect
                            interface="popover"
                            className={
                              errors.businessTypeText
                                ? 'error-border select-box'
                                : 'select-box'
                            }
                            id="businessTypeText"
                            onIonChange={formDataChangeHandler}
                            onIonBlur={businessBlurHandler}
                            value={formState.businessTypeText}
                            {...register('businessTypeText')}
                          >
                            {businessType.map((option) => (
                              <IonSelectOption
                                key={option.value}
                                value={option.value}
                              >
                                {option.label}
                              </IonSelectOption>
                            ))}
                          </IonSelect>
                          <span className='floating-label-outside'>{t('appproperties.text179')}
                            <sup>*</sup>
                          </span>
                        </div>
                        <p className={errors.businessTypeText ? 'error' : ''}>
                          {errors.businessTypeText?.message}
                        </p>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text162')} />

                      </IonCol>
                      <IonCol
                        size-md="6"
                        size-xs="12"
                        className="input-label-box mb-0 pb-0"
                      >
                        <IonItem
                          className={
                            errors.companyEmailId
                              ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                              : 'form-group input-label-box position-relative pt-0 mt-0'
                          }
                        >
                          <IonLabel position="floating">{t('commonproperties.text33')}</IonLabel>
                          <IonInput
                            autocomplete="off"
                            type="email"
                            className='input-box'
                            data-testid="companyEmailId"
                            placeholder=""
                            id="companyEmailId"
                            onIonChange={formDataChangeHandler}
                            value={formState.companyEmailId}
                            {...register('companyEmailId')}
                          />
                        </IonItem>
                        <p className={errors.companyEmailId ? 'error' : ''}>
                          {errors.companyEmailId?.message}
                        </p>
                      </IonCol>
                    </IonRow>
                  </IonCol>
                  <IonCol size-md="4" size-xs="12" className="input-label-box">
                    <IonItem
                      className={
                        errors.contactNo1
                          ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                          : 'form-group input-label-box position-relative pt-0 mt-0'
                      }
                    >
                      <IonLabel position="floating">{t('companyproperties.text5')}</IonLabel>
                      <IonInput
                        inputmode="numeric"
                        type="text"
                        pattern="[0-9]*"
                        autocomplete="off"
                        className='input-box'
                        data-testid="contactNo1"
                        placeholder=""
                        id="contactNo1"
                        {...register('contactNo1')}
                        onIonChange={formDataChangeHandler}
                        onkeydown={validateIsNumericInput}
                        value={formState.contactNo1}
                        maxlength={10}
                      />
                    </IonItem>
                    <p className={errors.contactNo1 ? 'error' : ''}>
                      {errors.contactNo1?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="4" size-xs="12" className="input-label-box">
                    <IonItem
                      className={
                        errors.contactNo2
                          ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                          : 'form-group input-label-box position-relative pt-0 mt-0'
                      }
                    >
                      <IonLabel position="floating">{t('userproperties.text6')}</IonLabel>
                      <IonInput
                        inputmode="numeric"
                        type="text"
                        pattern="[0-9]*"
                        autocomplete="off"
                        className='input-box'
                        data-testid="contactNo2"
                        placeholder=""
                        id="contactNo2"
                        {...register('contactNo2')}
                        onIonChange={formDataChangeHandler}
                        onkeydown={validateIsNumericInput}
                        value={formState.contactNo2}
                        maxlength={10}
                      />
                    </IonItem>
                    <p className={errors.contactNo2 ? 'error' : ''}>
                      {errors.contactNo2?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="4" size-xs="12" className="input-label-box">
                    <IonItem
                      className={
                        errors.designation
                          ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                          : 'form-group input-label-box position-relative pt-0 mt-0'
                      }
                    >
                      <IonLabel position="floating">{' '}{t('appproperties.text378')} <sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type="text"
                        className='input-box'
                        data-testid="designation"
                        placeholder=""
                        id="designation"
                        {...register('designation')}
                        onIonChange={formDataChangeHandler}
                        value={formState.designation}
                      />
                    </IonItem>
                    <p className={errors.designation ? 'error' : ''}>
                      {errors.designation?.message}
                    </p>
                  </IonCol>
                </IonRow>
              </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ">
                <IonRow className="full-width-row">
                  <IonCol size="12">
                    <IonCardTitle>
                      <h3 className="ion-no-margin">Address</h3>
                    </IonCardTitle>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className="input-label-box">
                    <IonItem
                      className={
                        errors.addressLine1
                          ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                          : 'form-group input-label-box position-relative pt-0 mt-0'
                      }
                    >
                      <IonLabel position="floating">{' '}{t('companyproperties.text8')} <sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type="text"
                        className='input-box'
                        data-testid="addressLine"
                        placeholder=""
                        id="addressLine1"
                        {...register('addressLine1')}
                        onIonChange={formDataChangeHandler}
                        value={formState.addressLine1}
                      />
                    </IonItem>
                    <p className={errors.addressLine1 ? 'error' : ''}>
                      {errors.addressLine1?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="6" size-xs="12" className="input-label-box">
                    <IonItem className='form-group input-label-box position-relative mt-0 pt-0'>
                      <IonLabel position="floating">{t('companyproperties.text9')}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type="text"
                        className="input-box"
                        data-testid="addressLine2"
                        placeholder=""
                        onIonChange={formDataChangeHandler}
                        value={formState.addressLine2}
                        id="addressLine2"
                        {...register('addressLine2')}
                      />
                    </IonItem>
                  </IonCol>
                  <IonCol size-md="4" size-xs="12" className="input-label-box">
                    <IonItem
                      className={
                        errors.pincode
                          ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                          : 'form-group input-label-box position-relative pt-0 mt-0'
                      }
                    >
                      <IonLabel position="floating">{' '}{t('companyproperties.text10')} <sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        inputmode="numeric"
                        pattern="[0-9]*"
                        autocomplete="off"
                        className='input-box'
                        data-testid="pincode"
                        placeholder=""
                        onIonChange={formDataChangeHandler}
                        onkeydown={validateIsNumericInput}
                        value={formState.pincode}
                        id="pincode"
                        {...register('pincode')}
                        maxlength={6}
                      />
                    </IonItem>
                    <p className={errors.pincode ? 'error' : ''}>
                      {errors.pincode?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="4" size-xs="12">
                    <Select
                      type="text"
                      options={stateCombo}
                      className="selectOption moreimp v-imp "
                      placeholder={t('companyproperties.text14')}
                      styles={customStyles}
                      id="stateId"
                      name="stateId"
                      onChange={stateDataChangeHandler}
                      noOptionsMessage={() => null}
                      isClearable
                    ></Select>
                    <p className={errors.stateId ? 'error' : ''}>
                      {errors.stateId?.message}
                    </p>
                  </IonCol>
                  <IonCol size-md="4" size-xs="12" className="input-label-box">
                    <IonItem
                      className={
                        errors.cityName
                          ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                          : 'form-group input-label-box position-relative pt-0 mt-0'
                      }
                    >
                      <IonLabel position="floating">{' '}{t('companyproperties.text11')} <sup>*</sup>{' '}</IonLabel>
                      <IonInput
                        autocomplete="off"
                        type="text"
                        className='input-box'
                        data-testid="cityName"
                        placeholder=""
                        onIonChange={formDataChangeHandler}
                        value={formState.cityName}
                        id="cityName"
                        {...register('cityName')}
                      />
                    </IonItem>
                    <p className={errors.cityName ? 'error' : ''}>
                      {errors.cityName?.message}
                    </p>
                  </IonCol>
                </IonRow>
              </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ">
                <IonRow className="full-width-row">
                  <IonCol size="12">
                    <IonCardTitle>
                      <h3 className="ion-no-margin">
                      {t('commonproperties.text7')} <sup className='mt-2'>*</sup>
                      </h3>
                    </IonCardTitle>
                  </IonCol>
                  <IonCol size-md="12" size-xs="12" className='show-tooltip input-popover d-block'>
                    <Controller
                      name="sales"
                      control={control}
                      render={({ field }) => (
                        <AsyncSelect
                          {...field}
                          autocomplete="off"
                          type="text"
                          isMulti
                          autocomplete="off"
                          className="selectOption moreimp"
                          placeholder={t('companyproperties.text15')}
                                
                          styles={customStyles}
                          loadOptions={promiseOptions}
                          components={{ LoadingIndicator: null }}
                          id="sales"
                        />
                      )}
                    />
                    <p className={errors.sales ? 'error' : ''}>
                      {errors.sales?.message}
                    </p>
                    <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text163')} />

                  </IonCol>
                </IonRow>
              </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ">
                <IonRow className="full-width-row">
                  <IonCol size="12">
                    <IonCardTitle>
                      <h3 className="ion-no-margin">{t('commonproperties.text8')} </h3>
                    </IonCardTitle>
                  </IonCol>
                  <IonCol size-md="12" size-xs="12" className='show-tooltip input-popover d-block'>
                    <div className='select-input-box'>
                      <AsyncSelect
                        autocomplete="off"
                        type="text"
                        isMulti
                        value={formState.buy}
                        className="selectOption"
                        onChange={buyHandleChange}
                        loadOptions={promiseOptions}
                        placeholder={t('companyproperties.text15')}
                        styles={customStyles}
                        components={{ LoadingIndicator: null }}
                        id="buys"
                        name="buys"
                      />
                      <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text164')}our requirements/>
                    </div>
                    <p className={errors.buys ? 'error' : ''}>
                      {errors.buys?.message}
                    </p>
                  </IonCol>
                </IonRow>
              </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ">
                <IonRow className="full-width-row">
                  <IonCol size="12">
                    <IonCardTitle>
                      <h3 className="ion-no-margin">
                      {t('commonproperties.text31')} <sup>*</sup>
                      </h3>
                    </IonCardTitle>
                  </IonCol>
                  <IonCol size-md="12" size-xs="12">
                    <IonItem
                        className={
                        errors.aboutFirm
                          ? 'error-border form-group input-label-box position-relative pt-0 mt-0'
                          : 'form-group input-label-box position-relative pt-0 mt-0'
                      }
                    >
                      <IonLabel position="floating">{t('companyproperties.text12')}</IonLabel>
                      <IonTextarea
                        autocomplete="off"
                        type="text"
                        rows={6}
                        className='input-box'
                        data-testid="aboutFirm"
                        placeholder=""
                        onIonChange={aboutFirmChangeHandler}
                        value={formState.aboutFirm}
                        id="aboutFirm"
                        {...register('aboutFirm')}
                        maxlength={500}
                      />
                    </IonItem>
                    <p className={errors.aboutFirm ? 'error' : ''}>
                      {errors.aboutFirm?.message}
                    </p>
                    <p className='text-grey text-end font-14'>{characterCount}/{maxCount}</p>
                  </IonCol>
                </IonRow>
              </IonCard>
            </IonCol>
            <IonCol>
              <div className="ion-text-center mb-4">
                <IonButton
                  disabled={saveDisabled}
                  type="submit"
                  size='large'
                  className="ion-button ion-button-color"
                >
                  {t('appproperties.text64')}
                  {saveDisabled
                    ? <span className="loader" id="loader-2">
                      <span></span>
                      <span></span>
                      <span></span>
                    </span>
                    : ''
                  }
                </IonButton>
              </div>
            </IonCol>
          </div>
        </form>
      </div>
      <IonModal isOpen={companyModel} cssClass="small-model" onDidDismiss={() => setCompanyModel(false)}>
        <IonContent>
          <IonRow className="full-width-row ion-padding-top ion-padding-bottom">
            <IonRow>
              <IonLabel className="MuiTypography-h6 ion-padding-start">
                {' '}
                {t('companyproperties.text13')}
              </IonLabel>
            </IonRow>
            <IonButton
              fill="clear"
              className="ion-activatable header-row-margin-left"
              onClick={() => setCompanyModel(false)}
            >
              <IonIcon
                icon={close}
                className="ion-button-color"
                slot="start"
                size="undefined"
              />
            </IonButton>
          </IonRow>
          <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom ion-justify-content-center">
            <span>
              Hi {getlocalStore('user')}, The entity is already registered by
              another user. To join the entity team click the below button.
            </span>
          </IonRow>
          <IonRow className="ion-padding-start">
            <IonButton
              className="ion-button ion-button-color"
              onClick={sendTeamRequest}
            >
             {t('appproperties.text237')}
            </IonButton>
          </IonRow>
          <IonRow className="ion-padding-start ion-padding-top">
            <span className="error">
              Note: {t('companyproperties.text38')}{' '}
              <a onClick={clickHereToReport}>{t('companyproperties.text39')}</a>.
            </span>
          </IonRow>
        </IonContent>
      </IonModal>
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />

    </IonRow>
  );
};
export default AddNewCompanyPage;
