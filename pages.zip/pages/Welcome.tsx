import { IonCol, IonAvatar, IonButton } from '@ionic/react';
import React, { useState } from 'react';
import CallFor from '../util/CallFor';

const Welcome = () => {
  const [file, setFile] = useState('');
  const url = 'api/v1/upload';
  const callFetchHandler = async() => {
    const companyProfile = document.getElementById('upload');
    const data = new FormData();
    data.append('file', companyProfile.files[0]);
    CallFor(url, 'POST', data, 'registrationWithoutContentType');
  };
  const uploadFileHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      setFile(file1);
    }
  };
  return (
    <div>
      <h4>Wellcome to Zyapaar</h4>
      <IonCol size-md="2" size-xs="12">
        <input
            type="file"
            color="primary"
            onChange={uploadFileHandleChange}
            id="upload"
            accept="image/*"
            className="upload"
        />
        <label htmlFor="upload">
            <IonAvatar
            id="avatar"
            slot="start"
            className="MuiCardHeader-avatar"
            >
            <img src={file} className="profileAvtar" />
            </IonAvatar>
        </label>
        </IonCol>
        <IonButton onClick ={callFetchHandler}> click</IonButton>
    </div>
  );
};

export default Welcome;
