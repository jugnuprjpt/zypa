/* eslint-disable no-tabs */
import React, { useState } from 'react';

import aboutintro from '../assets/img/aboutintro.svg';
import nirav from '../assets/img/Nirav.png';
import pankaj from '../assets/img/pankaj.png';
import vishal from '../assets/img/Vishal.png';
import palak from '../assets/img/palak.png';
import MetaTage from '../components/common/MetaTage';
import MetaTagProperties from '../properties/MetaTagProperties';
import { IonRow, IonCol } from '@ionic/react';
import { useTranslation } from 'react-i18next';
// import TagManager from 'react-gtm-module';
// const tagManagerArgs = {
//   gtmId: 'GTM-K26PQF2'
// };
// TagManager.initialize(tagManagerArgs); // Google Tag Manager
const Aboutus = () => {
  const { t } = useTranslation();
  const [showText, setShowText] = useState(false);
  return (
        <>
            <MetaTage metaDetails={MetaTagProperties.about} />
            <div className='web-pages-before AboutUspage'>

                <section className="">
                    <div className="container">
                    <h1 className='text-center'>About  Zyapaar</h1>
                        <IonRow className="align-items-center about-contentpart">
                            <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='align-items-center justify-content-flex-start about-maintext'>

                                <p>Zyapaar is a B2B state of art networking platform to connect, collaborate for seamless supply chain cycle which enables MSME (Micro, Small & Medium Enterprises) & Corporates of India for buying & selling requirements with 100% verified businesses.</p>
                                <p className='pt-3'>Founded by 4 dynamic leaders with overall 80 years of experience together in the B2B, B2C & B2G industries. The founders Nirav Shah, Vishal Dhori, Palak Shah & Pankaj Modi aim to build a network for small, medium or large businesses in India with cost effective supplies of new markets for buyers & sellers. With the rise of global pandemic, 67% businesses have actively engaged with online networks to reach out for new methods & sources of supplies to gain or generate qualified B2B leads, with which Zyapaar was incepted.</p>
                            </IonCol>
                            <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='align-items-center justify-content-flex-start'>
                                <img src={aboutintro} alt="Indian business to do business" />
                            </IonCol>
                        </IonRow>

                        <div className="about-lesstext">

                            {showText &&
                                <div>
                                    <p>Team Zyapaar with their knowledge, experience & expertise aspires to simplify the time consuming process into a coherent ecosystem of networks & connect demand with supply for desired results. Zyapaar creates a digital identity for businesses, allowing them to post their requirement of raw materials, semi-finished products, services & more. Our community helps a Zyapaari to get multiple and ideal responses for real time business needs. Businesses can also make their product catalogs & promote their wide range of products anytime, anywhere improving their brand visibility. The state-of-the-art algorithm developed by team Zyapaar makes the ends meet & aligns the business lead with the business need, with relevant suppliers to buyers & vice-versa.</p>
                                    <p className='pt-3'>Made in India, for India</p>
                                    <p className='pt-3'>Ab Daudega Business!</p>
                                </div>
                            }
                            <div className='btn-readmore-action'>
                                <button className="btn-about mt-3" onClick={() => { setShowText(!showText); }}>{!showText ? t('commonproperties.text29'): 'Read Less'}</button>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="jobListing about-founder">
                    <div className="container">
                        <div className="text-center mb-3">
                            <h2>Meet Zyapaar Team</h2>
                        </div>
                        <div className="JobContent d-flex justify-content-between pt-4">
                            <div className="job-item wow fadeInUp">
                                <div className="img">
                                    <span><img src={nirav} alt="nirav shah" /></span>
                                </div>
                                <div className="job-title SecondryText fw-bold">Nirav Shah</div>
                                <div className="job-exp">Co-founder</div>
                                <a target="_blank" href="https://www.linkedin.com/in/nirav-shah-006151b0/" rel="noreferrer"><i className="fab fa-linkedin"></i></a>
                            </div>
                            <div className="job-item wow fadeInUp" data-wow-delay=".2s">
                                <div className="img">
                                    <span><img src={pankaj} alt="pankaj shah" /></span>
                                </div>
                                <div className="job-title SecondryText fw-bold">Pankaj Modi</div>
                                <div className="job-exp">Co-founder</div>
                                <a target="_blank" href="https://www.linkedin.com/in/pankaj-modi-8baba412/" rel="noreferrer"><i className="fab fa-linkedin"></i></a>
                            </div>
                            <div className="job-item wow fadeInUp" data-wow-delay=".6s">
                                <div className="img">
                                    <span><img src={vishal} alt="vishal shah" /></span>
                                </div>
                                <div className="job-title SecondryText fw-bold">Vishal Dhori</div>
                                <div className="job-exp">Co-founder</div>
                                <a target="_blank" href="https://www.linkedin.com/in/vishaldhori/" rel="noreferrer"><i className="fab fa-linkedin"></i></a>
                            </div>
                            <div className="job-item wow fadeInUp" data-wow-delay="1s">
                                <div className="img">
                                    <span><img src={palak} alt="palak shah" /></span>
                                </div>
                                <div className="job-title SecondryText fw-bold">Palak Shah</div>
                                <div className="job-exp">Co-founder</div>
                                <a target="_blank" href="https://www.linkedin.com/in/palak-shah-74819513/" rel="noreferrer"><i className="fab fa-linkedin"></i></a>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            {/* <Footer></Footer> */}
        </>
  );
};
export default Aboutus;
