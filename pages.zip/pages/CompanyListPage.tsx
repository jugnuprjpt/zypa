import { IonRow } from '@ionic/react';
import React from 'react';
import { useParams } from 'react-router-dom';
import Company from '../components/profile/Company';

const CompanyListPage = () => {
  const { userId } = useParams();
  return (
    <IonRow className="plane-bg">
        <IonRow className="container">
            <Company/>
        </IonRow>
    </IonRow>);
};
export default CompanyListPage;
