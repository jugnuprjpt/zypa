/* eslint-disable multiline-ternary */
/* eslint-disable no-undef */
/* eslint-disable no-unused-expressions */
/* eslint-disable react/jsx-key */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCol,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonLabel,
  IonList,
  IonModal,
  IonRow
} from '@ionic/react';
import { arrowBack, caretForward, chevronForward, close } from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import ActivityCard from '../components/common/ActivityCard';
import ConnectionSuggestion from '../components/common/ConnectionSuggestion';
import CallFor from '../util/CallFor';
import { useHistory } from 'react-router';
import userProfile from '../assets/img/user-profile-placeholder.png';
import ConnectionScrollCard from '../components/network/ConnectionScrollCard';
import MetaTags from 'react-meta-tags';
import Footer from '../components/Layout/Footer';
import SkeletonConnectionRequest from '../components/common/skeleton/SkeletonConnectionRequest';
import ConfirmModelCommon from '../components/common/ConfirmModelCommon';
import ButtonComponent from '../components/common/ButtonComponent';
import companyProfile from '../assets/img/page-company-profile-placeholder.png';
import pageLogo from '../assets/img/page-logo-default.png';
import groupLogo from '../assets/img/group-profile-placeholder.png';
import MutualConnectionRow from '../components/common/MutualConnectionRow';
import { Trans, useTranslation } from 'react-i18next';

const NetworkPage = () => {
  const { t } = useTranslation();
  const [confirmIgnoreModel, setConfirmIgnoreModel] = useState(false);
  const [inviteSentBtnClass, setInviteSentBtnClass] = useState(
    'reqreceive activereq'
  );
  const [inviteReceivedGroupClass, setinviteReceivedGroupClass] =
    useState('reqreceive');
  const [allInvitationBtnClass, setAllInvitationBtnClass] =
    useState('ion-button-color');
  const [pageInvitationBtnClass, setPageInvitationBtnClass] =
    useState('category-btn-color');
  // const [groupInvitationBtnClass, setGroupInvitationBtnClass] = useState('category-btn-color');
  const [userInvitationBtnClass, setUserInvitationBtnClass] =
    useState('category-btn-color');
  const [teamInvitationBtnClass, setTeamInvitationBtnClass] =
    useState('category-btn-color');

  const network = [
    {
      id: 'ALL',
      name: (t('appproperties.text4')),
      connection: ''
    }
  ];
  const [adminInvite, setAdminInvitation] = useState([]);
  const [connectionData, setConnectionData] = useState([]);
  const [conClassMobile, setConClassMobile] = useState(false);
  const [classMobile, setclassMobile] = useState(false);
  const [type, setType] = useState('');
  const [contype, setconType] = useState('');
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [count, setCount] = useState();
  const [loadingRequest, setLoadingRequest] = useState(false);
  const [networkCount, setNetworkCount] = useState('');
  const [confirmModel, setConfirmModel] = useState(false);
  const [confirmModelMsg, setConfirmModelMsg] = useState('');
  const [userId, setUserId] = useState('');
  const [fromUserId, setFromUserId] = useState('');
  const [cType, setCType] = useState('');
  const [connectionType, setConnectionType] = useState('ALL');
  const [requestType, setRequestType] = useState('');
  const [industryloading, setIndustryLoading] = useState(true);
  const [connectionIndustry, setConnectionIndustry] = useState<object[]>([]);
  useEffect(() => {
    getconnectionList();
    getconnectionRequestList('RECEIVED', 'ALL', 0, false);
    getnetworkCount();
    getIndustryData();
  }, []);
  const getIndustryData = async() => {
    setIndustryLoading(true);
    const response = await CallFor(
      'api/v1.1/users/industries',
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data !== null) {
        setConnectionIndustry(json1Response.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setIndustryLoading(false);
  };
  const getconnectionList = async() => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.2/suggestions/users',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setConnectionData(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const getconnectionRequestList = async(
    requesttype,
    connType,
    page,
    scrolling
  ) => {
    setType(requesttype);
    setconType(connType);
    if (requesttype === 'SENT') {
      setInviteSentBtnClass('reqreceive activereq');
      setinviteReceivedGroupClass('reqreceive');
    } else {
      setInviteSentBtnClass('reqreceive');
      setinviteReceivedGroupClass('reqreceive activereq');
    }
    if (!scrolling) {
      setLoadingRequest(true);
    }
    const response = await CallFor(
      'api/v1.1/users/connections/' + requesttype + '/' + connType,
      'POST',
      '{"page": ' + page + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (scrolling) {
        if (json1Response.data.content.length > 0) {
          setAdminInvitation([...adminInvite, ...json1Response.data.content]);
        } else {
          setInfiniteDisabled(true);
        }
      } else {
        setAdminInvitation(json1Response.data.content);
      }
    }
    setCount(page + 1);
    if (!scrolling) {
      setLoadingRequest(false);
    }
  };
  const actionBtnHandler = async(fromUserId, type, id, requestType) => {
    let data = null;
    let url = '';
    if (requestType === 'user') {
      data = '{ "message":"' + cType + '", "id":"' + id + '"}';
      url = 'api/v1.1/connect/action/' + fromUserId + '/' + type.toUpperCase();
    } else if (requestType === 'company') {
      url =
        'api/v1.1/companies/teams/invitations/' + id + '/' + type.toUpperCase();
    } else if (requestType === 'page') {
      url = 'api/v1.1/pages/request/' + id + '/' + type.toLowerCase();
    }
    const response = await CallFor(url, 'POST', data, 'Auth');
    if (response.status === 200) {
      setAdminInvitation(adminInvite.filter((item) => item.requestId !== id));
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      const jsonRes = response.json();
      console.log(jsonRes);
    }
  };
  const actionBtnHandlerReceived = async(
    fromUserId,
    type,
    id,
    requestType
  ) => {
    let data = null;
    let url = '';
    if (requestType === 'user') {
      data = '{ "message":"' + type + '", "id":"' + id + '"}';
      url = 'api/v1.1/connect/action/' + fromUserId + '/' + type.toUpperCase();
    } else if (requestType === 'company') {
      url =
        'api/v1.1/companies/teams/invitations/' + id + '/' + type.toUpperCase();
    } else if (requestType === 'page') {
      url = 'api/v1.1/pages/request/' + id + '/' + type.toLowerCase();
    }
    const response = await CallFor(url, 'POST', data, 'Auth');
    if (response.status === 200) {
      setAdminInvitation(adminInvite.filter((item) => item.requestId !== id));
      if (requestType === 'user') {
        if (type === 'ACCEPT') {
          setNetworkCount(networkCount + 1);
          getIndustryData();
        }
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else if (response.status === 404) {
      const jsonRes = response.json();
      console.log(jsonRes);
    }
  };

  const loadData = (ev: any) => {
    setTimeout(() => {
      getconnectionRequestList(type, contype, count, true);
      ev.target.complete();
    }, 500);
  };

  const addMobileCss = () => {
    setclassMobile(true);
    document
      .getElementsByTagName('html')[0]
      .classList.add('mobileOverlayHandel');
  };
  const removeMobileCss = () => {
    setclassMobile(false);
    document
      .getElementsByTagName('html')[0]
      .classList.remove('mobileOverlayHandel');
  };
  const getnetworkCount = async() => {
    const response = await CallFor(
      'api/v1.1/users/connection/count',
      'get',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data !== null) {
        setNetworkCount(json1Response.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const withdrawMobile = (name, cType, requestId, userid, requestType) => {
    if (requestType === 'user') {
      setConfirmModelMsg(t('userproperties.text1'));
    } else if (requestType === 'company') {
      setConfirmModelMsg(t('appproperties.text25'));
    } else {
      setConfirmModelMsg(t('appproperties.text26'));
    }
    setConfirmModel(true);
    setCType(cType);
    setUserId(requestId);
    setFromUserId(userid);
    setRequestType(requestType);
  };
  const getAllRequestDetails = (connectionType) => {
    setInfiniteDisabled(false);
    if (connectionType === 'ALL') {
      setAllInvitationBtnClass('ion-button-color');
      setPageInvitationBtnClass('category-btn-color');
      // setGroupInvitationBtnClass('category-btn-color');
      setUserInvitationBtnClass('category-btn-color');
      setTeamInvitationBtnClass('category-btn-color');
    } else if (connectionType === 'PAGE') {
      setAllInvitationBtnClass('category-btn-color');
      setPageInvitationBtnClass('ion-button-color');
      // setGroupInvitationBtnClass('category-btn-color');
      setUserInvitationBtnClass('category-btn-color');
      setTeamInvitationBtnClass('category-btn-color');
    } else if (connectionType === 'GROUP') {
      setAllInvitationBtnClass('category-btn-color');
      setPageInvitationBtnClass('category-btn-color');
      // setGroupInvitationBtnClass('ion-button-color');
      setUserInvitationBtnClass('category-btn-color');
      setTeamInvitationBtnClass('category-btn-color');
    } else if (connectionType === 'USER') {
      setAllInvitationBtnClass('category-btn-color');
      setPageInvitationBtnClass('category-btn-color');
      // setGroupInvitationBtnClass('category-btn-color');
      setUserInvitationBtnClass('ion-button-color');
      setTeamInvitationBtnClass('category-btn-color');
    } else if (connectionType === 'COMPANY') {
      setAllInvitationBtnClass('category-btn-color');
      setPageInvitationBtnClass('category-btn-color');
      // setGroupInvitationBtnClass('category-btn-color');
      setUserInvitationBtnClass('category-btn-color');
      setTeamInvitationBtnClass('ion-button-color');
    }
    setConnectionType(connectionType);
    getconnectionRequestList(type, connectionType, 0, false);
  };

  const profileClick = (id, requestType, entityId) => {
    if (requestType === 'user') {
      history.push('/profile/' + id);
    } else if (requestType === 'company') {
      history.push('/companyDetail/' + entityId);
    } else if (requestType === 'page') {
      history.push('/pageDetails/' + entityId);
    }
    if (requestType === 'group') {
      history.push('/group/' + entityId);
    }
  };
  const [modelJsonData, setModelJsonData] = useState({});
  const ignoreModelBox = (
    fromUserId,
    type,
    id,
    requestType) => {
    const jsonData = {};
    jsonData.fromUserId = fromUserId;
    jsonData.id = id;
    jsonData.type = type;
    jsonData.requestType = requestType;
    jsonData.toastMsg = t('appproperties.text429');
    jsonData.modelMsg = t('appproperties.text383');
    setModelJsonData(jsonData);
    setConfirmIgnoreModel(true);
  };
  return (
    <>
      <MetaTags>
        <title>Zyapaar</title>
      </MetaTags>
      <IonRow className="plane-bg ">
        <IonRow className="container">
          <div className="row full-width-row main-page-content-row remove-connections-border">
            <IonCol
              size-lg="4"
              size-md="12"
              size-xs="12"
              className="left-col ion-no-padding"
            >
              <div className="sidebar-main network-sidebar connection-sapce">
                <ActivityCard
                  header={t('appproperties.text3')}
                  mapData={network}
                  icon={caretForward}
                  fieldLink="/connection/"
                  sublink={1}
                  className="sidebar-pages dn-mobile pages-scroll"
                  noDataFound={t('nodatafound.text12')}
                  networkCount={networkCount}
                />
                <IonCard className="sdb-box profile-details ion-no-margin ion-margin-top ion-margin-bottom no-shadow show-mobile">
                  <IonHeader
                    className="card-header-text ion-align-items-center ion-justify-content-between head-angle"
                    onClick={() => history.push('/connection/mynetwork/ALL')}
                  >
                    <p className="ion-align-self-start">{t('appproperties.text4')}</p>
                    <IonIcon
                      className="icon-mobile"
                      icon={chevronForward}
                    ></IonIcon>
                  </IonHeader>
                </IonCard>
                <ConnectionScrollCard
                  setConClassMobile={setConClassMobile}
                  conClassMobile={conClassMobile}
                  connectionIndustry ={connectionIndustry}
                  industryloading ={industryloading}
                />
                <Footer />
              </div>
            </IonCol>
            <IonCol
              size-lg="8"
              size-md="12"
              size-xs="12"
              className="right-col ion-no-padding ion-padding-top"
            >
              <IonCard
                className={
                  classMobile
                    ? 'showpage sdb-box profile-details MuiPaper-rounded con-request-card ion-no-margin ion-margin-top ion-margin-bottom no-mt-mb'
                    : 'sdb-box profile-details MuiPaper-rounded con-request-card ion-no-margin ion-margin-top ion-margin-bottom no-mt-mb'
                }
              >
                <IonHeader className="card-header-text ion-padding-start ion-padding-end card-header-text dn-mobile pb-lg-0">
                  <IonRow className="ion-no-padding w-100 d-block">
                    <div className="textcolour head-title">{t('appproperties.text12')}</div>
                    <div className="conrec-segment">
                      <IonButton
                        className={inviteReceivedGroupClass + ' m-0'}
                        fill="clear"
                        onClick={() => {
                          getconnectionRequestList(
                            'RECEIVED',
                            connectionType,
                            0,
                            false
                          );
                          setInfiniteDisabled(false);
                        }}
                      >
                        {t('appproperties.text166')}
                      </IonButton>
                      <IonButton
                        fill="clear"
                        className={inviteSentBtnClass + ' m-0'}
                        onClick={() => {
                          getconnectionRequestList(
                            'SENT',
                            connectionType,
                            0,
                            false
                          );
                          setInfiniteDisabled(false);
                        }}
                      >
                       {t('appproperties.text361')}
                      </IonButton>
                    </div>
                  </IonRow>
                </IonHeader>
                {/* for mobile */}
                <IonHeader
                  className="card-header-text ion-align-items-center ion-justify-content-between show-mobile head-angle"
                  onClick={addMobileCss}
                >
                  <p className="ion-align-self-start">{t('appproperties.text12')}</p>
                  <IonIcon
                    className="icon-mobile"
                    icon={chevronForward}
                  ></IonIcon>
                </IonHeader>

                <IonRow className="mobile-overlay-screen with-sb-box mobile-space-bottom concreqction">
                  <div className="mobile-back-screen show-mobile head-angle back-with-heading py-0">
                    <IonIcon
                      className="icon-mobile"
                      icon={arrowBack}
                      onClick={removeMobileCss}
                    ></IonIcon>
                    <div className="conrec-segment mt-lg-2 ms-auto">
                      <IonButton
                        size="small"
                        className={inviteReceivedGroupClass + ' m-0'}
                        fill="clear"
                        onClick={() => {
                          getconnectionRequestList(
                            'RECEIVED',
                            connectionType,
                            0,
                            false
                          );
                          setInfiniteDisabled(false);
                        }}
                      >
                        {t('appproperties.text360')}
                      </IonButton>
                      <IonButton
                        size="small"
                        fill="clear"
                        className={inviteSentBtnClass + ' m-0'}
                        onClick={() => {
                          getconnectionRequestList(
                            'SENT',
                            connectionType,
                            0,
                            false
                          );
                          setInfiniteDisabled(false);
                        }}
                      >
                        {t('appproperties.text361')}
                      </IonButton>
                    </div>
                  </div>
                  {/* for mobile */}
                  <IonRow className="gup-btn-action mobile-gup-btn-action ps-3 py-lg-3 py-1 mb-0 w-100 mt-0">
                    <IonButton
                      className={allInvitationBtnClass}
                      shape="round"
                      size="small"
                      onClick={() => getAllRequestDetails('ALL')}
                    >
                      {t('appproperties.text15')}
                    </IonButton>
                    <IonButton
                      className={userInvitationBtnClass}
                      shape="round"
                      size="small"
                      onClick={() => getAllRequestDetails('USER')}
                    >
                      {t('appproperties.text16')}
                    </IonButton>
                    <IonButton
                      className={teamInvitationBtnClass}
                      shape="round"
                      size="small"
                      onClick={() => getAllRequestDetails('COMPANY')}
                    >
                     {t('appproperties.text17')}
                    </IonButton>
                    <IonButton
                      className={pageInvitationBtnClass}
                      shape="round"
                      size="small"
                      onClick={() => getAllRequestDetails('PAGE')}
                    >
                      {t('appproperties.text212')}
                    </IonButton>
                  </IonRow>
                  {loadingRequest ? (
                    <SkeletonConnectionRequest />
                  ) : adminInvite.length > 0 ? (
                    <IonList
                      lines="none"
                      className="full-width-row GroupInvitation-list pt-lg-0"
                    >
                      {adminInvite.length > 5 ? (
                        <IonContent className="scrolling scrolling-custom-hei ">
                          {adminInvite.map((detail) => (
                            <IonRow className="ion-padding-start ion-bottom-padding-smallcom GroupInvitation-list-item">
                              {type === 'RECEIVED' ? (
                                <>
                                  <IonRow className="w-75">
                                    <div className="myprofile-feeds ion-no-padding cursor-pointer">
                                      <IonAvatar
                                        className="MuiAvatar ion-margin-end"
                                        onClick={() =>
                                          profileClick(
                                            detail.id,
                                            detail.type,
                                            detail.entityId
                                          )
                                        }
                                      >
                                        {detail.type === 'user' ? (
                                          detail.logo === null ||
                                          detail.logo === '' ? (
                                            <img src={userProfile} />
                                              ) : (
                                            <img onError={(ev) => { ev.target.src = userProfile; }} src={detail.logo} />
                                              )
                                        ) : detail.type === 'company' ? (
                                          detail.logo === null ||
                                          detail.logo === '' ? (
                                            <img src={companyProfile} />
                                              ) : (
                                            <img onError={(ev) => { ev.target.src = companyProfile; }} src={detail.logo} />
                                              )
                                        ) : detail.type === 'page' ? (
                                          detail.logo === null ||
                                          detail.logo === '' ? (
                                            <img src={pageLogo} />
                                              ) : (
                                            <img onError={(ev) => { ev.target.src = pageLogo; }} src={detail.logo} />
                                              )
                                        ) : detail.type === 'group' ? (
                                          detail.logo === null ||
                                          detail.logo === '' ? (
                                            <img src={groupLogo} />
                                              ) : (
                                            <img onError={(ev) => { ev.target.src = groupLogo; }} src={detail.logo} />
                                              )
                                        ) : (
                                          ''
                                        )}
                                      </IonAvatar>
                                      <IonRow className="display-grid">
                                        {detail.type === 'user' ? (
                                          <>
                                            <IonRow
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  'user',
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.fullName}
                                            </IonRow>
                                            <span className="margin MuiTypography-caption group-model-text">
                                              {detail.title}
                                            </span>
                                            <span className="margin MuiTypography-caption group-model-text">
                                            <MutualConnectionRow id = {detail.id} name = {detail.fullName} key={detail.id}/>
                                            </span>
                                          </>
                                        ) : detail.type === 'company' ? (
                                          <>
                                            <IonRow
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  'user',
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.fullName}
                                            </IonRow>
                                            <p
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  detail.type,
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.admin === 'true'
                                                ? <Trans i18nKey="appproperties.text318" values={{ team_name: detail.entityName }}
                                                components={{ bold: <strong className='text-dark' /> }} />

                                                : <Trans i18nKey="appproperties.text319" values={{ team_name: detail.entityName }}
                                                components={{ bold: <strong className='text-dark' /> }} /> }

                                              {/* <strong>
                                                {detail.entityName}
                                              </strong> */}
                                            </p>
                                          </>
                                        ) : detail.type === 'page' ? (
                                          <>
                                            <IonRow
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  'user',
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.fullName}
                                            </IonRow>
                                            <p
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  detail.type,
                                                  detail.entityId
                                                )
                                              }
                                            >
                                               {detail.admin === 'true'
                                                 ? <Trans i18nKey="appproperties.text314" values={{ page_name: detail.entityName }}
                                                 components={{ bold: <strong className='text-dark' /> }} />

                                                 : <Trans i18nKey="appproperties.text315" values={{ page_name: detail.entityName }}
                                                 components={{ bold: <strong className='text-dark' /> }} /> }

                                              {/* <strong>
                                                {' '}
                                                {detail.entityName}
                                              </strong> */}

                                            </p>
                                          </>
                                        ) : detail.type === 'group' ? (
                                          <>
                                            <IonRow
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  'user',
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.fullName}
                                            </IonRow>
                                            <p
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.entityId,
                                                  detail.type,
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              <Trans i18nKey="appproperties.text363" values={{ group_name: detail.entityName }}
 components={{ bold: <strong className='text-dark' /> }} />

                                              {/* <strong>
                                                {' '}
                                                {detail.entityName}
                                              </strong> */}

                                            </p>
                                          </>
                                        ) : (
                                          ''
                                        )}
                                      </IonRow>
                                    </div>
                                  </IonRow>
                                  <IonRow className="header-row-margin-left ion-align-items-center">
                                    {detail.type === 'company' ? (
                                      <>
                                        <IonButton
                                          className="category-btn-color cursor-pointer btn-sm-cn pe-0 btnIgnore"
                                          size="small"
                                          onClick={() =>
                                            actionBtnHandlerReceived(
                                              detail.id,
                                              'REJECT',
                                              detail.requestId,
                                              detail.type
                                            )
                                          }
                                        >
                                          {t('appproperties.text19')}
                                        </IonButton>
                                        <IonButton
                                          className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnAccept"
                                          size="small"
                                          onClick={() =>
                                            actionBtnHandlerReceived(
                                              detail.id,
                                              'ACCEPT',
                                              detail.requestId,
                                              detail.type
                                            )
                                          }
                                        >
                                          {t('appproperties.text20')}
                                        </IonButton>
                                      </>
                                    ) : (
                                      <>
                                        <ButtonComponent
                                          className="category-btn-color cursor-pointer btn-sm-cn pe-0 btnIgnore"
                                          btnClick={ignoreModelBox}
                                          field1={detail.id}
                                          field2="REJECT"
                                          field3={detail.requestId}
                                          field4={detail.type}
                                          name={t('appproperties.text19')}
                                          parametersPass={4}
                                        />
                                        <ButtonComponent
                                          className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnAccept"
                                          btnClick={actionBtnHandlerReceived}
                                          field1={detail.id}
                                          field2="ACCEPT"
                                          field3={detail.requestId}
                                          field4={detail.type}
                                          name={t('appproperties.text20')}
                                          parametersPass={4}
                                        />
                                      </>
                                    )}
                                  </IonRow>
                                </>
                              ) : (
                                <>
                                  <IonRow className="w-75">
                                    <div className="myprofile-feeds ion-no-padding cursor-pointer">
                                      <IonAvatar
                                        className="MuiAvatar ion-margin-end"
                                        onClick={() =>
                                          profileClick(
                                            detail.id,
                                            detail.type,
                                            detail.entityId
                                          )
                                        }
                                      >
                                        {detail.type === 'user' ? (
                                          detail.logo === null ||
                                          detail.logo === '' ? (
                                            <img src={userProfile} />
                                              ) : (
                                            <img onError={(ev) => { ev.target.src = userProfile; }} src={detail.logo} />
                                              )
                                        ) : detail.type === 'company' ? (
                                          detail.logo === null ||
                                          detail.logo === '' ? (
                                            <img src={companyProfile} />
                                              ) : (
                                            <img onError={(ev) => { ev.target.src = companyProfile; }} src={detail.logo} />
                                              )
                                        ) : detail.type === 'page' ? (
                                          detail.logo === null ||
                                          detail.logo === '' ? (
                                            <img src={pageLogo} />
                                              ) : (
                                            <img onError={(ev) => { ev.target.src = pageLogo; }} src={detail.logo} />
                                              )
                                        ) : (
                                          ''
                                        )}
                                      </IonAvatar>
                                      <IonRow className="display-grid">
                                        {detail.type === 'user' ? (
                                          <>
                                            <IonRow
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  'user',
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.fullName}
                                            </IonRow>
                                            <span className="margin MuiTypography-caption group-model-text">
                                              {detail.title}
                                            </span>
                                            <span className="margin MuiTypography-caption group-model-text">
                                              <MutualConnectionRow id = {detail.id} name = {detail.fullName} key={detail.id}/>
                                            </span>
                                          </>
                                        ) : detail.type === 'company' ? (
                                          <>
                                            <IonRow
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  'user',
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.fullName}
                                            </IonRow>
                                            <p
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  detail.type,
                                                  detail.entityId
                                                )
                                              }
                                            >
                                               {detail.admin === 'true'
                                                 ? <Trans i18nKey="appproperties.text316" values={{ team_name: detail.entityName }}
                                                 components={{ bold: <strong className='text-dark' /> }} />

                                                 : <Trans i18nKey="appproperties.text317" values={{ team_name: detail.entityName }}
                                                 components={{ bold: <strong className='text-dark' /> }} /> }
                                              {/* <strong>
                                                {' '}
                                                {detail.entityName}
                                              </strong> */}
                                            </p>
                                          </>
                                        ) : detail.type === 'page' ? (
                                          <>
                                            <IonRow
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  'user',
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.fullName}
                                            </IonRow>
                                            <p
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  detail.type,
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.admin === 'true'
                                                ? <Trans i18nKey="appproperties.text314" values={{ page_name: detail.entityName }}
                                                components={{ bold: <strong className='text-dark' /> }} />
                                                : <Trans i18nKey="appproperties.text315" values={{ page_name: detail.entityName }}
                                                components={{ bold: <strong className='text-dark' /> }} /> }

                                              {/* <strong>
                                                {' '}
                                                {detail.entityName}
                                              </strong> */}

                                            </p>
                                          </>
                                        ) : detail.type === 'group' ? (
                                          <>
                                            <IonRow
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.id,
                                                  'user',
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              {detail.fullName}
                                            </IonRow>
                                            <p
                                              className="fixed-textline"
                                              onClick={() =>
                                                profileClick(
                                                  detail.entityId,
                                                  detail.type,
                                                  detail.entityId
                                                )
                                              }
                                            >
                                              <Trans i18nKey="appproperties.text320" values={{ group_name: detail.entityName }}
 components={{ bold: <strong className='text-dark' /> }} />

                                              {/* <strong>
                                                {' '}
                                                {detail.entityName}
                                              </strong> */}
                                            </p>
                                          </>
                                        ) : (
                                          ''
                                        )}
                                      </IonRow>
                                    </div>
                                  </IonRow>
                                  <IonRow className="header-row-margin-left ion-align-items-center">
                                    {detail.type === 'company' ? (
                                      <IonButton
                                        className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnIgnore"
                                        size="small"
                                        onClick={() =>
                                          withdrawMobile(
                                            detail.full_name,
                                            'CANCEL',
                                            detail.requestId,
                                            detail.id,
                                            detail.type
                                          )
                                        }
                                      >
                                        {t('appproperties.text21')}
                                      </IonButton>
                                    ) : (
                                      <ButtonComponent
                                        btnClick={withdrawMobile}
                                        size="small"
                                        className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnIgnore"
                                        field1={detail.full_name}
                                        field2="CANCEL"
                                        field3={detail.requestId}
                                        field4={detail.id}
                                        field5={detail.type}
                                        name={t('appproperties.text21')}
                                        parametersPass={5}
                                      />
                                    )}
                                  </IonRow>
                                </>
                              )}
                            </IonRow>
                          ))}
                          <IonInfiniteScroll
                            onIonInfinite={loadData}
                            threshold="100px"
                            disabled={isInfiniteDisabled}
                          >
                            <IonInfiniteScrollContent
                              loadingSpinner="circular"
                              loadingText={t('appproperties.text215')}
                            ></IonInfiniteScrollContent>
                          </IonInfiniteScroll>
                        </IonContent>
                      ) : (
                        adminInvite.map((detail) => (
                          <IonRow className="ion-padding-start ion-bottom-padding-smallcom GroupInvitation-list-item">
                            {type === 'RECEIVED' ? (
                              <>
                                <IonRow className="w-70">
                                  <div className="myprofile-feeds ion-no-padding cursor-pointer">
                                    <IonAvatar
                                      className="MuiAvatar ion-margin-end"
                                      onClick={() =>
                                        profileClick(
                                          detail.id,
                                          detail.type,
                                          detail.entityId
                                        )
                                      }
                                    >
                                      {detail.type === 'user' ? (
                                        detail.logo === null ||
                                        detail.logo === '' ? (
                                          <img src={userProfile} />
                                            ) : (
                                          <img onError={(ev) => { ev.target.src = userProfile; }} src={detail.logo} />
                                            )
                                      ) : detail.type === 'company' ? (
                                        detail.logo === null ||
                                        detail.logo === '' ? (
                                          <img src={companyProfile} />
                                            ) : (
                                          <img onError={(ev) => { ev.target.src = companyProfile; }} src={detail.logo} />
                                            )
                                      ) : detail.type === 'page' ? (
                                        detail.logo === null ||
                                        detail.logo === '' ? (
                                          <img src={pageLogo} />
                                            ) : (
                                          <img onError={(ev) => { ev.target.src = pageLogo; }} src={detail.logo} />
                                            )
                                      ) : detail.type === 'group' ? (
                                        detail.logo === null ||
                                        detail.logo === '' ? (
                                          <img src={groupLogo} />
                                            ) : (
                                          <img onError={(ev) => { ev.target.src = groupLogo; }} src={detail.logo} />
                                            )
                                      ) : (
                                        ''
                                      )}
                                    </IonAvatar>
                                    <IonRow className="display-grid">
                                      {detail.type === 'user' ? (
                                        <>
                                          <IonRow
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                'user',
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.fullName}
                                          </IonRow>
                                          <span className="margin MuiTypography-caption group-model-text">
                                            {detail.title}
                                          </span>
                                          <span className="margin MuiTypography-caption group-model-text">
                                            <MutualConnectionRow id = {detail.id} name = {detail.fullName} key={detail.id}/>
                                            </span>
                                        </>
                                      ) : detail.type === 'company' ? (
                                        <>
                                          <IonRow
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                'user',
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.fullName}
                                          </IonRow>
                                          <p
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                detail.type,
                                                detail.entityId
                                              )
                                            }
                                          >
                                             {detail.admin === 'true'
                                               ? <Trans i18nKey="appproperties.text318" values={{ team_name: detail.entityName }}
                                               components={{ bold: <strong className='text-dark' /> }} />

                                               : <Trans i18nKey="appproperties.text319" values={{ team_name: detail.entityName }}
                                               components={{ bold: <strong className='text-dark' /> }} /> }
                                            {/* <strong>
                                              {' '}
                                              {detail.entityName}
                                            </strong> */}
                                          </p>
                                        </>
                                      ) : detail.type === 'page' ? (
                                        <>
                                          <IonRow
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                'user',
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.fullName}
                                          </IonRow>
                                          <p
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                detail.type,
                                                detail.entityId
                                              )
                                            }
                                          >
                                             {detail.admin === 'true'
                                               ? <Trans i18nKey="appproperties.text321" values={{ page_name: detail.entityName }}
                                               components={{ bold: <strong className='text-dark' /> }} />

                                               : <Trans i18nKey="pageproperties.text1" values={{ page_name: detail.entityName }}
                                               components={{ bold: <strong className='text-dark' /> }} /> }

                                            {/* <strong>
                                              {' '}
                                              {detail.entityName}
                                            </strong> */}
                                          </p>
                                        </>
                                      ) : detail.type === 'group' ? (
                                        <>
                                          <IonRow
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                'user',
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.fullName}
                                          </IonRow>
                                          <p
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.entityId,
                                                detail.type,
                                                detail.entityId
                                              )
                                            }
                                          >
                                            <Trans i18nKey="appproperties.text363" values={{ group_name: detail.entityName }}
 components={{ bold: <strong className='text-dark' /> }} />

                                            {/* <strong>
                                              {' '}
                                              {detail.entityName}
                                            </strong> */}
                                          </p>
                                        </>
                                      ) : (
                                        ''
                                      )}
                                    </IonRow>
                                  </div>
                                </IonRow>
                                <IonRow className="header-row-margin-left ion-align-items-center">
                                  {detail.type === 'company' ? (
                                    <>
                                      <IonButton
                                        className="category-btn-color cursor-pointer btn-sm-cn pe-0 btnIgnore"
                                        size="small"
                                        onClick={() =>
                                          actionBtnHandlerReceived(
                                            detail.id,
                                            'REJECT',
                                            detail.requestId,
                                            detail.type
                                          )
                                        }
                                      >
                                       {t('appproperties.text19')}
                                      </IonButton>
                                      <IonButton
                                        className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnAccept"
                                        size="small"
                                        onClick={() =>
                                          actionBtnHandlerReceived(
                                            detail.id,
                                            'ACCEPT',
                                            detail.requestId,
                                            detail.type
                                          )
                                        }
                                      >
                                        {t('appproperties.text20')}
                                      </IonButton>
                                    </>
                                  ) : (
                                    <>
                                      <ButtonComponent
                                        className="category-btn-color cursor-pointer btn-sm-cn pe-0 btnIgnore"
                                        btnClick={ignoreModelBox}
                                        field1={detail.id}
                                        field2="REJECT"
                                        field3={detail.requestId}
                                        field4={detail.type}
                                        name={t('appproperties.text19')}
                                        parametersPass={4}
                                      />
                                      <ButtonComponent
                                        className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnAccept"
                                        btnClick={actionBtnHandlerReceived}
                                        field1={detail.id}
                                        field2="ACCEPT"
                                        field3={detail.requestId}
                                        field4={detail.type}
                                        name={t('appproperties.text20')}
                                        parametersPass={4}
                                      />
                                    </>
                                  )}
                                </IonRow>
                              </>
                            ) : (
                              <>
                                <IonRow className="w-75">
                                  <div className="myprofile-feeds ion-no-padding cursor-pointer">
                                    <IonAvatar
                                      className="MuiAvatar ion-margin-end"
                                      onClick={() =>
                                        profileClick(
                                          detail.id,
                                          detail.type,
                                          detail.entityId
                                        )
                                      }
                                    >
                                      {detail.type === 'user' ? (
                                        detail.logo === null ||
                                        detail.logo === '' ? (
                                          <img src={userProfile} />
                                            ) : (
                                          <img onError={(ev) => { ev.target.src = userProfile; }} src={detail.logo} />
                                            )
                                      ) : detail.type === 'company' ? (
                                        detail.logo === null ||
                                        detail.logo === '' ? (
                                          <img src={companyProfile} />
                                            ) : (
                                          <img onError={(ev) => { ev.target.src = companyProfile; }} src={detail.logo} />
                                            )
                                      ) : detail.type === 'page' ? (
                                        detail.logo === null ||
                                        detail.logo === '' ? (
                                          <img src={pageLogo} />
                                            ) : (
                                          <img onError={(ev) => { ev.target.src = pageLogo; }} src={detail.logo} />
                                            )
                                      ) : (
                                        ''
                                      )}
                                    </IonAvatar>
                                    <IonRow className="display-grid">
                                      {detail.type === 'user' ? (
                                        <>
                                          <IonRow
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                'user',
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.fullName}
                                          </IonRow>
                                          <span className="margin MuiTypography-caption group-model-text">
                                            {detail.title}
                                          </span>
                                          <span className="margin MuiTypography-caption group-model-text">
                                            <MutualConnectionRow id = {detail.id} name = {detail.fullName} key={detail.id}/>
                                            </span>
                                        </>
                                      ) : detail.type === 'company' ? (
                                        <>
                                          <IonRow
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                'user',
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.fullName}
                                          </IonRow>
                                          <p
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                detail.type,
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.admin === 'true'
                                              ? <Trans i18nKey="appproperties.text316" values={{ team_name: detail.entityName }}
                                              components={{ bold: <strong className='text-dark' /> }} />

                                              : <Trans i18nKey="appproperties.text317" values={{ team_name: detail.entityName }}
                                                 components={{ bold: <strong className='text-dark' /> }} /> }
                                            {/* <strong>
                                              {' '}
                                              {detail.entityName}
                                            </strong> */}
                                          </p>
                                        </>
                                      ) : detail.type === 'page' ? (
                                        <>
                                          <IonRow
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                'user',
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.fullName}
                                          </IonRow>
                                          <p
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                detail.type,
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.admin === 'true'
                                              ? <Trans i18nKey="appproperties.text314" values={{ page_name: detail.entityName }}
                                                 components={{ bold: <strong className='text-dark' /> }} />
                                              : <Trans i18nKey="appproperties.text315" values={{ page_name: detail.entityName }}
                                              components={{ bold: <strong className='text-dark' /> }} /> }

                                            {/* <strong>
                                              {' '}
                                              {detail.entityName}
                                            </strong> */}

                                          </p>
                                        </>
                                      ) : detail.type === 'group' ? (
                                        <>
                                          <IonRow
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.id,
                                                'user',
                                                detail.entityId
                                              )
                                            }
                                          >
                                            {detail.fullName}
                                          </IonRow>
                                          <p
                                            className="fixed-textline"
                                            onClick={() =>
                                              profileClick(
                                                detail.entityId,
                                                detail.type,
                                                detail.entityId
                                              )
                                            }
                                          >
                                            <Trans i18nKey="appproperties.text320" values={{ group_name: detail.entityName }}
 components={{ bold: <strong className='text-dark' /> }} />

                                            {/* <strong>
                                              {' '}
                                              {detail.entityName}
                                            </strong> */}
                                          </p>
                                        </>
                                      ) : (
                                        ''
                                      )}
                                    </IonRow>
                                  </div>
                                </IonRow>
                                <IonRow className="header-row-margin-left ion-align-items-center">
                                  {detail.type === 'company' ? (
                                    <IonButton
                                      className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnIgnore"
                                      size="small"
                                      onClick={() =>
                                        withdrawMobile(
                                          detail.full_name,
                                          'CANCEL',
                                          detail.requestId,
                                          detail.id,
                                          detail.type
                                        )
                                      }
                                    >
                                      {t('appproperties.text21')}
                                    </IonButton>
                                  ) : (
                                    <ButtonComponent
                                      btnClick={withdrawMobile}
                                      size="small"
                                      className="btn-sm-cn ion-button-color ion-padding-end pe-0 ms-2 btnIgnore"
                                      field1={detail.full_name}
                                      field2="CANCEL"
                                      field3={detail.requestId}
                                      field4={detail.id}
                                      field5={detail.type}
                                      name={t('appproperties.text21')}
                                      parametersPass={5}
                                    />
                                  )}
                                </IonRow>
                              </>
                            )}
                          </IonRow>
                        ))
                      )}
                    </IonList>
                  ) : (
                    <IonRow className="w-100">
                      <p className="ion-padding-start ion-padding-top ion-padding-bottom">
                      {t('nodatafound.text15')}
                      </p>
                    </IonRow>
                  )}
                </IonRow>
              </IonCard>

              <ConnectionSuggestion
                connectionData={connectionData}
                header={t('appproperties.text27')}
                footer={t('appproperties.text28')}
                setConnectionData={setConnectionData}
                loading={loading}
                getconnectionList ={getconnectionList}
              />
            </IonCol>
          </div>
        </IonRow>
      </IonRow>
      <ConfirmModelCommon
        header={t('appproperties.text22')}
        message={confirmModelMsg}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text21')}
        confirmModel={confirmModel}
        setConfirmModel={setConfirmModel}
        deleteBtnHandler={actionBtnHandler}
        iD={userId}
        fromId={fromUserId}
        type={cType}
        requestType={requestType}
      />
      <IonModal id="confirm-modal" isOpen={confirmIgnoreModel} className="addCompany-modal report-modal" onDidDismiss={() => setConfirmIgnoreModel(false)}>
        <div className="report-spam-type">
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-align-items-center ion-justify-content-between">
            <div className="MuiTypography-h6 ms-lg-3 ms-1">
            {t('appproperties.text394')}
            </div>
            <IonButton fill="clear" onClick={() => setConfirmIgnoreModel(false)} className="close link-btn-tx ion-no-padding ion-no-margin pt-0">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0"
                slot="start"
                size="undefined" />
            </IonButton>
          </IonRow>
          <div className="modal-body">
            <IonRow className="MuiCardContent-root auth-form-width ion-padding-start ion-padding-end full-width-row">
              <IonCol size-md="12" size-xs="12" className="ion-no-padding">
                <IonLabel className='msg-text'>
                  {modelJsonData.modelMsg}
                </IonLabel>
              </IonCol>
            </IonRow>
          </div>
        </div>
        <IonFooter className="ion-no-border px-lg-3 pb-lg-3">
          <IonRow>
            <IonButton
              className="btn-secondry"
              size="small"
              onClick={() => {
                actionBtnHandlerReceived(modelJsonData.fromUserId,
                  modelJsonData.type,
                  modelJsonData.id,
                  modelJsonData.requestType);
                setConfirmIgnoreModel(false);
              }}
            >
              {t('appproperties.text241')}
            </IonButton>
            <IonButton
              className="ion-button-color ms-lg-2"
              size="small"
              onClick={() => setConfirmIgnoreModel(false)}
            >
              {t('appproperties.text242')}
            </IonButton>
          </IonRow>
        </IonFooter>
      </IonModal>
    </>
  );
};
export default NetworkPage;
