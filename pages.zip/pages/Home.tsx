/* eslint-disable react/jsx-key */
import {
  IonButton,
  IonCard,
  IonCol,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonList,
  IonModal,
  IonRow
} from '@ionic/react';
import React, { useEffect, useRef, useState } from 'react';
import ActivityCard from '../components/common/ActivityCard';
import AllFeeds from '../components/feed/AllFeeds';
import Post from '../components/feed/Post';
import ProfileDetails from '../components/feed/profile/ProfileDetails';
import CallFor from '../util/CallFor';
import screenshot1 from '../assets/img/1_Create_Company_splash.png';
import screenshot2 from '../assets/img/2_feed_splash.png';
import screenshot3 from '../assets/img/3_Create_Post_splash.png';
import screenshot4 from '../assets/img/4_product_list_splash.png';
import screenshot5 from '../assets/img/5_reaction_list_splash.png';
import screenshot6 from '../assets/img/6_page_list_splash.png';
import screenshot7 from '../assets/img/7_create_page_splash.png';
import screenshot8 from '../assets/img/8_Group_List_splash.png';
import screenshot9 from '../assets/img/9_Create_Group_Splash.png';
import screenshot10 from '../assets/img/10_team_member_list.png';
import screenshot11 from '../assets/img/11_Add_team_Member_splash.png';
import screenshot12 from '../assets/img/12_recommendation_splash.png';
import image from '../assets/img/group-profile-placeholder.png';
import ImageGallery, { ReactImageGalleryItem } from 'react-image-gallery';
import { close } from 'ionicons/icons';
import { useHistory } from 'react-router';
import { getlocalStore, setLocalStore } from '../util/Common';
import pageImg from '../assets/img/page-logo-default.png';
import MetaTags from 'react-meta-tags';
import Footer from '../components/Layout/Footer';
import SkeletonConnectionList from '../components/common/skeleton/SkeletonConnectionList';
import { useTranslation } from 'react-i18next';
import HeaderMenu from '../components/common/HeaderMenu';
import BannerSection from '../components/common/BannerSection';

const Home = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const refImg = useRef(null);
  const [imgIndex, setImgIndex] = useState(1);
  const photoGallery:
    | readonly ReactImageGalleryItem[]
    | { original: any; text: string }[] = [
      {
        original: screenshot1,
        text: t('appproperties.text284')
      },
      {
        original: screenshot2,
        text: t('appproperties.text285')
      },
      {
        original: screenshot3,
        text: t('appproperties.text286')
      },
      {
        original: screenshot4,
        text: t('appproperties.text287')
      },
      {
        original: screenshot5,
        text: t('appproperties.text288')
      },
      {
        original: screenshot6,
        text: t('appproperties.text289')
      },
      {
        original: screenshot7,
        text: t('pageproperties.text3')
      },
      {
        original: screenshot8,
        text: t('appproperties.text290')
      },
      {
        original: screenshot9,
        text: t('groupproperties.text1')
      },
      {
        original: screenshot10,
        text: t('appproperties.text291')
      },
      {
        original: screenshot11,
        text: t('teamproperties.text2')
      },
      {
        original: screenshot12,
        text:t('signuprecommendation.text6')
      }
    ];
  const [groups, setGroupsDetails] = useState([]);

  useEffect(() => {
    if (getlocalStore('showHomeModel') === null) {
      setLocalStore('showHomeModel', true);
      setShowModal(true);
    }
    getGroupsDetails();
    getPageDetails();
    gethashTagsDetails();
  }, []);
  const getGroupsDetails = async() => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/groups/list/ADMIN',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      // setShowModal(true);
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setGroupsDetails(json1Response.data.content);
      }
    } else if (response.status === 401) {
      // setShowModal(false);
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };

  const [pages, setPageDetails] = useState([]);
  const getPageDetails = async() => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/pages/list',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setPageDetails(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const [hashTags, setHashTags] = useState([]);
  const gethashTagsDetails = async() => {
    setLoading(true);
    const response = await CallFor(
      'api/v1/hashTags',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setHashTags(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };

  const handleStepChange = () => {
    setImgIndex(refImg.current.getCurrentIndex());
  };
  const closeHomeModal = () => {
    setLocalStore('showHomeModel', false);
    setShowModal(false);
  };
  return (
    <>
    <MetaTags>
      <title>
       Zyapaar
      </title>
    </MetaTags>
      <IonRow className="plane-bg">
       <IonRow className="container">
          <div className="row full-width-row main-page-content-row">
            <IonCol
             size-lg="4"
             size-md="12"
              size-xs="12"
              className="left-col col-mobile-none ion-no-padding"
            >
               <div className='sidebar-main'>
              <ProfileDetails />
              <ActivityCard
                // header="Pages"
                headerLinkLable={t('appproperties.text18')}
                headerLink="/page"
                mapData={pages}
                image={pageImg}
                fieldLink="/pageDetails/"
                className="sidebar-pages pages-scroll"
                noDataFound={t('nodatafound.text27')}
                loading={loading}
              />
              <ActivityCard
                // header="Groups"
                headerLinkLable={t('appproperties.text35')}
                headerLink="groups"
                mapData={groups}
                image={image}
                fieldLink="/groups/"
                className="sidebar-group pages-scroll"
                noDataFound={t('nodatafound.text19')}
                loading={loading}
              />
              <IonCard className='sdb-box profile-details left-cards no-shadow Sidebar-hashtag ion-padding-bottom pages-scroll'>
                <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between">
                  <p className="ion-align-self-start">{t('appproperties.text81')}</p>
                </IonHeader>
                <IonList className='with-sb-box'>
                {loading
                  ? <SkeletonConnectionList column='3'/>
                  : hashTags.length > 0
                    ? <>
                {hashTags.map((hashtags) => (
                  <IonRow>
                    <IonRow className='display-grid hashTagAtivityCard ion-padding-start ion-padding-top'>#{hashtags.key}</IonRow>
                  </IonRow>
                ))}</>
                    : <p className='ion-padding'>{t('nodatafound.text9')}</p>}
                    </IonList>
              </IonCard>
              <Footer/>
              </div>
            </IonCol>
            <IonCol size-lg="8" size-md="12" size-xs="12" className="right-col">
              {/* Header menu */}
              <HeaderMenu></HeaderMenu>

              {/* Feed banner section */}
              <BannerSection></BannerSection>

              <Post origin="USER" originId={0}/>
              <AllFeeds />
            </IonCol>
          </div>
        </IonRow>
      </IonRow>
      <IonModal isOpen={showModal} cssClass="add-award-model" onDidDismiss={() => closeHomeModal()}>
        <IonContent>
          <IonRow className="full-width-row ion-padding-top ion-padding-bottom">
            <IonButton
              fill="clear"
              className="ion-activatable header-row-margin-left"
              onClick={closeHomeModal}
            >
              <IonIcon
                icon={close}
                className="ion-button-color"
                slot="start"
                size="undefined"
              />
            </IonButton>
          </IonRow>
          <IonRow className="overview-heigth">
            <ImageGallery
              items={photoGallery}
              ref={refImg}
              showPlayButton={false}
              autoPlay={true}
              onSlide={handleStepChange}
            />
          </IonRow>
        </IonContent>
        <IonFooter className='feedModal'>
          <IonRow className="ion-padding ion-justify-content-center">
            <h4 className="font-color">{photoGallery[imgIndex].text}</h4>
          </IonRow>
        </IonFooter>
      </IonModal>
    </>
  );
};
export default Home;
