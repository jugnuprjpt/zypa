/* eslint-disable multiline-ternary */
import { IonButton, IonCard, IonCol, IonContent, IonIcon, IonInfiniteScroll, IonInfiniteScrollContent, IonItem, IonList, IonRow, useIonPopover } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import Post from '../components/feed/Post';
import 'swiper/swiper-bundle.min.css';
import 'swiper/swiper.min.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import PageDetails from '../components/myPage/PageDetails';
import PageAbout from '../components/myPage/PageaAbout';
import PageFollowers from '../components/myPage/PageFollowers';
import CallFor from '../util/CallFor';
import image from '../assets/img/page-logo-default.png';
import { useHistory, useParams } from 'react-router';
import FeedCard from '../components/common/FeedCard';
import { useDispatch, useSelector } from 'react-redux';
import { getFeedData } from '../Redux/reducers/feeds';
import CommonCard from '../components/common/CommonCard';
import { arrowBack } from 'ionicons/icons';
import { Link } from 'react-router-dom';
import Footer from '../components/Layout/Footer';
import SkeletonFeedComon from '../components/common/skeleton/SkeletonFeedComon';
import { Device } from '@capacitor/device';
import { isAndroid, isIOS } from 'react-device-detect';
import PageAnalystics from '../components/myPage/PageAnalytics';
import ConfirmModelCommon from '../components/common/ConfirmModelCommon';
import ToastCommon from '../components/common/ToastCommon';
import { useTranslation } from 'react-i18next';

const MyPageDetails = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const { pageId } = useParams();
  const [pageAbout, setPageAbout] = useState();
  const getFeedDatas = useSelector(getFeedData);
  const [activeBtnClass, setActiveBtnClass] = useState('ion-button-color');
  const [aboutBtnClass, setAbouteBtnClass] = useState('category-btn-color');
  const [followersBtnClass, setFollowersBtnClass] = useState('category-btn-color');
  const [analysticsBtnClass, setAnalysticsBtnClass] = useState('category-btn-color');
  const [categoryState, setCategoryState] = useState('POST');
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [pId, setpId] = useState(pageId);
  const [page, setPageDetails] = useState([]);
  const [count, setCount] = useState(0);
  const [classMobile, setClassMobile] = useState(true);
  const [loading, setLoading] = useState(false);
  const [feedloading, setFeedLoading] = useState(false);
  const deviceDetails = Device.getInfo();
  const [loadComponent, setLoadComponent] = useState(false);
  const [reportHideState, setReportHideState] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const getAllCategoryData = (category: any) => {
    if (category === 'POST') {
      setActiveBtnClass('ion-button-color');
      setAbouteBtnClass('category-btn-color');
      setFollowersBtnClass('category-btn-color');
      setAnalysticsBtnClass('category-btn-color');
    } else if (category === 'ABOUT') {
      setActiveBtnClass('category-btn-color');
      setAbouteBtnClass('ion-button-color');
      setFollowersBtnClass('category-btn-color');
      setAnalysticsBtnClass('category-btn-color');
    } else if (category === 'FOLLOWERS') {
      setActiveBtnClass('category-btn-color');
      setAbouteBtnClass('category-btn-color');
      setFollowersBtnClass('ion-button-color');
      setAnalysticsBtnClass('category-btn-color');
    } else if (category === 'ANALYTICS') {
      setActiveBtnClass('category-btn-color');
      setAbouteBtnClass('category-btn-color');
      setFollowersBtnClass('category-btn-color');
      setAnalysticsBtnClass('ion-button-color');
    }
    setCategoryState(category);
  };
  const history = useHistory();
  const [pageList, setaPageList] = useState([]);
  useEffect(() => {
    getPageList();
    dispatch({
      type: 'add_feedsData',
      Feeds: []
    });
    if (isAndroid || isIOS) {
      setLoadComponent(true);
    }
  }, []);
  const getPageList = async () => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/pages/list',
      'POST',
      '{"page": 0 }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        setaPageList(json1Response.data.content);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const getAllFeedData = async (paramPageId) => {
    setFeedLoading(true);
    setInfiniteDisabled(false);
    const allFeedDataResponse = await CallFor('api/v1/feed/PAGE/' + paramPageId,
      'PATCH',
      '{"page": 0 }',
      'Auth'
    );
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      if (json1Response.data.content.length > 0) {
        dispatch({
          type: 'add_feedsData',
          Feeds: json1Response.data.content
        });
      } else {
        dispatch({
          type: 'add_feedsData',
          Feeds: []
        });
      }
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setCount(1);
    setFeedLoading(false);
  };
  const scrollData = async () => {
    const allFeedDataResponse = await CallFor('api/v1/feed/PAGE/' + pId,
      'PATCH',
      '{"page": ' + count + ' }',
      'Auth'
    );
    if (allFeedDataResponse.status === 200) {
      const json1Response = await allFeedDataResponse.json();
      if (json1Response.data.content.length > 0) {
        json1Response.data.content.map((details) => {
          dispatch({
            type: 'add_feedsData_new',
            Feeds: details
          });
        });
      } else {
        setInfiniteDisabled(true);
      }
    } else if (allFeedDataResponse.status === 401) {
      localStorage.clear();
      history.push('/login');
    } else {
      dispatch({
        type: 'add_feedsData',
        Feeds: []
      });
    }
  };
  const getPageDetail = async (paramPageId) => {
    setLoading(true);
    dispatch({
      type: 'add_feedsData',
      Feeds: []
    });
    const response = await CallFor(
      'api/v1.1/pages/' + paramPageId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      setPageDetails(json1Response.data);
      setPageAbout(json1Response.data);
      if (json1Response.data !== undefined && (json1Response.data.status === 'inviate' || json1Response.data.status === 'default')) {
        getAllCategoryData('ABOUT');
      }
      getAllFeedData(paramPageId);
      setReportHideState(false);
    } else if (response.status === 404) {
      setPageDetails({ isDeleted: true });
    }
    setLoading(false);
  };
  const loadData = (ev: any) => {
    setCount(count + 1);
    setTimeout(() => {
      scrollData();
      ev.target.complete();
    }, 500);
  };
  if (classMobile) {
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  } else {
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  }
  const encodedString = (str) => {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (match, p1) {
      return String.fromCharCode(parseInt(p1, 16));
    }));
  };
  const encodedCompanyName = encodedString(page.name);
  const [leaveAdminConfirmationModal, setLeaveAdminConfirmationModal] = useState(false);
  const PopoverList: React.FC<{
    onHide: () => void;
  }> = ({ onHide }) => (
    <>
      <IonList className="my-account-pr">
        <IonItem
          lines="none"
          className="cursor-pointer"
          onClick={() => {
            onHide();
            history.push('/pageInvite/' + pageId + '/' + encodedCompanyName.replace('/', '&quot;'));
          }}
        >
          {t('appproperties.text195')}
        </IonItem>
      </IonList>
      {!page.isOwner
        ? <IonList className="my-account-pr">
          <IonItem
            lines="none"
            className="cursor-pointer"
            onClick={() => {
              onHide();
              setLeaveAdminConfirmationModal(true);
            }}
          >
            {t('appproperties.text293')}
          </IonItem>
        </IonList>
        : ''}
    </>
  );
  const [present, dismiss] = useIonPopover(PopoverList, { onHide: () => dismiss() });
  const openThreeDot = (e) => {
    present({ event: e.nativeEvent });
  };
  const leaveAdmin = async () => {
    const response = await CallFor(
      'api/v1.1/pages/' + pageId + '/leave/admin',
      'POST',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast12'));
      setShowToast(true);
      getPageDetail(pId);
    } else if (response.status === 400) {
      const json1Response = await response.json();
      console.log(json1Response);
      // setPageDetails({ isDeleted: true });
    }
  };
  return (
    <IonRow className="plane-bg">
      <IonRow className="container">
        <div className='showpage row full-width-row main-page-content-row'>
          <IonCol size-lg="4" size-md="12" size-xs="12" className="left-col ion-no-padding dn-mobile ">
            <div className='sidebar-main group-bottom-border'>
              <CommonCard
                headerLinkLable={t('appproperties.text325')}
                headerLink="/page"
                fieldLink='/pageDetails/'
                mapData={pageList}
                image={image}
                className="sidebar-pages  group-border pages-scroll"
                setId={setpId}
                btnHandler={getPageDetail}
                btnHandler2={getAllCategoryData}
                param1='POST'
                setClassMobile={setClassMobile}
                loading={loading}
                paramId={pageId}
              />
              <Footer />
            </div>
          </IonCol>
          <IonCol size-md="12" size-lg="8" size-xs="12" className="right-col ion-no-padding ion-padding-top ">
            <IonContent className='mobile-overlay-screen show-mobile activity-content-card-div back-screen-mobile'>
              <div className='mobile-back-screen show-mobile back-icon-mobile'>
                <Link to="/page"><IonIcon className='icon-mobile' icon={arrowBack}></IonIcon></Link>
              </div>
              <PageDetails setPageDetails={setPageDetails}
                pageId={pId}
                page={page}
                getPageDetail={getPageDetail} getPageList={getPageList} loading={loading} setReportHideState={setReportHideState} reportHideState={reportHideState} />
              {!reportHideState ? page.isHide !== true
                ? <IonRow className='gup-btn-action ion-margin-top px-2 px-lg-0 company-capsule-btn bg-white'>
                  {deviceDetails.platform === 'ios' || deviceDetails.platform === 'android'
                    ? <>
                      <Swiper id="ka-swiper2"
                        pagination={{
                          clickable: true
                        }}
                        className="mySwiper full-width-row"
                        autoHeight={false}
                        slidesPerView='auto'
                        breakpoints={{
                          // when window width is >= 640px
                          360: {
                            width: 360,
                            slidesPerView: 2
                          },
                          // when window width is >= 768px
                          768: {
                            width: 768,
                            slidesPerView: 4
                          }
                        }}
                      >
                        {pageAbout !== undefined && pageAbout.status === 'accept'
                          ? <SwiperSlide className="swiper-slide-btn">
                            <IonButton className={activeBtnClass} shape='round' size='small' onClick={() => getAllCategoryData('POST')}>
                              {t('appproperties.text73')}
                            </IonButton>
                          </SwiperSlide>
                          : ''}
                        {pageAbout !== undefined
                          ? <SwiperSlide className="swiper-slide-btn">
                            <IonButton className={aboutBtnClass} shape='round' size='small' onClick={() => getAllCategoryData('ABOUT')}>
                              {t('commonproperties.text17')}
                            </IonButton></SwiperSlide>
                          : ''}
                        {pageAbout !== undefined && pageAbout.status === 'accept'
                          ? <SwiperSlide className="swiper-slide-btn">
                            <IonButton className={followersBtnClass} shape='round' size='small' onClick={() => getAllCategoryData('FOLLOWERS')}>
                              {t('commonproperties.text38')}
                            </IonButton></SwiperSlide>
                          : ''}
                        {pageAbout !== undefined && pageAbout.status === 'accept' && page.isAdmin === true
                          ? <SwiperSlide className="swiper-slide-btn">
                            <IonButton className={analysticsBtnClass} shape='round' size='small' onClick={() => getAllCategoryData('ANALYTICS')}>
                              {t('appproperties.text252')}
                            </IonButton></SwiperSlide>
                          : ''}
                      </Swiper>
                    </>
                    : <>
                      {pageAbout !== undefined && pageAbout.status === 'accept'
                        ? <IonButton className={activeBtnClass} shape='round' size='small' onClick={() => getAllCategoryData('POST')}>
                          {t('appproperties.text73')}
                        </IonButton>
                        : ''}
                      {pageAbout !== undefined
                        ? <IonButton className={aboutBtnClass} shape='round' size='small' onClick={() => getAllCategoryData('ABOUT')}>
                          {t('commonproperties.text17')}
                        </IonButton>
                        : ''}
                      {pageAbout !== undefined && pageAbout.status === 'accept'
                        ? <IonButton className={followersBtnClass} shape='round' size='small' onClick={() => getAllCategoryData('FOLLOWERS')}>
                          {t('commonproperties.text38')}
                        </IonButton>
                        : ''}
                      {pageAbout !== undefined && pageAbout.status === 'accept' && page.isAdmin === true
                        ? <IonButton className={analysticsBtnClass} shape='round' size='small' onClick={() => getAllCategoryData('ANALYTICS')}>
                          {t('appproperties.text252')}
                        </IonButton>
                        : ''}
                      {pageAbout !== undefined && pageAbout.status === 'accept' && page.isAdmin === true
                        ? <IonButton size='small' className=" mergAdmin ion-button-color category-btn-color" onClick={openThreeDot} >{t('teamproperties.text3')}</IonButton>
                        : ''
                      }
                    </>
                  }
                </IonRow>
                : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                  {t('appproperties.text296')}
                </p> : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                {t('appproperties.text296')}
              </p>}
              {!reportHideState ? page.isHide !== true
                ? <>
                  {loadComponent
                    ? <>
                      {(() => {
                        if (categoryState === 'POST') {
                          if (pageAbout !== undefined && pageAbout.status !== 'accept') {
                            getAllCategoryData('ABOUT');
                          }
                          return (
                            <>
                              {pageAbout !== undefined && pageAbout.isAdmin === true ? <div className='mt-n2'><Post origin="PAGE" originId={pageAbout.id} /></div> : ''}
                              {pageAbout !== undefined && pageAbout.status === 'accept'
                                ? <>
                                  <div className='mb-5 pb-4 mb-lg-0 pb-lg-0'>
                                    {feedloading
                                      ? <SkeletonFeedComon column={5} />
                                      : getFeedDatas.length > 0
                                        ? Object.entries(getFeedDatas).map(([feedKey, feeds]) => (
                                          <>
                                            <FeedCard feeds={feeds} feedKey={feedKey} origin='PAGE' originId={pageAbout.id} />
                                          </>
                                        ))
                                        : (
                                          <>
                                            <IonCard className='ion-padding ion-no-margin ion-margin-bottom ion-margin-top'>
                                              {t('nodatafound.text33')}                        </IonCard>
                                          </>
                                        )}
                                  </div>
                                  <IonInfiniteScroll
                                    onIonInfinite={loadData}
                                    threshold="100px"
                                    disabled={isInfiniteDisabled}
                                  >
                                    <IonInfiniteScrollContent
                                      loadingSpinner="circular"
                                      loadingText={t('appproperties.text215')}
                                    ></IonInfiniteScrollContent>
                                  </IonInfiniteScroll>
                                </>
                                : ''
                              }
                            </>
                          );
                        } else if (categoryState === 'ABOUT') {
                          return (
                            <div className='mt-n3'><PageAbout pageAbout={pageAbout} /></div>
                          );
                        } else if (categoryState === 'FOLLOWERS') {
                          return (
                            <div className='mt-n3'><PageFollowers /></div>
                          );
                        } else if (categoryState === 'ANALYTICS') {
                          return (
                            <div className='mt-n3'><PageAnalystics /></div>
                          );
                        }
                      })()}
                    </>
                    : ''}
                </>
                : '' : ''}
            </IonContent>
          </IonCol>
        </div>
      </IonRow>

      <ConfirmModelCommon
        header={t('appproperties.text293')}
        message={t('appproperties.text386')}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text247')}
        confirmModel={leaveAdminConfirmationModal}
        setConfirmModel={setLeaveAdminConfirmationModal}
        deleteBtnHandler={leaveAdmin}
      />
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
    </IonRow>
  );
};
export default MyPageDetails;
