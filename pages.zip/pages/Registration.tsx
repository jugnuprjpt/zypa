/* eslint-disable no-unused-vars */
/* eslint-disable array-callback-return */
import {
  IonAvatar,
  IonButton,
  IonCard,
  IonCardTitle,
  IonCol,
  IonContent,
  IonIcon,
  IonInput,
  IonLabel,
  IonModal,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonTextarea,
  IonToast
} from '@ionic/react';
import AsyncSelect from 'react-select/async';
import React, { useEffect, useState } from 'react';
import CallFor from '../util/CallFor';
import { Controller, useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import ReactLoading from 'react-loading';
import userProfile from '../assets/img/user-profile-placeholder.png';
import { getlocalStore, setLocalStore, setUserSession } from '../util/Common';
import { useHistory } from 'react-router';
import { close, informationCircle, trashBinOutline } from 'ionicons/icons';
import Select from 'react-select';
import MetaTags from 'react-meta-tags';
import edit from '../assets/img/edit.svg';
import helptool from '../assets/img/help.svg';
import PopoverCommon from '../components/common/PopoverCommon';
import ToastCommon from '../components/common/ToastCommon';
import { defaultStyles } from 'react-select/dist/declarations/src/styles';
import GetRegisteredId from '../components/common/pushNotification/GetRegisteredId';
import { Device } from '@capacitor/device';
import { useTranslation } from 'react-i18next';
import { t } from 'i18next';

const customStyles = {
  control: (provided: any) => ({
    ...provided,
    minHeight: 50,
    zIndex: 9999,
    fontSize: '14px',
    background: '#fff !important',
    '&:focus': {
      border: '1px solid #d8d8d8'
    }
  }),
  multiValue: (styles, { data }) => {
    return {
      ...styles,
      padding: 4,
      backgroundColor: '#0073ae !important',
      borderRadius: '50px'
    };
  },
  multiValueLabel: (styles, { data }) => ({
    ...styles,
    color: '#fff'
  }),
  multiValueRemove: (styles, { data }) => ({
    ...styles,
    color: '#0073ae !important',
    borderRadius: '50px',
    margin: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    ':hover': {
      backgroundColor: '#fff'
    }
  }),
  indicatorSeparator: () => {}, // removes the "stick"
  dropdownIndicator: (defaultStyles: any) => ({
    ...defaultStyles,
    '& svg': { display: 'none' }
  })
};

const Registration = () => {
  const { t } = useTranslation();
  const identity = [
    {
      value: 'GSTIN',
      label: 'GSTIN'
    },
    {
      value: 'PAN',
      label: t('dropdownfields.text3')
    },
    {
      value: 'UDYOG_ADHAR',
      label: t('dropdownfields.text4')
    },
    {
      value: 'UDYAM_ADHAR',
      label: t('dropdownfields.text5')
    }
  ];
  
  const firmType = [
    {
      value: 'PROPRIETORSHIP',
      label: t('dropdownfields.text15')
    },
    {
      value: 'PARTNERSHIP_LLP',
      label: t('dropdownfields.text16')
    },
    {
      value: 'PUBLIC_LIMITED_COMPANY',
      label: t('dropdownfields.text17')
    },
    {
      value: 'PVT_LIMITED_COMPANY',
      label: t('dropdownfields.text18')
    },
    {
      value: 'TRUST',
      label: t('dropdownfields.text19')
    },
    {
      value: 'SOCIETIES',
      label: t('dropdownfields.text20')
    },
    {
      value: 'ASSOCIATIONS_CLUB',
      label: t('dropdownfields.text21')
    },
    {
      value: 'BANK_FINANCIAL_INSTITUTATION',
      label: t('dropdownfields.text22')
    },
    {
      value: 'EDUCATION_INSTUATION',
      label: t('dropdownfields.text23')
    },
    {
      value: 'GOVERNMENT_PUBLIC_SECTOR_Undertaking',
      label: t('dropdownfields.text24')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];
  
  const businessType = [
    {
      value: 'MANUFACTURING',
      label: t('dropdownfields.text7')
    },
    {
      value: 'TRADER',
      label: t('dropdownfields.text8')
    },
    {
      value: 'SERVICE_PROVIDER',
      label: t('dropdownfields.text9')
    },
    {
      value: 'WORKS_CONTRACT',
      label: t('dropdownfields.text10')
    },
    {
      value: 'FREELANCER',
      label: t('dropdownfields.text11')
    },
    {
      value: 'NON_PROFIT_ORGANIZATION',
      label: t('dropdownfields.text12')
    },
    {
      value: 'OTHERS',
      label: t('dropdownfields.text13')
    }
  ];
  const [companyModel, setCompanyModel] = useState(false);
  const [file, setFile] = useState('');
  const [companyFile, setCompanyFile] = useState('');
  const [stateCombo, setstate] = useState([]);
  const [buySelectedValue, setBuySelectedValue] = useState([]);
  const [loading, setLoading] = useState(false);
  const [verify, setVerify] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [imageView, setImageView] = useState(false);
  const [comapnyImageView, setComapnyImageView] = useState(false);
  const [characterCount, setCharacterCount] = useState(0);
  const maxCount = 500;
  const [diviceInfo, setDeviceInfo] = useState();
  const [userFormState, setUserFormState] = useState({
    mobileNo: getlocalStore('mobileNo')
  });
  // const buttonRef = useRef();
  const [formState, setformState] = useState({
    userMobile: getlocalStore('mobileNo'),
    email: '',
    contactNo2: null,
    designation: '',
    comments: '',
    contactNo1: null,
    addressLine2: ''
  });
  const [disabled, setdisabled] = useState(true);
  const history = useHistory();
  const [saveDisabled, setSaveDisabled] = useState(false);
  const [isValid, setIsValid] = useState(true);
  const userformDataChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.value !== undefined) {
      if (event.target.value.length > 0) {
        event.target.className =
          'input-box sc-ion-input-md-h sc-ion-input-md-s md hydrated input-fill';
        // $(this).parent().addClass('color');
      } else {
        event.target.className =
          'input-box sc-ion-input-md-h sc-ion-input-md-s md hydrated';
        // $(this).parent().removeClass('color');
      }
    }
    setUserFormState({
      ...userFormState,
      [event.target.name]: event.target.value
    });
  };
  const formDataChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value !== null && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setformState({ ...formState, [event.target.name]: event.target.value });
    }
  };
  const stateDataChangeHandler = (event) => {
    if (event !== null && event.value !== undefined) {
      setformState({ ...formState, stateId: event.value });
    } else {
      setformState({ ...formState, stateId: null });
    }
  };
  const validationSchema = Yup.object().shape({
    firstName: Yup.string().trim()
      .required(t('commonproperties.text10'))
      .matches(/^[A-Za-z-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text14'),
        (val) => val && val.toString().length <= 50
      ),
    lastName: Yup.string().trim()
      .required(t('commonproperties.text11'))
      .matches(/^[A-Za-z-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text14'),
        (val) => val && val.toString().length <= 50
      ),
    emailId: Yup.string().trim().email(t('commonproperties.text9')),
    // identityType: Yup.string().required('Identity type is required'),
    identityNumber: Yup.string().trim()
      .required(t('companyproperties.text28'))
      .when('identityType', {
        is: 'GSTIN',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1}/, t('companyproperties.text29'))
          .test(
            'len',
            t('companyproperties.text29'),
            (val) => val && val.toString().length >= 15
          )
          .test(
            'len',
            t('companyproperties.text29'),
            (val) => val && val.toString().length <= 15
          )
      })
      .when('identityType', {
        is: 'UDYOG_ADHAR',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[a-zA-Z]{2}[0-9]{2}[a-zA-Z][0-9]{7}/, t('companyproperties.text30'))
          .test(
            'len',
            t('companyproperties.text30'),
            (val) => val && val.toString().length >= 12
          )
          .test(
            'len',
            t('companyproperties.text30'),
            (val) => val && val.toString().length <= 12
          )
      })
      .when('identityType', {
        is: 'UDYAM_ADHAR',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[Uu]{1}[Dd]{1}[Yy]{1}[Aa]{1}[Mm]{1}[-][A-Za-z]{2}[-][0-9]{2}[-][0-9]{7}/, t('companyproperties.text31'))
          .test(
            'len',
            t('companyproperties.text31'),
            (val) => val && val.toString().length >= 19
          )
          .test(
            'len',
            t('companyproperties.text31'),
            (val) => val && val.toString().length <= 19
          )
      })
      .when('identityType', {
        is: 'PAN',
        then: Yup.string()
          .required(t('companyproperties.text28'))
          .matches(/[a-zA-Z]{3}[pcftghlabjPCFTGHLABJ]{1}[a-zA-Z]{1}[0-9]{4}[a-zA-Z]{1}/, t('companyproperties.text32'))
          .test(
            'len',
            t('companyproperties.text32'),
            (val) => val && val.toString().length >= 10
          )
          .test(
            'len',
            t('companyproperties.text32'),
            (val) => val && val.toString().length <= 10
          )
      }),

    name: Yup.string().trim()
      .required(t('commonproperties.text24'))
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text22'),
        (val) => val && val.toString().length <= 200
      ),
    // industryTypeText: Yup.string().required('Entity type is required'),
    // businessTypeText: Yup.string().required('{t('dropdownfields.text6')} is required'),
    addressLine1: Yup.string().trim()
      .required(t('companyproperties.text16'))
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length <= 150
      ),
    email: Yup.string().trim().email(t('commonproperties.text9')),
    contactNo1: Yup.string().nullable(true).optional().notRequired()
      .test('typeError',
        'Landline must be a number',
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return Number(val);
          } else {
            return true;
          }
        })
      .test(
        'len',
        ',
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().length >= 6;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('companyproperties.text19'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().length <= 10;
          } else {
            return true;
          }
        }
      ),
    contactNo2: Yup.string().optional().nullable()
      .test('typeError',
      t('commonproperties.text23'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return Number(val);
          } else {
            return true;
          }
        })
      .test(
        'len',
        t('commonproperties.text12'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().length >= 10;
          } else {
            return true;
          }
        }
      )
      .test(
        'len',
        t('commonproperties.text12'),
        (val) => {
          if (val !== null && val !== '' && val !== undefined) {
            return val && val.toString().length <= 10;
          } else {
            return true;
          }
        }
      ),
    firmPincode: Yup.string()
      .required(t('companyproperties.text20'))
      .test('typeError',
        t('companyproperties.text21'),
        (val) => Number(val))
      .test(
        'len',
        t('companyproperties.text21')
        ,
        (val) => val && val.toString().length === 6
      ),
    designation: Yup.string().trim()
      .required(t('companyproperties.text22'))
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('companyproperties.text17'),
        (val) => val && val.toString().length <= 150
      ),
    city: Yup.string().trim()
      .required(t('companyproperties.text23'))
      .matches(/^[A-Za-z-&-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('userproperties.text15'),
        (val) => val && val.toString().length <= 100
      ),
    about: Yup.string().trim()
      .required(t('companyproperties.text26'))
      .test(
        'len',
        t('companyproperties.text27'),
        (val) => val && val.toString().length >= 10
      )
      .test(
        'len',
        t('companyproperties.text27'),
        (val) => val && val.toString().length <= 500
      ),
    sales: Yup.array()
      .min(1, t('commonproperties.text36'))
      .of(
        Yup.object().shape({
          label: Yup.string().required(),
          value: Yup.string().required()
        })
      ).nullable()
      .required(t('commonproperties.text36'))
  });

  const buyHandleChange = (e) => {
    setBuySelectedValue(Array.isArray(e) ? e.map((x) => x.value) : []);
  };

  useEffect(async() => {
    setDeviceInfo(await Device.getInfo());
    comboData(101);
  }, []);
  const comboData = async(companyId: string | number) => {
    const response = await CallFor(
      'api/v1.1/states/' + companyId,
      'GET',
      null,
      'registrationWithAuth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      const states = await json1Response.data.map(
        (d: { id: any; name: any }) => ({
          value: d.id,
          label: d.name
        })
      );
      setstate(states);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const stateupdate = (data: React.SetStateAction<{}>) => {
    const companyData = {};
    // companyData.address = data.address;
    if (data.address !== null && data.address !== '') {
      if (data.address.addressLine1 !== null && data.address.addressLine1 !== '') {
        companyData.addressLine1 = data.address.addressLine1;
        setValue('addressLine1', data.address.addressLine1);
      }
      if (data.address.addressLine2 !== null && data.address.addressLine2 !== '') {
        companyData.addressLine2 = data.address.addressLine2;
        setValue('addressLine2', data.address.addressLine2);
      }
      if (data.address.pincode !== null && data.address.pincode !== '') {
        companyData.pincode = data.address.pincode;
        setValue('pincode', data.address.pincode);
      }
    }
    if (data.companyName !== null) {
      companyData.name = data.companyName;
      setValue('name', data.companyName);
      setformState({ ...formState, ...companyData });
    }
    setformState({ ...formState, ...companyData });
    const userData = {};
    if (data.firstName !== '' || data.lastName !== '') {
      if (data.firstName !== '' && data.firstName !== null) {
        userData.firstName = data.firstName;
        setValue('firstName', data.firstName);
      }
      if (data.lastName !== '' && data.lastName !== null) {
        userData.lastName = data.lastName;
        setValue('lastName', data.lastName);
      }
      setUserFormState({ ...userFormState, ...userData });
    }
  };

  const verifybtn = async() => {
    const identityType = formState.identityType;
    const identityNumber = formState.identityNumber.toUpperCase();
    if (identityType !== undefined && identityNumber !== undefined) {
      setLoading(true);
      const response = await CallFor(
        'api/v1/verify/identity',
        'POST',
        '{"identity":"' +
          identityType +
          '","identityNumber":"' +
          identityNumber.toUpperCase() +
          '"}',
        'registrationWithAuth'
      );
      if (response.status === 200) {
        setVerify(!verify);
        setLoading(false);
        setdisabled(true);
        // const jsonResponse = await response.json();
        // stateupdate(jsonResponse.data);
      } else if (response.status === 400) {
        setLoading(false);
        // setCompanyModel(true);
        const jsonResponse = await response.json();
        if (jsonResponse.error.errors !== null) {
          if (jsonResponse.error.errors[0].field === 'identityNumber') {
            if (
              jsonResponse.error.errors[0].message ===
              'Company is Already registered with us'
            ) {
              if (userFormState.firstName !== undefined && userFormState.lastName !== undefined && userFormState.firstName !== '' && userFormState.lastName !== '') {
                setVerify(!verify);
                setdisabled(true);
                setCompanyModel(true);
                setError(jsonResponse.error.errors[0].field, {
                  message: jsonResponse.error.errors[0].message
                });
              } else {
                setError('identityNumber', {
                  message: 'Enter your first & last name to proceed further'
                });
              }
            }
          }
        } else {
          setVerify(verify);
          setError('identityNumber', {
            message: jsonResponse.error.message
          });
        }
      } else if (response.status === 401) {
        localStorage.clear();
        history.push('/login');
      } else {
        setLoading(false);
      }
    } else {
      alert('Please select identity type and enter identity number');
    }
  };

  const promiseOptions = (inputValue: string) =>
    new Promise<any>((resolve) => {
      resolve(filterProductdata(inputValue.trim()));
    });

  const filterProductdata = async(inputValue: string) => {
    let productLists = [];
    if (inputValue.length >= 3) {
      const productsRes = await CallFor(
        'api/v1.1/searches/products/' + inputValue,
        'GET',
        null,
        'registrationWithAuth'
      );
      if (productsRes.status === 200) {
        const json1Response = await productsRes.json();
        productLists = await json1Response.data.map(
          (d: { id: any; keyword: any }) => ({
            value: d.id,
            label: d.keyword
          })
        );
      } else if (productsRes.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    }
    return productLists;
  };
  const {
    register,
    handleSubmit,
    setError,
    control,
    clearErrors,
    resetField,
    setValue,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema),
    reValidateMode: 'onBlur',
    mode: 'onTouched'
  });
  const submitHandler = async(event) => {
    if (onClickValidationHandler() && isValid) {
      setSaveDisabled(true);
      setLoading(true);
      let prodcustlist = null;
      const productsd = document.getElementsByName('sales');
      if (productsd.length > 0) {
        const sell = [];
        for (let i = 0; i < productsd.length; i++) {
          sell.push(productsd[i].value);
        }
        prodcustlist = sell;
      }
      let buys = null;
      if (buySelectedValue.length > 0) {
        buys = buySelectedValue;
      }
      const userData = JSON.stringify(userFormState);
      let contactNo2 = null;
      if (formState.contactNo2 !== '' && formState.contactNo1 !== null) {
        contactNo2 = formState.contactNo2;
      }
      let contactNo1 = null;
      if (formState.contactNo1 !== '' && formState.contactNo1 !== null) {
        contactNo1 = formState.contactNo1;
      }
      let stateId = null;
      if (formState.stateId !== null) {
        stateId = formState.stateId;
      }
      let userFirstName = '';
      let userLastName = '';
      let userEmail = '';
      let userIdentityNumber = '';
      let entityName = '';
      let companyEmail = '';
      let companyDesignation = '';
      let addLine1 = '';
      let addLine2 = '';
      let companyCity = '';
      let companyAbout = '';
      if (userFormState.firstName !== undefined && userFormState.firstName !== null) {
        userFirstName = userFormState.firstName.trim();
        userFormState.firstName = userFirstName;
      }
      if (userFormState.lastName !== undefined && userFormState.lastName !== null) {
        userLastName = userFormState.lastName.trim();
        userFormState.lastName = userLastName;
      }
      if (userFormState.emailId !== undefined && userFormState.emailId !== null) {
        userEmail = userFormState.emailId.trim();
        userFormState.emailId = userEmail;
      }
      if (formState.identityNumber !== undefined && formState.identityNumber !== null) {
        userIdentityNumber = formState.identityNumber.trim();
        formState.identityNumber = userIdentityNumber;
      }
      if (formState.name !== undefined && formState.name !== null) {
        entityName = formState.name.trim();
        formState.name = entityName;
      }
      if (formState.email !== undefined && formState.email !== null) {
        companyEmail = formState.email.trim();
        formState.email = companyEmail;
      }
      if (formState.designation !== undefined && formState.designation !== null) {
        companyDesignation = formState.designation.trim();
        formState.designation = companyDesignation;
      }
      if (formState.addressLine1 !== undefined && formState.addressLine1 !== null) {
        addLine1 = formState.addressLine1.trim();
        formState.addressLine1 = addLine1;
      }
      if (formState.addressLine2 !== undefined && formState.addressLine2 !== null) {
        addLine2 = formState.addressLine2.trim();
        formState.addressLine2 = addLine2;
      }
      if (formState.city !== undefined && formState.city !== null) {
        companyCity = formState.city.trim();
        formState.city = companyCity;
      }
      if (formState.about !== undefined && formState.about !== null) {
        companyAbout = formState.about.trim();
        formState.about = companyAbout;
      }

      const companyData = {
        userMobile: formState.userMobile,
        designation: formState.designation,
        contactNo1: contactNo1,
        verifiedBy: formState.identityType,
        identityNumber: formState.identityNumber.toUpperCase(),
        name: formState.name,
        type: formState.industryTypeText,
        natureOfBusiness: formState.businessTypeText,
        addressLine1: formState.addressLine1,
        addressLine2: formState.addressLine2,
        firmPincode: formState.firmPincode,
        city: formState.city,
        contactNo2: contactNo2,
        email: formState.email,
        sales: prodcustlist,
        buys: buys,
        about: formState.about,
        states: stateId,
        country: 101
      };
      const userCompanyRegistrationDto =
      '{"user": ' + userData + ',"company": ' + JSON.stringify(companyData) + ' }';
      const profilePhoto = document.getElementById('upload');
      const companyProfile = document.getElementById('companylogo');
      const data = new FormData();
      data.append('profile', profilePhoto.files[0]);
      data.append('logo', companyProfile.files[0]);
      data.append('userCompany', userCompanyRegistrationDto);

      const response = await CallFor(
        'api/v1/companies',
        'POST',
        data,
        'registrationWithoutContentType'
      );
      if (response.status === 201) {
        setLoading(false);
        const datares = await response.json();
        setLocalStore('flag', 'FULL');
        setUserSession(datares.data);
        GetRegisteredId(diviceInfo, 'Auth');
        history.push('/home');
      } else if (response.status === 400) {
        setLoading(false);
        const datares = await response.json();
        if (datares.error.errors !== null) {
          datares.error.errors.map((details) => {
            setError(details.field, {
              type: 'server',
              message: details.message
            });
          });
          if (datares.error.errors[0].field === 'identityNumber') {
            if (
              datares.error.errors[0].message ===
              'Company is Already registered with us'
            ) {
              setCompanyModel(true);
            }
          }
          setError(datares.error.errors[0].field, {
            message: datares.error.errors[0].message
          });
        } else {
          setError('identityNumber', {
            message: datares.error.message
          });
        }
      } else if (response.status === 401) {
        setLoading(false);
        setSaveDisabled(false);
        localStorage.clear();
        history.push('/login');
      } else {
        setLoading(false);
        setSaveDisabled(false);
      }
    }
  };

  const uploadFileHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0 && event.target.files !== undefined) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        // setSaveDisabled(true);
        setIsValid(false);
      } else {
        if (event.target.files[0].size > 3145728) {
          setError('upload', {
            type: 'required',
            message: t('companyproperties.text33')
          });
          // setSaveDisabled(true);
          setIsValid(false);
        } else {
          clearErrors('upload');
          resetField('upload');
          // setSaveDisabled(false);
          setIsValid(true);
        }
      }
      setFile(file1);
      setImageView(true);
    }
  };

  const uploadCompanylogoHandleChange = function loadFile(event: {
    target: { files: string | any[] };
  }) {
    if (event.target.files.length > 0) {
      const file1 = URL.createObjectURL(event.target.files[0]);
      if (!event.target.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('companylogo', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        setIsValid(false);
      } else {
        if (event.target.files[0].size > 3145728) {
          setError('companylogo', {
            type: 'required',
            message: t('companyproperties.text33')
          });
          setIsValid(false);
        } else {
          clearErrors('companylogo');
          resetField('companylogo');
          setIsValid(true);
        }
      }
      setCompanyFile(file1);
      setComapnyImageView(true);
    }
  };
  const onClickValidationHandler = () => {
    blurHandler();
    industryBlurHandler();
    businessBlurHandler();
    const profilePhoto = document.getElementById('upload');
    const companyProfile = document.getElementById('companylogo');
    let isUserLogoValid = true;
    let isComapnyLogoValid = true;
    if (profilePhoto.files[0] !== undefined && profilePhoto.files[0] !== '') {
      if (profilePhoto.files[0].size > 3145728) {
        setError('upload', {
          type: 'required',
          message: t('companyproperties.text33')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
      if (!profilePhoto.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('upload', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        // setIsValid(false);
        isUserLogoValid = false;
      }
    }

    if (companyProfile.files[0] !== undefined && companyProfile.files[0] !== '') {
      if (companyProfile.files[0].size > 3145728) {
        setError('companylogo', {
          type: 'required',
          message: t('companyproperties.text33')
        });
        isComapnyLogoValid = false;
      }
      if (!companyProfile.files[0].name.match(/\.(jpg|jpeg|png|jfif|PNG|JPEG|JPG|JFIF)$/)) {
        setError('companylogo', {
          type: 'required',
          message: t('commonproperties.text1')
        });
        isComapnyLogoValid = false;
      }
    }
    if (isUserLogoValid && isComapnyLogoValid) {
      setIsValid(true);
      return true;
    } else {
      setIsValid(false);
      return false;
    }
  };

  const sendTeamRequest = async() => {
    // setLoading(true);
    const userData = userFormState;
    userData.identityNumber = formState.identityNumber.toUpperCase();
    const data = new FormData();
    const profilePhoto = document.getElementById('upload');
    data.append('profile', profilePhoto.files[0]);
    data.append('user', JSON.stringify(userData));
    const response = await CallFor(
      'api/v1/user',
      'POST',
      data,
      'registrationWithoutContentType'
    );
    if (response.status === 201) {
      setShowToastMsg(t('toastmessages.toast3'));
      setCompanyModel(false);
      setShowToast(true);
      setTimeout(() => {
        history.push('/login');
      }, 3000);
    }
  };
  const companyVerificationChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    // setError({});
    if (event.target.value !== undefined) {
      if (event.target.name === 'identityType') {
        if (event.target.value.length > 0) {
          event.target.classList.add('input-fill');
        } else {
          event.target.classList.remove('input-fill');
        }
        setformState({ ...formState, identityNumber: '', [event.target.name]: event.target.value });
      } else {
        setformState({ ...formState, [event.target.name]: event.target.value });
      }
    }
    if (document.getElementById('identityType') !== null && document.getElementById('identityType').value !== undefined) {
      const identityType = document.getElementById('identityType').value;
      const identityNumber = document.getElementById('identityNumber').value;
      if (identityType !== undefined) {
        if (
          identityNumber !== undefined &&
          identityNumber !== '' &&
          identityNumber.length === 15 &&
          identityType === 'GSTIN'
        ) {
          setdisabled(false);
        } else if (
          identityNumber !== undefined &&
          identityNumber !== '' &&
          identityNumber.length === 10 &&
          identityType === 'PAN'
        ) {
          setdisabled(false);
        } else if (
          identityNumber !== undefined &&
          identityNumber !== '' &&
          identityNumber.length === 12 &&
          identityType === 'UDYOG_ADHAR'
        ) {
          setdisabled(false);
        } else if (
          identityNumber !== undefined &&
          identityNumber !== '' &&
          identityNumber.length === 19 &&
          identityType === 'UDYAM_ADHAR'
        ) {
          setdisabled(false);
        } else {
          setdisabled(true);
        }
      } else {
        setdisabled(true);
      }
      clearErrors([event.target.name]);
      // buttonRef.current.disabled = true;
      setSaveDisabled(false);
      setVerify(false);
    }
  };
  const validateIsNumericInput = (evt: { which: any; keyCode: any; }) => {
    const ASCIICode = (evt.which) ? evt.which : evt.keyCode;
    const permittedKeys = [8, 9, 46, 37, 39, 13, 46, 116, 50];
    if ((ASCIICode >= 48 && ASCIICode <= 57) || (ASCIICode >= 96 && ASCIICode <= 105)) {
      return true;
    };
    if (permittedKeys.includes(ASCIICode)) {
      return true;
    };
    return false;
  };

  const imageEditHandle = () => {
    setImageView(false);
  };
  const deleteImageHandle = () => {
    setIsValid(true);
    setFile('');
    document.getElementById('upload').value = '';
    clearErrors('upload');
    setImageView(true);
  };
  const addImg = () => {
    setImageView(false);
  };

  const imageCompanyEditHandle = () => {
    setComapnyImageView(false);
  };
  const deleteCompanyImageHandle = () => {
    setIsValid(true);
    setCompanyFile('');
    document.getElementById('companylogo').value = '';
    clearErrors('companylogo');
    setComapnyImageView(true);
  };
  const addComapnyImg = () => {
    setComapnyImageView(false);
  };

  const clickHereToReport = async() => {
    const reportsData =
      '{"originId": "' + formState.identityNumber.toUpperCase() + '","origin": "COMPANY","remarks":"User entity claim." }';
    const response = await CallFor(
      'api/v1.1/spam-report',
      'POST',
      reportsData,
      'registrationWithAuth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast24'));
      setShowToast(true);
      setTimeout(() => {
        // history.push('/login');
        setCompanyModel(false);
      }, 2000);
    }
  };
  const removeOverLay = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const addClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.add('imageHover');
  };
  const removeClass = () => {
    const element = document.querySelector('#lblupload');
    element.classList.remove('imageHover');
  };
  const removeOverLayCompany = () => {
    const element = document.querySelector('#lbluploadcompany');
    element.classList.remove('imageHover');
  };
  const addClassCompany = () => {
    const element = document.querySelector('#lbluploadcompany');
    element.classList.add('imageHover');
  };
  const removeClassCompany = () => {
    const element = document.querySelector('#lbluploadcompany');
    element.classList.remove('imageHover');
  };
  const blurHandler = () => {
    const identityType = formState.identityType;
    if (identityType === undefined) {
      setError('identityType', {
        type: 'required',
        message: t('commonproperties.text26')
      });
    }
  };
  const industryBlurHandler = () => {
    const industryTypeText = formState.industryTypeText;
    if (industryTypeText === undefined) {
      setError('industryTypeText', {
        type: 'required',
        message: t('commonproperties.text25')
      });
    }
  };
  const businessBlurHandler = () => {
    const businessTypeText = formState.businessTypeText;
    if (businessTypeText === undefined) {
      setError('businessTypeText', {
        type: 'required',
        message: t('companyproperties.text35')
      });
    }
  };
  const aboutChangeHandler = (event) => {
    if (event.target !== undefined) {
      if (event.target.value !== undefined && event.target.value.length > 0) {
        event.target.classList.add('input-fill');
      } else {
        event.target.classList.remove('input-fill');
      }
      setformState({
        ...formState,
        about: event.target.value
      });
    }
    if (event.target.value !== undefined && event.target.value !== null) {
      setCharacterCount(event.target.value.length);
    }
  };
  // const test = ['upload', 'companylogo'];
  return (
    <IonRow className="auth-screen with-header">
      <MetaTags>
      <title>
        Zyapaar
      </title>
    </MetaTags>
      {loading
        ? (
        <div className="loader">
          <div key="spokes">
            <ReactLoading type="spin" color="#fff" />
          </div>
        </div>
          )
        : (
        <div></div>
          )}
      <div className="auth-container company-container registration-page">
        <IonCardTitle className="auth-title ion-text-center">
        {t('logregproperties.text6')}
        </IonCardTitle>
        <form
          data-testid="form-submit"
          noValidate
          autoComplete="off"
          onSubmit={handleSubmit(submitHandler, onClickValidationHandler)}
        >
          <div className="register-form-details">
            <IonCol col-md-12 className="ion-no-padding">
              <IonRow className="ion-padding-start">
                <IonCardTitle>
                  <h3>
                  {t('logregproperties.text10')}
                  </h3>
                </IonCardTitle>
              </IonRow>
              <IonCard className="MuiCard-root MuiPaper-rounded ">
                    <IonRow className="full-width-row">
                      <IonCol size="12">
                        <IonCardTitle className='inner-title'>{t('logregproperties.text11')}</IonCardTitle>
                      </IonCol>
                      <IonCol size-md="2" className='ion-text-center' size-xs="12">
                        <input
                          type="file"
                          color="primary"
                          onChange={uploadFileHandleChange}
                          id="upload"
                          accept="image/png, image/jpg, image/jpeg"
                          className="upload"
                          disabled={imageView}
                        />
                        <label htmlFor="upload" className="cursor-pointer up-img hover-avtar m-auto" id='lblupload' onClick={removeOverLay} onMouseEnter={addClass} onMouseLeave={removeClass}>
                          <IonAvatar
                            id="avatar"
                            slot="start"
                            className="MuiCardHeader-avatar cursor-pointer "
                          >
                            {file
                              ? (
                              <img src={file} className="profileAvtar" />
                                )
                              : (
                              <img src={userProfile} className="profileAvtar" />
                                )}
                          </IonAvatar>
                          <span className='addImage' onClick={addImg}></span>
                              {file
                                ? <><div className='avr-edit-del-icon'>
                                                <span className="icon edit cursor-pointer">
                                                  <IonIcon icon={trashBinOutline} onClick={deleteImageHandle}/>
                                                </span>
                                                <span className="icon edit cursor-pointer">
                                                  <IonIcon icon={edit} onClick={imageEditHandle}/>
                                              </span>
                                              </div>
                                              </>
                                : ''}
                        </label>
                        <div className='error ion-text-center w-100'>
                        {errors.upload?.message}
                        </div>

                      </IonCol>
                      <IonCol
                        size-md="10"
                        size-xs="12"
                        className=""
                      >
                      <IonRow className="full-width-row">
                        <IonCol
                          size-md="6"
                          size-xs="12"
                          className="input-label-box"
                        >
                           <IonInput
                          autocomplete="off"
                          type='text'
                          className={
                            errors.firstName
                              ? 'error-border input-box'
                              : 'input-box'
                          }
                          data-testid="firstName"
                          placeholder=""
                          onIonChange={userformDataChangeHandler}
                          id="firstName"
                          {...register('firstName')}
                          value={userFormState.firstName}
                        />
                        <span className='floating-label-outside'>
                            {' '}
                            {t('commonproperties.text5')} <sup>*</sup>{' '}</span>
                        <p className={errors.firstName ? 'error' : ''}>
                          {errors.firstName?.message}
                        </p>
                        </IonCol>
                        <IonCol
                          size-md="6"
                          size-xs="12"
                          className="input-label-box"
                        >
                           <IonInput
                          autocomplete="off"
                          type='text'
                          className={
                            errors.lastName
                              ? 'error-border input-box '
                              : 'input-box'
                          }
                          data-testid="lastName"
                          placeholder=""
                          id="lastName"
                          onIonChange={userformDataChangeHandler}
                          {...register('lastName')}
                          value={userFormState.lastName}
                        />
                        <span className='floating-label-outside'>{' '}
                        {t('commonproperties.text6')} <sup>*</sup></span>
                        <p className={errors.lastName ? 'error' : ''}>
                          {errors.lastName?.message}
                        </p>
                        </IonCol>
                        <IonCol
                        size-md="6"
                        size-xs="12"
                        className="input-label-box"
                      >
                        <IonInput
                          autocomplete="off"
                          type='email'
                          className={
                            errors.emailId
                              ? 'error-border input-box '
                              : 'input-box'
                          }
                          data-testid="emailId"
                          placeholder=""
                          onIonChange={userformDataChangeHandler}
                          value={userFormState.emailId}
                          id="emailId"
                          {...register('emailId')}
                        />
                        <span className='floating-label-outside'>{t('userproperties.text7')}</span>
                        <p className={errors.emailId ? 'error' : ''}>
                          {errors.emailId?.message}
                        </p>
                      </IonCol>
                      </IonRow>
                    </IonCol>
                    </IonRow>
               </IonCard>
              {/* Company Detials */}
              <IonRow className="ion-padding-start">
                <IonCardTitle>
                  <h3>
                  {t('logregproperties.text12')}
                  </h3>
                </IonCardTitle>
              </IonRow>
              <IonCard className="MuiCard-root MuiPaper-rounded ">
                   <IonRow className="full-width-row">
                      <IonCol size="12">
                        <IonCardTitle className='inner-title'>  {t('commonproperties.text30')}</IonCardTitle>
                      </IonCol>
                      <IonCol size-md="4" size-xs="12" className='show-tooltip input-popover d-block'>
                          <div className='select-input-box'>
                          <IonSelect
                            interface="popover"
                            className={
                              errors.identityType
                                ? 'error-border select-box'
                                : 'select-box'
                            }
                            placeholder=""
                            onIonChange={companyVerificationChangeHandler}
                            onIonBlur={blurHandler}
                            value={formState.identityType}
                            id="identityType"
                            {...register('identityType')}
                          >
                            {identity.map((option) => (
                              <IonSelectOption
                                key={option.label}
                                value={option.value}
                              >
                                {option.label}
                              </IonSelectOption>
                            ))}
                          </IonSelect>
                          <span className='floating-label-outside'>{t('commonproperties.text37')}<sup>*</sup></span>
                        </div>
                        <p className={errors.identityType ? 'error' : ''}>
                          {errors.identityType?.message}
                        </p>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text155')}/>
                      </IonCol>
                        <IonCol
                        size-md="4"
                        size-xs="12"
                        className="input-label-box show-tooltip input-popover"
                      >
                        <IonInput
                          autocomplete="off`"
                          type='text'
                          className={
                            errors.identityNumber
                              ? 'error-border input-box ion-text-uppercase'
                              : 'input-box ion-text-uppercase'
                          }
                          data-testid="identityNumber"
                          placeholder=""
                          onIonChange={companyVerificationChangeHandler}
                          value={formState.identityNumber}
                          // onkeyup={(event) => event.target.value = (event.target.value).toUpperCase()}
                          id="identityNumber"
                          {...register('identityNumber')}
                        />
                        <span className='floating-label-outside'>{' '}
                        {t('commonproperties.text32')} <sup>*</sup>{' '}</span>
                        <p className={errors.identityNumber ? 'error' : ''}>
                          {errors.identityNumber?.message}
                        </p>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text155')} />
                      </IonCol>
                      <IonCol size-md="4" size-xs="12">
                        <IonButton
                          disabled={disabled}
                          type="button"
                          className="ion-button ion-button-color m-0 item-basline m-w-100 mpr-0 mt-1"
                          onClick={verifybtn}
                        >
                          {!verify ? 'VERIFY' : 'VERIFIED'}
                        </IonButton>
                      </IonCol>
                    </IonRow>
              </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ">
                    <IonRow className="full-width-row">
                      <IonCol size="12">
                        <IonCardTitle className='inner-title'>{t('companyproperties.text36')}</IonCardTitle>
                      </IonCol>
                      <IonCol size-md="2" className='ion-text-center' size-xs="12">
                        <input
                          type="file"
                          color="primary"
                          onChange={uploadCompanylogoHandleChange}
                          id="companylogo"
                          accept="image/png, image/jpg, image/jpeg"
                          className="upload"
                          disabled={comapnyImageView}
                        />
                        <label htmlFor="companylogo" className="cursor-pointer up-img hover-avtar m-auto" id='lbluploadcompany' onClick={removeOverLayCompany} onMouseEnter={addClassCompany} onMouseLeave={removeClassCompany}>
                          <IonAvatar
                            id="companyAvatar"
                            slot="start"
                            className="MuiCardHeader-avatar cursor-pointer "
                          >
                            {companyFile
                              ? (
                              <img src={companyFile} className="profileAvtar" />
                                )
                              : (
                              <img src={userProfile} className="profileAvtar" />
                                )}
                          </IonAvatar>
                          <span className='addImage' onClick={addComapnyImg}></span>
                          {companyFile
                            ? <><div className='avr-edit-del-icon'>
                                          <span className="icon edit cursor-pointer">
                                            <IonIcon icon={trashBinOutline} onClick={deleteCompanyImageHandle}/>
                                          </span>
                                          <span className="icon edit cursor-pointer">
                                            <IonIcon icon={edit} onClick={imageCompanyEditHandle}/>
                                        </span>
                                        </div>
                                        </>
                            : ''}
                        </label>
                        <div className='error ion-text-center w-100'>
                        {errors.companylogo?.message}
                        </div>
                      </IonCol>

                      <IonCol
                        size-md="10"
                        size-xs="12"
                        className='pb-0'
                      >
                        <IonRow>
                          <IonCol sizeMd="6" sizeSm="12" sizeXs="12" className="input-label-box show-tooltip input-popover">
                          <IonInput
                          autocomplete="off"
                          type='text'
                          className={
                            errors.name ? 'error-border input-box' : 'input-box'
                          }
                          data-testid="name"
                          placeholder=""
                          onIonChange={formDataChangeHandler}
                          value={formState.name}
                          id="name"
                          {...register('name')}
                        />
                       <span className='floating-label-outside'>{' '}
                       {t('commonproperties.text27')} <sup>*</sup></span>
                        <p className={errors.name ? 'error' : ''}>
                          {errors.name?.message}
                        </p>
                          <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text160')} />

                          </IonCol>
                          <IonCol sizeSm="12" sizeXs="12" sizeMd="6" className="input-label-box show-tooltip input-popover d-block">
                          <div className='select-input-box'>
                          <IonSelect
                          interface="popover"
                          className={
                            errors.industryTypeText
                              ? 'error-border select-box'
                              : 'select-box'
                          }
                          id="industryTypeText"
                          onIonChange={formDataChangeHandler}
                          onIonBlur={industryBlurHandler}
                          value={formState.industryTypeText}
                          {...register('industryTypeText')}
                        >
                          {firmType.map((option) => (
                            <IonSelectOption
                              key={option.value}
                              value={option.value}
                            >
                              {option.label}
                            </IonSelectOption>
                          ))}
                        </IonSelect>
                        <span className='floating-label-outside'>{t('companyproperties.text37')}<sup>*</sup></span>
                        </div>
                        <p className={errors.industryTypeText ? 'error' : ''}>
                          {errors.industryTypeText?.message}
                        </p>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text161')}/>
                          </IonCol>
                          <IonCol sizeMd="6" sizeSm="12" sizeXs="12" className="input-label-box show-tooltip input-popover d-block">
                          <div className='select-input-box'>
                          <IonSelect
                          interface="popover"
                          className={
                            errors.businessTypeText
                              ? 'error-border select-box'
                              : 'select-box'
                          }
                          id="businessTypeText"
                          onIonChange={formDataChangeHandler}
                          onIonBlur={businessBlurHandler}
                          value={formState.businessTypeText}
                          {...register('businessTypeText')}
                        >
                          {businessType.map((option) => (
                            <IonSelectOption
                              key={option.value}
                              value={option.value}
                            >
                              {option.label}
                            </IonSelectOption>
                          ))}
                        </IonSelect>
                        <span className='floating-label-outside'>{t('appproperties.text179')}<sup>*</sup></span>
                        </div>
                        <p className={errors.businessTypeText ? 'error' : ''}>
                          {errors.businessTypeText?.message}
                        </p>
                        <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text162')}/>
                          </IonCol>
                          <IonCol sizeMd="6" sizeSm="12" sizeXs="12" className="input-label-box">
                          <IonInput
                          autocomplete="off"
                          type='email'
                          className={
                            errors.email
                              ? 'error-border input-box'
                              : 'input-box'
                          }
                          data-testid="email"
                          placeholder=""
                          id="email"
                          onIonChange={formDataChangeHandler}
                          value={formState.email}
                          {...register('email')}
                        />
                       <span className='floating-label-outside'>{t('commonproperties.text33')}</span>
                        <p className={errors.email ? 'error' : ''}>
                          {errors.email?.message}
                        </p>
                          </IonCol>
                        </IonRow>
                      </IonCol>
                      <IonCol
                        size-md="4"
                        size-xs="12"
                        className="input-label-box"
                      >
                        <IonInput
                            type='text' pattern="[0-9]+"
                            autocomplete="off"
                          className={
                            errors.contactNo1
                              ? 'error-border input-box'
                              : 'input-box'
                          }
                          data-testid="contactNo1"
                          placeholder=""
                          maxlength={10}
                          id="contactNo1"
                          {...register('contactNo1')}
                          onkeydown={validateIsNumericInput}
                          onIonChange={formDataChangeHandler}
                          value={formState.contactNo1}
                        />
                        <span className='floating-label-outside'>{' '}
                            {t('companyproperties.text5')}{' '}</span>
                        <p className={errors.contactNo1 ? 'error' : ''}>
                          {errors.contactNo1?.message}
                        </p>
                      </IonCol>
                      <IonCol
                        size-md="4"
                        size-xs="12"
                        className="input-label-box"
                      >
                        <IonInput type='text' pattern="[0-9]+"
                            autocomplete="off"
                          className={
                            errors.contactNo2
                              ? 'error-border input-box'
                              : 'input-box'
                          }
                          data-testid="contactNo2"
                          placeholder=""
                          id="contactNo2"
                          {...register('contactNo2')}
                          onIonChange={formDataChangeHandler}
                          onkeydown={validateIsNumericInput}
                          value={formState.contactNo2}
                          maxlength={10}
                        />
                        <span className='floating-label-outside'>{t('userproperties.text6')}</span>
                        <p className={errors.contactNo2 ? 'error' : ''}>
                          {errors.contactNo2?.message}
                        </p>
                      </IonCol>
                      <IonCol
                        size-md="4"
                        size-xs="12"
                        className="input-label-box"
                      >
                        <IonInput
                          autocomplete="off"
                          type='text'
                          className={
                            errors.designation
                              ? 'error-border input-box'
                              : 'input-box'
                          }
                          data-testid="designation"
                          placeholder=""
                          id="designation"
                          {...register('designation')}
                          onIonChange={formDataChangeHandler}
                          value={formState.designation}
                        />
                        <span className='floating-label-outside'>{' '}
                            {t('companyproperties.text7')} <sup>*</sup>{' '}</span>
                        <p className={errors.designation ? 'error' : ''}>
                          {errors.designation?.message}
                        </p>
                      </IonCol>
                    </IonRow>
              </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ion-reg-address">
                    <IonRow className="full-width-row">
                      <IonCol size="12">
                        <IonCardTitle className='inner-title'>Address</IonCardTitle>
                      </IonCol>
                      <IonCol
                        size-md="6"
                        size-xs="12"
                        className="input-label-box"
                      >
                        <IonInput
                          autocomplete="off"
                          type='text'
                          className={
                            errors.addressLine1
                              ? 'error-border input-box'
                              : 'input-box'
                          }
                          data-testid="addressLine"
                          placeholder=""
                          id="addressLine1"
                          {...register('addressLine1')}
                          onIonChange={formDataChangeHandler}
                          value={formState.addressLine1}
                        />
                        <span className='floating-label-outside'>{' '}
                            {t('companyproperties.text8')} <sup>*</sup>{' '}</span>
                        <p className={errors.addressLine1 ? 'error' : ''}>
                          {errors.addressLine1?.message}
                        </p>
                      </IonCol>
                      <IonCol
                        size-md="6"
                        size-xs="12"
                        className="input-label-box"
                      >
                        <IonInput
                          autocomplete="off"
                          type='text'
                          className="input-box"
                          data-testid="addressLine2"
                          placeholder=""
                          onIonChange={formDataChangeHandler}
                          value={formState.addressLine2}
                          id="addressLine2"
                          {...register('addressLine2')}
                        />
                        <span className='floating-label-outside'>{t('companyproperties.text9')}</span>
                      </IonCol>
                      <IonCol
                        size-md="4"
                        size-xs="12"
                        className="input-label-box"
                      >
                        <IonInput type='text'
                          inputmode="numeric"
                          pattern="[0-9]*"
                          autocomplete="off"
                          className={
                            errors.firmPincode
                              ? 'error-border input-box'
                              : 'input-box'
                          }
                          data-testid="firmPincode"
                          placeholder=""
                          onIonChange={formDataChangeHandler}
                          onkeydown={validateIsNumericInput}
                          value={formState.firmPincode}
                          id="firmPincode"
                          {...register('firmPincode')}
                          maxlength={6}
                        />
                        <span className='floating-label-outside'>{' '}
                            {t('companyproperties.text10')} <sup>*</sup>{' '}</span>
                        <p className={errors.firmPincode ? 'error' : ''}>
                          {errors.firmPincode?.message}
                        </p>
                      </IonCol>
                      <IonCol size-md="4" size-xs="12">
                        <Select
                          onChange={stateDataChangeHandler}
                          options={stateCombo}
                          className="selectOption moreimp v-imp "
                          placeholder={t('companyproperties.text14')}
                          styles={customStyles}
                          id="stateId"
                          name="stateId"
                          isClearable
                          noOptionsMessage={() => null}
                          menuPlacement='bottom'
                          menuPosition='absolute'
                        />
                        <p className={errors.stateId ? 'error' : ''}>
                          {errors.stateId?.message}
                        </p>
                      </IonCol>
                      <IonCol
                        size-md="4"
                        size-xs="12"
                        className="input-label-box"
                      >
                        <IonInput
                          autocomplete="off"
                          type='text'
                          className={
                            errors.t('companyproperties.text11') ? 'error-border input-box' : 'input-box'
                          }
                          data-testid="city"
                          placeholder=""
                          onIonChange={formDataChangeHandler}
                          value={formState.city}
                          id="city"
                          {...register('city')}
                        />
                        <span className='floating-label-outside'>{' '}
                            {t('companyproperties.text11')} <sup>*</sup>{' '}</span>
                        <p className={errors.city ? 'error' : ''}>
                          {errors.city?.message}
                        </p>
                      </IonCol>
                    </IonRow>
              </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ion-card-reg-sell">
                    <IonRow className="full-width-row">
                      <IonCol size="12">
                        <IonCardTitle className='inner-title show-tooltip'>{t('commonproperties.text7')} <sup className='mt-2þ'>*</sup>
                         <PopoverCommon className='tooltip-zyapaar' Description='Input all products you sell so that we can help you connect with buyers of your products. We have made it very simple for you-name your products and select from our drop down!'/>
                        </IonCardTitle>
                      </IonCol>
                      <IonCol size-md="12" size-xs="12">
                      <Controller
                          name="sales"
                          control={control}
                          render={({ field }) => (
                            <AsyncSelect
                              {...field}
                              autocomplete="off"
                              type='text'
                              isMulti
                              autocomplete="off"
                              className="selectOption moreimp"
                              placeholder={t('companyproperties.text15')}
                              styles={customStyles}
                              loadOptions={promiseOptions}
                              components={{ LoadingIndicator: null }}
                              id='sales'
                              menuPlacement='bottom'
                              menuPosition='absolute'
                            />
                          )}
                        />
                        <p className={errors.sales ? 'error' : ''}>
                          {errors.sales?.message}
                        </p>
                      </IonCol>
                    </IonRow>
              </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ion-card-add-reg">
                    <IonRow className="full-width-row">
                      <IonCol size="12">
                        <IonCardTitle className='inner-title show-tooltip'>{t('commonproperties.text8')}
                         <PopoverCommon className='popover-zyapaar' Description='Buy from new suppliers, add all your purchase needs from raw material, finished product, packing material and services. We will bring new suppliers and service providers based on your requirements.'/>
                        </IonCardTitle>
                      </IonCol>
                      <IonCol size-md="12" size-xs="12">
                        <AsyncSelect
                          autocomplete="off"
                          type='text'
                          isMulti
                          value={formState.buy}
                          onChange={buyHandleChange}
                          loadOptions={promiseOptions}
                          className="selectOption"
                          placeholder={t('companyproperties.text15')}
                          styles={customStyles}
                          id="buys"
                          name="buys"
                         // menuPortalTarget={document.body}
                          menuPlacement='bottom'
                          components={{ LoadingIndicator: null }}
                          menuPosition='absolute'
                        />

                        <p className={errors.buys ? 'error' : ''}>
                          {errors.buys?.message}
                        </p>
                      </IonCol>
                    </IonRow>
                </IonCard>
              <IonCard className="MuiCard-root MuiPaper-rounded ">
                    <IonRow className="full-width-row">
                      <IonCol size="12">
                        <IonCardTitle className='inner-title'>
                        {t('commonproperties.text31')}<sup>*</sup>
                        </IonCardTitle>
                      </IonCol>
                      <IonCol size-md="12" size-xs="12">
                        <IonTextarea
                          autocomplete="off"
                          type='text'
                          rows={6}
                          className={
                            errors.about
                              ? 'error-border input-box zind1'
                              : 'input-box zind1'
                          }
                          data-testid="about"
                          placeholder={t('companyproperties.text12')}
                          onIonChange={aboutChangeHandler}
                          value={formState.about}
                          id="about"
                          {...register('about')}
                          maxlength={500}
                        />
                        <p className={errors.about ? 'error' : ''}>
                          {errors.about?.message}
                        </p>
                        <p className='text-grey text-end font-14'>{characterCount}/{maxCount}</p>
                      </IonCol>
                    </IonRow>
              </IonCard>
            </IonCol>
            <IonCol>
              <div className="ion-text-center mb-4">
                <IonButton
                  disabled={ saveDisabled }
                  type="submit"
                  // ref={buttonRef}
                  className="ion-button ion-button-color m-w-100 mpr-0 register-save"
                >
                  {t('appproperties.text64')}
                  {saveDisabled
                   ? <span className="loader" id="loader-2">
                  <span></span>
                  <span></span>
                  <span></span>
                </span>
                   : ''
                }
                </IonButton>
              </div>
            </IonCol>
          </div>
        </form>
      </div>
      <IonModal isOpen={companyModel} cssClass="small-model" onDidDismiss={() => setCompanyModel(false)}>
        <IonContent>
          <IonRow className="full-width-row ion-padding-top ion-padding-bottom">
            <IonRow>
              <IonLabel className="MuiTypography-h6 ion-padding-start">
                {' '}
                {t('companyproperties.text13')}
              </IonLabel>
            </IonRow>
            <IonButton
              fill="clear"
              className="ion-activatable header-row-margin-left"
              onClick={() => setCompanyModel(false)}
            >
              <IonIcon
                icon={close}
                className="ion-button-color"
                slot="start"
                size="undefined"
              />
            </IonButton>
          </IonRow>
          <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom ion-justify-content-center">
            <span>
            {t('appproperties.text236a')}{userFormState.firstName + ' ' + userFormState.lastName}{t('appproperties.text236b')}
            </span>
          </IonRow>
          <IonRow className="ion-padding-start">
            <IonButton
              className="ion-button ion-button-color"
              onClick={sendTeamRequest}
            >
            {t('appproperties.text237')}
            </IonButton>
          </IonRow>
          <IonRow className="ion-padding-start ion-padding-top">
            <span className="error">
              Note: {t('companyproperties.text38')} <a onClick={clickHereToReport}>{t('companyproperties.text39')}</a>.
            </span>
          </IonRow>
        </IonContent>
      </IonModal>
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000}/>
    </IonRow>
  );
};
export default Registration;