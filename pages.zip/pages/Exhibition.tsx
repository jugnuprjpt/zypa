import { IonRow, IonCol } from '@ionic/react';
import React, { useEffect, useState } from 'react';

const Exhibition = () => {
  const [exhibition, setExhibition] = useState([]);

  const dateComparison = (date) => {
    const currentData = new Date();
    const enddate = new Date(date);
    const UsFormatter = new Intl.DateTimeFormat('en-US');
    if (enddate >= new Date(UsFormatter.format(currentData))) {
      return true;
    }
    return false;
  };

  useEffect(async() => {
    const response = await fetch('https://zyapaar-final--1---ga4-default-rtdb.firebaseio.com/exhibitionDetails.json');
    const exhibitionDetails = await response.json();
    setExhibition(exhibitionDetails.response);
  }, []);
  return (
    <>
        <div className='web-pages-before exhibition-page '>
                <div className="container">
                <IonRow>
                  <IonCol>
                    <div className="heading mb-2">
                        <h1>Exhibition</h1>
                    </div>
                    </IonCol>
                    </IonRow>
                </div>

                <section className="section-space exhibition-part">
          <div className="container">
          <IonRow className='exhibition-boxes'>
            {
                exhibition.map((details) => {
                  return (
                    <>
                    {dateComparison(details.enddate)
                      ? <div className='exhibition-box'>
                   <div className='exhibition-clr pb-3'>
                   <div className='exhi-details pt-4  text-center exhi-logo'>
                      <img src={`https://www.tender247.com/${details.ImageName}`}/>
                    </div>
                   <div className='exhi-logo-title pt-2 text-center'>{details.ExhibitionName}</div>
                   <div className='exhi-details pt-5  text-center'> {details.startdate} {details.enddate}</div>
                   <div className='exhi-logo-title pt-2 text-center'>{details.CityName},{details.StateName},{details.CountryName}</div>
                   <div className='exhi-details pt-5  text-center'>
                   <a href={details.URL} target="_blank" rel="noreferrer" >{details.URL}</a></div>
                   <div className='exhi-logo-title pt-2 text-center'>  {details.Description}</div>
                  </div>
                   </div>
                      : ''}
                      </>

                  );
                })
              }
            </IonRow>
          </div>
        </section>
        </div>
    </>
  );
};
export default Exhibition;
