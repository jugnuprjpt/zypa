import React from 'react';
import { IonLabel } from '@ionic/react';
import language from '../assets/img/language.svg';

const Language = () => {
  return (
        <>
            <div className='plane-bg'>
                <div className='d-flex justify-content-between'>
                <h4 className='p-2 py-0'>Choose Your Language</h4>
                <img src={language} alt="language" width='22' className='me-3' />
                </div>
                <div className='language-section p-2'>
                    <IonLabel className='align-items-center d-flex hydrated justfy-mobile-center'>English</IonLabel>
                    <IonLabel className='align-items-center d-flex hydrated justfy-mobile-center'>हिंदी</IonLabel>
                    <IonLabel className='align-items-center d-flex hydrated justfy-mobile-center'>ગુજરાતી</IonLabel>
                    <IonLabel className='align-items-center d-flex hydrated justfy-mobile-center'>తెలుగు</IonLabel>
                    <IonLabel className='align-items-center d-flex hydrated justfy-mobile-center'>मराठी</IonLabel>
                    <IonLabel className='align-items-center d-flex hydrated justfy-mobile-center'>ਪੰਜਾਬੀ</IonLabel>
                </div>
            </div>
        </>
  );
};
export default Language;
