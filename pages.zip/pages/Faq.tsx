import { IonRow, IonCol } from '@ionic/react';
import React from 'react';
import { useTranslation } from 'react-i18next';
import faqicon from '../assets/img/new-web/faq-icon.svg';
import Input from '../components/common/Input';

const Faq = () => {
  const { t } = useTranslation();
  return (
    <>
      <div className='web-pages-before faq-page'>
        <div className="container">
          <IonRow className='faq-wrapper m-auto'>
            <IonCol>
              <div className="mb-2 d-flex faq-title">
                <img src={faqicon} alt='Faq Icon' className='pe-2' />
                <h1>Frequently asked questions</h1>
              </div>
            </IonCol>
          </IonRow>

          <IonRow className='m-auto'>
            <IonCol>

              <div className="tabs">

                <div className="tab">
                  <input type="checkbox" id="rd1" name="rd" />
                  <label className="tab-label" htmlFor="rd1">What is Zyapaar? How does it work? </label>
                  <div className="tab-content">
                  Zyapaar is a platform which helps you increase your sales and brings proficiency in procurement. You can register by filling up basic details and start exploring Zyapaar. Zyapaar allows you to create catalogue of your products, you can find thousands of buyers &amp; suppliers, you can also post your requirements which others users will reply to. So, in a nutshell Zyapaar is digital identity of your business, a networking platform &amp; procurement tool- all in one for your business.
                  </div>
                </div>

                <div className="tab">
                  <input type="checkbox" id="rd13" name="rd" />
                  <label className="tab-label" htmlFor="rd13">Is there any Registration fee for using Zyapaar? </label>
                  <div className="tab-content">
                  No, there is absolutely no registration fee on Zyapaar. The usage of the platform is also free that means you do not have to pay any subscription fee as well.
                  </div>
                </div>

                <div className="tab">
                  <input type="checkbox" id="rd2" name="rd" />
                  <label className="tab-label" htmlFor="rd2">How can I grow my business using Zyapaar?</label>
                  <div className="tab-content">
                  Zyapaar creates Digital identity of business it allows you to create strong online presence of Business. 
                  <p className='pt-1'>Benefits Of Zyapaar:</p>
                  <ul>
                    <li>Create Complete Business Profile</li>
                    <li>Create Detailed Product Catalogues</li>                    
                    <li>Connect with More than 10000 Buyers &amp; Suppliers</li>
                    <li>Deal With verified Users</li>
                    <li>Generate Most Qualified Leads</li>
                    <li>Create Post to Market your products &amp; Procure Product &amp; Services</li>
                  </ul>
                  </div>
                </div>

                <div className="tab">
                  <input type="checkbox" id="rd3" name="rd" />
                  <label className="tab-label" htmlFor="rd3">Can I create products catalogue on Zyapaar? </label>
                  <div className="tab-content">
                  Yes, you can.There is a section of Uploading a product catalog in your profile. Go to your Profile -&gt; Tap on Company  -&gt; Product -&gt; Upload your Product Catalog.
                  </div>
                </div>
                
                <div className="tab">
                  <input type="checkbox" id="rd4" name="rd" />
                  <label className="tab-label" htmlFor="rd4">How can I post my products or purchase requirement?  </label>
                  <div className="tab-content">
                  To post purchase requirement, follow these simple steps:-
                  <ul>
                    <li>On the bottom of home page, click on Post given on the task bar.</li>
                    <li>Select Post Type and Privacy for your post.</li>
                    <li>Then enter product name and specifications of the product you wish to buy.</li>
                    <li>After entering the details, click on post.</li>
                  </ul>
                  </div>
                </div>

                <div className="tab">
                  <input type="checkbox" id="rd5" name="rd" />
                  <label className="tab-label" htmlFor="rd5">What are the connection suggestions I receive on zyapaar ?</label>
                  <div className="tab-content">
                  Zyapaar displays connection suggestion of people who belong to your industry. The system shows you suggestions of Zyapaaris who Buy your products or Sell raw material/products/ services you need. These suggestions are based on what you have entered under <b>What you Buy</b> and <b>What you sell</b> under your profile. Zyapaar also suggests connection of Zyapaaris from your city from different Industries.
                  </div>
                </div>

                <div className="tab">
                  <input type="checkbox" id="rd6" name="rd" />
                  <label className="tab-label" htmlFor="rd6">How will Buyers find &amp; connect with me? </label>
                  <div className="tab-content">
                  Users, who want to buy your products, can get connected by sending you a connection request. You can see these requests in Connection -> Connection Requests.
                  </div>
                </div>
                
                

                <div className="tab">
                  <input type="checkbox" id="rd7" name="rd" />
                  <label className="tab-label" htmlFor="rd7">Can I manage my multiple businesses from a single Zyapaar account?</label>
                  <div className="tab-content">
                  Yes, You can. Zyapaar allows you to add multiple companies from your own user account. You can add your company in My Account -&gt; Company -&gt; {t('companyproperties.text2')}.
                  </div>
                </div>
                
                <div className="tab">
                  <input type="checkbox" id="rd8" name="rd" />
                  <label className="tab-label" htmlFor="rd8">Can a company/business have multiple users manage business on Zyapaar?</label>
                  <div className="tab-content">
                  Yes, multiple users can manage business on behalf of the single entity. Any new user of same business will have to register using same Tax Credentials ( GST/Udyam Aaadhar/Pan) as the first member. The first member of company will get notification to add the user to the Team which once approved will allow new user to actively use Zyapaar. 
                  </div>
                </div>

                <div className="tab">
                  <input type="checkbox" id="rd11" name="rd" />
                  <label className="tab-label" htmlFor="rd11">How does Group function work on Zyapaar? </label>
                  <div className="tab-content">
                  By participating in Group, You can discuss industry issues or look for resources with help of group members. You can use this for group buying as well. You can invite or allow users to join who are from your industry or have the same interest. You can even join multiple groups at a time. 
                  </div>
                </div>
                
                <div className="tab">
                  <input type="checkbox" id="rd12" name="rd" />
                  <label className="tab-label" htmlFor="rd12">How page function works on Zyapaar?</label>
                  <div className="tab-content">
                  You can create a page of your industry to post and share blog. By following pages of industries of your interest, you can get a lot of information on current trends and demands.
                  </div>
                </div>

                <div className="tab">
                  <input type="checkbox" id="rd9" name="rd" />
                  <label className="tab-label" htmlFor="rd9">Can I make payment to the supplier via Zyapaar? </label>
                  <div className="tab-content">
                  Zyapaar facilitates users to connect with multiple Suppliers, Buyers and Sellers. However, you cannot pay via Zyapaar as it does not provide any online payment service.
                  </div>
                </div>
                
                <div className="tab">
                  <input type="checkbox" id="rd10" name="rd" />
                  <label className="tab-label" htmlFor="rd10">Does Zyapaar guarantee about the quality of products? </label>
                  <div className="tab-content">
                  Zyapaar is an online platform to connect buyers with suppliers. It does not provide assurance of product quality on behalf of listed suppliers. However, it provides the buyer with multiple options of suppliers to choose from. It recommends you to connect with multiple suppliers and then choose the most suitable one.
                  </div>
                </div>

                

              </div>              
            </IonCol>
          </IonRow>

        </div>
      </div>
    </>
  );
};
export default Faq;
