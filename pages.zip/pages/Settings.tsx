/* eslint-disable multiline-ternary */
import {
  IonButton,
  IonCard,
  IonCol,
  IonIcon,
  IonItem,
  IonLabel,
  IonRadio,
  IonRadioGroup,
  IonRow
} from '@ionic/react';
import { chevronForwardOutline } from 'ionicons/icons';
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router';
import PopoverCommon from '../components/common/PopoverCommon';
import SettingNotification from '../components/common/SettingNotification';
import ToastCommon from '../components/common/ToastCommon';
import callFor from '../util/CallFor';

const Settings = () => {
  const { t, i18n } = useTranslation();
  const history = useHistory();
  const [showToast, setShowToast] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const [settingForm, setSettingForm] = useState({
    profileViewPush: true,
    profileViewEmail: true,
    postReactionPush: true,
    postReactionEmail: true,
    commentPush: true,
    commentEmail: true,
    postSharePush: true,
    postShareEmail: true,
    commentReactionPush: true,
    commentReactionEmail: true,
    commentReplyPush: true,
    commentReplyEmail: true,
    postMentionPush: true,
    postMentionEmail: true,
    commentMentionPush: true,
    commentMentionEmail: true,
    teamPush: true,
    teamEmail: true,
    groupPush: true,
    groupEmail: true,
    pagePush: true,
    pageEmail: true,
    connectionPush: true,
    connectionEmail: true,
    messagePush: true,
    messageEmail: true,
    networkProfile: 'PUBLIC_PROFILE',
    postDelivery: 'ANYONE'
  });
  useEffect(() => {
    getSettings();
  }, []);
  const settingFromChangeHandler = (event: {
    target: { name: any; value: any };
  }) => {
    if (event.target.checked !== undefined) {
      setSettingForm({
        ...settingForm,
        [event.target.name]: event.target.checked
      });
    } else {
      setSettingForm({
        ...settingForm,
        [event.target.name]: event.target.value
      });
    }
  };
  const { handleSubmit } = useForm();
  const settingSubmitHandler = async() => {
    setLoading(true);
    const data =
      '{"profileViewPush" :' +
      settingForm.profileViewPush +
      ',"profileViewEmail" :' +
      settingForm.profileViewEmail +
      ',"postReactionPush" :' +
      settingForm.postReactionPush +
      ',"postReactionEmail" :' +
      settingForm.postReactionEmail +
      ',"commentPush" :' +
      settingForm.commentPush +
      ',"commentEmail" :' +
      settingForm.commentEmail +
      ',"postSharePush" :' +
      settingForm.postSharePush +
      ',"postShareEmail" :' +
      settingForm.postShareEmail +
      ',"commentReactionPush" :' +
      settingForm.commentReactionPush +
      ',"commentReactionEmail" :' +
      settingForm.commentReactionEmail +
      ',"commentReplyPush" :' +
      settingForm.commentReplyPush +
      ',"commentReplyEmail":' +
      settingForm.commentReplyEmail +
      ',"postMentionPush" :' +
      settingForm.postMentionPush +
      ',"postMentionEmail" :' +
      settingForm.postMentionEmail +
      ',"commentMentionPush" :' +
      settingForm.commentMentionPush +
      ',"commentMentionEmail" :' +
      settingForm.commentMentionEmail +
      ',"teamPush" :' +
      settingForm.teamPush +
      ',"teamEmail" :' +
      settingForm.teamEmail +
      ',"groupPush" :' +
      settingForm.groupPush +
      ',"groupEmail" :' +
      settingForm.groupEmail +
      ',"pagePush" :' +
      settingForm.pagePush +
      ',"pageEmail":' +
      settingForm.pageEmail +
      ',"connectionPush" :' +
      settingForm.connectionPush +
      ',"connectionEmail" :' +
      settingForm.connectionEmail +
      ',"messagePush" :' +
      settingForm.messagePush +
      ',"messageEmail" :' +
      settingForm.messageEmail +
      ',"networkProfile" :"' +
      settingForm.networkProfile +
      '","postDelivery" :"' +
      settingForm.postDelivery +
      '"}';
    const response = await callFor(
      'api/v1.1/notifications/settings',
      'POST',
      data,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast30'));
      setShowToast(true);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };

  const getSettings = async() => {
    setLoading(true);
    const response = await callFor(
      'api/v1.1/notifications/settings',
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data !== null) {
        setSettingForm(json1Response.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const [selectLang, setSelectLang] = useState('en_US');
  const langChangeHandler = (event) => {
    localStorage.setItem('localelang', event.currentTarget.value);
    i18n.changeLanguage(event.currentTarget.value);
  };
  return (
    <IonRow className="plane-bg">
      {/* {loading ? (
        <div className="loader">
          <div key="spokes">
            <ReactLoading type="spokes" color="#fff" />
          </div>
        </div>
      ) : ( */}
        <IonRow className="container">
          <IonCol sizeMd="12">
            <h3 className="head-title mtm-0 mbm-0">{t('appproperties.text101')} </h3>
          </IonCol>
          <form
            data-testid="form-submit"
            autoComplete="off"
            onSubmit={handleSubmit(settingSubmitHandler)}
          >
            <IonCol size="12">
              <IonCard className="profile-details left-cards ion-no-margin MuiPaper-rounded ion-padding-bottom ion-padding-end">
                <IonRow className="ion-padding-start">
                  <h5> {t('appproperties.text106')} </h5>
                </IonRow>
                <IonRow>
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.profileViewPush}
                    valueEmail={settingForm.profileViewEmail}
                    namePush="profileViewPush"
                    nameEmail="profileViewEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text108')}
                  />
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.messagePush}
                    valueEmail={settingForm.messageEmail}
                    namePush="messagePush"
                    nameEmail="messageEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text115')}
                  />
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.connectionPush}
                    valueEmail={settingForm.connectionEmail}
                    namePush="connectionPush"
                    nameEmail="connectionEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text109')}
                  />
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.postReactionPush}
                    valueEmail={settingForm.postReactionEmail}
                    namePush="postReactionPush"
                    nameEmail="postReactionEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text116')}
                  />
                   <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.postMentionPush}
                    valueEmail={settingForm.postMentionEmail}
                    namePush="postMentionPush"
                    nameEmail="postMentionEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text110')}
                  />
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.postSharePush}
                    valueEmail={settingForm.postShareEmail}
                    namePush="postSharePush"
                    nameEmail="postShareEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text117')}
                  />
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.commentReactionPush}
                    valueEmail={settingForm.commentReactionEmail}
                    namePush="commentReactionPush"
                    nameEmail="commentReactionEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text111')}
                  />
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.commentReplyPush}
                    valueEmail={settingForm.commentReplyEmail}
                    namePush="commentReplyPush"
                    nameEmail="commentReplyEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text118')}
                  />
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valueEmail={settingForm.commentEmail}
                    valuePush={settingForm.commentPush}
                    namePush="commentPush"
                    nameEmail="commentEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text112')}
                  />
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.commentMentionPush}
                    valueEmail={settingForm.commentMentionEmail}
                    namePush="commentMentionPush"
                    nameEmail="commentMentionEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text119')}
                  />
                   <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    name="eventNotification"
                    valuePush={settingForm.pagePush}
                    valueEmail={settingForm.pageEmail}
                    namePush="pagePush"
                    nameEmail="pageEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text113')}
                  />
                  <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.groupPush}
                    valueEmail={settingForm.groupEmail}
                    namePush="groupPush"
                    nameEmail="groupEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text120')}
                  />
                 <SettingNotification
                    settingFromChangeHandler={settingFromChangeHandler}
                    valuePush={settingForm.teamPush}
                    valueEmail={settingForm.teamEmail}
                    namePush="teamPush"
                    nameEmail="teamEmail"
                    toggleA={t('appproperties.text107')}
                    toggleB={t('userproperties.text7')}
                    heading={t('appproperties.text114')}
                  />
                </IonRow>
              </IonCard>
            </IonCol>
            <IonRow>
            <IonCol sizeMd='12' sizeXs='12'>
              <IonCard className="profile-details left-cards ion-no-margin MuiPaper-rounded pb-lg-4 pb-3">
                <IonRow className="ion-padding-start">
                <h5 className='show-tooltip'> {t('appproperties.text121')}
                  <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text390')}/>
                  </h5>
                </IonRow>
                <IonRadioGroup
                  value={selectLang}
                  // onIonChange={langChangeHandler}
                  onIonChange={(e) => setSelectLang(e.detail.value)}
                  name="networkProfile"
                >
                  <IonRow className="ion-padding-start language-input">
                    <IonItem lines="none">
                      <IonRadio mode="md" value="en_US"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                        {t('appproperties.text122')}
                      </IonLabel>
                    </IonItem>
                    {/* <IonItem lines="none">
                      <IonRadio mode="md" value="hindi_IN"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                      {t('appproperties.text124')}
                      </IonLabel>
                    </IonItem>
                    <IonItem lines="none">
                      <IonRadio mode="md" value="guj_IN"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                      {t('appproperties.text123')}
                      </IonLabel>
                    </IonItem>
                    <IonItem lines="none">
                      <IonRadio mode="md" value="marathi_IN"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                      {t('appproperties.text126')}
                      </IonLabel>
                    </IonItem>
                    <IonItem lines="none">
                      <IonRadio mode="md" value="pun_IN"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                      {t('appproperties.text127')}
                      </IonLabel>
                    </IonItem>
                    <IonItem lines="none">
                      <IonRadio mode="md" value="telugu_IN"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                      {t('appproperties.text125')}
                      </IonLabel>
                    </IonItem> */}
                  </IonRow>
                </IonRadioGroup>
              </IonCard>
            </IonCol>
            <IonCol sizeMd='6' sizeXs='12'>
              <IonCard className="profile-details left-cards ion-no-margin MuiPaper-rounded pb-lg-4 pb-3">
                <IonRow className="ion-padding-start">
                <h5 className='show-tooltip'>{t('appproperties.text128')+'*'}
                  <PopoverCommon className='popover-zyapaar' Description={t('appproperties.text390')}/>
                  </h5>
                </IonRow>
                <IonRadioGroup
                  value={settingForm.networkProfile}
                  onIonChange={settingFromChangeHandler}
                  name="networkProfile"
                >
                  <IonRow className="ion-padding-start">
                    <IonItem lines="none">
                      <IonRadio mode="md" value="PUBLIC_PROFILE"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                      {t('appproperties.text129')}
                      </IonLabel>
                    </IonItem>
                    <IonItem lines="none">
                      <IonRadio mode="md" value="PRIVATE_PROFILE"></IonRadio>
                      <IonLabel className="MuiFormControlLabel-root">
                      {t('appproperties.text130')}
                      </IonLabel>
                    </IonItem>
                  </IonRow>
                </IonRadioGroup>
              </IonCard>
            </IonCol>
            <IonCol sizeMd='6' sizeXs='12'>
              <IonCard className="legal-conteb profile-details left-cards ion-no-margin MuiPaper-rounded ion-padding-horizontal ion-padding-top">
                <IonRow>
                  <h5 className="mt-0"> {t('appproperties.text131')}</h5>
                </IonRow>
                <IonRow className="legal-inner-content">
                  <IonCol sizeMd="6" sizeXs="12" className="ion-no-padding pb-0">
                    <div className="myprofile-feeds ion-no-padding box-group ion-padding-end ion-padding-bottom">
                      <IonRow className="ion-padding-start">
                      {t('appproperties.text132')}
                      </IonRow>
                      <IonRow
                        className="header-row-margin-left"
                        onClick={() => history.push('/content/privacy-policy')}
                      >
                        <div className="p-0">
                          <IonIcon
                            icon={chevronForwardOutline}
                            slot="start"
                            size="medium"
                            className="test cursor-pointer"
                          />
                        </div>
                      </IonRow>
                    </div>
                  </IonCol>
                  <IonCol sizeMd="6" sizeXs="12" className="ion-no-padding pb-0">
                    <div
                      className="myprofile-feeds ion-no-padding box-group
                        ion-padding-end ion-padding-bottom"
                    >
                      <IonRow className="ion-padding-start">
                      {t('appproperties.text133')}
                      </IonRow>
                      <IonRow
                        className="header-row-margin-left"
                        onClick={() => history.push('/content/terms')}
                      >
                        <div className="p-0">
                          <IonIcon
                            icon={chevronForwardOutline}
                            slot="start"
                            size="medium"
                            className="test cursor-pointer"
                          />
                        </div>
                      </IonRow>
                    </div>
                  </IonCol>
                </IonRow>
              </IonCard>
            </IonCol>
            </IonRow>
            <IonRow className='mb-4 mb-lg-0'>
              <div className="ion-text-center ion-margin-top mx-auto">
                <IonButton
                  type="submit"
                  className="ion-button-color setting-button  "
                >
                  {t('appproperties.text64')}
                </IonButton>
              </div>
            </IonRow>
          </form>
        </IonRow>
       {/* )} */}
      <ToastCommon
        setShowToast={setShowToast}
        setShowToastMsg={setShowToastMsg}
        showToast={showToast}
        showToastMsg={showToastMsg}
        duration={3000}
      />
    </IonRow>
  );
};
export default Settings;