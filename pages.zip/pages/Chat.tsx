/* eslint-disable multiline-ternary */
import { IonAvatar, IonCol, IonRow, IonCard, IonHeader, IonCardContent, IonCardHeader, IonFooter, IonInput, IonButton, IonItem, IonLabel, IonIcon } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router';
import callFor from '../util/CallFor';
import AsyncSelect from 'react-select/async';
import { components } from 'react-select';
import { useTranslation } from 'react-i18next';
import userProfile from '../assets/img/user-profile-placeholder.png';
import ScrollToBottom from 'react-scroll-to-bottom';
import ChatList from '../components/common/ChatList';
import Messages from '../components/common/Messages';
import { arrowBack, searchOutline, send, sendOutline } from 'ionicons/icons';
let stompClient: any;

const Chat = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const { userId } = useParams() as any;
  const [inputMsg, setInputMsg] = useState('');
  const [textmsg, setTextMsg] = useState('');
  const [msges, setMsges] = useState<any[]>([]);
  const [activeContact, setActiveContact] = useState<any>();
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const [msgShow, setMsgShow] = useState(false);
  const isOnline = true;

  useEffect(() => {
    let subscribe = true;
    if (subscribe && userId) {
      connect();
      loadContacts();
    }

    return () => {
      subscribe = false;
    };
  }, []);
  useEffect(() => {
    let subscribe = true;
    if (subscribe) {
      if (userId && activeContact?.id) {
        getMsgList();
      }
    }

    return () => {
      subscribe = false;
    };
  }, [activeContact]);

  async function loadContacts() {
    const users = await getChatHistory();
    const contactPromise = await users?.map(async (user: any) => {
      const temp = Object.assign({}, user);
      const count = await countNewMessages(user.id, userId);
      temp.newMessagesCount = await count;
      return temp;
    });

    if (contactPromise !== undefined) {
      const contacts = await Promise.all(contactPromise);
      setChatHistory(contacts);
    }
  };

  const countNewMessages = async (senderId: any, receiverId: any) => {
    try {
      const response = await fetch(
        `http://192.168.7.64:8080/messages/${senderId}/${receiverId}/count`
      );
      const newMessagesCount = await response.json();
      return newMessagesCount;
    } catch (err) {
      console.log(err);
    }
  };
  const getMsgList = async () => {
    try {
      const response = await fetch(
        `http://192.168.7.64:8080/messages/${activeContact?.id}/${userId}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ page: 0 })
        }
      );
      const messages = await response.json();
      loadContacts();
      setMsges(messages.data.content);
    } catch (error) {
      console.log(error);
    }
  };

  const getChatHistory = async () => {
    try {
      const chatResponse = await fetch('http://192.168.7.64:8080/chat-room', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Z-AUTH-USERID': `${userId}`
        },
        body: JSON.stringify({ page: 0 })
      });
      const chHistory = await chatResponse.json();
      return chHistory.data.content;
    } catch (error) {
      console.log(error);
    }
  };

  const connect = () => {
    const Stomp = require('stompjs');
    let SockJS = require('sockjs-client');
    SockJS = new SockJS('http://192.168.7.64:8080/ws');
    stompClient = Stomp.over(SockJS);
    stompClient.connect({}, onConnected, onError);
  };
  const onConnected = () => {
    stompClient.subscribe('/user/' + userId + '/queue/messages', onMessageReceived);
  };
  const onError = (err: any) => {
    console.log(err);
  };
  const getMsg = async (id: any) => {
    try {
      const res = await fetch(`http://192.168.7.64:8080/messages/${id}`);
      const message = await res.json();
      return message;
    } catch (error) {
      console.log(error);
    }
  };
  const onMessageReceived = async (msg: any) => {
    const notification = JSON.parse(msg.body);
    const active = JSON.parse(sessionStorage.getItem('activeContact') || '');
    if (active?.id === notification.senderId) {
      const active = JSON.parse(sessionStorage.getItem('activeContact') || '');
      if (active?.id === notification.senderId) {
        const newMessage = await getMsg(notification.id);
        setMsges((prev: any) => [newMessage, ...prev]);
      }
      loadContacts();
    };
  };
  const sendMessage = (msg: any) => {
    if (String(msg).trim() !== '') {
      const message = {
        senderId: userId,
        receiverId: activeContact?.id,
        content: msg
      };
      stompClient.send('/app/chat', {}, JSON.stringify(message));
      setMsges((prev: any) => [{ ...message, createdOn: new Date() }, ...prev]);
      setInputMsg('');
    }
  };
  const CustomOption = (props: any) => {
    const { data, innerRef, innerProps } = props;
    return data.custom
      ? (
        <div ref={innerRef} {...innerProps}>
          link
        </div>
      )
      : (
        <components.Option {...props} />
      );
  };
  const selectClickHandler = (details: any) => {
    if (details.id !== userId) {
      setActiveContact(details);
      sessionStorage.setItem('activeContact', JSON.stringify(details));
      setChatHistory((prev: any) => [details, ...prev]);
    }
  };
  const selectCurrentUserHandler = (details: any) => {
    setActiveContact(details);
    setMsgShow(true);
    sessionStorage.setItem('activeContact', JSON.stringify(details));
  };
  const promiseOptions = (inputValue: string) =>
    new Promise<any>((resolve) => {
      resolve(filterSearchData(inputValue));
    });

  const filterSearchData = async (inputValue: string) => {
    if (inputValue.trim().length >= 3) {
      const productsRes: any = await callFor(
        `api/v1.1/searches/keywords/${inputValue}/types/USER?page=0&size=5`,
        'GET',
        null,
        'Auth'
      );
      if (productsRes.status === 200) {
        const json1Response: any = await productsRes.json();
        const options = await json1Response.data.user.map((details: any) => ({
          value: details.id,
          label: (
            <div>
              <IonRow className='ion-align-items-center' onClick={() => selectClickHandler(details)}>
                <IonAvatar className="MuiAvatar ion-margin-end avr-small">
                  {details.profileImg !== null
                    ? <img onError={(ev: any) => {
                      ev.target.src = userProfile;
                    }}
                      src={details.profileImg} className="MuiAvatar-circular" />
                    : <img src={userProfile} className="MuiAvatar-circular" />
                  }
                </IonAvatar>
                <span className='result-user-option'>
                  <b className='fixed-textline2'>{details.fullName}</b>
                </span>
              </IonRow>
            </div>
          )
        }));
        return options;
      }
    }
    return '';
  };
  const customStyles = {
    control: (provided: any) => ({
      ...provided,
      background: 'rgb(231 237 245)',
      border: '1px solid #e7edf5 !important',
      '&:focus': {
        border: '0px solid #e7edf5 !important',
        outline: 'none !important'
      }
    }),
    indicatorSeparator: () => { }, // removes the "stick"
    dropdownIndicator: (defaultStyles: any) => ({
      ...defaultStyles,
      '& svg': { display: 'none' }
    })
  };
  const onSearchFocus = () => {
    setTextMsg('');
  };
  const inputChangeHandler = (e: any) => {
    setInputMsg(e.target.value);
  };
  const removeMobileCss = () => {
    history.goBack();
    setMsgShow(false);
  };

  return (<>
    <div className='mobilechat h-100'>
      {msgShow ? <>

        {/* messages section */}
        {activeContact &&
        <div>
          <IonCardHeader className="p-0 d-flex w-100 align-items-center">
          <div className="mobile-back-screen show-mobile back-icon-mobile show-mobile position-relative">
            <IonIcon
              className="icon-mobile"
              icon={arrowBack}
              onClick={removeMobileCss}>
            </IonIcon>
          </div>
          <div>
          <h5 className='ps-3'>Chat list</h5>
          </div>
          </IonCardHeader>
          <IonCard className='m-0 chat-bg'>
            {/* chat Header */}
            <IonCardHeader className="p-0 ps-2">
              <IonAvatar
                slot="start"
                className="mx-md-auto"
              >
                {activeContact.profileImg
                  ? <img src={activeContact.profileImg} alt={activeContact.fullName} />
                  : <img src={userProfile} alt={'username'} />}

              </IonAvatar>
              <h6>{activeContact.fullName}</h6>
            </IonCardHeader>

            {/* chat Area */}
            <IonCardContent className='p-0 chatbox'>
              <ScrollToBottom>
                <Messages messages={msges} userId={userId} />
              </ScrollToBottom>
            </IonCardContent>
          </IonCard>
          {/* input area */}
          <IonFooter className='position-absolute chat-footer'>
              <IonItem lines="none" className='d-flex ion-align-items-stretch'>
                <IonInput
                  autocomplete="off"
                  type="text"
                  className="input-box input-custom-width"
                  placeholder='Start new message'
                  onIonChange={inputChangeHandler}
                  value={inputMsg}
                  onKeyPress={(e) =>
                    e.key === 'Enter' ? sendMessage(inputMsg) : null
                  }
                />
                 <div onClick={() => sendMessage(inputMsg)} className='blue-bg align-items-center blue-bg d-flex font-16 justfy-mobile-center'>
                <IonIcon icon={send} className='color-white'/>
              </div>
              </IonItem>
            </IonFooter>
        </div>}
      </> : <IonRow>
        <IonCard className="all-company-list-show profile-details MuiPaper-rounded ion-no-margin ion-margin-top ion-margin-bottom follower-list-card my-company-list grouplist-card ion-no-padding ion-padding-horizontal ion-padding-bottom shadow-none border-0 companylist m-0">
          <IonHeader className="profile-header ion-no-border head-title-con">
            <div className='left-col-cn'>
              <h5 className='mb-0'>Chat</h5>
            </div>
          </IonHeader>
        </IonCard>
        {/* heading */}

        {/* search bar */}
        <IonCol size-lg="4" size-md="12" size-sm="12" size-xs="11" className="icon-input-left autoSearchContent">

          <AsyncSelect
            placeholder={t('appproperties.text92')}
            id="comments"
            name="comments"
            onFocus={onSearchFocus}
            value={textmsg ? { label: textmsg } : { label: t('appproperties.text92') }}
            cacheOptions
            loadOptions={promiseOptions}
            className="header-search ms-2"
            defaultOptions
            styles={customStyles}
            components={{ Option: CustomOption }}
            noOptionsMessage={() => t('nodatafound.text11')} />
          <IonIcon
            icon={searchOutline}
            size="small"
            className="header-menu-img" />
        </IonCol>
        {/* chat lists */}
        <IonRow className="member-listing w-100 chat-listing">
          {chatHistory.length > 0 &&
            (chatHistory?.map((history: any, i: number) => <div key={i} onClick={() => selectCurrentUserHandler(history)}>
              <ChatList
                defultImage={userProfile}
                img={history.profileImg}
                name={history.fullName}
              />
              <p>{history?.newMessagesCount > 0 && <span>{history?.newMessagesCount}</span>
              }</p>
            </div>
            )
            )
          }
        </IonRow>
      </IonRow>
      }
    </div>
  </>);
};
export default Chat;
