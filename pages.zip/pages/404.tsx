import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
const s404 = () => {
  const { t } = useTranslation();
  return (
    <><section className="AboutusHeading AboutusHeading1 wow fadeIn heading-background sts-web home-title" style={{ height: '350px' }}>
          <div className="container">
              <h1 className="text-center WhiteText wow fadeInUp" style={{ fontSize: '65px' }}> Page doesn't exist!</h1>
              <h4 className="text-center WhiteText wow fadeInUp">Sorry, the page you were looking for could not ne found.</h4>
          </div>
      </section><section className="features" style={{ color: '#616161', fontFamily: 'sans-serif' }}>
              <div className="container" style={{ textAlign: 'center', paddingTop: '100px' }}>
                   <p> You can return to our  <Link to={'zyapaarhome'}>Home Page</Link> <span> | </span>
                      <Link to={'contact-us'}>{t('signuprecommendation.text11')}</Link> if you can't find what you are looking for. </p>
              </div>
          </section></>
  );
};

export default s404;
