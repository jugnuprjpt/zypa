import { IonRow, IonCol, IonAvatar, IonCard, IonHeader, IonList, IonContent } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import SkeletonActivityComon from '../components/common/skeleton/SkeletonActivityComon';
import Footer from '../components/Layout/Footer';
import CallFor from '../util/CallFor';
import image from '../assets/img/user-profile-placeholder.png';
// import CompanyProduct from '../components/company/CompanyProduct';
import { useParams } from 'react-router';
import CompanyProduct from '../components/company/CompanyProduct';
import { useTranslation } from 'react-i18next';
export const CompanyCatalogue = () => {
  const { t } = useTranslation();
  const [comapny, setComapny] = useState([]);
  const [aboutDetails, setAboutDetails] = useState({});
  const [classMobile, setClassMobile] = useState(false);
  const { userId } = useParams();
  const [loading, setLoading] = useState(false);
  const [companyId, setCompanyId] = useState();

  useEffect(() => {
    getComanyData();
  }, []);

  async function getComanyData() {
    setLoading(true);
    const companyData = await CallFor(
      'api/v1.1/companies?userId=' + userId,
      'GET',
      null,
      'Auth'
    );
    if (companyData.status === 200) {
      const json1Response = await companyData.json();
      if (json1Response.data !== null && json1Response.data.length > 0) {
        setComapny(json1Response.data);
        setCompanyId(json1Response.data[0].id);
        setAboutDetails({ owner: json1Response.data[0].owner });
      }
    }
    setLoading(false);
  };
  const myCompanyDetails = (id, ownerFlag) => {
    // props.getTeamMember(id);
    setCompanyId(id);
    setClassMobile(true);
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
    setAboutDetails({ owner: ownerFlag });
  };
  return (

    <IonRow className="plane-bg">
      <IonRow className="container">
        <div className={classMobile ? 'showpage row full-width-row main-page-content-row' : 'row full-width-row main-page-content-row'}>
          <IonCol size-lg="4" size-md="12" size-xs="12" className="left-col ion-no-padding">
            <div className='sidebar-main'>
              <IonCard className={classMobile ? 'showpage sdb-box profile-details left-cards no-shadow sidebar-pages md hydrated my-company-details-mobile' : 'sdb-box profile-details no-shadow sidebar-pages md hydrated my-company-details-mobile'}>
                <IonHeader className="card-header-text ion-align-items-center ion-justify-content-between md header-md header-collapse-none hydrated  mtm-0 mbm-5">
                  <p className="ion-align-self-start">{t('companyproperties.text1')}</p>
                </IonHeader>
                <IonRow className='custom-scroll'>
                  {loading
                    ? <SkeletonActivityComon />
                    : comapny.length > 0
                      ? <div className='company-list-details w-100 mt-1 p-0 company-bottom-border'>
                        {
                          comapny.map((detail, i) => {
                            return (
                              // eslint-disable-next-line react/jsx-key
                              <IonList lines="none" key={i} className={companyId === detail.id ? 'full-width-row pb-0 activeCatalogue' : 'full-width-row pb-0'} >
                                <IonRow onClick={() => myCompanyDetails(detail.id, detail.owner)}>
                                  <IonRow className='cursor-pointer item'>
                                    <div className="myprofile-feeds ion-no-padding cursor-pointer">
                                      {detail.entityLogo
                                        ? (<IonAvatar className="MuiAvatar ion-margin-end">
                                          <img onError={(ev) => { ev.target.src = image; }} src={detail.entityLogo} alt={t('appproperties.text267')} />
                                        </IonAvatar>)
                                        : (<IonAvatar className="MuiAvatar ion-margin-end">
                                          <img src={image} alt={t('appproperties.text267')} />
                                        </IonAvatar>
                                        )}
                                      <IonRow className='display-grid'>
                                        <div className='fixed-textline2'>{detail.name}</div>
                                        <span className="margin MuiTypography-caption group-model-text fixed-textline2">
                                          {detail.city + ' ' + (detail.state ? ' | ' + detail.state : ' ')}
                                        </span>
                                      </IonRow>
                                    </div>
                                  </IonRow>
                                </IonRow>
                              </IonList>
                            );
                          })
                        }
                      </div>
                      : <IonRow className='ion-padding'> !!</IonRow>}
                </IonRow>
              </IonCard>
              <Footer />
            </div>
          </IonCol>
          <IonCol size-lg="8" size-md="12" size-xs="12" className="left-col ion-no-padding mobile-overlay-screen back-screen-mobile">
            <IonContent className="scrolling">
              {companyId
                && <CompanyProduct userId={userId} admin={aboutDetails.owner} aboutDetails={aboutDetails} companyId={companyId} key={companyId} setClassMobile={setClassMobile} />
              }
            </IonContent>
          </IonCol>
        </div>
      </IonRow>
    </IonRow>

  );
};
export default CompanyCatalogue;
