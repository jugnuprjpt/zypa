import { IonCard, IonCardContent, IonCol, IonRow } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import MetaTags from 'react-meta-tags';
import SendOtp from '../components/login/SendOtp';
import VerifyOtp from '../components/login/VerifyOtp';
import DesktopLogin from '../assets/img/login/desktop-login.svg';
import MobileOTP from '../assets/img/login/mobile-otp.svg';
import MobileLogin from '../assets/img/login/mobile-login.svg';

const Login = () => {
    const [showSendOtpComponent, setshowSendOtpComponent] = useState(true);
    const [mobileNo, setMobileNo] = useState('');
    const [refcode, setRefcode] = useState();
    useEffect(() => {
        // change by Prachi solve By Mayur Patel
        const data = JSON.parse(localStorage.getItem('refcode') || null);
        setRefcode(data);
    }, [])
    return (
        <>
            <MetaTags>
                <title>Zyapaar</title>
            </MetaTags>
            <IonRow className='loginPage h-100 overflow-hidden'>
                <IonCol sizeMd="6" sizeXs="12" className='leftpart d-none d-md-block'>
                    <div className='d-flex align-items-center justify-content-center h-100'>
                        <img src={DesktopLogin} alt="Login" className='zindex9 d-none d-lg-block' width='550' />
                    </div>
                    <ul className="circles position-absolute overflow-hidden d-none d-md-block">
                        <li /><li /><li /><li /><li /><li /><li /><li /><li /><li />
                    </ul>
                </IonCol>

                <IonCol sizeMd="6" sizeXs="12" className='rightpart p-lg-2 p-0 bg-white'>
                    {showSendOtpComponent
                        ? (
                            <div
                                className='mobileimg zindex99 d-block d-lg-none w-100 position-absolute'
                                setshowSendOtpComponent={setshowSendOtpComponent}
                            >
                                <img src={MobileLogin} alt="Login" className='d-flex m-auto' width='360' />
                            </div>
                        )
                        : (
                            <div className='mobileimg mobileotp zindex99 d-block d-lg-none w-100 position-absolute'>
                                <img src={MobileOTP} alt="Login" className='d-flex m-auto' width='360' />
                            </div>
                        )}
                    <IonCol className='h-100 d-flex p-lg-2 p-0'>
                        <IonCard className='shadow-none w-lg-75 w-xl-50 mx-auto my-lg-auto mt-lg-auto mt-0 w-100 border-0'>
                            <IonCardContent className='mb-lg-4 px-4 px-lg-1 h-100 h-lg-auto'>
                                {showSendOtpComponent
                                    ? (
                                        <SendOtp
                                            setshowSendOtpComponent={setshowSendOtpComponent}
                                            setMobileNo={setMobileNo} />)
                                    : (
                                        <VerifyOtp mobileNo={mobileNo} />
                                    )}
                            </IonCardContent>
                        </IonCard>
                    </IonCol>
                </IonCol>
            </IonRow>
        </>
    );
};
export default Login;
