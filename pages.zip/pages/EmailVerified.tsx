import { IonCard, IonCol, IonRow } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import ReactLoading from 'react-loading';
import { Link, useParams } from 'react-router-dom';
import ZyapaarLogo from '../assets/img/logo.svg';
import EmailVerify from '../assets/img/email-verification.svg';
import callFor from '../util/CallFor';

const EmailVerified = () => {
  const { userId, hash } = useParams();
  const [isloader, setLoader] = useState(false);
  const [isMessage, setMessage] = useState('');
  const [isError, setError] = useState(false);
  useEffect(() => {
    VerifyEmail();
  }, []);

  const VerifyEmail = async() => {
    const response = await callFor(
            `api/v1/verifyEmail/${userId}/${hash}`,
            'GET',
            null,
            'Auth'
    );
    if (response.status === 200) {
      setMessage('Your email verified successfully');
      setLoader(true);
    } else if (response.status === 400) {
      const json1Resp = await response.json();
      setMessage(json1Resp.error.message);
      setLoader(true);
      setError(true);
    } else {
      setMessage('Something went wrong');
      setLoader(true);
      setError(true);
    }
  };

  return (
        <IonRow className='email-verified h-100 overflow-hidden'>
            <IonCol className='d-flex ion-justify-content-center ion-align-items-center'>
                 <IonCard className='p-5 w-lg-35'>
                    <img src={ZyapaarLogo} alt="Zyapaar Logo" className='logo position-absolute' />
                    <div className='text-center'>
                        {!isloader
                          ? <>
                                <div className='d-flex ion-justify-content-center ion-align-items-center h-300'>
                                    <div className="loader">
                                        <div key="spokes">
                                            <ReactLoading type="spin" color="#fff" />
                                        </div>
                                    </div>
                                </div>
                            </>
                          : <>
                                <div className='fade-in-text'>
                                    <img src={EmailVerify} alt='Email Verify' width='60' />
                                    <h1 className='mb-3'>{isMessage}</h1>
                                    {!isError
                                      ? <><p>
                                          Hello Zyapaari, Your email id is verified successfully! <br />
                                      </p></>
                                      : '' }
                                      <div className='d-flex ion-justify-content-center ion-align-items-center'>
                                              <Link
                                                  to='/home'
                                                  className='btn-home mt-lg-5 mt-4 pe-0 overflow-hidden d-flex ion-justify-content-center ion-align-items-center me-3'
                                              >
                                                  Go to zyapaar
                                              </Link>
                                          </div>
                                </div>
                            </>
                        }
                    </div>
                </IonCard>
            </IonCol>
        </IonRow>
  );
};
export default EmailVerified;
