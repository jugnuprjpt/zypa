/* eslint-disable multiline-ternary */
/* eslint-disable no-redeclare */
/* eslint-disable import/no-duplicates */
import React, { useEffect, useState } from 'react';
import {
  IonModal, IonLabel, IonContent, IonCard, IonCardTitle, IonCol, IonHeader, IonIcon, IonRow, IonInfiniteScroll,
  IonInfiniteScrollContent, useIonViewWillEnter, IonList, IonButton, useIonPopover
} from '@ionic/react';
import TeamMember from '../components/myPage/TeamMember';
import CallFor from '../util/CallFor';
import { useHistory, useParams } from 'react-router';
import { arrowBack, close, ellipsisVertical } from 'ionicons/icons';
import { Link } from 'react-router-dom';
import userLogo from '../assets/img/user-profile-placeholder.png';
import companyProfile from '../assets/img/banner-placeholder.png';
import companyProfileLogo from '../assets/img/page-company-profile-placeholder.png';
import MetaTags from 'react-meta-tags';
import SkeletonComonViewAll from '../components/common/skeleton/SkeletonComonViewAll';
import SkeletonComonViewDetais from '../components/common/skeleton/SkeletonComonViewDetail';
import ImageEditModal from '../components/myPage/ImageEditModal';
import CommonGridList from '../components/common/CommonGridList';
import { setLocalStore } from '../util/Common';
import ButtonComponent from '../components/common/ButtonComponent';
import ToastCommon from '../components/common/ToastCommon';
import ConfirmModelCommon from '../components/common/ConfirmModelCommon';
import { useTranslation } from 'react-i18next';
const Teams = (props) => {
  const { t } = useTranslation();
  const { companyId, userId } = useParams();
  const [confirmModel, setConfirmModel] = useState(false);
  const history = useHistory();
  const [companyDetail, setCompanyDetails] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [count, setCount] = useState(0);
  const [scrollData, setScrollData] = useState<object[]>([]);
  const [teamMember, setTeamMember] = useState<object[]>([]);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [classMobile, setClassMobile] = useState(true);
  const [loading, setLoading] = useState(false);
  const [showModelProfilePicture, setshowModelProfilePicture] = useState(false);
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    getcompanyDetail(companyId);
    // getTeamMemberOnScroll();
  }, []);

  const getcompanyDetail = async(paramCompanyId) => {
    setLoading(true);
    const response = await CallFor(
      'api/v1.1/companies/details/' + paramCompanyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data !== null) {
        if (!json1Response.data.hide) {
          getTeamMember(companyId);
        }
        setCompanyDetails(json1Response.data);
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setLoading(false);
  };
  const [teamLoading, setTeamLoading] = useState(false);
  const getTeamMember = async(paramCompanyId) => {
    setTeamLoading(true);
    const stateres = await CallFor('api/v1.1/companies/' + paramCompanyId + '/ALL', 'POST', '{"page": 0 }', 'Auth');
    if (stateres.status === 200) {
      const json1Response = await stateres.json();
      if (json1Response.data.content !== null) {
        setScrollData(json1Response.data.content);
        setTeamMember(json1Response.data.content);
        setCount(count + 1);
      }
    } else if (stateres.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setTeamLoading(false);
    setCount(1);
  };
  const getTeamMemberOnScroll = async() => {
    const stateres = await CallFor('api/v1.1/companies/' + companyId + '/ALL', 'POST', '{"page": ' + count + '}', 'Auth');
    if (stateres.status === 200) {
      const json1Response = await stateres.json();
      if (json1Response.data.content.length > 0) {
        setScrollData([...scrollData, ...json1Response.data.content]);
      } else {
        setInfiniteDisabled(true);
      }
      setCount(count + 1);
    } else if (stateres.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  useIonViewWillEnter(async() => {
    getTeamMemberOnScroll();
  });

  function searchNext(ev: any) {
    setTimeout(() => {
      getTeamMemberOnScroll();
      ev.target.complete();
    }, 500);
  }
  const viewPaginaction = () => {
    setShowModal(true);
    getTeamMemberOnScroll();
  };
  const closemodel = () => {
    setCount(1);
    setShowModal(false);
    setScrollData(teamMember);
    setInfiniteDisabled(false);
  };
  if (classMobile) {
    document.getElementsByTagName('html')[0].classList.add('mobileOverlayHandel');
  } else {
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  }
  const removeMobileCss = () => {
    setClassMobile(false);
    document.getElementsByTagName('html')[0].classList.remove('mobileOverlayHandel');
  };
  const encodedString = (str) => {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
      return String.fromCharCode(parseInt(p1, 16));
    }));
  };
  const encodedCompanyName = encodedString(companyDetail.name);

  // for mobile
  const PopoverList: React.FC<{
    onHide: () => void
  }> = ({ onHide }) => (
    <><IonList className="my-account-pr">
      {/* <IonButton fill="clear" onClick={memberinvite} className="link-btn-tx">
      Add Team Member
    </IonButton> */}
    </IonList><IonList className="my-account-pr">
        <IonButton fill="clear" onClick={() => { onHide(); admin(); }} className="link-btn-tx">
          {t('appproperties.text191')}
        </IonButton>
      </IonList></>
  );
  const [present, dismiss] = useIonPopover(PopoverList, {
    onHide: () => dismiss()
  });// for mobile
  const admin = () => {
    dismiss();
    setLocalStore('companyOwner', encodedString(companyDetail.owner).replace('/', '&quot;'));
    setLocalStore('companyAdmin', encodedString(companyDetail.admin).replace('/', '&quot;'));
    history.push('/manageCompanyTeam/' + companyId + '/' + encodedCompanyName.replace('/', '&quot;'));
  };

  const leaveBtn = () => {
    setConfirmModel(true);
  };
  const leaveSubmitBtn = async() => {
    const response = await CallFor(
      'api/v1.1/companies/member/leave/' + companyId,
      'GET',
      null,
      'Auth'
    );
    if (response.status === 200) {
      setShowToastMsg(t('toastmessages.toast2'));
      setShowToast(true);
      getcompanyDetail(companyId);
    } else if (response.status === 400) {
      const json1Response = await response.json();
      console.log(json1Response);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  const joinBtn = async() => {
    const response = await CallFor(
      'api/v1.1/companies/' + companyId + '/team/join',
      'POST',
      null,
      'Auth'
    );
    if (response.status === 201) {
      setShowToastMsg(t('toastmessages.toast3'));
      setShowToast(true);
      getcompanyDetail(companyId);
    } else if (response.status === 400) {
      const json1Response = await response.json();
      console.log(json1Response);
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
  };
  return (
    <><MetaTags>
      <title>
        Zyapaar
      </title>
    </MetaTags>
      <IonRow className="plane-bg">
        <IonRow className="container">
          <div className={classMobile ? 'showpage row full-width-row main-page-content-row' : 'row full-width-row main-page-content-row'}>
            <IonCol size-lg="4" size-md="12" size-xs="12" className="left-col ion-no-padding">
              <div className='sidebar-main'>
                <TeamMember setClassMobile={setClassMobile} classMobile={classMobile} userId={userId} companyId={companyId} getTeamMember={getTeamMember} getcompanyDetail={getcompanyDetail} />
              </div>
            </IonCol>
            <IonCol size-lg="8" size-md="12" size-xs="12" className="left-col ion-no-padding mobile-overlay-screen back-screen-mobile">
              <div className='mobile-back-screen show-mobile back-icon-mobile' >
                <IonIcon className='icon-mobile' icon={arrowBack} onClick={removeMobileCss}></IonIcon>
              </div>
              {!loading
                ? <IonCard className="MuiPaper-rounded ion-no-margin ion-margin-top profile-card-content mtm-0">
                  <ImageEditModal
                    id={companyId}
                    image={companyDetail.cover}
                    defultLogo={companyProfile}
                    serviceType='COMPANY'
                    getDetails={getcompanyDetail}
                    logo='COVER'
                    aspect={22 / 4.5}
                    cropShape={'rect'}
                    className='cover-photo'
                    cssClass='edit-img model-img-hei-width CoverPhotoMain'
                    isAdmin={companyDetail.admin}
                    reportHideState={props.reportHideState}
                    isHide={companyDetail.hide}
                  />
                  <div className="profile-card-body">
                    <div className="profile-avt-content">
                      <ImageEditModal
                        id={companyId}
                        image={companyDetail.entityLogo}
                        defultLogo={companyProfileLogo}
                        serviceType='COMPANY'
                        getDetails={getcompanyDetail}
                        logo='LOGO'
                        aspect={1}
                        cropShape={'round'}
                        className='logo-photo'
                        cssClass='edit-img model-img-hei-width'
                        isAdmin={companyDetail.admin}
                        reportHideState={props.reportHideState}
                        isHide={companyDetail.hide}
                        background={true}
                      />

                    </div>
                    <div className="profileName w-100">
                      <IonCardTitle>
                        <h4 className="margin fixed-textline2">
                          {companyDetail.name}
                        </h4>
                        <p className='color-grey font-14 font-regular fixed-textline2'>
                          {companyDetail.addressLine1 !== '' && companyDetail.addressLine1 !== null && companyDetail.addressLine2 !== '' && companyDetail.addressLine1 !== null &&
                            <>{companyDetail.addressLine1}  {companyDetail.addressLine2} | </>
                          }
                          {companyDetail.city} {companyDetail.firmPincode}
                        </p>
                        <p className='align-items-center color-grey d-flex font-regular'>
                          <p className='me-1'>{companyDetail.members}</p>
                          {t('appproperties.text190')}(s)
                        </p>
                      </IonCardTitle>
                      <div className='d-flex justify-content-end align-items-center'>
                        {companyDetail.owner !== true
                          ? <>
                            {companyDetail.status === null
                              ? <ButtonComponent
                                btnClick={joinBtn}
                                className='ion-button-color mt-2 pe-0'
                                size='small'
                                name={t('appproperties.text237')} parametersPass={0} />
                              : companyDetail.status === 'accept'
                                ? companyDetail.admin !== true
                                  ? <ButtonComponent
                                    btnClick={leaveBtn}
                                    className='ion-button-color mt-2 pe-0'
                                    size='small'
                                    name={t('appproperties.text243')} parametersPass={0} />
                                  : ''
                                // : companyDetail.status === 'join'
                                //   ? <ButtonComponent
                                //    btnClick={requestedBtn}
                                //    className='ion-button-color mt-2 pe-0'
                                //    size ='small'
                                //    name='Requested' parametersPass={0} />
                                : ''}
                          </>
                          : ''}
                      </div>
                    </div>
                  </div>
                </IonCard>
                : <SkeletonComonViewDetais />}
              {
                companyDetail.hide !== true
                  ? <IonCard className="MuiPaper-rounded ion-margin-top ion-margin-bottom ion-padding ion-no-margin follower-list-card shadow-none">
                    <IonHeader className="profile-header ion-no-border head-title-con">
                      <div className='left-col-cn mt-3'>
                        <h4>{t('appproperties.text190')}</h4>
                      </div>
                      {(() => {
                        if (companyDetail.admin === true) {
                          return (
                            <><div className='right-col-cn gup-btn-action dn-mobile'>
                              {/* <Link to={'/memberinvite/' + companyDetail.id + '/' + encodedCompanyName.replace('/', '&quot;')} className="link-btn-tx">
                                  Add Team Member
                                </Link> */}
                              <div className="link-btn-tx cursor-pointer" onClick={admin}>
                                {t('appproperties.text191')}
                              </div>
                              {teamMember.length >= 8
                                ? <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
                                  {t('commonproperties.text3')}
                                </div>
                                : ''}
                            </div>
                              {/* for mobile */}
                              <div className="dot-btn show-mobile">
                                <IonIcon
                                  icon={ellipsisVertical}
                                  slot="start"
                                  className="test report cursor-pointer"
                                  onClick={(e) => present({ event: e.nativeEvent })} />
                              </div>
                              {/* for mobile */}
                            </>
                          );
                        } else {
                          return (<>{teamMember.length >= 8
                            ? <div className='right-col-cn gup-btn-action dn-mobile'>
                              <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
                                {t('commonproperties.text3')}
                              </div>
                            </div> : ''}</>
                          );
                        }
                      })()}
                    </IonHeader>
                    <IonRow className="ion-padding-top ptm-0 member-listing">
                      {teamMember.length > 0
                        ? <>
                          {teamMember.map((detail, i) => (
                            <CommonGridList key={i} id={detail.id} defultImage={userLogo} img={detail.profileImg} name={detail.firstName + ' ' + detail.lastName}
                              subString={detail.profileTitle} dots={false} redirectLink='profile' />
                          ))}
                        </> : teamLoading
                          ? <>
                            <SkeletonComonViewAll column={8} sizeMd={3} sizeXs={6} name={true} title={true} distription={false} link={false} />
                          </>
                          : <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">Team member Not Found</p>
                      }
                    </IonRow>
                    {teamMember.length >= 8
                      ? <div className='right-col-cn gup-btn-action view-all-mobile'>
                        <div onClick={viewPaginaction} className="link-btn-tx cursor-pointer">
                          {t('commonproperties.text3')}
                        </div>
                      </div> : ''}
                  </IonCard>
                  : <p className="ion-padding-top ion-margin-top ion-padding-bottom ion-margin-bottom bg-light w-100 ion-text-center bg-light">
                    {t('appproperties.text346')}
                  </p>
              }
            </IonCol>
          </div>
        </IonRow>

        <IonModal isOpen={showModal} cssClass="team-list-modal" onDidDismiss={() => closemodel()}>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-between">
            <IonLabel className="MuiTypography-h6">{t('commonproperties.text3')}</IonLabel>
            <Link
              onClick={closemodel}
              className="close ion-no-padding" to={''}
            >
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined" />
            </Link>
          </IonRow>
          <IonContent>
            <div className="modal-body">
              <div className="no-footer">
                <IonRow className="ion-padding-start ion-padding-end ion-padding-bottom member-listing">
                  {!loading
                    ? <>
                      {scrollData.map((detail, i) => (
                        // eslint-disable-next-line react/jsx-key
                        <CommonGridList key={i} id={detail.id} defultImage={userLogo} img={detail.profileImg} name={detail.firstName + ' ' + detail.lastName}
                          subString={detail.profileTitle} dots={false} redirectLink='profile' />
                      ))}
                    </>
                    : <SkeletonComonViewAll column={8} sizeMd={3} sizeXs={6} name={true} title={true} distription={false} link={false} />
                  }
                  <IonInfiniteScroll
                    onIonInfinite={searchNext}
                    threshold="100px"
                    disabled={isInfiniteDisabled}
                  >
                    <IonInfiniteScrollContent
                      loadingSpinner="circular"
                      loadingText={t('appproperties.text215')}
                    ></IonInfiniteScrollContent>
                  </IonInfiniteScroll>
                </IonRow>
              </div>
            </div>
          </IonContent>
        </IonModal>
      </IonRow>

      {/*  Profile Picture Zoom  */}
      <IonModal isOpen={showModelProfilePicture} cssClass="add-award-model awd-img-gallery" onDidDismiss={() => setshowModelProfilePicture(false)}>
        <IonContent>
          <IonRow className="MuiDialogTitle-root full-width-row modal-heading ion-padding-start ion-padding-end ion-align-items-center ion-justify-content-end ">
            <div onClick={() => setshowModelProfilePicture(false)} className="close ion-no-padding">
              <IonIcon
                icon={close}
                className="ion-button-color pr-0 "
                slot="start"
                size="undefined" />
            </div>
          </IonRow>
          <IonRow className="mx-auto d-flex justify-content-center overview-heigth">
            {companyDetail.entityLogo === null ||
              companyDetail.entityLogo === ''
              ? (
                <img src={companyProfile} />
                )
              : (
                <img onError={(ev) => { ev.target.src = companyProfile; }} src={companyDetail.entityLogo} />
                )}
          </IonRow>
        </IonContent>
      </IonModal>
      <ConfirmModelCommon
        header={t('appproperties.text282')}
        message={t('appproperties.text283')}
        btn1={t('appproperties.text11')}
        btn2={t('appproperties.text247')}
        confirmModel={confirmModel}
        setConfirmModel={setConfirmModel}
        deleteBtnHandler={leaveSubmitBtn}
      />
      <ToastCommon setShowToast={setShowToast} setShowToastMsg={setShowToastMsg} showToast={showToast} showToastMsg={showToastMsg} duration={5000} />
      {/*  Profile Picture Zoom  */}
    </>
  );
};

export default Teams;
