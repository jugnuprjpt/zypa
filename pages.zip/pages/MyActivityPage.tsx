import { IonCard, IonInfiniteScroll, IonInfiniteScrollContent, IonRow } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory, useParams } from 'react-router';
import ActivityComman from '../components/common/ActivityComon';
import SkeletonFeedComon from '../components/common/skeleton/SkeletonFeedComon';
import CallFor from '../util/CallFor';

const MyActivityPage = () => {
  const history = useHistory();
  const { t } = useTranslation();
  const { userId, userName } = useParams();
  useEffect(() => {
    getActivityList(0, userId, false);
  }, []);
  const [activityDetails, setActivityDetails] = useState([]);
  const [count, setCount] = useState(0);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [activityLoading, setActivityLoading] = useState(true);
  const getActivityList = async(count, paramUserId, scrolling) => {
    const response = await CallFor(
      'api/v1/user/activity?userId=' + paramUserId,
      'POST',
      '{"page": ' + count + ' }',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      if (json1Response.data.content !== null) {
        if (scrolling) {
          if (json1Response.data.content.length > 0) {
            setActivityDetails([
              ...activityDetails,
              ...json1Response.data.content
            ]);
          } else {
            setInfiniteDisabled(true);
          }
        } else {
          setActivityDetails(json1Response.data.content);
        }
      }
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setCount(count + 1);
    setActivityLoading(false);
  };
  const loadData = (ev: any) => {
    setTimeout(() => {
      getActivityList(count, userId, true);
      ev.target.complete();
    }, 500);
    setCount(count + 1);
  };
  return (
        <IonRow className="plane-bg">
        <IonRow className="container full-width-row myactivity-display-block">
            {activityLoading
              ? <SkeletonFeedComon column={5}/>
              : activityDetails.length > 0
                ? (
                    activityDetails.map((activity: any) => (
                <ActivityComman activity={activity} userName={userName} userId={userId}/>
                    ))
                  )
                : (
                <IonCard className="full-width-row MuiPaper-rounded ion-margin-top ion-margin-bottom ion-padding ion-no-margin follower-list-card">
                <p className="ion-padding-top ion-margin-top ion-padding-bottom bg-light w-100 ion-text-center bg-light">
                {t('nodatafound.text1')}
                </p>
                </IonCard>
                  )}
            <IonInfiniteScroll
        onIonInfinite={loadData}
        threshold="100px"
        disabled={isInfiniteDisabled}
        >
        <IonInfiniteScrollContent
        loadingSpinner="circular"
        loadingText={t('appproperties.text215')}
        ></IonInfiniteScrollContent>
        </IonInfiniteScroll>
        </IonRow>
    </IonRow>
  );
};
export default MyActivityPage;
