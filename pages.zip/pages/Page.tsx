/* eslint-disable no-lone-blocks */
/* eslint-disable react/jsx-key */
/* eslint-disable no-undef */
import {
  IonCol,
  IonRow
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import PageList from '../components/myPage/PageList';
import callFor from '../util/CallFor';
import { useHistory } from 'react-router';
import image from '../assets/img/page-logo-default.png';
import MetaTags from 'react-meta-tags';
import Footer from '../components/Layout/Footer';
import InterestedScrollCommon from '../components/common/InterestedScrollCommon';
import ButtonComponent from '../components/common/ButtonComponent';
import { useTranslation } from 'react-i18next';

const Page = () => {
  const { t } = useTranslation();
  const history = useHistory();
  const [intrestPage, setInreastPage] = useState([]);
  const [showModal, setShowModal] = useState(false);
  // const [classMobile, setClassMobile] = useState(false);
  // const [adminInvite, setAdminInvite] = useState([]);
  // const [inviteSentBtnClass, setInviteSentBtnClass] =
  //   useState('ion-button-color');
  // const [inviteReceivedClass, setinviteReceivedClass] =
  //   useState('category-btn-color');
  // const [getType, setType] = useState();
  useEffect(() => {
    // getPageData(0, false);
    viewRecursivegetPageDataList();
  }, []);
  // const [count, setCount] = useState();
  // const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  // const [requestloading, setRequestLoading] = useState(true);
  // const getinvitedlist = async(page, scrolling, type) => {
  //   if (!scrolling) {
  //     setRequestLoading(true);
  //   }
  //   setType(type);
  //   if (type === 'sent') {
  //     setInviteSentBtnClass('ion-button-color');
  //     setinviteReceivedClass('category-btn-color');
  //   } else {
  //     setInviteSentBtnClass('category-btn-color');
  //     setinviteReceivedClass('ion-button-color');
  //   }
  //   const response = await callFor(
  //     'api/v1.1/users/connections/' + type.toUpperCase() + '/PAGE',
  //     'POST',
  //     '{"page": ' + page + '}',
  //     'Auth'
  //   );
  //   if (response.status === 200) {
  //     const json1Response = await response.json();
  //     if (scrolling) {
  //       if (json1Response.data.content.length > 0) {
  //         setAdminInvite([
  //           ...adminInvite,
  //           ...json1Response.data.content
  //         ]);
  //       } else {
  //         setInfiniteDisabled(true);
  //       }
  //     } else {
  //       setAdminInvite(json1Response.data.content);
  //     }
  //   } else if (response.status === 401) {
  //     localStorage.clear();
  //     history.push('/login');
  //   }
  //   setCount(page + 1);
  //   if (!scrolling) {
  //     setRequestLoading(false);
  //   }
  // };
  // const loadData = (ev: any) => {
  //   setTimeout(() => {
  //     getinvitedlist(count, true, getType);
  //     ev.target.complete();
  //   }, 500);
  // };
  const openCreatePageModal = () => {
    setShowModal(true);
  };

  const getRecursivePageDataList = async(page: string | number) => {
    const response = await callFor(
      'api/v1.1/suggestions/pages',
      'POST',
      '{"page": ' + page + '}',
      'Auth'
    );
    if (response.status === 200) {
      const json1Response = await response.json();
      return json1Response.data.content;
    } else if (response.status === 401) {
      localStorage.clear();
      history.push('/login');
      return [];
    }
  };
  const viewRecursivegetPageDataList = async() => {
    const data = await getRecursivePageDataList(0);
    if (data !== undefined && data.length > 0) {
      const data1 = await getRecursivePageDataList(1);
      if (data1.length > 0) {
        const data2 = await getRecursivePageDataList(2);
        if (data2.length > 0) {
          const data3 = await getRecursivePageDataList(3);
          if (data3.length > 0) {
            setInreastPage([...data, ...data1, ...data2, ...data3]);
            setCountComon(4);
          } else {
            setInreastPage([...data, ...data1, ...data2]);
            setInfiniteDisabledComon(true);
          }
        } else {
          setInreastPage([...data, ...data1]);
          setInfiniteDisabledComon(true);
        }
      } else {
        setInreastPage(data);
        setInfiniteDisabledComon(true);
      }
    } else {
      setInfiniteDisabledComon(true);
    }
    setRequestLoadingComon(false);
  };

  const [requestloadingComon, setRequestLoadingComon] = useState(true);
  const [isInfiniteDisabledComon, setInfiniteDisabledComon] = useState(false);
  const [countComon, setCountComon] = useState(0);

  const getPageData = async(page, scrolling) => {
    if (!scrolling) {
      setRequestLoadingComon(true);
    }
    const responseData = await callFor(
      'api/v1.1/suggestions/pages',
      'POST',
      '{"page": ' + page + '}',
      'Auth'
    );
    if (responseData.status === 200) {
      const json1Response = await responseData.json();
      if (scrolling) {
        if (json1Response.data.content.length > 0) {
          setInreastPage([
            ...intrestPage,
            ...json1Response.data.content
          ]);
        } else {
          setInfiniteDisabledComon(true);
        }
      } else {
        setInreastPage(json1Response.data.content);
      }
    } else if (responseData.status === 401) {
      localStorage.clear();
      history.push('/login');
    }
    setCountComon(page + 1);
    if (!scrolling) {
      setRequestLoadingComon(false);
    }
  };
  const loadDataComon = (ev: any) => {
    setTimeout(() => {
      getPageData(countComon, true);
      ev.target.complete();
    }, 500);
  };

  return (
    <>
      <MetaTags>
        <title>
          Zyapaar
        </title>
      </MetaTags>
      <IonRow className="plane-bg ">
        <IonRow className="container">
          <div className="row full-width-row main-page-content-row">
            <IonCol
              size-lg="4"
              size-md="12"
              size-xs="12"
              className="left-col ion-no-padding"
            >
              <IonRow className='ion-margin-bottom mobile-heading-title mbm-0 pb-0 mt-1 d-flex d-lg-none'>
                <h3 className="page-title-hd ps-lg-3 ps-0">{t('appproperties.text18')}</h3>
                <ButtonComponent btnClick={openCreatePageModal}
                  className='ion-button-color ion-margin-top ml-auto no-pd-r pr-0 mtm-0'
                  size='small' name={t('pageproperties.text3')} parametersPass={0} />
              </IonRow>
              <div className='sidebar-main groups-bottom-border'>
                <InterestedScrollCommon
                  header={t('appproperties.text214')}
                  mapData={intrestPage}
                  fieldLink="/pageDetails/"
                  noDataFound={t('nodatafound.text32')}
                  image={image}
                  requestloadingComon={requestloadingComon}
                  loadDataComon={loadDataComon}
                  isInfiniteDisabledComon={isInfiniteDisabledComon}
                />
                <Footer />
              </div>
            </IonCol>
            <IonCol
              size-lg="8" size-md="12"
              size-xs="12"
              className="right-col ion-no-padding"
            >
              <IonRow className='ion-margin-bottom mobile-heading-title mbm-0 d-none d-lg-flex'>
                <h3 className="page-title-hd">{t('appproperties.text18')}</h3>
                <ButtonComponent btnClick={openCreatePageModal}
                  className='ion-button-color ion-margin-top ml-auto no-pd-r pr-0 mtm-0'
                  size='small' name={t('pageproperties.text3')} parametersPass={0} />
              </IonRow>
              <PageList setShowModal={setShowModal} showModal={showModal} />
            </IonCol>
          </div>
        </IonRow>
      </IonRow>
    </>
  );
};
export default Page;
