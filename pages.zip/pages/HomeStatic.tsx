import React, { useEffect, useRef, useState } from 'react';
import AndroidApp from '../assets/img/new-web/android-app.svg';
import IosApp from '../assets/img/new-web/ios-app.svg';
import register from '../assets/img/new-web/register.svg';
import buildnetwork from '../assets/img/new-web/build-network.svg';
import starttrade from '../assets/img/new-web/start-trade.svg';
import thumb from '../assets/img/new-web/thumb.svg';
import seller from '../assets/img/new-web/seller.svg';
import buyer from '../assets/img/new-web/buyer.svg';
import product from '../assets/img/new-web/products.svg';
import download from '../assets/img/new-web/download.svg';
// import banner from '../assets/img/new-web/banner-img.svg';
import banner from '../assets/img/new-web/banner-img.gif';

import openall from '../assets/img/new-web/open-all.svg';
import buysell from '../assets/img/new-web/buying-selling.svg';
import verification from '../assets/img/new-web/verification.svg';
import search from '../assets/img/new-web/search.svg';
import opportunities from '../assets/img/new-web/opportunities.svg';
import tag from '../assets/img/new-web/price-tag.svg';
import manage from '../assets/img/new-web/manage-multiple.svg';
import member from '../assets/img/new-web/member.svg';
import share from '../assets/img/new-web/share.svg';
import quote from '../assets/img/new-web/quote.svg';

import ReactPlayer from 'react-player';
import { IonRow, IonCol, IonSlide, IonSlides, IonVirtualScroll, IonInfiniteScroll, IonInfiniteScrollContent } from '@ionic/react';
import { Link } from 'react-router-dom';
import MetaTage from '../components/common/MetaTage';
import MetaTagProperties from '../properties/MetaTagProperties';
import { useTranslation } from 'react-i18next';

const slideOpts = {
  initialSlide: 0,
  slidesPerView: 1,
  getActiveIndex: 2,
  speed: 400,
  loop: true,
  autoplay: true
};
const HomeStatic = () => {
  const { t } = useTranslation();
  const divRef = useRef();
  const [exhibition, setExhibition] = useState([]);

  const scriptData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Zyapaar',
    url: window.location.href,
    logo: 'https://zyapaar-image-test.s3.ap-south-1.amazonaws.com/1652873326512_zyapaar.png',
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: '+91 9106194889',
      contactType: 'Customer Care'
    },
    sameAs: [
      'https://www.linkedin.com/company/78295060',
      'https://www.facebook.com/Zyapaar-103699905374860',
      'https://instagram.com/zyapaar?igshid=YmMyMTA2M2Y='
    ]

  };
  const schemaData = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'Zyapaar',
    url: window.location.href,
    potentialAction: [{
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: 'https://www.zyapaar.com/{search_term_string}'
      },
      'query-input': 'required name=search_term_string'
    }, {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: 'android-app://com.zyapaar/https/mobile.zyapaar.com/search/?q={search_term_string}'
      },
      'query-input': 'required name=search_term_string'
    }]

  };
  const softwareApplicationData = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: 'zyapaar- B2B Networking App',
    operatingSystem: 'ANDROID',
    applicationCategory: 'Business Service',
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '4.9',
      ratingCount: '5'
    },
    offers: {
      '@type': 'Offer',
      price: '0.00',
      priceCurrency: 'INR'
    }

  };
  const dateComparison = (date) => {
    const currentData = new Date();
    const enddate = new Date(date);
    const UsFormatter = new Intl.DateTimeFormat('en-US');
    if (enddate >= new Date(UsFormatter.format(currentData))) {
      return true;
    }
    return false;
  };
  useEffect(async() => {
    const response = await fetch('https://zyapaar-final--1---ga4-default-rtdb.firebaseio.com/exhibitionDetails.json');
    const exhibitionDetails = await response.json();
    setExhibition(exhibitionDetails.response);
  }, []);

  return (
    <>
    <script type="application/ld+json">{JSON.stringify(scriptData)}</script>
    <script type="application/ld+json">{JSON.stringify(schemaData)}</script>
    <script type="application/ld+json">{JSON.stringify(softwareApplicationData)}</script>
      <MetaTage metaDetails ={MetaTagProperties.home}/>

      <div className='web-pages-before mainhomepage'>
        {/* banner part */}
        <section className="banner pt-4">
          <div className="container">
            <IonRow className="align-items-center banner-content">
              <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='align-items-center justify-content-flex-start'>
                <h1 className='w-100 mt-0'>
                {/* Find New Buyers, Sell More.<br></br> Buy From New Suppliers, Save Cost. */}
                Find new Buyers, Sell more.<br></br> Buy from new Suppliers, Save cost.
                </h1>
                <div className='py-3 w-100 banner-subtext'>
                Connect with Buyers, Suppliers, Traders, Service <br></br>
                  Providers from across Country.
                </div>
                <div className='pb-5'>
                {/* It's Completely Free! */}
                  <p className='pb-3'></p>
                  <Link className='btn-login text-nowrap font-bold' to='/login'> Start Free Service </Link>
                </div>
                <div className='dwn-app-btn'>
                  <p>Download Now</p>
                  <a className='btn-login text-nowrap d-inline-block' href='https://apps.apple.com/in/app/zyapaar-b2b-networking-app/id1622370449' target='_blank' rel="noopener noreferrer"><img src={IosApp} alt='App Store' /></a>
                  <a className='btn-login text-nowrap d-inline-block' href='https://play.google.com/store/apps/details?id=com.zyapaar.mobile' target='_blank' rel="noopener noreferrer"><img src={AndroidApp} alt='Play Store' /></a>
                </div>
              </IonCol>
              <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='d-flex align-items-center justfy-mobile-center justify-lg-content-end'>
              <img src={banner} alt='Main Banner' className="d-lg-block" />
              </IonCol>
            </IonRow>
          </div>
        </section>

        {/* compant content part */}

        <section className='section-space company-text'>
          <div className="container text-center">
            Welcome to Zyapaar, the ultimate Business &amp; Networking Platform. <br></br>
            {/* Create your Product Catalogue, manage your multiple Businesses , Post your Buy-Sell requirements &amp; Close deals in Seconds. */}
            Create Product Catalogue, Post your Buy-Sell requirements, Connect with similar businesses &amp; Close deals in Seconds.
          </div>
        </section>

        {/* Steps section */}
        <section className='section-space spets-bg'>
          <div className="container">
            <div className='subheader-title'>Start selling in few steps</div>
            <IonRow>
              <IonCol sizeMd='4' sizeSm='12' sizeXs='12' className='align-items-center justify-content-flex-start  text-center px-sm-4 m-bottom-space'>
                <div className=''>
                  <img src={register} alt='Register on Zyapaar' height={210} />
                </div>
                <div className='step-title'>
                  Register on Zyapaar
                </div>
                <div className='step-content'>
                  Register with  your mobile number,
                  fill up entity details don't forget to enter what you buy &amp; what you sell.
                </div>
              </IonCol>

              <IonCol sizeMd='4' sizeSm='12' sizeXs='12' className='align-items-center justify-content-flex-start  text-center px-sm-4 m-bottom-space'>
                <div className=''>
                  <img src={buildnetwork} alt='Build your Network' height={210} />
                </div>
                <div className='step-title'>
                  Build your Network
                </div>
                <div className='step-content'>
                  Connect with people/businesses from our connection Suggestions or Search people/businesses you want to connect with.
                </div>
              </IonCol>

              <IonCol sizeMd='4' sizeSm='12' sizeXs='12' className='align-items-center justify-content-flex-start  text-center px-sm-4'>
                <div className=''>
                  <img src={starttrade} alt='Start your Trade' height={210} />
                </div>
                <div className='step-title'>
                  Start your Trade
                </div>
                <div className='step-content'>
                  Post buy or sell requirements. <br /> Submit your offer by commenting on other Zyapaari's post.
                </div>
              </IonCol>
            </IonRow>
          </div>
        </section>

        {/* Video */}
        <section className='section-space video-section'>
          <div className="container text-center">

            <IonRow>
              <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='align-items-center justify-content-flex-start video-player m-bottom-space'>
                <ReactPlayer
                  // width="100%"
                  // height="100%"
                  playing
                  // playIcon={<button>Play</button>}
                  light={thumb}
                  controls={true}
                  url='https://zyapaar-image-test.s3.ap-south-1.amazonaws.com/zyapaarvideo.mp4'
                  config={{ file: { attributes: { controlsList: 'nodownload' } } }}
                />
              </IonCol>

              <IonCol sizeMd='6' sizeSm='12' sizeXs='12' className='text-left justify-content-flex-start'>
                <h1>India's first B2B Networking Platform For Buyers, Suppliers &amp; Service Providers.</h1>
                <div className='digital-con'>Give your business Digital Identity, Create your Catalogue, connect with Businesses from across India &amp; grow your Business.</div>
              </IonCol>
            </IonRow>
          </div>
        </section>

        {/* ======= Network ======= */}
        <section className="section-space network-section" >
          <div className="container">
            <div className='subheader-title'>Join India's First B2B Networking Platform</div>
            <IonRow className="align-items-center">
              <IonCol sizeSm='3' sizeXs='6' className='align-items-center d-flex justify-content-center py-5'>
                <div className='text-center'>
                  <div className='network-icon'>
                    <img src={seller} alt='Seller' />
                  </div>
                  <div className='network-title'>
                    Seller
                    <p>12000+</p>
                  </div>
                </div>
              </IonCol>

              <IonCol sizeSm='3' sizeXs='6' className='align-items-center d-flex justify-content-center py-5'>
                <div className='text-center'>
                  <div className='network-icon'>
                    <img src={buyer} alt={t('appproperties.text33')} />
                  </div>
                  <div className='network-title'>
                    {t('appproperties.text33')}
                    <p>8000+</p>
                  </div>
                </div>
              </IonCol>

              <IonCol sizeSm='3' sizeXs='6' className='align-items-center d-flex justify-content-center py-5'>
                <div className='text-center'>
                  <div className='network-icon'>
                    <img src={product} alt='Products' />
                  </div>
                  <div className='network-title'>
                    Products
                    <p>170000+</p>
                  </div>
                </div>
              </IonCol>

              <IonCol sizeSm='3' sizeXs='6' className='align-items-center d-flex justify-content-center py-5'>
                <div className='text-center'>
                  <div className='network-icon'>
                    <img src={download} alt='Download' />
                  </div>
                  <div className='network-title'>
                    Download
                    <p>20000+</p>
                  </div>
                </div>
              </IonCol>
            </IonRow>

          <div className='text-center network-reg'>
            <Link to='/login' className='btn-login'>Register</Link>
          </div>

          </div>
        </section>
        {/* Services */}

        <section className="section-space services-part">
          <div className="container">
            <div className='subheader-title'>Why  Choose Zyapaar?</div>
            <IonRow className="">
              <IonCol sizeMd='4' sizeSm='6' sizeXs='6' className='d-flex justify-content-center'>
                <div className='text-center service-padding'>
                  <div><img src={openall} alt='Open for all' /></div>
                  <div className='service-title'>Open for all</div>
                </div>
              </IonCol>
              <IonCol sizeMd='4' sizeSm='6' sizeXs='6' className='d-flex justify-content-center'>
                <div className='text-center service-padding'>
                  <div><img src={buysell} alt='Abundant Buying, selling, service and Gig worker leads' /></div>
                  <div className='service-title'>Abundant Buying, selling, service and Gig worker leads</div>
                </div>
              </IonCol>
              <IonCol sizeMd='4' sizeSm='6' sizeXs='6' className='d-flex justify-content-center'>
                <div className='text-center service-padding'>
                  <div><img src={verification} alt='Strict verification criteria' /></div>
                  <div className='service-title'>Strict verification criteria</div>
                </div>
              </IonCol>
              <IonCol sizeMd='4' sizeSm='6' sizeXs='6' className='d-flex justify-content-center'>
                <div className='text-center service-padding'>
                  <div><img src={search} alt='Company, People, Product available on Search' /></div>
                  <div className='service-title'>Company, People, Product available on Search</div>
                </div>
              </IonCol>
              <IonCol sizeMd='4' sizeSm='6' sizeXs='6' className='d-flex justify-content-center'>
                <div className='text-center service-padding'>
                  <div><img src={opportunities} alt='Equal opportunities' /></div>
                  <div className='service-title'>Equal opportunities</div>
                </div>
              </IonCol>
              <IonCol sizeMd='4' sizeSm='6' sizeXs='6' className='d-flex justify-content-center'>
                <div className='text-center service-padding'>
                  <div><img src={tag} alt='Advantage of competitive prices' /></div>
                  <div className='service-title'>Advantage of competitive prices</div>
                </div>
              </IonCol>
              <IonCol sizeMd='4' sizeSm='6' sizeXs='6' className='d-flex justify-content-center'>
                <div className='text-center service-padding'>
                  <div><img src={manage} alt='Manage Multiple Business from one Account' /></div>
                  <div className='service-title'>Manage Multiple Business from one Account</div>
                </div>
              </IonCol>
              <IonCol sizeMd='4' sizeSm='6' sizeXs='6' className='d-flex justify-content-center'>
                <div className='text-center service-padding'>
                  <div><img src={member} alt='Delegate tasks to Team Members' /></div>
                  <div className='service-title'>Delegate tasks to Team Members</div>
                </div>
              </IonCol>
              <IonCol sizeMd='4' sizeSm='6' sizeXs='6' className='d-flex justify-content-center'>
                <div className='text-center service-padding'>
                  <div><img src={share} alt='Social media sharing options' /></div>
                  <div className='service-title'>Social media sharing options</div>
                </div>
              </IonCol>
            </IonRow>
          </div>
        </section>

        {/* Testimonials */}
        <section className="section-space testimonials-part">
          <div className="container">
            <div className='subheader-title'>What Zyapaaris say,</div>
            <div><img src={quote} alt='What Zyapaaris say' /></div>

            <IonSlides pager={true} options={slideOpts} className='d-flex ion-justify-content-center ion-align-items-center'>

                    <IonSlide className='flex-column'>
                        <div className='text-left mb-5'>
                            <div className='testimonials-text my-4'>We are using Zyapaar for a month now and in our opinion it is the best B2B Networking platform.  one gets to connect with verified users and can post project designs and requirements.  We are building good network of new suppliers for our projects using the platform</div>
                            <span className=''>
                            <p>Chintal Mehta, Design Director</p>
                            Chintal Design Studio,
                            </span>
                        </div>
                    </IonSlide>
                    <IonSlide className='flex-column'>
                    <div className='text-left mb-5'>
                            <div className='testimonials-text my-4'>Zyapaar is coming up as go to platform of Indian
									businesses. It is providing a platform for business to
									network . It is helping us go to new markets &amp; buyers
									as well as put up our buy requirements. We are really
									happy using the platform and have strongly
									recommend it toall our suppliers to use the services</div>
                            <span className=''>
                            <p>Hiren Parikh, Managing	Director</p>
                            Jarun Pharmaceuticals Pvt Ltd,
                            </span>
                        </div>
                    </IonSlide>
                    <IonSlide className='flex-column lastslide'>
                    <div className='text-left mb-5'>
                            <div className='testimonials-text my-4'>I have been member of many networking groups and
									platforms but Zyapaar is one the best and easiest to use B2B networking platform.
									Also, they have unique features like verified users and team function which
									sets them apart from all other similar platforms.</div>
                            <span className=''>
                            <p>Saurin Shah, Managing Director</p>
                            Globizz Synergy Pvt Ltd,
                            </span>
                        </div>
                    </IonSlide>
                </IonSlides>

          </div>
        </section>

        {/* Exhibition */}
        <section className="section-space exhibition-part">
          <div className="container">
            <div className='subheader-title'>Upcoming Exhibition</div>
            <IonRow className='exhibition-boxes'>

              {
                exhibition.slice(0, 4).map((details) => {
                  return (
                    <>
                    {dateComparison(details.enddate)
                      ? <div className='exhibition-box'>
                   <div className='exhibition-clr pb-3'>
                   <div className='exhi-details pt-4  text-center exhi-logo'>
                      <img src={`https://www.tender247.com/${details.ImageName}`}/>
                    </div>
                   <div className='exhi-logo-title pt-2 text-center'>{details.ExhibitionName}</div>
                   <div className='exhi-details pt-5  text-center'> {details.startdate} {details.enddate}</div>
                   <div className='exhi-logo-title pt-2 text-center'>{details.CityName},{details.StateName},{details.CountryName}</div>
                   <div className='exhi-details pt-5  text-center'>
                   <a href={details.URL} target="_blank" rel="noreferrer" >{details.URL}</a></div>
                   <div className='exhi-logo-title pt-2 text-center'>  {details.Description}</div>
                  </div>
                   </div>
                      : ''}
                      </>

                  );
                })
              }
            </IonRow>

            <IonRow className=''>
              <IonCol className='d-flex justify-content-end pt-3'>
                <Link className='btn-login text-nowrap d-inline-block' to='/content/exhibition'>{t('commonproperties.text3')}</Link>
              </IonCol>
            </IonRow>

          </div>
        </section>
      </div>

    </>
  );
};
export default HomeStatic;
