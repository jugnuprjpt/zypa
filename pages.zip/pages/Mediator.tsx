import { useHistory, useParams } from 'react-router';

const Mediator = () => {
  const { idPass, urlName, id } = useParams();
  const history = useHistory();
  if (idPass === '1') {
    history.push('/' + urlName + '/' + id);
  } else {
    history.push('/' + urlName);
  }
  return (
    ''
  );
};
export default Mediator;
