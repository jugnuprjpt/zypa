import { IonRow } from '@ionic/react';
import React from 'react';
import { useParams } from 'react-router';
import Footer from '../components/Layout/Footer';
import SearchFeedsDetails from '../components/searchFeeds/SearchFeedDetails';

const SearchFeeds = () => {
  const { searchValue, searchType } = useParams();
  return (
     <>
     <IonRow className="plane-bg">
      <IonRow className="container searchfeed-heading">
          <SearchFeedsDetails searchValue = {searchValue} searchType = {searchType}/>
      </IonRow>
    </IonRow>
    <Footer /></>
  );
};
export default SearchFeeds;
