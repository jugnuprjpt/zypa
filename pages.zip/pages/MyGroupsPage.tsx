import {
  IonButton,
  IonCol,
  IonRow
} from '@ionic/react';
import { addCircle } from 'ionicons/icons';
import React from 'react';
import { useTranslation } from 'react-i18next';
import ActivityCard from '../components/common/ActivityCard';
import Notification from '../components/groups/Notification';
import RecentlyAdded from '../components/groups/RecentlyAdded';

const MyGroupsPage = () => {
  const { t } = useTranslation();
  const intrestGroups = [
    {
      key: '1',
      img:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Creative Design Specialists'
    },
    {
      key: '2',
      img:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Design News'
    },
    {
      key: '3',
      img:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Design News'
    },
    {
      key: '4',
      img:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Design News'
    },
    {
      key: '5',
      img:
        'https://i.pinimg.com/564x/31/58/69/315869d23f7bfd166dcec509ba69f19f.jpg',
      name: 'Design News'
    }
  ];
  return (
      <>
        <IonRow className="plane-bg ">
          <IonRow className="container">
            <div className="row full-width-row main-page-content-row">
              <IonCol
                size-lg="4"
                size-md="12"
             size-xs="12"
                className="left-col ion-no-padding"
              >
                 <div className='sidebar-main'>
                <Notification />
                <ActivityCard
              header={t('groupproperties.text28')}
              headerLinkLable={t('commonproperties.text3')}
              headerLink="/test"
              mapData={intrestGroups}
              icon={addCircle}
              className="sidebar-pages"
            />
            </div>
              </IonCol>
              <IonCol
                size-lg="8"
                size-md="12"
                size-xs="12"
                className="right-col ion-no-padding"
              >
                <h3><b className="ion-padding-start ion-padding-top"> {t('groupproperties.text27')}</b></h3>
                <IonRow>
                  <IonCol size="3">
                    {/* <IonSelect className="popdown-clr input-box" placeholder="RECENTLY ADDED"> </IonSelect> */}
                  </IonCol>
                  <IonButton
                    className="ion-button-color header-row-margin-left ion-padding-end"
                  >
                    {t('groupproperties.text1')}
                  </IonButton>
                </IonRow>
                <RecentlyAdded />
              </IonCol>
            </div>
          </IonRow>
        </IonRow>
      </>
  );
};
export default MyGroupsPage;
