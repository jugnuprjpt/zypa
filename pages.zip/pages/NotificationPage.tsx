import { IonRow } from '@ionic/react';
import React from 'react';
import NotificationDetails from '../components/Notification/NotificationDetails';
import MetaTags from 'react-meta-tags';

const NotificationPage = () => {
  return (
    <><MetaTags>
      <title>
        Zyapaar
      </title>
    </MetaTags><IonRow className="plane-bg">
        <IonRow className="container">
          <NotificationDetails />
        </IonRow>
      </IonRow>
      </>
  );
};
export default NotificationPage;
