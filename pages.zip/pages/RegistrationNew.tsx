import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCol,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonRow,
  IonSlide,
  IonSlides
} from '@ionic/react';
import React, { useEffect, useState } from 'react';
import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { getlocalStore, setLocalStore, setUserSession } from '../util/Common';
import LoginSlider1 from '../assets/img/get-started/slider-1.svg';
import LoginSlider2 from '../assets/img/get-started/slider-2.svg';
import LoginSlider3 from '../assets/img/get-started/slider-3.svg';
import AsyncSelect from 'react-select/async';
import PopoverCommon from '../components/common/PopoverCommon';
import callFor from '../util/CallFor';
import { useHistory } from 'react-router';
import MetaTags from 'react-meta-tags';
import GetRegisteredId from '../components/common/pushNotification/GetRegisteredId';
import { Device } from '@capacitor/device';
import ToastCommon from '../components/common/ToastCommon';
import { logoFacebook, logoInstagram, logoLinkedin, logoYoutube } from 'ionicons/icons';
import CustomeFirebaseEvent from '../components/common/CustomFirebaseEvent';
import { useTranslation } from 'react-i18next';

const slideOpts = {
  initialSlide: 0,
  slidesPerView: 1,
  loop: true,
  speed: 400,
  autoplay: {
    delay: 4000
  }
};

const RegistrationNew = () => {
  const { t } = useTranslation();
  const [formState, setformState] = useState({
    mobileNo: getlocalStore('mobileNo')
  });
  const [saveDisabled, setSaveDisabled] = useState(false);
  const [deviceInfo, setDeviceInfo] = useState();
  const [showToastMsg, setShowToastMsg] = useState('');
  const [showToast, setShowToast] = useState(false);
  useEffect(async() => {
    setDeviceInfo(await Device.getInfo());
  }, []);

  const customStyles = {
    control: (provided: any) => ({
      ...provided,
      minHeight: 50,
      zIndex: 9999,
      fontSize: '14px',
      background: '#fff !important',
      '&:focus': {
        border: '1px solid #d8d8d8'
      }
    }),
    multiValue: (styles, { data }) => {
      return {
        ...styles,
        padding: 4,
        backgroundColor: '#0073ae!important',
        borderRadius: '50px'
      };
    },
    multiValueLabel: (styles, { data }) => ({
      ...styles,
      color: '#fff'
    }),
    multiValueRemove: (styles, { data }) => ({
      ...styles,
      color: '#0073ae!important',
      borderRadius: '50px',
      margin: 3,
      backgroundColor: 'rgba(255, 255, 255, 0.7)',
      ':hover': {
        backgroundColor: '#fff'
      }

    }),
    indicatorSeparator: () => { }, // removes the "stick"
    dropdownIndicator: (defaultStyles: any) => ({
      ...defaultStyles,
      '& svg': { display: 'none' }
    })
  };

  const validationSchema = Yup.object().shape({
    firstName: Yup.string()
      .trim()
      .required(t('commonproperties.text10'))
      .matches(/^[A-Za-z-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text14'),
        (val) => val && val.toString().length <= 50
      ),
    lastName: Yup.string()
      .trim()
      .required(t('commonproperties.text11'))
      .matches(/^[A-Za-z-\s]+$/, t('commonproperties.text4'))
      .test(
        'len',
        t('commonproperties.text13'),
        (val) => val && val.toString().length >= 2
      )
      .test(
        'len',
        t('commonproperties.text14'),
        (val) => val && val.toString().length <= 50
      ),
    emailId: Yup.string().trim().email(t('commonproperties.text9')),
    sales: Yup.array()
      .min(1, t('commonproperties.text36'))
      .of(
        Yup.object().shape({
          label: Yup.string().required(),
          value: Yup.string().required()
        })
      )
      .nullable()
      .required(t('commonproperties.text36'))
  });

  const history = useHistory();
  const promiseOptions = (inputValue: string) =>
    new Promise<any>((resolve) => {
      resolve(selectProducts(inputValue.trim()));
    });

  const selectProducts = async(inputValue: string) => {
    let productLists = [];
    if (inputValue.length >= 3) {
      const productsRes = await callFor(
        'api/v1.1/searches/products/' + inputValue,
        'GET',
        null,
        'registrationWithAuth'
      );
      if (productsRes.status === 200) {
        const json1Response = await productsRes.json();
        productLists = await json1Response.data.map(
          (d: { id: any; keyword: any }) => ({
            value: d.id,
            label: d.keyword
          })
        );
      } else if (productsRes.status === 401) {
        localStorage.clear();
        history.push('/login');
      }
    }
    return productLists;
  };
  const {
    register,
    handleSubmit,
    setError,
    resetField,
    control,
    formState: { errors, isValid }
  } = useForm({
    resolver: yupResolver(validationSchema),
    criteriaMode: 'all',
    reValidateMode: 'onTouched',
    mode: 'onChange'
  });
  console.log(isValid);
  const submitHandler = async(event: any) => {
    setSaveDisabled(true);
    let prodcustlist = null;
    const productsd = document.getElementsByName('sales');
    if (productsd.length > 0) {
      const sell = [];
      for (let i = 0; i < productsd.length; i++) {
        sell.push(productsd[i].value);
      }
      prodcustlist = sell;
    }

    let firstname = '';
    let emailId = '';
    let lastName = '';

    if (formState.firstName !== undefined && formState.firstName !== null) {
      firstname = formState.firstName.trim();
      formState.firstName = firstname;
    }
    if (formState.lastName !== undefined && formState.lastName !== null) {
      lastName = formState.lastName.trim();
      formState.lastName = lastName;
    }
    if (formState.emailId !== undefined && formState.emailId !== null) {
      emailId = formState.emailId.trim();
      formState.emailId = emailId;
    }
    const companyData = {
      firstName: formState.firstName,
      sales: prodcustlist,
      lastName: formState.lastName,
      emailId: formState.emailId,
      mobileNo: getlocalStore('mobileNo')
    };
    const data = JSON.stringify(companyData);
    const response = await callFor(
      'api/v1.1/users/' + getlocalStore('mobileNo') + '/registration',
      'POST',
      data,
      'registrationWithAuth'
    );
    if (response.status === 200) {
      const datares = await response.json();
      setLocalStore('flag', datares.data.flag);
      setUserSession(datares.data.token);
      GetRegisteredId(deviceInfo, 'Auth');
      CustomeFirebaseEvent('registration_success_user_event', deviceInfo);
      history.push('/home');
    } else if (response.status === 400) {
      const jsonResponse = await response.json();
      if (jsonResponse.error.errors !== null) {
        setError(jsonResponse.error.errors[0].field, {
          message: jsonResponse.error.errors[0].message
        });
      }
      if (jsonResponse.error.errors[0].field === 'mobileNo') {
        setShowToastMsg(jsonResponse.error.errors.message);
        setShowToast(true);
        localStorage.clear();
        setTimeout(() => {
          history.push('/login');
        }, 3000);
      }
    } else if (response.status === 401) {
      CustomeFirebaseEvent('registration_failure_user_event', deviceInfo);
      localStorage.clear();
      history.push('/login');
    } else {
      const datares = await response.json();
      console.log(datares);
      CustomeFirebaseEvent('registration_failure_user_event', deviceInfo);
    }
    setSaveDisabled(false);
  };
  const userformDataChangeHandler = (value, name) => {
    if (value !== undefined && value !== null) {
      setformState({
        ...formState,
        [name]: value
      });
    }
  };
  const resetHandler = (event) => {
    if (event.target.name === 'firstName' && event.target.value === '') {
      resetField('firstName');
    } else if (event.target.name === 'lastName' && event.target.value === '') {
      resetField('lastName');
    } else if (event.target.name === 'emailId' && event.target.value === '') {
      resetField('emailId');
    } else if (event.target.name === 'sales' && event.target.value === '') {
      resetField('sales');
    }
  };
  return (
    <>
      <MetaTags>
        <title>Zyapaar</title>
      </MetaTags>
      <IonRow className="registration h-100 overflow-hidden loginPage">
        <IonCol sizeMd="6" sizeXs="12" className="loginPage p-0">
          <div className="leftpart d-none d-md-block">
            <IonSlides
              pager={true}
              options={slideOpts}
              className="d-flex ion-justify-content-center ion-align-items-center vh-100"
            >
              <IonSlide className="d-block">
                <img src={LoginSlider1} alt="Login Slider" />
                <div className="slider-text mt-4 mt-lg-5 text-white">
                  <h2 className="mb-3 ">Zyada Network</h2>
                  <p>
                    Connect with your industry professionals <br />
                    and entrepreneurs across the india.
                  </p>
                </div>
              </IonSlide>
              <IonSlide className="d-block">
                <img src={LoginSlider2} alt="Login Slider" />
                <div className="slider-text mt-4 mt-lg-5 text-white">
                  <h2 className="mb-3">Zyada Leads</h2>
                  <p>
                    Showcase and promote your products <br />
                    and services to a larger audience.
                  </p>
                </div>
              </IonSlide>
              <IonSlide className="d-block">
                <img src={LoginSlider3} alt="Login Slider" />
                <div className="slider-text mt-4 mt-lg-5 text-white">
                  <h2 className="mb-3">Zyada Business</h2>
                  <p>
                    Grow your business with larger audiences, <br />
                    bigger market presence and specific buyers
                    <br /> and seller requirements.
                  </p>
                </div>
              </IonSlide>
            </IonSlides>
          </div>
          <ul className="circles position-absolute overflow-hidden d-none d-md-block">
            <li />
            <li />
            <li />
            <li />
            <li />
            <li />
            <li />
            <li />
            <li />
            <li />
          </ul>
        </IonCol>
        <IonCol
          sizeMd="6"
          sizeXs="12"
          className="h-100 d-flex p-lg-2 p-0 bg-white rightpart"
        >
          <div className='mobileimg zindex99 d-block d-lg-none w-100 position-absolute'>

            {/* <div className="leftpart">
            <IonSlides
              pager={true}
              options={slideOpts}
              className="d-flex ion-justify-content-center ion-align-items-center h-100"
            >
              <IonSlide className="d-block mb-5">
                <img src={LoginSlider1} alt="Login Slider" />
                <div className="slider-text mt-lg-5 text-white">
                  <h2 className="m-0  text-white">Zyada Network</h2>
                  <p>
                    Connect with your industry professionals <br />
                    and entrepreneurs across the india.
                  </p>
                </div>
              </IonSlide>
              <IonSlide className="d-block">
                <img src={LoginSlider2} alt="Login Slider" />
                <div className="slider-text mt-lg-5 text-white">
                  <h2 className="m-0  text-white">Zyada Leads</h2>
                  <p>
                    Showcase and promote your products <br />
                    and services to a larger audience.
                  </p>
                </div>
              </IonSlide>
              <IonSlide className="d-block">
                <img src={LoginSlider3} alt="Login Slider" />
                <div className="slider-text mt-lg-5 text-white">
                  <h2 className="m-0  text-white">Zyada Business</h2>
                  <p>
                    Grow your business with larger audiences, <br />
                    bigger market presence and specific buyers
                    <br /> and seller requirements.
                  </p>
                </div>
              </IonSlide>
            </IonSlides>
          </div> */}
            <ul className="circles position-absolute overflow-hidden d-none d-md-block">
              <li />
              <li />
              <li />
              <li />
              <li />
              <li />
              <li />
              <li />
              <li />
              <li />
            </ul>
          </div>
          <IonCard className="shadow-none w-lg-75 w-xl-50 mx-auto my-lg-auto mt-lg-auto mt-0 w-100 border-0">
            <h1 className="text-center mt-5 mt-lg-0 mb-lg-5 mb-4 position-relative">
            {t('logregproperties.text6')}
            </h1>
            <IonCardContent className="mb-lg-4 pt-4 px-lg-1 h-lg-auto">
              <form
                data-testid="form-submit"
                noValidate
                autoComplete="off"
                onSubmit={handleSubmit(submitHandler)}
              >
                <IonRow className="full-width-row">
                  <IonCol
                    className="input-label-box mb-2 mb-lg-0"
                    size-md="12"
                    size-xs="12"
                  >
                    <IonItem
                      className={
                        errors.firstName
                          ? 'error-border form-group input-label-box position-relative pt-0'
                          : 'form-group input-label-box position-relative pt-0'
                      }
                    >
                      <IonLabel position="floating">
                        {' '}
                        {t('commonproperties.text5')} <sup>*</sup>{' '}
                      </IonLabel>
                      <Controller
                        name="firstName"
                        control={control}
                        defaultValue=""
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonInput
                            type="text"
                            autocomplete="off"
                            {...field}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              userformDataChangeHandler(value, name);
                            }}
                            onClick={resetHandler}
                            placeholder=""
                            className="input-box"
                            id="firstName"
                            data-testid="firstName"
                            {...register('firstName')}
                          />
                        )}
                      />
                    </IonItem>
                    <span
                      className={errors.firstName ? 'error input-error registration-error' : ''}
                    >
                      {errors.firstName?.message}
                    </span>
                  </IonCol>
                  <IonCol
                    className="input-label-box mb-2 mb-lg-0"
                    size-md="12"
                    size-xs="12"
                  >
                    <IonItem
                      className={
                        errors.lastName
                          ? 'error-border form-group input-label-box position-relative pt-0'
                          : 'form-group input-label-box position-relative pt-0'
                      }
                    >
                      <IonLabel position="floating">
                        {' '}
                        {t('commonproperties.text6')} <sup>*</sup>
                      </IonLabel>
                      <Controller
                        name="lastName"
                        control={control}
                        defaultValue=""
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonInput
                            type="text"
                            autocomplete="off"
                            {...field}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              userformDataChangeHandler(value, name);
                            }}
                            onClick={resetHandler}
                            data-testid="lastName"
                            placeholder=""
                            className="input-box"
                            id="lastName"
                            {...register('lastName')}
                          />
                        )}
                      />

                    </IonItem>
                    <span className={errors.lastName ? 'error input-error registration-error' : ''}>
                      {errors.lastName?.message}
                    </span>
                  </IonCol>
                  <IonCol
                    className="input-label-box mb-2 mb-lg-0"
                    size-md="12"
                    size-xs="12"
                  >
                    <IonItem
                      className={
                        errors.emailId
                          ? 'error-border form-group input-label-box position-relative pt-0'
                          : 'form-group input-label-box position-relative pt-0'
                      }
                    >
                      <IonLabel position="floating">{t('userproperties.text7')}</IonLabel>
                      <Controller
                        name="emailId"
                        control={control}
                        defaultValue=""
                        render={({ field: { value, onChange, ...field } }) => (
                          <IonInput
                            type="text"
                            autocomplete="off"
                            {...field}
                            onIonChange={({ target: { value, name } }) => {
                              onChange(value);
                              userformDataChangeHandler(value, name);
                            }}
                            onClick={resetHandler}
                            data-testid="emailId"
                            placeholder=""
                            className="input-box"
                            id="emailId"
                            {...register('emailId')}
                          />
                        )}
                      />
                    </IonItem>
                    <span className={errors.emailId ? 'error input-error registration-error' : ''}>
                      {errors.emailId?.message}
                    </span>
                  </IonCol>
                  <IonCol size-md="12" size-xs="12" className="pt-0">
                    <div className="inner-title show-tooltip">
                      <p className="colo-grey">
                      {t('commonproperties.text7')}<sup>*</sup>
                      </p>
                      <div className="position-relative tooltip-zyapaar">
                        <PopoverCommon
                          className="tooltip-zyapaar"
                          Description="Input all products you sell so that we can help you connect with buyers of your products. We have made it very simple for you-name your products and select from our drop down!"
                        />
                      </div>
                    </div>
                    <Controller
                      name="sales"
                      control={control}
                      render={({ field }) => (
                        <AsyncSelect
                          {...field}
                          autocomplete="off"
                          type="text"
                          isMulti
                          className={
                            errors.sales
                              ? 'error-border selectOption moreimp border'
                              : 'selectOption moreimp'
                          }
                          placeholder={<div className="select-placeholder-text">{t('logregproperties.text5')}</div>}
                          styles={customStyles}
                          loadOptions={promiseOptions}
                          id="sales"
                          menuPlacement="top"
                          components={{ LoadingIndicator: null }}
                          menuPosition="absolute"
                        // noOptionsMessage={() => {t('nodatafound.text11')}}
                        />
                      )}
                    />
                    <p className={errors.sales ? 'error' : ''}>
                      {errors.sales?.message}
                    </p>
                  </IonCol>
                </IonRow>
                <IonRow className="mt-lg-4 mt-4 pt-lg-4 pt-0">

                </IonRow>
                <IonCol>
                    <div className="ion-text-center mb-4">
                      <IonButton
                        disabled={saveDisabled || !isValid}
                        type="submit"
                        size="large"
                        className="ion-button-color w-100 register-save d-block pe-0"
                      >
                        Register
                        {saveDisabled
                          ? (
                            <span className="loader" id="loader-2">
                              <span></span>
                              <span></span>
                              <span></span>
                            </span>
                            )
                          : (
                              ''
                            )}
                      </IonButton>
                    </div>
                  </IonCol>
              </form>
            </IonCardContent>
            <IonRow className="d-block d-lg-none text-center">
              <ul className="mb-0 d-flex ion-align-items-center ion-justify-content-around social-links">
                <li>
                  <a href="https://www.facebook.com/zyapaar/" target='_blank' rel="noopener noreferrer" className="text-decoration-none">
                    <IonIcon icon={logoFacebook} className='facebook' />
                  </a>
                </li>
                <li>
                  <a href="https://instagram.com/zyapaar?igshid=YmMyMTA2M2Y=" target='_blank' rel="noopener noreferrer" className="text-decoration-none">
                    <IonIcon icon={logoInstagram} className='instagram' />
                  </a>
                </li>
                <li>
                  <a href="https://www.linkedin.com/company/lets-talk-business-pvt-ltd" rel="noopener noreferrer" target='_blank' className="text-decoration-none">
                    <IonIcon icon={logoLinkedin} className='linkedin' />
                  </a>
                </li>
                <li>
                  <a href="https://www.youtube.com/channel/UCqXoM4Olk8UyxwEGVialg6g" target='_blank' rel="noopener noreferrer" className="text-decoration-none">
                    <IonIcon icon={logoYoutube} className='youtube' />
                  </a>
                </li>
              </ul>
              <p className='mb-0 copyright'>Copyright © 2022. Lets Talk Business Pvt. Ltd. <br />All rights reserved.</p>
            </IonRow>
          </IonCard>
        </IonCol>
      </IonRow>
      <ToastCommon
        setShowToast={setShowToast}
        setShowToastMsg={setShowToastMsg}
        showToast={showToast}
        showToastMsg={showToastMsg}
        duration={5000}
      />
    </>
  );
};
export default RegistrationNew;
