import { IonAvatar, IonCol, IonIcon, IonRow } from '@ionic/react';
import { arrowBackCircleSharp, chatbox, eyeOutline, send } from 'ionicons/icons';
import React from 'react';
import reellike from '../assets/img/icons/reel-like.png';
import reel from '../assets/img/reels.png';
import DemoJson from '../components/ReelsDemo/DemoJson'
import DuplicateCard from '../components/ReelsDemo/DuplicateCard'
import FeedCommon from '../components/common/FeedCard'
import FeedCard from '../components/common/FeedCard'
import feeds from '../Redux/reducers/feeds';



const Reels = (props) => {
  return (
    <>
   <FeedCard />
 
    <FeedCommon />
      <IonRow className='d-flex h-100 reelsMain'>
        <IonCol className='d-flex ion-align-items-center w-100 p-0'>
          {/* <img src={reel} alt="Reel Image" className='w-100' /> */}
          <div className="app_videos">
        {
          DemoJson.map(({channel,avatarSrc,song,url,likes,shares}, i)=>(

            <DuplicateCard 
            key={i}
            channel={channel}
            avatarSrc={avatarSrc}
            song= {song}
            url={url}
            likes={likes}
            shares={shares}
            />
            ))} 
      </div> 
        
        </IonCol>
        <div className='color-white font-30 ms-1 mt-2 position-absolute cursor-pointer'>
        <IonIcon
        icon={arrowBackCircleSharp}
       />
      </div>
      <IonCol className='d-flex justify-content-between position-absolute w-100 px-2 bottom0 p-0'>
        <div className='color-white reelcontent position-absolute'>
          <h4 className='font-17 mb-1 m-0 p-0'>Shubham Dholaria</h4>
          <p className='fixed-textline1 w-75 mb-1'>Which devices does the counter</p>
          <p>Read more</p>
          <div className='d-flex reelviews justfy-mobile-center mt-1'>
          <IonIcon icon={eyeOutline} size='small' className='color-white font-24' />
          <span className='ps-1 font-12'>5159</span>
          </div>
        </div>

        <div className='position-absolute right10 zindex9 text-center reelicon'>
          <IonAvatar className='mb-3'>
          <img src={reel} />
          </IonAvatar>
          <div className='pb-3'>
            <IonIcon icon={send} className='color-white share-icon font-20'/>
            <p className='color-white font-12'>Share</p>
          </div>
          <div className='pb-3'>
            <img src={reellike} width='20'/>
            <p className='color-white'>101</p>
          </div>
          <div className='pb-3'>
            <IonIcon icon={chatbox} className='color-white font-22' />
            <p className='color-white'>05</p>
          </div>
        </div>
        </IonCol>
      </IonRow>
    </>
  );
};
export default Reels;
