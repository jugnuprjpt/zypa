import changeNumber from './LikeCommentShare'

import {combineReducers} from 'redux'

const rootReducer = combineReducers ({
      changeNumber
});

export default rootReducer;