export const LIKE = "LIKE"
export const COMMENT = "COMMENT"
export const SHARE = "SHARE"
export const FOLLOW = "FOLLOW"
