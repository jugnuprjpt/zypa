
const DemoJson = [
{
    id:0,
    channel:"jugnu",
    avatarSrc:"https://mui.com/static/images/avatar/1.jpg",
    song:"welcome to zyapar",
    url:"https://zprod-post.s3.ap-south-1.amazonaws.com/1655488825121_VID-20220614-WA0003.mp4",
    likes:20,
    shares:40
},
{
    id:1,
    channel:"Arjun",
    avatarSrc:"https://mui.com/static/images/avatar/1.jpg",
    song:"product new",
    url:"https://zyapaar-image-test.s3.ap-south-1.amazonaws.com/zyapaarvideo.mp4",
    likes:10,
    shares:30
},
{
    id:2,
    channel:"prachi",
    avatarSrc:"https://mui.com/static/images/avatar/1.jpg",
    song:"zyda vyapar zyda munafa",
    url:"https://zprod-post.s3.ap-south-1.amazonaws.com/1663240705890_Blue%20and%20White%20Modern%20Benefit%20Whey%20Protein%20Instagram%20post.mp4",
    likes:50,
    shares:60
},
{
    id:3,
    channel:"mohini",
    avatarSrc:"https://mui.com/static/images/avatar/1.jpg",
    song:"zyada bharosa zyda paisa",
    url:"https://zprod-post.s3.ap-south-1.amazonaws.com/1662284417691_trim.50D4667B-4C48-4843-A7EB-BF8D18CBA2CE.MOV",
    likes:80,
    shares:100
},
{
    id:4,
    channel:"Kishan",
    avatarSrc:"https://mui.com/static/images/avatar/1.jpg",
    song:"abhi to party sharu hue hai",
    url:"https://zprod-post.s3.ap-south-1.amazonaws.com/1662716316927_VID-20220621-WA0001.mp4",
    likes:25,
    shares:45
},
{
    id:5,
    channel:"siddharth",
    avatarSrc:"https://mui.com/static/images/avatar/1.jpg",
    song:"welcome to new feature",
    url:"https://zprod-post.s3.ap-south-1.amazonaws.com/1662716385720_VID-20220617-WA0007.mp4",
    likes:35,
    shares:55
}

]

export default DemoJson;